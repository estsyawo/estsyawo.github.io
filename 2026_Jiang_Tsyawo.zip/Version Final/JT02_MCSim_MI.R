#===============================================================================
# Author: Feiyu Jiang & Emmanuel Selorm Tsyawo
# Project: A Consistent ICM-based X2 Specification Test
# Date began:   Feb 03, 2022
# Last Update:  Nov 12, 2025
# Place:        Shanghai & Tuscaloosa  
#===============================================================================
# Load packages, clear memory,
rm(list=ls())
library(MASS)
library(parallel)
library(pbapply)
library(estrpac) #install from github using devtools::install_github("estsyawo/estrpac")
library(ivreg)
library(latex2exp)
library(ggplot2)
#set working directory path to source file
#setwd(dirname(rstudioapi::getActiveDocumentContext()$path))
project_dir <- normalizePath(getwd())
output_dir <- file.path(project_dir, "output")
if (!dir.exists(output_dir)) dir.create(output_dir, recursive = TRUE)
#===============================================================================
#Notes: 
# 1. Running time: 
# 2. Peak RAM usage: 
#===============================================================================

#===============================================================================
# Comments: 
# Computes the size and power of the pivotal chi-squared specification test
# compared to the multiplier and wild bootstrap procedures using the Gaussian
# and the negative Euclidean Kernels
#===============================================================================
# Set Parameters
R = 1000 # set number of simulations
B=999 # number of wild bootstrap samples
levls = c(0.10,0.05,0.01) #nominal levels of the test
nvec=c(200,400,600,800) #sample sizes
gamvec=seq(0,1,by=0.2) #tuning the deviation away from the null
Sig.X = 0.25^as.matrix(dist(1:5)) #covariance matrix for generating instruments
Sig.U = 0.25^as.matrix(dist(1:2)) #covariance matrix for 1st & 2nd stage 
bet = rep(0,ncol(Sig.X)) #vector of coefficients on X
eta = rep(1,ncol(Sig.X)) #vector of coefficients on transforms of Z
#generate auxiliary variables for the bootstrap; n=400 fixed
wmat400=wmat.mammen(n=nvec[2],B=B,seed = 2)
Kernels=c("Gauss","Euclid") # ICM kernels to consider
cl = floor(2*detectCores()/3) #number of cores to use in parallel computation
#===============================================================================
source("JT05_Fonctions.R")
source("JT06_Fonctions_Sim.R")
list.files()
#===============================================================================
start.time<- Sys.time()
#===============================================================================


#===============================================================================
# *** Compute Expirical Size - Exogeneity *** 

MCOBJ.Gauss_1=MCOBJ.Euclid_1=list()
# ------------------------- Compute Size

cat("Compute Size - DGP MI 1 \n ")

set.seed(0)
for (l in 1:length(nvec)) {
  #generate data
  datl_1 =gdat1(n=nvec[l],gam = 0.0)
  #generate auxiliary variables for the bootstrap
  wmat=wmat.mammen(nvec[l],B,seed = l)
  
  #--------------------------------------
  #results for the Gaussian kernel
  MCOBJ.Gauss_1[[l]]=pbsapply(1:R,MCfun.type.MI,datl=datl_1,cl=cl,wmat=wmat,
                              Kern = "Gauss")
  cat("Kern=Gauss, n = ",nvec[l],"\n")
  print(apply(MCOBJ.Gauss_1[[l]],1,mean)); cat("\n")
  #--------------------------------------
  #results for the Euclidean kernel - Shao & Zhang 2014
  MCOBJ.Euclid_1[[l]]=pbsapply(1:R,MCfun.type.MI,datl=datl_1,cl=cl,wmat=wmat,
                               Kern = "Euclid")
  cat("Kern=Euclid, n = ",nvec[l],"\n")
  print(apply(MCOBJ.Euclid_1[[l]],1,mean)); cat("\n")
}
#===============================================================================


#===============================================================================
# *** Compute Power Curve under local alternatives *** 

MCOBJ.Gauss_2lp=MCOBJ.Euclid_2lp=list()
# ------------------------- Compute Size

cat("Compute Curve - DGP MI 2 - local alternatives \n ")

set.seed(0)
for (l in 1:length(nvec)) {
  #generate data
  datl_2lp =gdat2(n=nvec[l],gam = 1.0/sqrt(nvec[l]))
  #generate auxiliary variables for the bootstrap
  wmat=wmat.mammen(nvec[l],B,seed = l)
  
  #--------------------------------------
  #results for the Gaussian kernel
  MCOBJ.Gauss_2lp[[l]]=pbsapply(1:R,MCfun.type.MI,datl=datl_2lp,cl=cl,wmat=wmat,
                                Kern = "Gauss")
  cat("Kern=Gauss, n = ",nvec[l],"\n")
  print(apply(MCOBJ.Gauss_2lp[[l]],1,mean)); cat("\n")
  #--------------------------------------
  #results for the Euclidean kernel - Shao & Zhang 2014
  MCOBJ.Euclid_2lp[[l]]=pbsapply(1:R,MCfun.type.MI,datl=datl_2lp,cl=cl,wmat=wmat,
                                 Kern = "Euclid")
  cat("Kern=Euclid, n = ",nvec[l],"\n")
  print(apply(MCOBJ.Euclid_2lp[[l]],1,mean)); cat("\n")
}
#===============================================================================


#===============================================================================
# *** Compute Power Curve Using Design 2 above ***

MCOBJ.Gauss_2p=MCOBJ.Euclid_2p=list()
# ------------------------- Compute Power

cat("Compute Power Curve - DGP MI 2 - fixed alternative \n ")

for (l in 1:length(gamvec)) {
  #generate data
  datl_2p =gdat2(n=nvec[2],gam = (1/5)*gamvec[l]); 
  
  #--------------------------------------
  #results for the Gaussian kernel
  MCOBJ.Gauss_2p[[l]]=pbsapply(1:R,MCfun.type.MI,datl=datl_2p,cl=cl,wmat=wmat400,
                               Kern = "Gauss")
  cat("Kern=Gauss, gamma = ",gamvec[l],"\n")
  print(apply(MCOBJ.Gauss_2p[[l]],1,mean)); cat("\n")
  #--------------------------------------
  #results for the Euclidean kernel - Shao & Zhang 2014
  MCOBJ.Euclid_2p[[l]]=pbsapply(1:R,MCfun.type.MI,datl=datl_2p,cl=cl,wmat=wmat400,
                                Kern = "Euclid")
  cat("Kern=Euclid, gamma = ",gamvec[l],"\n")
  print(apply(MCOBJ.Euclid_2p[[l]],1,mean)); cat("\n")
}
#===============================================================================


#===============================================================================
# *** Compute Power Curve under high frequency alternatives *** 

MCOBJ.Gauss_3p=MCOBJ.Euclid_3p=list()
# ------------------------- Compute Power

cat("Compute Power Curve - DGP MI 3 - High-frequency alternatives \n ")

for (l in 1:length(gamvec)) {
  #generate data
  datl_3p =gdat3(n=nvec[2],gam = gamvec[l]); 
  
  #--------------------------------------
  #results for the Gaussian kernel
  MCOBJ.Gauss_3p[[l]]=pbsapply(1:R,MCfun.type.MI,datl=datl_3p,cl=cl,wmat=wmat400,
                               Kern = "Gauss")
  cat("Kern=Gauss, gamma = ",gamvec[l],"\n")
  print(apply(MCOBJ.Gauss_3p[[l]],1,mean)); cat("\n")
  #--------------------------------------
  #results for the Euclidean kernel - Shao & Zhang 2014
  MCOBJ.Euclid_3p[[l]]=pbsapply(1:R,MCfun.type.MI,datl=datl_3p,cl=cl,wmat=wmat400,
                                Kern = "Euclid")
  cat("Kern=Euclid, gamma = ",gamvec[l],"\n")
  print(apply(MCOBJ.Euclid_3p[[l]],1,mean)); cat("\n")
}
#===============================================================================


#===============================================================================
# *** Compute Power Curve with alternatives in mind for the chi-squared test *** 

MCOBJ.Gauss_4p=MCOBJ.Euclid_4p=list()

# ------------------------- Compute Power

cat("Compute Power Curve - DGP MI 4 - targeting alternatives \n ")

for (l in 1:length(gamvec)) {
  #generate data
  datl_4p =gdat4(n=nvec[2],gam = gamvec[l]); 
  
  #--------------------------------------
  #results for the Gaussian kernel
  MCOBJ.Gauss_4p[[l]]=pbsapply(1:R,MCfun.type.MI,datl=datl_4p,cl=cl,wmat=wmat400,
                               Kern = "Gauss")
  cat("Kern=Gauss, gamma = ",gamvec[l],"\n")
  print(apply(MCOBJ.Gauss_4p[[l]],1,mean)); cat("\n")
  #--------------------------------------
  #results for the Euclidean kernel - Shao & Zhang 2014
  MCOBJ.Euclid_4p[[l]]=pbsapply(1:R,MCfun.type.MI,datl=datl_4p,cl=cl,wmat=wmat400,
                                Kern = "Euclid")
  cat("Kern=Euclid, gamma = ",gamvec[l],"\n")
  print(apply(MCOBJ.Euclid_4p[[l]],1,mean)); cat("\n")
}
#===============================================================================


#===============================================================================
# *** Compute Power Curve with alternatives in mind for the chi-squared test *** 

MCOBJ.Gauss_5p=MCOBJ.Euclid_5p=list()

# ------------------------- Compute Power

cat("Compute Power Curve - DGP MI 4 - targeting alternatives \n ")

for (l in 1:length(gamvec)) {
  #generate data
  datl_5p =gdat5(n=nvec[2],gam = gamvec[l]); 
  
  #--------------------------------------
  #results for the Gaussian kernel
  MCOBJ.Gauss_5p[[l]]=pbsapply(1:R,MCfun.type.MI,datl=datl_5p,cl=cl,wmat=wmat400,
                               Kern = "Gauss")
  cat("Kern=Gauss, gamma = ",gamvec[l],"\n")
  print(apply(MCOBJ.Gauss_5p[[l]],1,mean)); cat("\n")
  #--------------------------------------
  #results for the Euclidean kernel - Shao & Zhang 2014
  MCOBJ.Euclid_5p[[l]]=pbsapply(1:R,MCfun.type.MI,datl=datl_5p,cl=cl,wmat=wmat400,
                                Kern = "Euclid")
  cat("Kern=Euclid, gamma = ",gamvec[l],"\n")
  print(apply(MCOBJ.Euclid_5p[[l]],1,mean)); cat("\n")
}
#===============================================================================


#===============================================================================
# Write out results for Tex tables
n.test<- 2 #number of tests being compared
n.levels<- length(levls)#number of significance levels being considered

#column ids for empirical size at significance levels 0.1,0.05, and 0.01
id.10 = 1+(0:(n.test-1))*n.levels
id.05 = 2+(0:(n.test-1))*n.levels
id.01 = 3+(0:(n.test-1))*n.levels

#column ids for computational times in seconds
Ts<- c(n.test*n.levels+1, n.test*n.levels + 2 + (0:(n.test-2))*2)
#column ids for computational times relative to the t-test
Trel<- n.test*n.levels+1 + (1:(n.test-1))*2
#--------------------------------------------

#print results for the empirical size, DGP MI 1: Main text
sink(file.path(output_dir, "tab.size.MI_1.txt")) #print to file
print.size.type(MCOBJ1 = MCOBJ.Gauss_1,
                MCOBJ2 = MCOBJ.Euclid_1,id=c(id.10,id.05,id.01),
                Kernels=Kernels)
sink()

#print results for computational time, DGP MI 1; Main text
sink(file.path(output_dir, "tab.comp_time.MI_1.txt")) #print to file
print.time.type(MCOBJ1 = MCOBJ.Gauss_1,
                MCOBJ2 = MCOBJ.Euclid_1,id1=Ts,id2=Trel,
                Kernels=Kernels)
sink()

#print results for local power, DGP MI 3; Main text
sink(file.path(output_dir, "tab.loc_pow.MI_2.txt")) #print to file
print.size.type(MCOBJ1 = MCOBJ.Gauss_2lp,
                MCOBJ2 = MCOBJ.Euclid_2lp,id=c(id.10,id.05,id.01),
                Kernels=Kernels)
sink()


#--------------------------------------------
#print power curves (check working directory for files)
#-----------------------

# plot power curve, DGP MI 2
plot.pow2(MCOBJ=MCOBJ.Gauss_2p,id=c(id.10,id.05,id.01),
          filename=file.path(output_dir, "PCMI_Gauss_2"))
plot.pow2(MCOBJ=MCOBJ.Euclid_2p,id=c(id.10,id.05,id.01),
          filename=file.path(output_dir, "PCMI_Euclid_2"))

# plot power curve, DGP MI 3
plot.pow2(MCOBJ=MCOBJ.Gauss_3p,id=c(id.10,id.05,id.01),
          filename=file.path(output_dir, "PCMI_Gauss_3"))
plot.pow2(MCOBJ=MCOBJ.Euclid_3p,id=c(id.10,id.05,id.01),
          filename=file.path(output_dir, "PCMI_Euclid_3"))

# plot power curve, DGP MI 4
plot.pow2(MCOBJ=MCOBJ.Gauss_4p,id=c(id.10,id.05,id.01),
          filename=file.path(output_dir, "PCMI_Gauss_4"))
plot.pow2(MCOBJ=MCOBJ.Euclid_4p,id=c(id.10,id.05,id.01),
          filename=file.path(output_dir, "PCMI_Euclid_4"))

# plot power curve, DGP MI 5
plot.pow2(MCOBJ=MCOBJ.Gauss_5p,id=c(id.10,id.05,id.01),
          filename=file.path(output_dir, "PCMI_Gauss_5"))
plot.pow2(MCOBJ=MCOBJ.Euclid_5p,id=c(id.10,id.05,id.01),
          filename=file.path(output_dir, "PCMI_Euclid_5"))
#===============================================================================

cat("See the output folder for output tables and plots \n ")

#===============================================================================
end.time<- Sys.time()
print(end.time-start.time)
#===============================================================================
