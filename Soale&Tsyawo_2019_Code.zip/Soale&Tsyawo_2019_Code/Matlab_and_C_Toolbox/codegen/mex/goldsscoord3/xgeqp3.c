/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * xgeqp3.c
 *
 * Code generation for function 'xgeqp3'
 *
 */

/* Include files */
#include "mwmathutil.h"
#include "rt_nonfinite.h"
#include "goldsscoord3.h"
#include "xgeqp3.h"
#include "goldsscoord3_emxutil.h"
#include "error.h"
#include "goldsscoord3_data.h"
#include "lapacke.h"

/* Variable Definitions */
static emlrtRSInfo s_emlrtRSI = { 14,  /* lineNo */
  "xgeqp3",                            /* fcnName */
  "/usr/local/MATLAB/R2018b/toolbox/eml/eml/+coder/+internal/+lapack/xgeqp3.m"/* pathName */
};

static emlrtRSInfo t_emlrtRSI = { 37,  /* lineNo */
  "xgeqp3",                            /* fcnName */
  "/usr/local/MATLAB/R2018b/toolbox/eml/eml/+coder/+internal/+lapack/xgeqp3.m"/* pathName */
};

static emlrtRSInfo u_emlrtRSI = { 38,  /* lineNo */
  "xgeqp3",                            /* fcnName */
  "/usr/local/MATLAB/R2018b/toolbox/eml/eml/+coder/+internal/+lapack/xgeqp3.m"/* pathName */
};

static emlrtRSInfo v_emlrtRSI = { 45,  /* lineNo */
  "xgeqp3",                            /* fcnName */
  "/usr/local/MATLAB/R2018b/toolbox/eml/eml/+coder/+internal/+lapack/xgeqp3.m"/* pathName */
};

static emlrtRSInfo w_emlrtRSI = { 64,  /* lineNo */
  "xgeqp3",                            /* fcnName */
  "/usr/local/MATLAB/R2018b/toolbox/eml/eml/+coder/+internal/+lapack/xgeqp3.m"/* pathName */
};

static emlrtRSInfo x_emlrtRSI = { 67,  /* lineNo */
  "xgeqp3",                            /* fcnName */
  "/usr/local/MATLAB/R2018b/toolbox/eml/eml/+coder/+internal/+lapack/xgeqp3.m"/* pathName */
};

static emlrtRSInfo y_emlrtRSI = { 76,  /* lineNo */
  "xgeqp3",                            /* fcnName */
  "/usr/local/MATLAB/R2018b/toolbox/eml/eml/+coder/+internal/+lapack/xgeqp3.m"/* pathName */
};

static emlrtRTEInfo bc_emlrtRTEI = { 77,/* lineNo */
  9,                                   /* colNo */
  "xgeqp3",                            /* fName */
  "/usr/local/MATLAB/R2018b/toolbox/eml/eml/+coder/+internal/+lapack/xgeqp3.m"/* pName */
};

/* Function Definitions */
void xgeqp3(const emlrtStack *sp, emxArray_real_T *A, real_T tau_data[], int32_T
            tau_size[1], int32_T jpvt[2])
{
  int32_T m;
  int32_T tau_size_tmp;
  ptrdiff_t jpvt_t[2];
  ptrdiff_t m_t;
  ptrdiff_t info_t;
  boolean_T p;
  boolean_T b_p;
  int32_T loop_ub;
  emlrtStack st;
  emlrtStack b_st;
  emlrtStack c_st;
  st.prev = sp;
  st.tls = sp->tls;
  st.site = &s_emlrtRSI;
  b_st.prev = &st;
  b_st.tls = st.tls;
  c_st.prev = &b_st;
  c_st.tls = b_st.tls;
  m = A->size[0];
  b_st.site = &t_emlrtRSI;
  b_st.site = &u_emlrtRSI;
  if (A->size[0] == 0) {
    tau_size[0] = 0;
    jpvt[0] = 1;
    jpvt[1] = 2;
  } else {
    tau_size_tmp = muIntScalarMin_sint32(m, 2);
    tau_size[0] = tau_size_tmp;
    b_st.site = &v_emlrtRSI;
    jpvt_t[0] = (ptrdiff_t)0;
    jpvt_t[1] = (ptrdiff_t)0;
    b_st.site = &w_emlrtRSI;
    m_t = (ptrdiff_t)A->size[0];
    b_st.site = &x_emlrtRSI;
    info_t = LAPACKE_dgeqp3(102, m_t, (ptrdiff_t)2, &A->data[0], m_t, &jpvt_t[0],
      &tau_data[0]);
    m = (int32_T)info_t;
    b_st.site = &y_emlrtRSI;
    if (m != 0) {
      p = true;
      b_p = false;
      if (m == -4) {
        b_p = true;
      }

      if (!b_p) {
        if (m == -1010) {
          c_st.site = &db_emlrtRSI;
          error(&c_st);
        } else {
          c_st.site = &eb_emlrtRSI;
          b_error(&c_st, m);
        }
      }
    } else {
      p = false;
    }

    if (p) {
      m = A->size[0] * A->size[1];
      A->size[1] = 2;
      emxEnsureCapacity_real_T(&st, A, m, &bc_emlrtRTEI);
      loop_ub = A->size[0];
      for (m = 0; m < loop_ub; m++) {
        A->data[m] = rtNaN;
      }

      loop_ub = A->size[0];
      for (m = 0; m < loop_ub; m++) {
        A->data[m + A->size[0]] = rtNaN;
      }

      for (m = 0; m < tau_size_tmp; m++) {
        tau_data[m] = rtNaN;
      }

      jpvt[0] = 1;
      jpvt[1] = 2;
    } else {
      jpvt[0] = (int32_T)jpvt_t[0];
      jpvt[1] = (int32_T)jpvt_t[1];
    }
  }
}

/* End of code generation (xgeqp3.c) */
