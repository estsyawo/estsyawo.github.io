/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 * File: rdivide_helper.c
 *
 * MATLAB Coder version            : 4.1
 * C/C++ source code generated on  : 23-Nov-2018 17:24:14
 */

/* Include Files */
#include "CCRls2.h"
#include "rdivide_helper.h"
#include "CCRls2_emxutil.h"

/* Function Definitions */

/*
 * Arguments    : const emxArray_uint32_T *x
 *                unsigned int y
 *                emxArray_uint32_T *z
 * Return Type  : void
 */
void rdivide_helper(const emxArray_uint32_T *x, unsigned int y,
                    emxArray_uint32_T *z)
{
  int nx;
  int k;
  unsigned int b_z;
  unsigned int b_x;
  nx = z->size[0] * z->size[1];
  z->size[0] = 1;
  z->size[1] = x->size[1];
  emxEnsureCapacity_uint32_T(z, nx);
  nx = x->size[1];
  for (k = 0; k < nx; k++) {
    if (y == 0U) {
      b_z = MAX_uint32_T;
    } else {
      b_z = x->data[k] / y;
    }

    b_x = x->data[k] - b_z * y;
    if ((b_x > 0U) && (b_x >= (y >> 1U) + (y & 1U))) {
      b_z++;
    }

    z->data[k] = b_z;
  }
}

/*
 * File trailer for rdivide_helper.c
 *
 * [EOF]
 */
