/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * ceil.c
 *
 * Code generation for function 'ceil'
 *
 */

/* Include files */
#include "mwmathutil.h"
#include "rt_nonfinite.h"
#include "CCRls.h"
#include "ceil.h"

/* Function Definitions */
void b_ceil(emxArray_real_T *x)
{
  int32_T nx;
  int32_T k;
  nx = x->size[1];
  for (k = 0; k < nx; k++) {
    x->data[k] = muDoubleScalarCeil(x->data[k]);
  }
}

/* End of code generation (ceil.c) */
