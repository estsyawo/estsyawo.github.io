/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * rng.c
 *
 * Code generation for function 'rng'
 *
 */

/* Include files */
#include "rt_nonfinite.h"
#include "goldsscoord.h"
#include "rng.h"
#include "goldsscoord_data.h"

/* Function Definitions */
void rng(void)
{
  uint32_T r;
  int32_T mti;
  r = 1U;
  state[0] = 1U;
  for (mti = 0; mti < 623; mti++) {
    r = ((r ^ r >> 30U) * 1812433253U + mti) + 1U;
    state[mti + 1] = r;
  }

  state[624] = 624U;
}

/* End of code generation (rng.c) */
