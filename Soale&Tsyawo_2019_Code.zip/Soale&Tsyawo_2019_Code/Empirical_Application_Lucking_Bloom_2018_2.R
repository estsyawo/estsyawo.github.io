#=======================================================================================================>
# Emmanuel Selorm Tsyawo
# First update: March 7, 2018
# Last Update:  April 27, 2019
# Philadelphia
#=======================================================================================================>
# Set working directory to source file
rm(list = ls())
setwd(dirname(rstudioapi::getActiveDocumentContext()$path)) 
#set directory to source file

#=======================================================================================================>
# Source functions
source("Functions.R"); source("Functions1.R"); source("CC_Sequential_opt.R")
# for loading stata data sets
library(foreign); library("MASS")
library(sandwich)
#=======================================================================================================>
# load data
dat <- read.dta("rsampleXXX_old.dta"); 

attach(dat); #use data from 1980 to 2015
#=======================================================================================================>
# Construct a balanced panel:
ufirmcode<- sort(num); head(ufirmcode); tail(ufirmcode)
freqfirm<- table(num); 
zz=as.numeric(names(freqfirm))

# Construct a balanced panel
(lyr=length(unique(year))) # 36 years of panel data
fbl<- zz[c(freqfirm)==lyr]; length(fbl) # 254 firms in balanced panel
datr<- dat[dat$num %in%fbl,]; 

vars<- c("lsales", "lgrd1","lgspilltec1", "lgspillsic1","lemp1", "lppent1", "lgrd1_dum", "lsales_ind", 
         "lsales_ind1", "lpind_ind","num","year")
# For benchmark models (OLS)
xvars1 = c("lgspilltec1", "lgspillsic1", "lemp1", "lppent1", "lgrd1", 
           "lgrd1_dum", "lsales_ind", "lsales_ind1", "lpind_ind") 
xvars2 = c("lgspilltec1", "lemp1", "lppent1", "lgrd1", 
           "lgrd1_dum", "lsales_ind", "lsales_ind1", "lpind_ind") 

# For CCR (without lgrd1 - prevent perfect 
# multicollinearity with network design matrix)
xCCR1 = c("lgspilltec1", "lgspillsic1", "lemp1", "lppent1", 
           "lgrd1_dum", "lsales_ind", "lsales_ind1", "lpind_ind") 
# covariates

allvars<- unique(c("lsales","pat_cite",vars,xvars1,xvars2)) # all variables needed for both regressions
allvars

# Detect firms with NAs and low variation in log(R&D) in datr
# Reduce data to firms without missing values. Years 1985-2011 
# Construct balanced panel
rdDat<- datr[allvars]; cnt=k=0; firm_drop<- c(0); fsddrop=c(0); sdvec=mnvec=mxvec=c(0)
for (j in unique(datr$num)) {
  if(any(is.na(rdDat[which(rdDat$num==j & rdDat$year<=2011 & rdDat$year>=1985),]))){
    cnt=cnt+1; firm_drop[cnt]<- j
  }
  if(sd(rdDat$lgrd1[which(rdDat$num==j)],na.rm = TRUE)<0.75){
    k=k+1; fsddrop[k]<- j
  }
}
cnt;firm_drop;k;fsddrop; length(unique(c(firm_drop,fsddrop)))
#cbind(unique(datr$num),sdvec,mnvec,mxvec)[sdvec>=1,]
firm_drop=unique(c(firm_drop,fsddrop)) #subset of firms data set
#firm_drop=unique(firm_drop) #all firms data set
datnet<- rdDat[!rdDat$num%in%firm_drop& rdDat$year<=2011 & rdDat$year>=1985,]
any(is.na(datnet))# final data without NAs set ready for estimation
dim(datnet)
#number of firms in subset data : 52
#=======================================================================================================>
# Replication of results (Lucking & Bloom 2018)

# The following do not exactly replicate results in Lucking & Bloom 2018 because only the 
# balanced panel over the period 1980 to 2011 is used. We expect slightly different results.
#------------------------------------------------------
# Table 4: Productivity equation: Regression (2) - Ordinary Least Squares
# Column (1) - First baseline OLS
reg1<- lm(datnet$lsales~as.matrix(datnet[xvars1])+as.factor(datnet$num)+as.factor(datnet$year),x=TRUE)
summary(reg1)

#compute Newey-West
NWhac1<- sandwich::NeweyWest(reg1,lag = 1,order.by = datnet$year,adjust = TRUE,prewhite = FALSE)
# Use Newey-West heteroskedasticity & autocorrelation-robust and clustered standard errors (see paper)

#Compute standard errors
StdErrs1<- sqrt(diag(NWhac1))

tstats1=reg1$coefficients[1:10]/StdErrs1[1:10]
df1 = nrow(datnet)-length(reg1$coefficients)
pval1 = 2*(1-pt(abs(tstats1),df1))
robj1<- data.frame(round(rbind(reg1$coefficients[1:10],
      StdErrs1[1:10],tstats1,pval1),4))
names(robj1)<- c("Intercept",xvars1)
row.names(robj1)<- c("coefs","stde","tstat","p-val")
robj1
length(reg1$coefficients)-1 #number of covariates
#------------------------------------------------------
# Column (2) - Second baseline OLS without lgspillsic
reg2<- lm(datnet$lsales~as.matrix(datnet[xvars2])+as.factor(datnet$num)+as.factor(datnet$year),x=TRUE)
summary(reg2)

#compute Newey-West
NWhac2<- sandwich::NeweyWest(reg2,lag = 1,order.by = datnet$year,adjust = TRUE,prewhite = FALSE)
# Use Newey-West heteroskedasticity & autocorrelation-robust and clustered standard errors (see paper)
k2 = length(xvars2)+1 
#Compute standard errors
StdErrs2<- sqrt(diag(NWhac2))
tstats2=reg2$coefficients[1:k2]/StdErrs2[1:k2]
df2 = nrow(datnet)-length(reg2$coefficients)
pval2 = 2*(1-pt(abs(tstats2),df2))

robj2<- data.frame(round(rbind(reg2$coefficients[1:k2],
            StdErrs2[1:k2],tstats2,pval2),4))
names(robj2)=c("Intercept",xvars2)
row.names(robj2)<- c("coefs","stde","tstat","p-val")
robj2
# Use heteroskedasticity-robust and clustered standard errors (see paper)
#=======================================================================================================>
# remove unneeded data to free up memory
rm(dat)
rm(datr)
rm(rdDat)
#=======================================================================================================>

# Construct Network design matrix
# Estimation of the productivity equation (Bloom 2013 and Lucking,Bloom, Reenen 2018)

Wi1=c("lgspilltec1", "lgspillsic1", "lemp1", "lppent1",  
      "lgrd1_dum", "lsales_ind", "lsales_ind1", "lpind_ind") # covariates: productivity equation
# Generate network design matrix; note: spillover generating variable is R&D
zag1<- netdat(datf = datnet, Y="lsales", X="lgrd1",Wi=Wi1,
             panvar = "num",tvar = "year",factors = c("num","year"),scaling=FALSE,unicons=FALSE) 

# unicons set to FALSE because of firm fixed effects -  avoid perfect multicollinearity
# Note: high memory requirement

# -------------------------------------------------------------------------------------------->
# Inspect components of network design matrices
names(zag1)
#"Y"    "X"    "Wm"   "Wf"   "sdX": inspect components of zag1 and zag2
length(zag1$Y) #outcome
# 1404 for subset firms # 5859 for all firms
dim(zag1$X) # network design matrix
# 1404 2704 for subset firms # 5859 47089
dim(zag1$Wm) # other covariates
# 1404    8 for subset firms # 5859    8 for all firms
dim(zag1$Wf) # for fixed effects
# 1404   77 for subset firms # 5859  242 for all firms

n=1404 # sample size, 
p=2789 # covariates
p/n # 1.986467 for subset firms # 8.037037 for all firms

#=======================================================================================================>
# Write out outcome and design matrix for estimation in Matlab using the mex function.
# The design matrix is:

datlm<- data.frame(zag1$Y,cbind(1,zag1$Wm,zag1$X,zag1$Wf))
# Note, order of variables: 
# 1. Y - outcome
# 2. 1's for intercept term, 
# 3. Wm - 8 covariates not to cluster
names(zag1$Wm)
# 4. dummies for fixed effects

#write to csv file:
#write.table(datlm,file = "datlm.csv",sep = " ",row.names = FALSE,col.names = FALSE)
#write.table(datlm,file = "datlm_all.csv",sep = " ",row.names = FALSE,col.names = FALSE)

#=======================================================================================================>
clus1<- read.csv(file = "clus1.csv",header = TRUE)
clus2<- read.csv(file = "clus2.csv",header = TRUE)
clus3<- read.csv(file = "clus3.csv",header = TRUE)
# load covariate cluster assignments as .csv file
# See Matlab file Empirical_Application_mex3.m for details
# clusfile - name of .csv clus file
# idnC are indices of variables left unclustered in datlm, excluding intercept
# number of elements not to cluster, including intercept
prepxk<- function(clus,idnC){
  nC = length(idnC)+1
  uniclus<- sort(unique(clus[,1]))
  optk = length(uniclus) #optimal number of clusters
  Xk = matrix(NA,nrow=nrow(datlm),ncol = (optk+nC-1)) #exclude intercept term -1
  if(length(idnC)!=(nC-1)){stop("nC not length of idnC")}
  Xk[,c(1:(nC-1))] = as.matrix(datlm[,idnC])
  XX = as.matrix(datlm[,-c(1:max(idnC))]) # are outcome & covariates not clustered
  #check dimension equality
  XX= as.matrix(XX)
  if(nrow(clus)!=ncol(XX)){stop("dimensions do not agree")}
  for (j in 1:optk) {
    cID = which(clus[,1]==uniclus[j])
    if(length(cID)>1){
      Xk[,(nC+j-1)] = apply(XX[,cID], 1, sum)
    }else{
      Xk[,(nC+j-1)] = XX[,cID]
    }
  }
  
  print(paste("Any NAs in Xk ?",any(is.na(Xk))))
  return(Xk)
}

# Run CCR regressions
#===============================================================================>
# Column 3 - without Bloom's Spilltech & Spillsic
list.files()
idnC3 = 5:10
Xk3=prepxk(clus=clus1,idnC=idnC3)
 #non-clustered covariates of interest
regnet3<- lm(datlm$zag1.Y~Xk3) #lgspillsic1 is the second column in Xk
#compute Newey-West
NWhacnet3<- sandwich::NeweyWest(regnet3,lag = 1,order.by = datnet$year,
                               adjust = TRUE,prewhite = FALSE)
# Use Newey-West heteroskedasticity & autocorrelation-robust and clustered standard errors (see paper)
#Compute standard errors
StdErrsnet3<- sqrt(diag(NWhacnet3))

tstatsnet3=regnet3$coefficients/StdErrsnet3
dfnet3 = nrow(datlm)-length(regnet3$coefficients)
pvalnet3 = 2*(1-pt(abs(tstatsnet3),dfnet3))

objCCR3=data.frame(round(rbind(regnet3$coefficients[1:8],
                              StdErrsnet3[1:8],tstatsnet3[1:8],pvalnet3[1:8]),4))

names(objCCR3)=c("Intercept",names(datlm)[5:10])
row.names(objCCR3)<- c("coefficients", "Stder","tstat","pval")
objCCR3
#------------------------------------------------------------------>
# Column (4) -  with Bloom's Spilltech
idnC4 = c(3,5:10)
Xk4=prepxk(clus=clus2,idnC= idnC4)
#non-clustered covariates of interest
regnet4<- lm(datlm$zag1.Y~Xk4) #lgspillsic1 is the second column in Xk
#compute Newey-West
NWhacnet4<- sandwich::NeweyWest(regnet4,lag = 1,order.by = datnet$year,
                                adjust = TRUE,prewhite = FALSE)
# Use Newey-West heteroskedasticity & autocorrelation-robust and clustered standard errors (see paper)
#Compute standard errors
StdErrsnet4<- sqrt(diag(NWhacnet4))

tstatsnet4=regnet4$coefficients/StdErrsnet4
dfnet4 = nrow(datlm)-length(regnet4$coefficients)
pvalnet4 = 2*(1-pt(abs(tstatsnet4),dfnet4))

objCCR4=data.frame(round(rbind(regnet4$coefficients[1:8],
                               StdErrsnet4[1:8],tstatsnet4[1:8],pvalnet4[1:8]),4))

names(objCCR4)=c("Intercept",names(datlm)[c(3,5:10)])
row.names(objCCR4)<- c("coefficients", "Stder","tstat","pval")
objCCR4
#------------------------------------------------------------------>
# Column (5) -  with Bloom's Spilltech & Spillsic
idnC5 = c(3:10)
Xk5=prepxk(clus=clus3,idnC=c(3:10))
regnet5<- lm(datlm$zag1.Y~Xk5)
#compute Newey-West
NWhacnet5<- sandwich::NeweyWest(regnet5,lag = 1,order.by = datnet$year,
                                adjust = TRUE,prewhite = FALSE)
# Use Newey-West heteroskedasticity & autocorrelation-robust and clustered standard errors (see paper)
#Compute standard errors
StdErrsnet5<- sqrt(diag(NWhacnet5))

tstatsnet5=regnet5$coefficients/StdErrsnet5
dfnet5 = nrow(datlm)-length(regnet5$coefficients)
pvalnet5 = 2*(1-pt(abs(tstatsnet5),dfnet5))

objCCR5=data.frame(round(rbind(regnet5$coefficients[1:9],
                               StdErrsnet5[1:9],tstatsnet5[1:9],pvalnet5[1:9]),4))

names(objCCR5)=c("Intercept",names(datlm)[3:10])
row.names(objCCR5)<- c("coefficients", "Stder","tstat","pval")
objCCR5
#------------------------------------------------------------------>

#===========================================================================================>
#----------------------------------------------
# This function maps a vector of unique clusters to coefficients 
# and corresponding coefficient indices.
# Arguments:
#           1. clusvec - cluster vector of interest; must be at most length of clus
#           2. clus - estimated cluster vector of all clustered parameters
#           3. nC - number of non-clustered covariates; these come first
# Output:   a list of the following 3 elements
#           1. idpar - indices of parameters delta corresponding to unique clusvec (unicv)
#           2. unicv - sorted unique elements in clusvec
#           3. freq - cluster sizes corresponding to uclusvec

parclus<- function(clusvec,clus,nC){
  ncv = length(clusvec)
  frqidpar=table(clusvec)
  uclusvec = as.numeric(names(frqidpar))
  uclus = sort(unique(clus)) #keep line as in prepxk()
  nucv = length(uclusvec)
  idpar<- rep(NA,nucv)
  for (j in 1:nucv) {
    idj = nC+which(uclus==uclusvec[j])
    idpar[j]=idj
  }
  ans=list(idpar,uclusvec,unname(frqidpar))
  names(ans)<- c("idpar","unicv","freq")
  ans
}

#----------------------------------------------
# This function returns estimates of Average effects (mean parameter values) 
# with standard errors, t-stats, and p-values
# Arguments: 
#           1. parobj - an output object from parclus()
#           2. vcmat - the variance covariance matrix extracted from input regobj
#           3. regobj - the regression object that runs on reduced space xm
# Output:   a list of the following 4 elements
#           1. mnAE - average effect (averaged parameter value)
#           2. seAE - standard error of mnAE
#           3. tstat - t-statistics
#           4. pval - p-value

AECCR<- function(parobj,vcmat,regobj){
  nU = length(parobj$idpar)
  pars=matrix(regobj$coefficients[parobj$idpar]*parobj$freq,ncol = 1)
  vc=diag(parobj$freq)%*%vcmat[parobj$idpar,parobj$idpar]%*%diag(parobj$freq)
  projccr = matrix(1,nrow = 1,ncol = nU)
  mnAE = (projccr%*%pars)/sum(parobj$freq)
  seAE = sqrt(projccr%*%vc%*%t(projccr)/(sum(parobj$freq)^2))
  tstat = mnAE/seAE
  pval = 2*(1-pt(abs(tstat),regobj$df.residual))
  list(mnAE=mnAE,seAE=seAE,tstat=tstat,pval=pval)
}

#===========================================================================================>
# Analysis of private, spillover, and social effects

nF = nrow(datlm)/27 #number of firms in the sample
names(zag1)
dim(zag1$X) #2704 columns in the network design matrix; we're concerned about the first
# 2704 elements of the clus vectors

#---------------------------------------------------------------------------
# Column (3)

# Private effect 
clusPE3 = rep(NA,nF)
for (i in 1:nF) {
  clusPE3[i] = clus1[(i-1)*nF+i,1]
}

parobPE3=parclus(clusvec = clusPE3,clus = c(clus1[,1]),nC=length(idnC3)+1) #+1 for the intercept
lapply(AECCR(parobj = parobPE3,vcmat = NWhacnet3,regobj = regnet3),round,4)


# Spillover effect
clusSpill3 = rep(NA,nF*(nF-1))
cnt = 0
for (i in 1:nF) {
  for (j in 1:nF) {
    if(j!=i){
      cnt = cnt+1
      clusSpill3[cnt] = clus1[(j-1)*nF+i,1]
    }
  }
}
any(is.na(clusSpill3)) #checking

parobSpillE3=parclus(clusvec = clusSpill3,clus = c(clus1[,1]),nC=length(idnC3)+1) #+1 for the intercept
lapply(AECCR(parobj = parobSpillE3,vcmat = NWhacnet3,regobj = regnet3),round,4)


# Social effects
clusSoc3 = clus1[1:(nF^2),1]

parobSoc3=parclus(clusvec = clusSoc3,clus = c(clus1[,1]),nC=length(idnC3)+1) #+1 for the intercept
lapply(AECCR(parobj = parobSoc3,vcmat = NWhacnet3,regobj = regnet3),round,4)


#---------------------------------------------------------------------------


#---------------------------------------------------------------------------
# Column (4)

# Private effect 
clusPE4 = rep(NA,nF)
for (i in 1:nF) {
  clusPE4[i] = clus2[(i-1)*nF+i,1]
}

parobPE4=parclus(clusvec = clusPE4,clus = c(clus2[,1]),nC=length(idnC4)+1) #+1 for the intercept
lapply(AECCR(parobj = parobPE4,vcmat = NWhacnet4,regobj = regnet4),round,4)


# Spillover effect
clusSpill4 = rep(NA,nF*(nF-1))
cnt = 0
for (i in 1:nF) {
  for (j in 1:nF) {
    if(j!=i){
      cnt = cnt+1
      clusSpill4[cnt] = clus2[(j-1)*nF+i,1]
    }
  }
}
any(is.na(clusSpill4)) #checking

parobSpillE4=parclus(clusvec = clusSpill4,clus = c(clus2[,1]),nC=length(idnC4)+1) #+1 for the intercept
lapply(AECCR(parobj = parobSpillE4,vcmat = NWhacnet4,regobj = regnet4),round,4)


# Social effects
clusSoc4 = clus2[1:(nF^2),1]

parobSoc4=parclus(clusvec = clusSoc4,clus = c(clus2[,1]),nC=length(idnC4)+1) #+1 for the intercept
lapply(AECCR(parobj = parobSoc4,vcmat = NWhacnet4,regobj = regnet4),round,4)

#---------------------------------------------------------------------------
# Column (5)

# Private effect 
clusPE5 = rep(NA,nF)
for (i in 1:nF) {
  clusPE5[i] = clus3[(i-1)*nF+i,1]
}

parobPE5=parclus(clusvec = clusPE5,clus = c(clus3[,1]),nC=length(idnC5)+1) #+1 for the intercept
lapply(AECCR(parobj = parobPE5,vcmat = NWhacnet5,regobj = regnet5),round,4)


# Spillover effect
clusSpill5 = rep(NA,nF*(nF-1))
cnt = 0
for (i in 1:nF) {
  for (j in 1:nF) {
    if(j!=i){
      cnt = cnt+1
      clusSpill5[cnt] = clus3[(j-1)*nF+i,1]
    }
  }
}
any(is.na(clusSpill5)) #checking

parobSpillE5=parclus(clusvec = clusSpill5,clus = c(clus3[,1]),nC=length(idnC5)+1) #+1 for the intercept
lapply(AECCR(parobj = parobSpillE5,vcmat = NWhacnet5,regobj = regnet5),round,4)


# Social effects
clusSoc5 = clus3[1:(nF^2),1]

parobSoc5=parclus(clusvec = clusSoc5,clus = c(clus3[,1]),nC=length(idnC5)+1) #+1 for the intercept
lapply(AECCR(parobj = parobSoc5,vcmat = NWhacnet5,regobj = regnet5),round,4)
#---------------------------------------------------------------------------

# Extract number of clusters:
length(unique(clus1[,1]))
length(unique(clus2[,1]))
length(unique(clus3[,1]))
