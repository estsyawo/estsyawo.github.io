#===============================================================================
rm(list=ls()) #clear memory
setwd(dirname(rstudioapi::getActiveDocumentContext()$path)) #set working directory
#path to source file
#===============================================================================
#load packages
library(cluscov)
library(mvtnorm)
library(fastDummies)
library(pbapply)
library(glmnet)
library(hdme)
library(sandwich) 
library(pracma)
library(ggplot2)
library(latex2exp)
source("Funktionen.R") #source functions from file
#===============================================================================
#Notes: 
# 1. Running time: 20 hours
# 2. Peak RAM usage: about 15 GB
# 3. Parallel computation on: 4 cores
#===============================================================================

start.time<- Sys.time()

#===============================================================================
#Set parameters
R = 1000 #number of Monte Carlo replications
p.vec<- c(75,150)
n.vec<- c(100,400)
h.vec<- seq(0,0.4,length.out=5)
rho<- 0.5
#===============================================================================

#--------------------------------------------------------
#Main Text
#--------------------------------------------------------
#-- DGP CnS: Continuous-non-Sparse beta0 with chi^2 error
MCobj.CnS=gen.sim.res(Config="CnS",n.vec,p.vec,R=R,dist.eps="chisq")
print.res.file(MCobj.list=MCobj.CnS,n.vec,p.vec,outfile="Out_1.Cns.txt")
#--------------------------------------------------------

#--------------------------------------------------------
#-- DGP CaS1: Continuous-approximately-Sparse beta0 with chi^2 error
MCobj.CaS1=gen.sim.res(Config="CaS1",n.vec,p.vec,R=R,dist.eps="chisq")
print.res.file(MCobj.list=MCobj.CaS1,n.vec,p.vec,outfile="Out_2.CaS1.txt")
#--------------------------------------------------------

#--------------------------------------------------------
#-- DGP CaS2: Continuous-approximately-Sparse beta0 with normal error
MCobj.CaS2=gen.sim.res(Config="CaS2",n.vec,p.vec,R=R,dist.eps="normal")
print.res.file(MCobj.list=MCobj.CaS2,n.vec,p.vec,outfile="Out_3.CaS2.txt")
#--------------------------------------------------------

#--------------------------------------------------------
#-- DGP D_S1: Discrete-Sparse beta0 with normal error
MCobj.D_S1=gen.sim.res(Config="D_S1",n.vec,p.vec,R=R,dist.eps="normal")
print.res.file(MCobj.list=MCobj.D_S1,n.vec,p.vec,outfile="Out_4.D_S1.txt")
#--------------------------------------------------------

#--------------------------------------------------------
#Online Appendix
#--------------------------------------------------------
#-- DGP MnS: Mixed-non-Sparse beta0 with chi^2 error
MCobj.MnS=gen.sim.res(Config="MnS",n.vec,p.vec,R=R,dist.eps="chisq")
print.res.file(MCobj.list=MCobj.MnS,n.vec,p.vec,outfile="Out_5.MnS.txt")
#--------------------------------------------------------

#--------------------------------------------------------
#-- DGP MnS: Mixed-Sparse beta0 with chi^2 error
MCobj.M_S=gen.sim.res(Config="M_S",n.vec,p.vec,R=R,dist.eps="chisq")
print.res.file(MCobj.list=MCobj.M_S,n.vec,p.vec,outfile="Out_6.M_S.txt")
#--------------------------------------------------------

#--------------------------------------------------------
#-- DGP DnS: Discrete-non-Sparse beta0 with normal error
MCobj.DnS=gen.sim.res(Config="DnS",n.vec,p.vec,R=R,dist.eps="normal")
print.res.file(MCobj.list=MCobj.DnS,n.vec,p.vec,outfile="Out_7.DnS.txt")
#--------------------------------------------------------

#--------------------------------------------------------
#-- DGP D_S2: Discrete-Sparse beta0 with normal error
MCobj.D_S2=gen.sim.res(Config="D_S2",n.vec,p.vec,R=R,dist.eps="normal")
print.res.file(MCobj.list=MCobj.D_S2,n.vec,p.vec,outfile="Out_8.D_S2.txt")
#--------------------------------------------------------

#--------------------------------------------------------
#-- DGP DaS2: Discrete-approximately-Sparse beta0 with normal error
MCobj.DaS2=gen.sim.res(Config="DaS2",n.vec,p.vec,R=R,dist.eps="normal")
print.res.file(MCobj.list=MCobj.DaS2,n.vec,p.vec,outfile="Out_9.DaS2.txt")
#--------------------------------------------------------

#===============================================================================



#===============================================================================
#Main Text: Box Plots
group.est <- c(rep("GPE",R), rep("pLASSO",R),rep("pGDS",R),rep("OLS",R),rep("Orac.OLS",R),rep("Orac.GPE",R))
#--------------------------------------------------------
#-----------Box plot: bias CnS
box_plot(MCobj.list=MCobj.CnS,res.type=c("bias","nbias","k")[1],group.est,
         title.name="DGP CnS",out.file="fig.box_CnS.bias.pdf")

#-----------Box plot: nbias CnS
box_plot(MCobj.list=MCobj.CnS,res.type=c("bias","nbias","k")[2],group.est,
         title.name="DGP CnS",out.file="fig.box_CnS.nbias.pdf")

#-----------Box plot: k CnS
box_plot(MCobj.list=MCobj.CnS,res.type=c("bias","nbias","k")[3],group.est,
         title.name="DGP CnS",out.file="fig.box_CnS.k.pdf")
#--------------------------------------------------------

#--------------------------------------------------------
#-----------Box plot: bias CaS1
box_plot(MCobj.list=MCobj.CaS1,res.type=c("bias","nbias","k")[1],group.est,
         title.name=TeX('CaS$_1$'),out.file="fig.box_CaS1.bias.pdf")

#-----------Box plot: nbias CaS1
box_plot(MCobj.list=MCobj.CaS1,res.type=c("bias","nbias","k")[2],group.est,
         title.name=TeX('CaS$_1$'),out.file="fig.box_CaS1.nbias.pdf")

#-----------Box plot: k CaS1
box_plot(MCobj.list=MCobj.CaS1,res.type=c("bias","nbias","k")[3],group.est,
         title.name=TeX('CaS$_1$'),out.file="fig.box_CaS1.k.pdf")
#--------------------------------------------------------


#--------------------------------------------------------
#-----------Box plot: bias CaS2
box_plot(MCobj.list=MCobj.CaS2,res.type=c("bias","nbias","k")[1],group.est,
         title.name=TeX('CaS$_2$'),out.file="fig.box_CaS2.bias.pdf")

#-----------Box plot: nbias CaS2
box_plot(MCobj.list=MCobj.CaS2,res.type=c("bias","nbias","k")[2],group.est,
         title.name=TeX('CaS$_2$'),out.file="fig.box_CaS2.nbias.pdf")

#-----------Box plot: k CaS2
box_plot(MCobj.list=MCobj.CaS2,res.type=c("bias","nbias","k")[3],group.est,
         title.name=TeX('CaS$_2$'),out.file="fig.box_CaS2.k.pdf")
#--------------------------------------------------------


#--------------------------------------------------------
#-----------Box plot: bias D_S1
box_plot(MCobj.list=MCobj.D_S1,res.type=c("bias","nbias","k")[1],group.est,
         title.name=TeX('D-S$_1$'),out.file="fig.box_D_S1.bias.pdf")

#-----------Box plot: nbias D_S1
box_plot(MCobj.list=MCobj.D_S1,res.type=c("bias","nbias","k")[2],group.est,
         title.name=TeX('D-S$_1$'),out.file="fig.box_D_S1.nbias.pdf")

#-----------Box plot: k D_S1
box_plot(MCobj.list=MCobj.D_S1,res.type=c("bias","nbias","k")[3],group.est,
         title.name=TeX('D-S$_1$'),out.file="fig.box_D_S1.k.pdf")
#--------------------------------------------------------


#===============================================================================
# Compute simulation results for power curves
MCobj.pow.CnS=gen.sim.pow(Config="CnS",h.vec=h.vec,n=100,p=75,R=R,dist.eps="chisq")
MCobj.pow.CaS1=gen.sim.pow(Config="CaS1",h.vec=h.vec,n=100,p=75,R=R,dist.eps="chisq")
MCobj.pow.CaS2=gen.sim.pow(Config="CaS2",h.vec=h.vec,n=100,p=75,R=R,dist.eps="normal")
MCobj.pow.D_S1=gen.sim.pow(Config="D_S1",h.vec=h.vec,n=100,p=75,R=R,dist.eps="normal")
#===============================================================================


#===============================================================================
n.h = length(h.vec)
group.Rej <-c(rep("GPE",n.h), rep("pLASSO",n.h),rep("pGDS",n.h),
              rep("OLS",n.h),rep("Orac.OLS",n.h),rep("Orac.GPE",n.h))

pow_plot(powmat=MCobj.pow.CnS,group.Rej,h.vec,title.name="DGP CnS",out.file="fig.pow_CnS.pdf",Legend = T)
pow_plot(powmat=MCobj.pow.CaS1,group.Rej,h.vec,title.name=TeX('CaS$_1$'),out.file="fig.pow_CaS1.pdf",Legend = F)
pow_plot(powmat=MCobj.pow.CaS2,group.Rej,h.vec,title.name=TeX('CaS$_2$'),out.file="fig.pow_CaS2.pdf",Legend = F)
pow_plot(powmat=MCobj.pow.D_S1,group.Rej,h.vec,title.name=TeX('D-S$_1$'),out.file="fig.pow_D_S1.pdf",Legend = F)
#===============================================================================


#===============================================================================
end.time<- Sys.time()
end.time-start.time #Time difference of 4.919239 hours
