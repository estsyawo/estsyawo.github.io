/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * xgeqp3.c
 *
 * Code generation for function 'xgeqp3'
 *
 */

/* Include files */
#include "mwmathutil.h"
#include "rt_nonfinite.h"
#include "CCRls2.h"
#include "xgeqp3.h"
#include "colon.h"
#include "CCRls2_emxutil.h"
#include "CCRls2_data.h"
#include "lapacke.h"

/* Function Definitions */
void b_xgeqp3(emxArray_real_T *A, real_T tau_data[], int32_T tau_size[1],
              emxArray_int32_T *jpvt)
{
  int32_T m;
  int32_T n;
  emxArray_ptrdiff_t *jpvt_t;
  int32_T loop_ub;
  ptrdiff_t m_t;
  ptrdiff_t info_t;
  int32_T b_loop_ub;
  int32_T i7;
  emlrtHeapReferenceStackEnterFcnR2012b(emlrtRootTLSGlobal);
  m = A->size[0];
  n = A->size[1];
  if ((A->size[0] == 0) || (A->size[1] == 0)) {
    tau_size[0] = 0;
    eml_signed_integer_colon(A->size[1], jpvt);
  } else {
    emxInit_ptrdiff_t(&jpvt_t, 1, true);
    tau_size[0] = muIntScalarMin_sint32(m, n);
    m = jpvt_t->size[0];
    jpvt_t->size[0] = A->size[1];
    emxEnsureCapacity_ptrdiff_t(jpvt_t, m);
    loop_ub = A->size[1];
    for (m = 0; m < loop_ub; m++) {
      jpvt_t->data[m] = (ptrdiff_t)0;
    }

    m_t = (ptrdiff_t)A->size[0];
    info_t = LAPACKE_dgeqp3(102, m_t, (ptrdiff_t)A->size[1], &A->data[0], m_t,
      &jpvt_t->data[0], &tau_data[0]);
    if ((int32_T)info_t != 0) {
      m = A->size[0] * A->size[1];
      emxEnsureCapacity_real_T(A, m);
      loop_ub = A->size[1];
      for (m = 0; m < loop_ub; m++) {
        b_loop_ub = A->size[0];
        for (i7 = 0; i7 < b_loop_ub; i7++) {
          A->data[i7 + A->size[0] * m] = rtNaN;
        }
      }

      loop_ub = tau_size[0];
      tau_size[0] = loop_ub;
      for (m = 0; m < loop_ub; m++) {
        tau_data[m] = rtNaN;
      }

      eml_signed_integer_colon(n, jpvt);
    } else {
      m = jpvt->size[0] * jpvt->size[1];
      jpvt->size[0] = 1;
      jpvt->size[1] = jpvt_t->size[0];
      emxEnsureCapacity_int32_T(jpvt, m);
      loop_ub = jpvt_t->size[0];
      for (m = 0; m < loop_ub; m++) {
        jpvt->data[m] = (int32_T)jpvt_t->data[m];
      }
    }

    emxFree_ptrdiff_t(&jpvt_t);
  }

  emlrtHeapReferenceStackLeaveFcnR2012b(emlrtRootTLSGlobal);
}

void xgeqp3(real_T A_data[], int32_T A_size[2], real_T tau_data[], int32_T
            tau_size[1], int32_T jpvt[2])
{
  int32_T loop_ub;
  ptrdiff_t jpvt_t[2];
  ptrdiff_t m_t;
  ptrdiff_t info_t;
  int32_T b_loop_ub;
  int32_T i6;
  if (A_size[0] == 0) {
    tau_size[0] = 0;
    jpvt[0] = 1;
    jpvt[1] = 2;
  } else {
    loop_ub = muIntScalarMin_sint32(A_size[0], 2);
    tau_size[0] = loop_ub;
    jpvt_t[0] = (ptrdiff_t)0;
    jpvt_t[1] = (ptrdiff_t)0;
    m_t = (ptrdiff_t)A_size[0];
    info_t = LAPACKE_dgeqp3(102, m_t, (ptrdiff_t)2, &A_data[0], m_t, &jpvt_t[0],
      &tau_data[0]);
    if ((int32_T)info_t != 0) {
      A_size[1] = 2;
      b_loop_ub = A_size[0];
      for (i6 = 0; i6 < b_loop_ub; i6++) {
        A_data[i6] = rtNaN;
      }

      b_loop_ub = A_size[0];
      for (i6 = 0; i6 < b_loop_ub; i6++) {
        A_data[i6 + A_size[0]] = rtNaN;
      }

      for (i6 = 0; i6 < loop_ub; i6++) {
        tau_data[i6] = rtNaN;
      }

      jpvt[0] = 1;
      jpvt[1] = 2;
    } else {
      jpvt[0] = (int32_T)jpvt_t[0];
      jpvt[1] = (int32_T)jpvt_t[1];
    }
  }
}

/* End of code generation (xgeqp3.c) */
