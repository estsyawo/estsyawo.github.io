#Function File
#=============================================================================>
# Purpose: Computes the observed treated DF and the untreated counterfactual DF
#          for the treated at a single outcome threshold.
# Input: Outcome vector Y, threshold y, treatment indicator D, time indicator t,
#        and link-function choice G.
# Output: Two-column matrix with F11_1 and F01_1 evaluated at y.
DFs.y<- function(Y,y,D,t,G){
  n00 = sum(D==0 & t==0); n01 = sum(D==0 & t==1)
  n10 = sum(D==1 & t==0); n11 = sum(D==1 & t==1)
  if (any(c(n00, n01, n10, n11) == 0)) {
    warning("Empty (D,t) cell encountered; returning NA for counterfactual DF.")
    return(cbind(F11_1 = NA_real_, F01_1 = NA_real_))
  }
  F00 = mean((1*(Y<=y))[D==0&t==0]); F01 = mean((1*(Y<=y))[D==0&t==1])
  F10 = mean((1*(Y<=y))[D==1&t==0]); F11 = mean((1*(Y<=y))[D==1&t==1])
  
  #compute parameters of the counterfactual distribution F_{01|D=1}(y)
  if(G=="logis"){
    G=plogis; Ginv=qlogis
  }else if(G=="normal"){
    G=pnorm; Ginv=qnorm
  }else if(G=="uniform"){
    G=function(x) punif(x, min=0, max=1)
    Ginv=function(tau) qunif(tau, min=0, max=1)
  }else if(G=="identity"){
    G=function(x) x
    Ginv=function(tau) tau
  }else if(G=="Cauchy"){
    G=pcauchy; Ginv=qcauchy
  }else{
    stop("CDF not available; should be logis, normal, uniform, identity, Cauchy or chi2")
  }
  
  #compute alpha_y
  if(Ginv(F00)==Inf){
    alpha_y = Ginv(F00-.Machine$double.eps)
  }else if(Ginv(F00)==-Inf){
    alpha_y = Ginv(F00+.Machine$double.eps)
  }else{
    alpha_y = Ginv(F00)
  }
  #compute beta_y
  if(Ginv(F10)==Inf){
    beta_y = Ginv(F10-.Machine$double.eps) - alpha_y
  }else if(Ginv(F10)==-Inf){
    beta_y = Ginv(F10+.Machine$double.eps) - alpha_y
  }else{
    beta_y = Ginv(F10) - alpha_y
  }
  #compute gamma_y
  if(Ginv(F01)==Inf){
    gamma_y = Ginv(F01-.Machine$double.eps) - alpha_y
  }else if(Ginv(F01)==-Inf){
    gamma_y = Ginv(F01+.Machine$double.eps) - alpha_y
  }else{
    gamma_y = Ginv(F01) - alpha_y
  }
  #compute counterfactual
  F01_1 = G(alpha_y + beta_y + gamma_y)
  #compute treated potential outcome for the treated
  F11_1 = F11
  
  return(cbind(F11_1,F01_1))
}
#=============================================================================>


#=============================================================================>
# Purpose: Applies DFs.y over a grid of outcome values.
# Input: Outcome vector Y, evaluation grid ygrid, treatment indicator D,
#        time indicator t, and link-function choice G.
# Output: Data frame with F11_1 and F01_1 over the full y-grid.
DFs<- function(Y,ygrid,D,t,G="normal"){
  fn=function(l) DFs.y(Y=Y,ygrid[l],D=D,t=t,G=G)
  res=t(sapply(1:length(ygrid),fn))
  ord = order(ygrid)
  res = res[ord, , drop=FALSE]
  res=as.data.frame(res); names(res)=c("F11_1","F01_1")
  res
}
#=============================================================================>


#=============================================================================>
# Purpose: Builds the left-inverse map of a step CDF or empirical distribution.
# Input: Support values ys and corresponding cumulative probabilities Fs.
# Output: Step function that maps probabilities to quantile values.
left.inv <- function(ys, Fs){
  ys <- sort(ys)
  Fs <- sort(Fs)
  iF <- stepfun(Fs, c(ys, max(ys)), right = TRUE)
  return(iF)
}
#=============================================================================>


#=============================================================================>
# Purpose: Computes QTT and DTT objects from a two-period/two-group sample.
# Input: Outcome vector Y, treatment indicator D, time indicator t,
#        link choice G, and optional ygrid and taus.
# Output: Matrix containing quantile functions, QTT, distribution functions,
#         and DTT over the evaluation grid.
QTT_DTT<- function(Y,D,t,G="normal",ygrid=NULL,taus=NULL){
  nu.Y=length(unique(Y))
  if(is.null(taus)){taus=seq(0.05,0.95,length.out=min(c(101,(nu.Y-1))))}
  if(is.null(ygrid)){ygrid=quantile(c(Y),probs = taus,na.rm=T)}
  
  DFobj=DFs(Y=Y,ygrid = ygrid,D=D,t=t,G=G)
  Q11_1.fun = left.inv(ys=ygrid,Fs=DFobj$F11_1); Q11_1=Q11_1.fun(taus)
  Q01_1.fun = left.inv(ys=ygrid,Fs=DFobj$F01_1); Q01_1=Q01_1.fun(taus)
  DTT=DFobj$F11_1-DFobj$F01_1; QTT=Q11_1-Q01_1
  return(cbind(taus,Q11_1,Q01_1,QTT,ygrid,DFobj,DTT))
}
#=============================================================================>

#=============================================================================>
# Purpose: Generates bootstrap replications of the QTT_DTT estimator.
# Input: Outcome vector Y, treatment indicator D, time indicator t,
#        link choice G, grid inputs, bootstrap count B, and optional index matrix id.b.
# Output: List of bootstrap QTT_DTT objects, one per replication.
QTT_DTT.boot = function(Y,D,t,G="normal",ygrid=NULL,taus=NULL,B=999,id.b=NULL){
  N = length(Y)
  if(is.null(id.b)){id.b=matrix(sample(1:N,N*B,replace = T),N,B)}
  qtt_dtt.bootfn<- function(l){QTT_DTT(Y=Y[id.b[,l]],D=D[id.b[,l]],t=t[id.b[,l]],
                                       G=G,ygrid=ygrid,taus=taus)}
  lapply(1:B,qtt_dtt.bootfn)
}
#=============================================================================>

#=============================================================================>
# Purpose: Extracts one function of interest from a list of bootstrap outputs.
# Input: List produced by QTT_DTT.boot and a selector fn equal to "QTT" or "DTT".
# Output: Matrix whose columns are bootstrap draws of the selected function.
extract.fn<-function(bootQttDtt,fn="QTT"){
  R=length(bootQttDtt) #number of bootstrap samples
  res=matrix(NA,nrow = nrow(bootQttDtt[[1]]),ncol = R)
  for(l in 1:R){
    if(fn=="QTT"){
      res[,l]<- bootQttDtt[[l]]$QTT
    }else if(fn=="DTT"){
      res[,l]<- bootQttDtt[[l]]$DTT
    }else{
      stop("function not yet implemented. \n")
    }
  }#end for l
  res
}
#=============================================================================>


#=============================================================================>
# Purpose: Pre-computes scale and supremum objects used in uniform bands.
# Input: Point estimate Fn, bootstrap matrix Boot.Fn, and sample size n.
# Output: List with scale vector Sigv and bootstrap max-statistic vector tbv.
Band.Fn.Objs<- function(Fn,Boot.Fn,n){
  Zbstar = Boot.Fn
  for (j in 1:ncol(Boot.Fn)){Zbstar[,j] = Zbstar[,j] - Fn}
  Zbstar = sqrt(n)*Zbstar
  Sigv = apply(Zbstar,1,IQR)/(qnorm(0.75)-qnorm(0.25))
  
  tbmat = abs(Zbstar)
  for (j in 1:ncol(tbmat)) {tbmat[,j]=tbmat[,j]/Sigv}
  
  tbv = apply(tbmat,2,max)
  list(Sigv=Sigv,tbv=tbv)
}
#=============================================================================>


#=============================================================================>
# Purpose: Builds uniform confidence bands from bootstrap band objects.
# Input: Point estimate Fn, Band.Fn.Objs output BFObjs, confidence level alpha,
#        and sample size n.
# Output: List containing lower and upper uniform confidence bands.
UBand.Fn=function(Fn,BFObjs,alpha=0.05,n){
  LB.Fn = Fn - quantile(c(BFObjs$tbv),1-alpha,na.rm=T)*BFObjs$Sigv/sqrt(n) 
  UB.Fn = Fn + quantile(c(BFObjs$tbv),1-alpha,na.rm=T)*BFObjs$Sigv/sqrt(n)
  list(LB.Fn=sort(LB.Fn), UB.Fn=sort(UB.Fn))
}
#=============================================================================>

#=============================================================================>
# Purpose: Computes the Lp distance between an estimated function and a target.
# Input: Estimated function values est.fn, target values true.fn, and norm order p.
# Output: Scalar Lp error measure.
Lp_norm<- function(est.fn,true.fn,p=2){
  (mean((abs(est.fn-true.fn))^p))^(1/p)
}
#-------------------------------------------------
# Purpose: Computes an Anderson-Darling-style weighted error for distribution functions.
# Input: Estimated DF est.fn, target DF true.fn, and norm order p.
# Output: Scalar weighted discrepancy measure that emphasizes tail behavior.
Lp_norm_A.D<- function(est.fn,true.fn,p=2){
  wgt = sqrt(true.fn*(1-true.fn))
  (median((abs(est.fn-true.fn)/wgt)^p))^(1/p)
}
#=============================================================================>

#=============================================================================>
# Purpose: Runs the Monte Carlo table simulations for the DiD and CiC estimators.
# Input: DGP choice, error distribution settings, simulation parameters,
#        bootstrap settings, output location, and runtime options.
# Output: Matrix of average bias and rejection rates, and optionally a text file in output_dir.
run_sim_table <- function(
  dgp=NULL,
  e_dist="normal",
  e_params=list(),
  outcome_type=c("continuous","discrete"),
  alpha=NULL, beta=NULL, gamma=NULL, delta=NULL,
  B=NULL, R=NULL,
  taus=NULL,
  n_vec=NULL,
  seed=NULL,
  cl=NULL,
  output_dir="output",
  output_prefix=NULL,
  verbose=TRUE
){
  required_args <- list(
    alpha = alpha, beta = beta, gamma = gamma, delta = delta,
    B = B, R = R, taus = taus, n_vec = n_vec, seed = seed
  )
  missing_args <- names(required_args)[vapply(required_args, is.null, logical(1))]
  if (length(missing_args) > 0) {
    stop("Missing required simulation argument(s): ",
         paste(missing_args, collapse = ", "),
         ". Set these in the calling script.")
  }

  if (!is.null(dgp)) {
    dgp <- match.arg(dgp, c("DGP0", "DGP1", "DGP2"))
    outcome_type <- switch(
      dgp,
      DGP0 = "discrete",
      DGP1 = "discrete",
      DGP2 = "continuous"
    )
  } else {
    outcome_type = match.arg(outcome_type)
    dgp <- if (outcome_type == "discrete") "DGP1" else "DGP2"
  }
  if (is.null(cl)) {cl = ceiling(parallel::detectCores()*(0.75))}
  set.seed(seed)

  if (verbose) {
    message("Running table simulation with dgp=", dgp,
            ", outcome_type=", outcome_type,
            ", e_dist=", e_dist)
  }

  make_error_generator <- function(e_dist, e_params){
    switch(
      e_dist,
      ald = function(N){
        if (!requireNamespace("ald", quietly = TRUE)) {
          stop("Package 'ald' is required for e_dist='ald'.")
        }
        mu = ifelse(is.null(e_params$mu), 0, e_params$mu)
        sigma = ifelse(is.null(e_params$sigma), 1, e_params$sigma)
        p = ifelse(is.null(e_params$p), 0.1, e_params$p)
        ald::rALD(n=N, mu=mu, sigma=sigma, p=p)
      },
      normal = function(N){
        mu = ifelse(is.null(e_params$mu), 0, e_params$mu)
        sd = ifelse(is.null(e_params$sd), 1, e_params$sd)
        rnorm(N, mean=mu, sd=sd)
      },
      cauchy = function(N){
        loc = ifelse(is.null(e_params$location), 0, e_params$location)
        scale = ifelse(is.null(e_params$scale), 1, e_params$scale)
        rcauchy(N, location=loc, scale=scale)
      },
      chi2 = function(N){
        df = ifelse(is.null(e_params$df), 1, e_params$df)
        rchisq(N, df=df)
      },
      custom = {
        if (is.null(e_params$fn) || !is.function(e_params$fn)) {
          stop("For e_dist='custom', provide e_params$fn as a function.")
        }
        e_params$fn
      },
      stop("Unknown e_dist: ", e_dist)
    )
  }

  e_fun <- make_error_generator(e_dist = e_dist, e_params = e_params)

  #=====================================================================================
  calibrate_dgp0 <- function(){
    if (!requireNamespace("haven", quietly = TRUE)) {
      stop("Package 'haven' is required for dgp='DGP0'.")
    }

    donnees <- haven::read_dta("MonthlyPanel_tab3ABC.dta")
    donnees$totrob <- pmin(pmax(donnees$totrob, 0), 1)

    ygrid <- sort(unique(c(0, donnees$totrob, 1)))

    make_valid_cdf <- function(Fvals, ygrid){
      Fvals <- pmin(pmax(as.numeric(Fvals), 0), 1)
      Fvals <- cummax(Fvals)
      if (length(Fvals) > 1) {
        Fvals <- stats::isoreg(x = ygrid, y = Fvals)$yf
      }
      Fvals <- pmin(pmax(cummax(Fvals), 0), 1)
      Fvals[length(Fvals)] <- 1
      Fvals
    }

    F00 <- stats::ecdf(donnees$totrob[(donnees$institu1 == 0) & (donnees$mes <= 6)])
    F01 <- stats::ecdf(donnees$totrob[(donnees$institu1 == 0) & (donnees$mes >= 8)])
    F10 <- stats::ecdf(donnees$totrob[(donnees$institu1 == 1) & (donnees$mes <= 6)])

    F00_vals <- F00(ygrid)
    F01_vals <- F01(ygrid)
    F10_vals <- F10(ygrid)

    # Uniform-link DiD counterfactual, then project onto the space of valid CDFs.
    # A raw sum/difference of ecdfs need not itself be a valid CDF.
    F11_vals <- make_valid_cdf(F10_vals + F01_vals - F00_vals, ygrid)
    
    list(
      Q00 = left.inv(ys = ygrid, Fs = make_valid_cdf(F00_vals, ygrid)),
      Q01 = left.inv(ys = ygrid, Fs = make_valid_cdf(F01_vals, ygrid)),
      Q10 = left.inv(ys = ygrid, Fs = make_valid_cdf(F10_vals, ygrid)),
      Q11 = left.inv(ys = ygrid, Fs = F11_vals)
    )
  }

  dgp0_quantiles <- NULL
  if (dgp == "DGP0") {
    dgp0_quantiles <- calibrate_dgp0()
  }

  sample_dgp_data <- function(seed, N){
    set.seed(seed)
    D = rbinom(N, 1, 0.5)
    t = ifelse(seq_len(N) <= N/2, 0, 1)

    if (dgp == "DGP0") {
      Y = rep(NA_real_, N)
      id00 = which(D == 0 & t == 0)
      id01 = which(D == 0 & t == 1)
      id10 = which(D == 1 & t == 0)
      id11 = which(D == 1 & t == 1)

      if (length(id00) > 0) Y[id00] = dgp0_quantiles$Q00(stats::runif(length(id00)))
      if (length(id01) > 0) Y[id01] = dgp0_quantiles$Q01(stats::runif(length(id01)))
      if (length(id10) > 0) Y[id10] = dgp0_quantiles$Q10(stats::runif(length(id10)))
      if (length(id11) > 0) Y[id11] = dgp0_quantiles$Q11(stats::runif(length(id11)))
    } else {
      e = e_fun(N)
      mu = alpha + beta * D + gamma * t + D * t * delta
      if (dgp == "DGP1") {
        Y = pmax(ceiling(mu + e + 1), 0)
      } else {
        Y = mu + e
      }
    }

    data.frame(Y, D, t)
  }
  #--------------------------------------------------------------------------------
  get_ygrid <- function(daten){
    if (dgp == "DGP2") {
      ygrid = unique(quantile(daten$Y, probs = taus))
      taus_use = taus
    } else {
      U.Y<- sort(unique(daten$Y))
      ygrid = U.Y
      if (length(ygrid) > 2) {
        ygrid1 = ygrid[1:(length(ygrid)-2)]
      } else {
        ygrid1 = ygrid
      }
      ygrid2 <- U.Y[U.Y<=quantile(daten$Y,probs = 0.90)]
      if (length(ygrid1) < length(ygrid2)) {ygrid=ygrid1} else {ygrid=ygrid2}
      taus_use = seq(0.05,0.95,length.out=length(ygrid))
    }
    list(ygrid=ygrid, taus_use=taus_use)
  }

  did_stats <- function(daten, id.b, G="normal"){
    grid = get_ygrid(daten)
    ygrid = grid$ygrid
    taus_use = grid$taus_use

    estQttDtt = QTT_DTT(Y=daten$Y,D=daten$D,t=daten$t,
                       G=G,ygrid=ygrid,taus=taus_use)
    bootQttDtt = QTT_DTT.boot(Y=daten$Y,D=daten$D,t=daten$t,
                              G=G,ygrid=ygrid,taus=taus_use,B=B,id.b=id.b)

    Boot.DTT<- extract.fn(bootQttDtt,fn="DTT")
    BFObjs.DTT = Band.Fn.Objs(Fn=estQttDtt$DTT,Boot.Fn = Boot.DTT,n=length(daten$Y))
    UBand.DTT<- UBand.Fn(Fn=estQttDtt$DTT,BFObjs=BFObjs.DTT,alpha=alpha,n=length(daten$Y))
    bias.DTT=Lp_norm(est.fn=estQttDtt$DTT,true.fn=0,p=2)
    Rej.DTT<- 1- 1*all(UBand.DTT$LB.Fn<=0 & UBand.DTT$UB.Fn>=0)
    list(bias=bias.DTT, rej=Rej.DTT)
  }

  cic_stats <- function(daten, id.b){
    grid = get_ygrid(daten)
    ygrid = grid$ygrid

    cic_dtt_for_data <- function(dat, grid) {
      y00 <- dat$Y[dat$D==0 & dat$t==0]
      y01 <- dat$Y[dat$D==0 & dat$t==1]
      y10 <- dat$Y[dat$D==1 & dat$t==0]
      y11 <- dat$Y[dat$D==1 & dat$t==1]
      if (min(length(y00), length(y01), length(y10), length(y11)) == 0) {
        return(rep(NA_real_, length(grid)))
      }
      cic_df <- cic_counterfactual_cdf(y00, y01, y10, y11, grid=grid)
      cic_df$DTT
    }

    DTT.cic <- cic_dtt_for_data(daten, ygrid)
    Boot.DTT.cic <- matrix(NA_real_, nrow=length(DTT.cic), ncol=B)
    for (b in 1:B) {
      datb <- daten[id.b[,b],]
      Boot.DTT.cic[,b] <- cic_dtt_for_data(datb, ygrid)
    }

    BFObjs.DTT.cic <- Band.Fn.Objs(Fn=DTT.cic, Boot.Fn=Boot.DTT.cic, n=length(daten$Y))
    UBand.DTT.cic <- UBand.Fn(Fn=DTT.cic, BFObjs=BFObjs.DTT.cic, alpha=alpha, n=length(daten$Y))
    bias.DTT.cic <- Lp_norm(est.fn=DTT.cic, true.fn=0, p=2)
    Rej.DTT.cic <- 1- 1*all(UBand.DTT.cic$LB.Fn<=0 & UBand.DTT.cic$UB.Fn>=0)
    list(bias=bias.DTT.cic, rej=Rej.DTT.cic)
  }

  res_rows = list()

  for (N in n_vec) {
    if (verbose) message("Simulating N=", N)
    daten.MC = lapply(1:R, sample_dgp_data, N=N)
    id.b = matrix(sample(1:N, N*B, replace=TRUE), nrow=N, ncol=B)

    one_run <- function(l){
      dat <- daten.MC[[l]]
      did_norm <- did_stats(dat, id.b, G="normal")
      did_uniform <- did_stats(dat, id.b, G="uniform")
      did_identity <- did_stats(dat, id.b, G="identity")
      cic <- cic_stats(dat, id.b)
      c(
        did_norm_bias=did_norm$bias,
        did_norm_rej=did_norm$rej,
        did_uniform_bias=did_uniform$bias,
        did_uniform_rej=did_uniform$rej,
        did_identity_bias=did_identity$bias,
        did_identity_rej=did_identity$rej,
        cic_bias=cic$bias,
        cic_rej=cic$rej
      )
    }

    MC_Res = pbapply::pbsapply(1:R, FUN=one_run, cl=cl)
    mean_vec <- round(apply(MC_Res,1,mean),3)
    res_rows[[as.character(N)]] <- mean_vec
  }

  res = do.call(rbind, res_rows)
  colnames(res) = c(
    "Bias.DTT.DiD.Normal","Rej.DTT.DiD.Normal",
    "Bias.DTT.DiD.Uniform","Rej.DTT.DiD.Uniform",
    "Bias.DTT.DiD.Identity","Rej.DTT.DiD.Identity",
    "Bias.DTT.CiC","Rej.DTT.CiC"
  )
  rownames(res) = n_vec

  if (is.null(output_prefix)) {
    output_prefix = paste("SimTable", dgp, e_dist, sep="_")
  }

  if (!is.null(output_dir)) {
    dir.create(output_dir, showWarnings = FALSE, recursive = TRUE)
    out_file = file.path(output_dir, paste0(output_prefix, ".txt"))
    # write numeric entries as LaTeX-ready rows
    con <- file(out_file, open="w")
    for (i in 1:nrow(res)) {
      vals <- sprintf("%.3f", as.numeric(res[i,]))
      line <- paste(rownames(res)[i], "&", paste(vals, collapse=" & "), "\\\\")
      writeLines(line, con)
    }
    close(con)
    if (verbose) message("Wrote output to ", out_file)
  }

  return(res)
}
#=============================================================================>
# Purpose: Computes a Changes-in-Changes counterfactual CDF and the implied DTT curve.
# Input: Outcomes for the four group-time cells y00, y01, y10, y11,
#        plus an optional evaluation grid or grid length.
# Output: Data frame with the y-grid, treated-post CDF, CiC counterfactual CDF,
#         and DTT values.

cic_counterfactual_cdf <- function(y00, y01, y10, y11, grid = NULL, n_grid = 200) {
  y00 <- as.numeric(y00); y01 <- as.numeric(y01); y10 <- as.numeric(y10); y11 <- as.numeric(y11)
  
  # Grid of y-values where we evaluate CDFs
  if (is.null(grid)) {
    y_min <- min(c(y00, y01, y10, y11), na.rm = TRUE)
    y_max <- max(c(y00, y01, y10, y11), na.rm = TRUE)
    grid  <- seq(y_min, y_max, length.out = n_grid)
  } else {
    grid <- sort(as.numeric(grid))
  }
  
  # Empirical CDFs
  F00 <- stats::ecdf(y00)
  F01 <- stats::ecdf(y01)
  F10 <- stats::ecdf(y10)
  F11 <- stats::ecdf(y11)
  
  # Empirical quantile function for F00^{-1}:
  # Use type=1 for empirical (inverse of right-continuous CDF in a discrete sample sense)
  Q00 <- function(u) stats::quantile(y00, probs = u, type = 1, names = FALSE)
  
  # CiC counterfactual CDF for treated group at post under no treatment:
  # F_cf(y) = F10( Q00( F01(y) ) )
  F01_vals <- pmin(pmax(F01(grid), 0), 1)      # u = F01(y) in [0,1]
  x_map    <- as.numeric(Q00(F01_vals))        # x = F00^{-1}(u)
  F_cf     <- as.numeric(F10(x_map))           # F10(x)
  
  # Observed treated-post CDF
  F_treat_post <- as.numeric(F11(grid))
  
  # Distribution Treatment Effect (CDF difference)
  # DTT(y) = F_{Y1(1)|G=1}(y) - F_{Y1(0)|G=1}(y)
  DTT <- F_treat_post - F_cf
  
  data.frame(
    y = grid,
    F11 = F_treat_post,
    F10_cic_cf = F_cf,
    DTT = DTT
  )
}

# --- Example usage ---
# df <- cic_counterfactual_cdf(y00, y01, y10, y11, n_grid = 300)
# head(df)
# plot(df$y, df$DTT, type="l", xlab="y", ylab="DTT(y) = F11(y) - F_cic(y)")
#=============================================================================>
