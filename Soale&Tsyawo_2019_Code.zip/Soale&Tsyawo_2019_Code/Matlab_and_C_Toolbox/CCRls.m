function betas = CCRls(Y,X)
[n,p]=size(X); tol = 1e-06; az = 1e-20;
bet_vec = zeros(1,p); % vector to store parameters, excludes intercept
kp = 0.1; % fraction of total number of observations as partition size
slc = floor(kp*n); %maximum size of a local covariate cluster.
if (slc > p)
    error('use this function for p >> 0.1n');
end
lcls = ceil((1:p)./slc); %partition covarites into clusters
nlcls = max(lcls); % number of partitions

%% Initialise parameters
bet0 = 0; %initialise intercept
X0 = ones(n,2); % initialise coefficients
for j=1:p
   X0(:,2) = X(:,j); 
   coef0 = X0\Y;
   bet_vec(j) = coef0(2) ;
end

val0 = 10^10+0.1; val1=0; l=0; dev = val0;
coefs = zeros(1,slc)'; 
ngIDLS=false(1,(p-slc));
IDls = false(1,slc);

%% commence main iteration until convergence
while (dev>tol)
    if (l>0)
      val0 = val1;
      bet_vec(IDls)=coefs(2:(end-1));
      bet0 = coefs(1);
      bet_vec(ngIDLS) =  bet_vec(ngIDLS) * coefs(end);
    end
    
     l = l+1; IND = l - (ceil(l/nlcls)-1)*nlcls;
     IDls = lcls ==IND; % nIDls = length(IDls);
     ngIDLS = lcls ~=IND;
     XB = X(:,ngIDLS)*bet_vec(ngIDLS)';
     Xl = X(:,IDls);
     XX = [ones(n,1) Xl XB] ; %make room for intercept term
     coefs = XX\Y;
     val1=sum((Y-XX*coefs).^2);
     
     if (l>1)
        dev = (val0-val1)/(az+abs(val0)); 
     else
        dev=1; 
     end
     % print progress
     if(mod(l,100)==0)
     sprintf('iter = %.0f fval = %f and dev = %f',l,val1,dev)
     end
end
betas = [bet0 bet_vec]; %concatenate final parameter estimates
