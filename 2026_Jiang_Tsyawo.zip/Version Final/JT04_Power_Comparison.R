#===============================================================================
# Author: Feiyu Jiang & Emmanuel Selorm Tsyawo
# Project: A Consistent ICM-based X2 Specification Test
# Date began:   Feb 03, 2022
# Last Update:  Nov 12, 2025
# Place:        Shanghai & Tuscaloosa  
#===============================================================================
# Load packages, clear memory,
rm(list=ls())
#===============================================================================
library(parallel)
library(pbapply)
library(estrpac) #install using: devtools::install_github("estrpac")
library(pracma)
project_dir <- normalizePath(getwd())
output_dir <- file.path(project_dir, "output")
if (!dir.exists(output_dir)) dir.create(output_dir, recursive = TRUE)
source("JT07_Fonctions_Bahadur.R")
list.files()
#===============================================================================

#===============================================================================
#Notes: 
# 1. Running time: 
# 2. Peak RAM usage: 
#===============================================================================


#===============================================================================
# Comments: 
# Computes the Bahadur slopes of the pivotal chi-squared test
# compared to the bootstrap-based (GMDD) tests based on different kernels: 
# Gaussian, MDD, and Esc6.
#===============================================================================


#===============================================================================
n = 1e03 #size of a random sample
S = 1e04 #number of random samples
cl = floor(2*detectCores()/3) #number of cores to use in parallel computation
#===============================================================================


#===============================================================================
start.time<- Sys.time()
#===============================================================================


#===============================================================================
# generate the data
set.seed(0)
dbl = lapply(1:S,gdat.Bahadur2,n=n)

#test:
(try.obj<- MC.fn.Bahadur(s=1,dbl = dbl))
#===============================================================================


#===============================================================================
start.time<- Sys.time()

#===============================================================================

MC.res = pblapply(1:S,FUN = MC.fn.Bahadur,dbl=dbl,cl=cl)

#===============================================================================
end.time<- Sys.time()
end.time-start.time #Time difference of 1.408572 hours
#===============================================================================

# Extract results and compute Bahadur slopes

GMDD.vec<- lam1.vec<- ao2.vec<- Omg2.vec<- rep(0,S)
ao1.mat<- ao3.mat<- matrix(data=0,nrow=2,ncol=S)
ao1a.mat<- ao3a.mat<- matrix(data=0,nrow=3,ncol=S)
Omg1.array<- Omg3.array<- array(data = 0,dim = c(2,2,S))
Omg1a.array<- Omg3a.array<- array(data = 0,dim = c(3,3,S))

for (s in 1:S) {
  
  GMDD.vec[s]<- MC.res[[s]]$GMDD.obj[1]
  lam1.vec[s]<- MC.res[[s]]$GMDD.obj[2]
  
  ao1.mat[,s]<- MC.res[[s]]$Chi.obj1$ao
  Omg1.array[,,s]<- MC.res[[s]]$Chi.obj1$Omg
  
  ao1a.mat[,s]<- MC.res[[s]]$Chi.obj1a$ao
  Omg1a.array[,,s]<- MC.res[[s]]$Chi.obj1a$Omg
  
  ao2.vec[s]<- MC.res[[s]]$Chi.obj2$ao[1]
  Omg2.vec[s]<- MC.res[[s]]$Chi.obj2$Omg
  
  ao3.mat[,s]<- MC.res[[s]]$Chi.obj3$ao
  Omg3.array[,,s]<- MC.res[[s]]$Chi.obj3$Omg
  
  ao3a.mat[,s]<- MC.res[[s]]$Chi.obj3a$ao
  Omg3a.array[,,s]<- MC.res[[s]]$Chi.obj3a$Omg
}
mean(lam1.vec) #[1] 0.6175762
(GMDD.Bahadur_Slope<- mean(GMDD.vec)/mean(lam1.vec)) #[1] 0.01088869

ao1 = apply(ao1.mat,1,mean)
ao1a = apply(ao1a.mat,1,mean)
ao3 = apply(ao3.mat,1,mean)
ao3a = apply(ao3a.mat,1,mean)
Omg1<- apply(Omg1.array,MARGIN = c(1,2),FUN = mean)
Omg1a<- apply(Omg1a.array,MARGIN = c(1,2),FUN = mean)
Omg3<- apply(Omg3.array,MARGIN = c(1,2),FUN = mean)
Omg3a<- apply(Omg3a.array,MARGIN = c(1,2),FUN = mean)

(Chi2.Bahadur_Slope_1<- t(ao1)%*%solve(Omg1)%*%ao1) #0.021371

(Chi2.Bahadur_Slope_1a<- t(ao1a)%*%solve(Omg1a)%*%ao1a) #0.024212

(Chi2.Bahadur_Slope_2<- mean(ao2.vec)^2/mean(Omg2.vec)) #0.005644399

(Chi2.Bahadur_Slope_3<- t(ao3)%*%solve(Omg3)%*%ao3) #0.02458676

(Chi2.Bahadur_Slope_3a<- t(ao3a)%*%solve(Omg3a)%*%ao3a) #0.02458677

res.Bahadur_Slopes=round(c(GMDD.Bahadur_Slope,Chi2.Bahadur_Slope_1,Chi2.Bahadur_Slope_1a,
                           Chi2.Bahadur_Slope_2,
                          Chi2.Bahadur_Slope_3, Chi2.Bahadur_Slope_3a),4)

cat("Printing out results for the table")

print(paste(res.Bahadur_Slopes,collapse = " & "))
writeLines(
  c(
    "Bahadur slope summary",
    paste(res.Bahadur_Slopes, collapse = " & ")
  ),
  con = file.path(output_dir, "Bahadur_slopes.txt")
)
# [1] "0.0109 & 0.0214 & 0.0242 & 0.0056 & 0.0246 & 0.0246"
#===============================================================================




#===============================================================================
end.time<- Sys.time()
print(end.time-start.time) #Time difference of 1.753972 hours
#===============================================================================



#===============================================================================
# The following code is used to verify the above values using numerical
# integration

a.Z = function(Z) {exp(-Z^2/3) - sqrt(3/5)} 
a.Z=Vectorize(a.Z);curve(a.Z,-6,6);
integrate(function(Z) a.Z(Z)*dnorm(Z),-Inf,Inf)

mu.U = function(Z){
  sqrt(3/5)/(2^(3/2))*
    (sqrt(5)*exp(-(5/16)*Z^2) - 2*exp(-Z^2/4) )
}; mu.U=Vectorize(mu.U);curve(mu.U,-6,6)
(E.mu.U=integrate(function(Z) mu.U(Z)*dnorm(Z),-Inf,Inf))

GMDD.Z = function(Z) mu.U(Z)*a.Z(Z)
GMDD.Z = Vectorize(GMDD.Z); curve(GMDD.Z,-6,6)

(E.GMDD.Z=integrate(function(Z) GMDD.Z(Z)*dnorm(Z),-Inf,Inf))

(val.GMDD.Bahadur = E.GMDD.Z$value/mean(lam1.vec)) #[1] 0.01088396

#-------------------------------------------------------------------------------

# Compute delta_V
h1.Z = function(Z) exp(Z) - exp(1/2)
h1.Z=Vectorize(h1.Z);curve(h1.Z,-6,6)

(E.h1.Z=integral(function(Z) h1.Z(Z)*dnorm(Z),-Inf,Inf))

h2.Z = function(Z) sqrt(3)*exp(-Z^2/2) - sqrt(3/2)
h2.Z=Vectorize(h2.Z);curve(h2.Z,-6,6)
(E.h2.Z=integrate(function(Z) h2.Z(Z)*dnorm(Z),-30,30))

V1.Za = function(Z) h1.Z(Z)
V1.Zb = function(Z) a.Z(Z)-h1.Z(Z)
V1.Za=Vectorize(V1.Za); V1.Zb=Vectorize(V1.Zb)

integral(function(Z)V1.Za(Z)*dnorm(Z),-Inf,Inf)
integral(function(Z)V1.Zb(Z)*dnorm(Z),-Inf,Inf)

V2.Za = function(Z) h2.Z(Z)
V2.Zb = function(Z) a.Z(Z)-h2.Z(Z)
V2.Za=Vectorize(V2.Za); V2.Zb=Vectorize(V2.Zb)

integral(function(Z)V2.Za(Z)*dnorm(Z),-Inf,Inf)
integral(function(Z)V2.Zb(Z)*dnorm(Z),-Inf,Inf)


# delta_V values
(val.delta_V1 = c(integral(function(Z)mu.U(Z)*V1.Za(Z)*dnorm(Z),-Inf,Inf),
                 integral(function(Z)mu.U(Z)*V1.Zb(Z)*dnorm(Z),-Inf,Inf)))


(val.delta_V2 = c(integral(function(Z)mu.U(Z)*V2.Za(Z)*dnorm(Z),-Inf,Inf),
                  integral(function(Z)mu.U(Z)*V2.Zb(Z)*dnorm(Z),-Inf,Inf)))

#===============================================================================





