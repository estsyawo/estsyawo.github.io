//=====================================================
// Rank-correlation helper
// Purpose:
//   Provide fast C++ routines for Kendall's tau and Spearman's rho in their
//   U-statistic forms, together with centred empirical first-order projections
//   used by the weak-dependence simulation arm.
// Inputs:
//   Passed from R via Rcpp.
// Outputs:
//   Rcpp-exported lists containing point estimates and empirical projections.
// Side effects:
//   None.
//=====================================================

// [[Rcpp::depends(Rcpp)]]
#include <Rcpp.h>
using namespace Rcpp;

static inline int signum(double z) {
  return (z > 0.0) - (z < 0.0);
}

//=====================================================
// kendall_u2_projection_cpp
// Purpose:
//   Compute Kendall's tau as an order-2 U-statistic and return its centred
//   empirical first-order projection.
// Inputs:
//   x, y : numeric vectors of equal length.
// Outputs:
//   Rcpp list with elements:
//     estimate
//     projection
// Side effects:
//   None.
//=====================================================
// [[Rcpp::export]]
List kendall_u2_projection_cpp(NumericVector x, NumericVector y) {
  const int n = x.size();
  if (y.size() != n) stop("x and y must have the same length.");
  if (n < 3) stop("Need at least 3 observations.");

  NumericVector row_sum(n);
  double pair_sum = 0.0;
  for (int i = 0; i < n - 1; i++) {
    for (int j = i + 1; j < n; j++) {
      const double h = signum(x[i] - x[j]) * signum(y[i] - y[j]);
      row_sum[i] += h;
      row_sum[j] += h;
      pair_sum += h;
    }
  }

  const double estimate = 2.0 * pair_sum / ((double)n * (n - 1));
  NumericVector projection(n);
  for (int i = 0; i < n; i++) {
    projection[i] = row_sum[i] / (n - 1.0) - estimate;
  }

  return List::create(
    _["estimate"] = estimate,
    _["projection"] = projection
  );
}

//=====================================================
// spearman_u3_projection_cpp
// Purpose:
//   Compute the order-3 U-statistic representation of Spearman's rho and
//   return its centred empirical first-order projection.
// Inputs:
//   x, y : numeric vectors of equal length.
// Outputs:
//   Rcpp list with elements:
//     estimate
//     projection
// Side effects:
//   None.
//=====================================================
// [[Rcpp::export]]
List spearman_u3_projection_cpp(NumericVector x, NumericVector y) {
  const int n = x.size();
  if (y.size() != n) stop("x and y must have the same length.");
  if (n < 4) stop("Need at least 4 observations.");

  NumericVector rx(n), ry(n), concordance_row(n);
  NumericMatrix sx(n, n), sy(n, n);

  for (int i = 0; i < n; i++) {
    for (int j = i + 1; j < n; j++) {
      const int sx_ij = signum(x[i] - x[j]);
      const int sy_ij = signum(y[i] - y[j]);
      sx(i, j) = sx_ij;
      sx(j, i) = -sx_ij;
      sy(i, j) = sy_ij;
      sy(j, i) = -sy_ij;
      rx[i] += sx_ij;
      rx[j] -= sx_ij;
      ry[i] += sy_ij;
      ry[j] -= sy_ij;
      const int c_ij = sx_ij * sy_ij;
      concordance_row[i] += c_ij;
      concordance_row[j] += c_ij;
    }
  }

  NumericVector anchor_terms(n);
  double anchor_sum = 0.0;
  for (int i = 0; i < n; i++) {
    anchor_terms[i] = rx[i] * ry[i] - concordance_row[i];
    anchor_sum += anchor_terms[i];
  }
  const double estimate = 3.0 * anchor_sum / ((double)n * (n - 1) * (n - 2));

  NumericVector projection(n);
  for (int i = 0; i < n; i++) {
    double role_2_cross = 0.0;
    double role_3_cross = 0.0;
    for (int j = 0; j < n; j++) {
      role_2_cross += ry[j] * sx(j, i);
      role_3_cross += rx[j] * sy(j, i);
    }
    const double role_1 = 3.0 * anchor_terms[i];
    const double role_2 = 3.0 * (role_2_cross - concordance_row[i]);
    const double role_3 = 3.0 * (role_3_cross - concordance_row[i]);
    const double avg_containing_i =
      (role_1 + role_2 + role_3) / (3.0 * (n - 1) * (n - 2));
    projection[i] = avg_containing_i - estimate;
  }

  return List::create(
    _["estimate"] = estimate,
    _["projection"] = projection
  );
}
