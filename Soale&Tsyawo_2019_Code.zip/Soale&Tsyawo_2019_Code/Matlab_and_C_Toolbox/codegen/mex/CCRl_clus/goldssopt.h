/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * goldssopt.h
 *
 * Code generation for function 'goldssopt'
 *
 */

#ifndef GOLDSSOPT_H
#define GOLDSSOPT_H

/* Include files */
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "tmwtypes.h"
#include "mex.h"
#include "emlrt.h"
#include "rtwtypes.h"
#include "CCRl_clus_types.h"

/* Function Declarations */
extern void goldssopt(const emxArray_real_T *coefs, const emxArray_real_T *Y,
                      const emxArray_real_T *X, const emxArray_real_T *Xc,
                      uint64_T a, uint64_T b, uint64_T *optk, emxArray_real_T
                      *clus, emxArray_real_T *deltas, real_T *BIC);

#endif

/* End of code generation (goldssopt.h) */
