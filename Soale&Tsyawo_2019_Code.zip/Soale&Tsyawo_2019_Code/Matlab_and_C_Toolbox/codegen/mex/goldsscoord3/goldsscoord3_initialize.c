/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * goldsscoord3_initialize.c
 *
 * Code generation for function 'goldsscoord3_initialize'
 *
 */

/* Include files */
#include "rt_nonfinite.h"
#include "goldsscoord3.h"
#include "goldsscoord3_initialize.h"
#include "rng.h"
#include "_coder_goldsscoord3_mex.h"
#include "goldsscoord3_data.h"

/* Function Declarations */
static void goldsscoord3_once(void);

/* Function Definitions */
static void goldsscoord3_once(void)
{
  rng_init();
  rng_init();
  rng_init();
  rng_init();
  rng_init();
  rng_init();
  rng_init();
  rng_init();
  rng_init();
  rng_init();
  rng_init();
  rng_init();
  rng_init();
}

void goldsscoord3_initialize(void)
{
  emlrtStack st = { NULL,              /* site */
    NULL,                              /* tls */
    NULL                               /* prev */
  };

  mexFunctionCreateRootTLS();
  emlrtBreakCheckR2012bFlagVar = emlrtGetBreakCheckFlagAddressR2012b();
  st.tls = emlrtRootTLSGlobal;
  emlrtClearAllocCountR2012b(&st, false, 0U, 0);
  emlrtEnterRtStackR2012b(&st);
  emlrtLicenseCheckR2012b(&st, "Statistics_Toolbox", 2);
  if (emlrtFirstTimeR2012b(emlrtRootTLSGlobal)) {
    goldsscoord3_once();
  }
}

/* End of code generation (goldsscoord3_initialize.c) */
