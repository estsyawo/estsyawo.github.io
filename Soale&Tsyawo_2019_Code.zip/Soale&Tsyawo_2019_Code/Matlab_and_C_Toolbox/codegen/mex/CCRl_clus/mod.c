/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * mod.c
 *
 * Code generation for function 'mod'
 *
 */

/* Include files */
#include "rt_nonfinite.h"
#include "CCRl_clus.h"
#include "mod.h"

/* Function Definitions */
uint64_T b_mod(uint64_T x, uint64_T y)
{
  uint64_T r;
  uint64_T b_y;
  if (y == 0UL) {
    r = x;
  } else {
    if (y == 0UL) {
      b_y = MAX_uint64_T;
    } else {
      b_y = x / y;
    }

    r = x - b_y * y;
  }

  return r;
}

/* End of code generation (mod.c) */
