#===============================================================================
# JT06_Fonctions_Sim.R
# Data-generating processes used by the output-generating simulation scripts.
#===============================================================================

# Purpose: Generate the exogenous linear-model design used for LM size results.
# Input: `n` is the sample size and `gam` is accepted for interface consistency.
# Output: A length-`R` list of datasets, each containing `Y`, `X`, and `Z`.
gdat1 <- function(n, gam = 0.0) {
  datl <- list()
  for (l in 1:R) {
    set.seed(l + 10)
    U <- mvrnorm(n, rep(0, ncol(Sig.U)), Sig.U)
    set.seed(l + 20)
    Z <- mvrnorm(n, rep(0, ncol(Sig.X)), Sig.X)
    Y <- 1 + Z %*% bet + U[, 1] / sqrt(1 + Z[, 1]^2)
    datl[[l]] <- list(Y = Y, X = Z, Z = Z)
  }
  datl
}

#===============================================================================

# Purpose: Generate the endogenous linear/MI design with quadratic alternatives.
# Input: `n` is the sample size and `gam` controls the alternative strength.
# Output: A length-`R` list of datasets, each containing `Y`, `X`, and `Z`.
gdat2 <- function(n, gam = 0.0) {
  datl <- list()
  for (l in 1:R) {
    set.seed(l + 10)
    U <- mvrnorm(n, rep(0, ncol(Sig.U)), Sig.U)
    set.seed(l + 20)
    Z <- mvrnorm(n, rep(0, ncol(Sig.X)), Sig.X)
    X <- Z
    X[, 1] <- (1.5 * Z[, 1] + U[, 2]) / sqrt(1 + 1.5^2)
    Y <- 1 + X %*% bet + gam * (Z^2) %*% eta / sqrt(2) +
      U[, 1] / sqrt(1 + Z[, 1]^2)
    datl[[l]] <- list(Y = Y, X = X, Z = Z)
  }
  datl
}

#===============================================================================

# Purpose: Generate the endogenous design with high-frequency alternatives.
# Input: `n` is the sample size and `gam` controls the alternative strength.
# Output: A length-`R` list of datasets, each containing `Y`, `X`, and `Z`.
gdat3 <- function(n, gam = 0.0) {
  datl <- list()
  for (l in 1:R) {
    set.seed(l + 10)
    U <- mvrnorm(n, rep(0, ncol(Sig.U)), Sig.U)
    set.seed(l + 20)
    Z <- mvrnorm(n, rep(0, ncol(Sig.X)), Sig.X)
    X <- Z
    X[, 1] <- (1.5 * Z[, 1] + U[, 2]) / sqrt(1 + 1.5^2)
    Y <- 1 + X %*% bet +
      0.5 * gam * (cos(2 * Z)) %*% eta / sqrt((1 + exp(-8)) / 2) +
      U[, 1] / sqrt(1 + Z[, 1]^2)
    datl[[l]] <- list(Y = Y, X = X, Z = Z)
  }
  datl
}

#===============================================================================

# Purpose: Generate the endogenous design targeted to the chi-squared alternative.
# Input: `n` is the sample size and `gam` controls the alternative strength.
# Output: A length-`R` list of datasets, each containing `Y`, `X`, and `Z`.
gdat4 <- function(n, gam = 0.0) {
  datl <- list()
  for (l in 1:R) {
    set.seed(l + 10)
    U <- mvrnorm(n, rep(0, ncol(Sig.U)), Sig.U)
    set.seed(l + 20)
    Z <- mvrnorm(n, rep(0, ncol(Sig.X)), Sig.X)
    X <- Z
    X[, 1] <- (1.5 * Z[, 1] + U[, 2]) / sqrt(1 + 1.5^2)
    Y <- 1 + X %*% bet + gam * (exp(-Z^2 / 3) - sqrt(3 / 5)) %*% eta +
      U[, 1] / sqrt(1 + Z[, 1]^2)
    datl[[l]] <- list(Y = Y, X = X, Z = Z)
  }
  datl
}

#===============================================================================

# Purpose: Generate the nonlinear logit design used in `JT01_MCSim_NLM.R`.
# Input: `n` is the sample size and `gam` controls the alternative strength.
# Output: A length-`R` list of datasets, each containing `Y`, `X`, and `Z`.
gdatGLM <- function(n, gam = 0.0) {
  datl <- list()
  for (l in 1:R) {
    set.seed(l + 10)
    U <- mvrnorm(n, rep(0, ncol(Sig.U)), Sig.U)
    set.seed(l + 20)
    Z <- mvrnorm(n, rep(0, ncol(Sig.X)), Sig.X)
    X <- Z
    Y <- ((X %*% bet + gam * ((Z^2 - 1) %*% eta)) >= rlogis(n))
    datl[[l]] <- list(Y = Y, X = X, Z = Z)
  }
  datl
}

#===============================================================================

# Purpose: Generate the MI design with indicator-type fixed alternatives.
# Input: `n` is the sample size and `gam` controls the alternative strength.
# Output: A length-`R` list of datasets, each containing `Y`, `X`, and `Z`.
gdat5 <- function(n, gam = 0.0) {
  datl <- list()
  for (l in 1:R) {
    set.seed(l + 10)
    U <- mvrnorm(n, rep(0, ncol(Sig.U)), Sig.U)
    set.seed(l + 20)
    Z <- mvrnorm(n, rep(0, ncol(Sig.X)), Sig.X)
    X <- Z
    X[, 1] <- (1.5 * Z[, 1] + U[, 2]) / sqrt(1 + 1.5^2)
    Y <- 1 + X %*% bet + 0.5 * gam * (abs(Z) <= -qnorm(0.25)) %*% eta +
      U[, 1] / sqrt(1 + Z[, 1]^2)
    datl[[l]] <- list(Y = Y, X = X, Z = Z)
  }
  datl
}

#===============================================================================
