#=========================================================================================>
# Author: Emmanuel Selorm Tsyawo
# Project: Feasible IV Regression without Excluded Instruments
# Date began:   Jan. 15, 2022
# Last Update:  Mar. 28, 2022
# Place:        Rabat
#=========================================================================================>
# Load packages, clear memory,
#rm(list=ls())
library(MASS)
library(estrpac)#install from binary file estrpac_0.1.0.tgz or
# use devtools::install_github("estsyawo/estrpac")
library(pbapply)
library(AER)
setwd(dirname(rstudioapi::getActiveDocumentContext()$path)) #set working directory path to source file
#list.files()
#=========================================================================================>
# Comments: Examining the almost constant kernel problem. The specification here
# allows several instruments.
# DGP_4 at n=250, n=500, and n = 1000
#=========================================================================================>
# Set Parameters
R = 1000 # set number of simulations
a=b=1

RMSE = function(x) sqrt(mean(x^2))
MAD = function(x) median(abs(x))
#-------------------------------------------------------
gdat1<- function(n,pz){
  datl=list()
  for (l in 1:R) {
    set.seed(l) #generate seed
    Z=mvrnorm(n=n,mu=rep(0,pz),Sigma = exp(-as.matrix(dist(1:pz))))
    Sig = diag(2); Sig[1,2]=Sig[2,1]=0.5
    set.seed(l+100)
    EU=mvrnorm(n=n,mu=c(0,0),Sigma = Sig)
    #generate endogenous covariate
    D = apply(Z,1,sum)/sqrt(pz) + EU[,2]
    #generate outcome
    Y = a + D + EU[,1] #D is endogenous
    #save in a list
    datl[[l]]<- list(Y=Y,X=D,Z=Z)
  }
  datl
}


MCfun1<- function(j=NULL,datl,b){
  dat = datl[[j]] #null operation for looping
  Y = dat$Y; X = as.matrix(dat$X)
  Z = as.matrix(dat$Z)
  
  #run Integrated Moment regressions
  T_MMD=system.time((MMDobj=imlmreg2.fit(Y,X,Z,Kern = "Euclid")))
  T_WMD=system.time((WMDobj=imlmreg2.fit(Y,X,Z,Kern = "WMD")))
  T_WMDF=system.time((WMDFobj=imlmreg2.fit(Y,X,Z,Kern = "WMDF")))
  T_DL=system.time((DLobj=imlmreg2.fit(Y,X,Z,Kern = "DL")))
  T_ESC6=system.time((Esc6obj=imlmreg2.fit(Y,X,Z,Kern = "Esc6")))
  T_IIV=system.time((IIVobj=imlmreg2.fit(Y,X,Z,Kern = "Gauss.W")))
  
  #compute bias
  bias.MMD = MMDobj$coefficients[2]-b 
  bias.WMD = WMDobj$coefficients[2]-b
  bias.WMDF = WMDFobj$coefficients[2]-b
  bias.DL = DLobj$coefficients[2]-b
  bias.Esc6 = Esc6obj$coefficients[2]-b
  bias.IIV = IIVobj$coefficients[2]-b
  
  #compute size (for rejection probabilities)
  size.MMD = 1*(abs(bias.MMD/MMDobj$HC_Std.Err[2])>qnorm(0.975))
  size.WMD = 1*(abs(bias.WMD/WMDobj$HC_Std.Err[2])>qnorm(0.975))
  size.WMDF = 1*(abs(bias.WMDF/WMDFobj$HC_Std.Err[2])>qnorm(0.975))
  size.DL = 1*(abs(bias.DL/DLobj$HC_Std.Err[2])>qnorm(0.975))
  size.Esc6 = 1*(abs(bias.Esc6/Esc6obj$HC_Std.Err[2])>qnorm(0.975))
  size.IIV = 1*(abs(bias.IIV/IIVobj$HC_Std.Err[2])>qnorm(0.975))
  
  res=c(bias.MMD,bias.WMD,bias.WMDF,bias.DL,bias.Esc6,bias.IIV,
        size.MMD,size.WMD,size.WMDF,size.DL,size.Esc6,size.IIV,
        T_MMD[3],T_WMD[3],T_WMDF[3],T_DL[3],T_ESC6[3],T_IIV[3])
  names(res)=c("BiasMMD","BiasWMD","BiasWMDF","BiasDL","BiasEsc6","BiasIIV",
               "SizeMMD","SizeWMD","SizeWMDF","SizeDL","SizeEsc6","SizeIIV",
               "T_MMD","T_WMD","T_WMDF","T_DL","T_Esc6","T_IIV")
  res
}

# 
#-------------------------------------------------------
#n = 250
datl1a=gdat1(n=250,pz = 8)
#illustration
MCfun1(j=1,datl = datl1a,b=b)

Bias1a = pbsapply(1:R, FUN=MCfun1,cl=5,datl=datl1a,b=b)
summary(t(Bias1a))

#n = 250
datl1aM=gdat1(n=250,pz = 18)
Bias1a.M = pbsapply(1:R, FUN=MCfun1,cl=5,datl=datl1aM,b=b)
summary(t(Bias1a.M))

#n = 250
datl1aMM=gdat1(n=250,pz = 32)
Bias1a.MM = pbsapply(1:R, FUN=MCfun1,cl=5,datl=datl1aMM,b=b)
summary(t(Bias1a.MM))
#-------------------------------------------------------

#-------------------------------------------------------
#n = 500
datl1b=gdat1(n=500,pz = 8)
Bias1b = pbsapply(1:R, FUN=MCfun1,cl=5,datl=datl1b,b=b)
summary(t(Bias1b))

#n = 500
datl1bM=gdat1(n=500,pz = 18)
Bias1b.M = pbsapply(1:R, FUN=MCfun1,cl=5,datl=datl1bM,b=b)
summary(t(Bias1b.M))

#n = 500
datl1bMM=gdat1(n=500,pz = 32)
Bias1b.MM = pbsapply(1:R, FUN=MCfun1,cl=5,datl=datl1bMM,b=b)
summary(t(Bias1b.MM))
#-------------------------------------------------------


#-------------------------------------------------------
#n = 1000
datl1c=gdat1(n=1000,pz = 8)
Bias1c = pbsapply(1:R, FUN=MCfun1,cl=4,datl=datl1c,b=b)
summary(t(Bias1c))

#n = 1000
datl1cM=gdat1(n=1000,pz = 18)
Bias1c.M = pbsapply(1:R, FUN=MCfun1,cl=4,datl=datl1cM,b=b)
summary(t(Bias1c.M))

#n = 1000
datl1cMM=gdat1(n=1000,pz = 32)
Bias1c.MM = pbsapply(1:R, FUN=MCfun1,cl=4,datl=datl1cMM,b=b)
summary(t(Bias1c.MM))
#=========================================================================================>

# Results:

Res.A1=round(cbind(apply(Bias1a[1:6,],1,mean),apply(Bias1a[1:6,],1,MAD),
                   apply(Bias1a[1:6,],1,RMSE),
                   apply(Bias1a[7:12,],1,mean)),3)
colnames(Res.A1)=c("MB","MAD","RMSE","Rej")
rownames(Res.A1)=c("MMD","WMD","WMDF","DL","ESC6","IIV")
Res.A1

T.A1=round(cbind(apply(Bias1a[13:18,],1,mean),apply(Bias1a[13:18,],1,sd),
                 apply(t(Bias1a[13:18,])/c(Bias1a[13,]),2,median),
                 apply(t(Bias1a[13:18,])/c(Bias1a[13,]),2,IQR)),3)
colnames(T.A1)=c("MT","SDT","MdRel","IQR")
rownames(T.A1)=c("MMD","WMD","WMDF","DL","ESC6","IIV")
T.A1


Res.A2=round(cbind(apply(Bias1a.M[1:6,],1,mean),apply(Bias1a.M[1:6,],1,MAD),
                   apply(Bias1a.M[1:6,],1,RMSE),
                   apply(Bias1a.M[7:12,],1,mean)),3)
colnames(Res.A2)=c("MB","MAD","RMSE","Rej")
rownames(Res.A2)=c("MMD","WMD","WMDF","DL","ESC6","IIV")
Res.A2

T.A2=round(cbind(apply(Bias1a.M[13:18,],1,mean),apply(Bias1a.M[13:18,],1,sd),
                 apply(t(Bias1a.M[13:18,])/c(Bias1a.M[13,]),2,median),
                 apply(t(Bias1a.M[13:18,])/c(Bias1a.M[13,]),2,IQR)),3)
colnames(T.A2)=c("MT","SDT","MdRel","IQR")
rownames(T.A2)=c("MMD","WMD","WMDF","DL","ESC6","IIV")
T.A2


Res.A3=round(cbind(apply(Bias1a.MM[1:6,],1,mean),apply(Bias1a.MM[1:6,],1,MAD),
                   apply(Bias1a.MM[1:6,],1,RMSE),
                   apply(Bias1a.MM[7:12,],1,mean)),3)
colnames(Res.A3)=c("MB","MAD","RMSE","Rej")
rownames(Res.A3)=c("MMD","WMD","WMDF","DL","ESC6","IIV")
Res.A3

T.A3=round(cbind(apply(Bias1a.MM[13:18,],1,mean),apply(Bias1a.MM[13:18,],1,sd),
                 apply(t(Bias1a.MM[13:18,])/c(Bias1a.MM[13,]),2,median),
                 apply(t(Bias1a.MM[13:18,])/c(Bias1a.MM[13,]),2,IQR)),3)
colnames(T.A3)=c("MT","SDT","MdRel","IQR")
rownames(T.A3)=c("MMD","WMD","WMDF","DL","ESC6","IIV")
T.A3


cbind(Res.A1,Res.A2,Res.A3)
#         MB   MAD  RMSE   Rej     MB   MAD  RMSE   Rej    MB   MAD  RMSE   Rej
# MMD   0.007 0.034 0.048 0.061  0.014 0.031 0.047 0.072 0.023 0.036 0.051 0.126
# WMD  -0.001 0.044 0.068 0.060 -0.004 0.071 0.121 0.054 0.140 0.132 0.168 0.559
# WMDF  0.147 0.147 0.152 0.978  0.163 0.162 0.167 0.997 0.161 0.161 0.165 0.995
# DL    0.003 0.043 0.066 0.064  0.159 0.165 0.168 0.851 0.161 0.161 0.165 0.995
# ESC6  0.007 0.034 0.048 0.058  0.013 0.031 0.047 0.069 0.022 0.034 0.050 0.115
# IIV   0.103 0.102 0.111 0.692  0.162 0.162 0.166 0.997 0.161 0.161 0.165 0.995

#writing out output to pasting into TeX

apply(cbind(Res.A1,Res.A2,Res.A3),1,paste,collapse=" & ")

# MMD 0.007 & 0.034 & 0.048 & 0.061 & 0.014 & 0.031 & 0.047 & 0.072 & 0.023 & 0.036 & 0.051 & 0.126" 
# WMD -0.001 & 0.044 & 0.068 & 0.06 & -0.004 & 0.071 & 0.121 & 0.054 & 0.14 & 0.132 & 0.168 & 0.559" 
# WMDF 0.147 & 0.147 & 0.152 & 0.978 & 0.163 & 0.162 & 0.167 & 0.997 & 0.161 & 0.161 & 0.165 & 0.995" 
# DL 0.003 & 0.043 & 0.066 & 0.064 & 0.159 & 0.165 & 0.168 & 0.851 & 0.161 & 0.161 & 0.165 & 0.995" 
# ESC6 0.007 & 0.034 & 0.048 & 0.058 & 0.013 & 0.031 & 0.047 & 0.069 & 0.022 & 0.034 & 0.05 & 0.115" 
# IIV 0.103 & 0.102 & 0.111 & 0.692 & 0.162 & 0.162 & 0.166 & 0.997 & 0.161 & 0.161 & 0.165 & 0.995"

#----------------------------------------------------------------------------------------->
cbind(T.A1,T.A2,T.A3)
#         MT   SDT   MdRel    IQR    MT   SDT   MdRel    IQR    MT   SDT   MdRel     IQR
# MMD  0.011 0.004   1.000  0.000 0.012 0.003   1.000  0.000 0.014 0.004   1.000   0.000
# WMD  0.014 0.005   1.250  0.545 0.015 0.004   1.222  0.500 0.017 0.004   1.273   0.446
# WMDF 0.013 0.005   1.182  0.518 0.015 0.004   1.222  0.500 0.016 0.004   1.200   0.455
# DL   0.138 0.016  13.038  4.792 0.146 0.017  12.569  4.059 0.149 0.018  11.380   3.773
# ESC6 1.577 0.127 151.800 52.441 2.981 0.322 257.636 81.893 4.883 0.499 372.326 114.638
# IIV  0.017 0.006   1.500  0.657 0.022 0.007   1.778  0.688 0.033 0.008   2.462   0.933

apply(cbind(T.A1,T.A2,T.A3),1,paste,collapse=" & ")
# MMD 0.011 & 0.004 & 1 & 0 & 0.012 & 0.003 & 1 & 0 & 0.014 & 0.004 & 1 & 0" 
# WMD 0.014 & 0.005 & 1.25 & 0.545 & 0.015 & 0.004 & 1.222 & 0.5 & 0.017 & 0.004 & 1.273 & 0.446" 
# WMDF 0.013 & 0.005 & 1.182 & 0.518 & 0.015 & 0.004 & 1.222 & 0.5 & 0.016 & 0.004 & 1.2 & 0.455" 
# DL 0.138 & 0.016 & 13.038 & 4.792 & 0.146 & 0.017 & 12.569 & 4.059 & 0.149 & 0.018 & 11.38 & 3.773" 
# ESC6 1.577 & 0.127 & 151.8 & 52.441 & 2.981 & 0.322 & 257.636 & 81.893 & 4.883 & 0.499 & 372.326 & 114.638" 
# IIV 0.017 & 0.006 & 1.5 & 0.657 & 0.022 & 0.007 & 1.778 & 0.688 & 0.033 & 0.008 & 2.462 & 0.933"

#=========================================================================================>
Res.B1=round(cbind(apply(Bias1b[1:6,],1,mean),apply(Bias1b[1:6,],1,MAD),
                   apply(Bias1b[1:6,],1,RMSE),
                   apply(Bias1b[7:12,],1,mean)),3)
colnames(Res.B1)=c("MB","MAD","RMSE","Rej")
rownames(Res.B1)=c("MMD","WMD","WMDF","DL","ESC6","IIV")
Res.B1

T.B1=round(cbind(apply(Bias1b[13:18,],1,mean),apply(Bias1b[13:18,],1,sd),
                 apply(t(Bias1b[13:18,])/c(Bias1b[13,]),2,median),
                 apply(t(Bias1b[13:18,])/c(Bias1b[13,]),2,IQR)),3)
colnames(T.B1)=c("MT","SDT","MdRel","IQR")
rownames(T.B1)=c("MMD","WMD","WMDF","DL","ESC6","IIV")
T.B1


Res.B2=round(cbind(apply(Bias1b.M[1:6,],1,mean),apply(Bias1b.M[1:6,],1,MAD),
                   apply(Bias1b.M[1:6,],1,RMSE),
                   apply(Bias1b.M[7:12,],1,mean)),3)
colnames(Res.B2)=c("MB","MAD","RMSE","Rej")
rownames(Res.B2)=c("MMD","WMD","WMDF","DL","ESC6","IIV")
Res.B2

T.B2=round(cbind(apply(Bias1b.M[13:18,],1,mean),apply(Bias1b.M[13:18,],1,sd),
                 apply(t(Bias1b.M[13:18,])/c(Bias1b.M[13,]),2,median),
                 apply(t(Bias1b.M[13:18,])/c(Bias1b.M[13,]),2,IQR)),3)
colnames(T.B2)=c("MT","SDT","MdRel","IQR")
rownames(T.B2)=c("MMD","WMD","WMDF","DL","ESC6","IIV")
T.B2


Res.B3=round(cbind(apply(Bias1b.MM[1:6,],1,mean),apply(Bias1b.MM[1:6,],1,MAD),
                   apply(Bias1b.MM[1:6,],1,RMSE),
                   apply(Bias1b.MM[7:12,],1,mean)),3)
colnames(Res.B3)=c("MB","MAD","RMSE","Rej")
rownames(Res.B3)=c("MMD","WMD","WMDF","DL","ESC6","IIV")
Res.B3

T.B3=round(cbind(apply(Bias1b.MM[13:18,],1,mean),apply(Bias1b.MM[13:18,],1,sd),
                 apply(t(Bias1b.MM[13:18,])/c(Bias1b.MM[13,]),2,median),
                 apply(t(Bias1b.MM[13:18,])/c(Bias1b.MM[13,]),2,IQR)),3)
colnames(T.B3)=c("MT","SDT","MdRel","IQR")
rownames(T.B3)=c("MMD","WMD","WMDF","DL","ESC6","IIV")
T.B3


cbind(Res.B1,Res.B2,Res.B3)
#         MB   MAD  RMSE   Rej    MB   MAD  RMSE   Rej    MB   MAD  RMSE   Rej
# MMD   0.003 0.022 0.033 0.059 0.008 0.023 0.033 0.066 0.012 0.023 0.033 0.080
# WMD  -0.002 0.031 0.046 0.066 0.002 0.048 0.072 0.049 0.136 0.131 0.153 0.753
# WMDF  0.103 0.103 0.107 0.946 0.164 0.164 0.166 1.000 0.161 0.161 0.163 1.000
# DL    0.001 0.030 0.045 0.055 0.125 0.131 0.140 0.640 0.161 0.161 0.163 1.000
# ESC6  0.003 0.023 0.033 0.062 0.008 0.023 0.033 0.065 0.011 0.023 0.033 0.079
# IIV   0.071 0.071 0.079 0.592 0.163 0.163 0.165 1.000 0.161 0.161 0.163 1.000

#for pasting into TeX
apply(cbind(Res.B1,Res.B2,Res.B3),1,paste,collapse=" & ")
# MMD 0.003 & 0.022 & 0.033 & 0.059 & 0.008 & 0.023 & 0.033 & 0.066 & 0.012 & 0.023 & 0.033 & 0.08" 
# WMD -0.002 & 0.031 & 0.046 & 0.066 & 0.002 & 0.048 & 0.072 & 0.049 & 0.136 & 0.131 & 0.153 & 0.753" 
# WMDF 0.103 & 0.103 & 0.107 & 0.946 & 0.164 & 0.164 & 0.166 & 1 & 0.161 & 0.161 & 0.163 & 1" 
# DL 0.001 & 0.03 & 0.045 & 0.055 & 0.125 & 0.131 & 0.14 & 0.64 & 0.161 & 0.161 & 0.163 & 1" 
# ESC6 0.003 & 0.023 & 0.033 & 0.062 & 0.008 & 0.023 & 0.033 & 0.065 & 0.011 & 0.023 & 0.033 & 0.079" 
# IIV 0.071 & 0.071 & 0.079 & 0.592 & 0.163 & 0.163 & 0.165 & 1 & 0.161 & 0.161 & 0.163 & 1"

#----------------------------------------------------------------------------------------->
cbind(T.B1,T.B2,T.B3)
#         MT   SDT   MdRel     IQR     MT   SDT   MdRel     IQR     MT   SDT    MdRel     IQR
# MMD   0.023 0.006   1.000   0.000  0.027 0.006   1.000   0.000  0.028 0.006    1.000   0.000
# WMD   0.029 0.006   1.239   0.419  0.034 0.010   1.241   0.397  0.035 0.006    1.229   0.364
# WMDF  0.027 0.006   1.190   0.414  0.033 0.009   1.185   0.424  0.033 0.006    1.156   0.393
# DL    1.137 0.106  49.187  15.902  1.169 0.118  43.618  13.752  1.086 0.058   38.583  11.880
# ESC6 13.197 1.020 575.659 199.984 24.349 2.081 911.420 272.038 36.849 1.374 1313.518 383.468
# IIV   0.026 0.006   1.154   0.379  0.035 0.012   1.263   0.393  0.044 0.009    1.542   0.412

apply(cbind(T.B1,T.B2,T.B3),1,paste,collapse=" & ")
# MMD 0.023 & 0.006 & 1 & 0 & 0.027 & 0.006 & 1 & 0 & 0.028 & 0.006 & 1 & 0" 
# WMD 0.029 & 0.006 & 1.239 & 0.419 & 0.034 & 0.01 & 1.241 & 0.397 & 0.035 & 0.006 & 1.229 & 0.364" 
# WMDF 0.027 & 0.006 & 1.19 & 0.414 & 0.033 & 0.009 & 1.185 & 0.424 & 0.033 & 0.006 & 1.156 & 0.393" 
# DL 1.137 & 0.106 & 49.187 & 15.902 & 1.169 & 0.118 & 43.618 & 13.752 & 1.086 & 0.058 & 38.583 & 11.88" 
# ESC6 13.197 & 1.02 & 575.659 & 199.984 & 24.349 & 2.081 & 911.42 & 272.038 & 36.849 & 1.374 & 1313.518 & 383.468" 
# IIV 0.026 & 0.006 & 1.154 & 0.379 & 0.035 & 0.012 & 1.263 & 0.393 & 0.044 & 0.009 & 1.542 & 0.412"

#=========================================================================================>


#=========================================================================================>
Res.C1=round(cbind(apply(Bias1c[1:6,],1,mean),apply(Bias1c[1:6,],1,MAD),apply(Bias1c[1:6,],1,RMSE),
                   apply(Bias1c[7:12,],1,mean)),3)
colnames(Res.C1)=c("MB","MAD","RMSE","Rej")
rownames(Res.C1)=c("MMD","WMD","WMDF","DL","ESC6","IIV")
Res.C1

T.C1=round(cbind(apply(Bias1c[13:18,],1,mean),apply(Bias1c[13:18,],1,sd),
                 apply(t(Bias1c[13:18,])/c(Bias1c[13,]),2,median),
                 apply(t(Bias1c[13:18,])/c(Bias1c[13,]),2,IQR)),3)
colnames(T.C1)=c("MT","SDT","MdRel","IQR")
rownames(T.C1)=c("MMD","WMD","WMDF","DL","ESC6","IIV")
T.C1


Res.C2=round(cbind(apply(Bias1c.M[1:6,],1,mean),apply(Bias1c.M[1:6,],1,MAD),apply(Bias1c.M[1:6,],1,RMSE),
                   apply(Bias1c.M[7:12,],1,mean)),3)
colnames(Res.C2)=c("MB","MAD","RMSE","Rej")
rownames(Res.C2)=c("MMD","WMD","WMDF","DL","ESC6","IIV")
Res.C2

T.C2=round(cbind(apply(Bias1c.M[13:18,],1,mean),apply(Bias1c.M[13:18,],1,sd),
                 apply(t(Bias1c.M[13:18,])/c(Bias1c.M[13,]),2,median),
                 apply(t(Bias1c.M[13:18,])/c(Bias1c.M[13,]),2,IQR)),3)
colnames(T.C2)=c("MT","SDT","MdRel","IQR")
rownames(T.C2)=c("MMD","WMD","WMDF","DL","ESC6","IIV")
T.C2


Res.C3=round(cbind(apply(Bias1c.MM[1:6,],1,mean),apply(Bias1c.MM[1:6,],1,MAD),apply(Bias1c.MM[1:6,],1,RMSE),
                   apply(Bias1c.MM[7:12,],1,mean)),3)
colnames(Res.C3)=c("MB","MAD","RMSE","Rej")
rownames(Res.C3)=c("MMD","WMD","WMDF","DL","ESC6","IIV")
Res.C3

T.C3=round(cbind(apply(Bias1c.MM[13:18,],1,mean),apply(Bias1c.MM[13:18,],1,sd),
                 apply(t(Bias1c.MM[13:18,])/c(Bias1c.MM[13,]),2,median),
                 apply(t(Bias1c.MM[13:18,])/c(Bias1c.MM[13,]),2,IQR)),3)
colnames(T.C3)=c("MT","SDT","MdRel","IQR")
rownames(T.C3)=c("MMD","WMD","WMDF","DL","ESC6","IIV")
T.C3


cbind(Res.C1,Res.C2,Res.C3)
#        MB   MAD  RMSE   Rej    MB   MAD  RMSE   Rej    MB   MAD  RMSE   Rej
# MMD   0.001 0.015 0.022 0.046 0.004 0.016 0.022 0.041 0.008 0.016 0.023 0.058
# WMD  -0.001 0.021 0.031 0.044 0.002 0.030 0.044 0.056 0.130 0.128 0.135 0.950
# WMDF  0.047 0.046 0.053 0.449 0.164 0.163 0.165 1.000 0.161 0.161 0.162 1.000
# DL    0.000 0.020 0.030 0.042 0.064 0.066 0.087 0.294 0.162 0.162 0.163 1.000
# ESC6  0.001 0.015 0.023 0.042 0.004 0.015 0.022 0.046 0.007 0.016 0.023 0.057
# IIV   0.045 0.045 0.051 0.431 0.162 0.162 0.163 1.000 0.161 0.161 0.162 1.000

apply(cbind(Res.C1,Res.C2,Res.C3),1,paste,collapse=" & ")
# MMD 0.001 & 0.016 & 0.023 & 0.041 & 0.004 & 0.015 & 0.022 & 0.049 & 0.008 & 0.016 & 0.023 & 0.06" 
# WMD 0 & 0.018 & 0.026 & 0.042 & 0.002 & 0.024 & 0.034 & 0.046 & 0.123 & 0.12 & 0.129 & 0.906" 
# WMDF 0.04 & 0.039 & 0.045 & 0.396 & 0.164 & 0.163 & 0.165 & 1 & 0.161 & 0.161 & 0.162 & 1" 
# DL 0 & 0.02 & 0.03 & 0.042 & 0.064 & 0.066 & 0.087 & 0.294 & 0.162 & 0.162 & 0.163 & 1" 
# ESC6 0.001 & 0.016 & 0.023 & 0.042 & 0.004 & 0.015 & 0.022 & 0.047 & 0.007 & 0.016 & 0.023 & 0.056" 
# IIV 0.035 & 0.035 & 0.042 & 0.295 & 0.162 & 0.161 & 0.163 & 1 & 0.161 & 0.161 & 0.162 & 1"

#----------------------------------------------------------------------------------------->
# Running Time
cbind(T.C1,T.C2,T.C3)
#         MT   SDT   MdRel     IQR     MT   SDT   MdRel     IQR     MT   SDT    MdRel     IQR
# MMD 0.054 & 0.012 & 1 & 0 & 0.065 & 0.015 & 1 & 0 & 0.082 & 0.028 & 1 & 0" 
# WMD 0.069 & 0.009 & 1.354 & 0.295 & 0.081 & 0.013 & 1.31 & 0.245 & 0.099 & 0.031 & 1.258 & 0.199" 
# WMDF 0.068 & 0.008 & 1.386 & 0.449 & 0.079 & 0.011 & 1.326 & 0.364 & 0.097 & 0.026 & 1.262 & 0.301" 
# DL 7.691 & 0.397 & 157.875 & 51.547 & 7.864 & 0.685 & 133.522 & 39.562 & 8.313 & 1.27 & 111.363 & 25.499" 
# ESC6 84.211 & 3.246 & 1720.677 & 550.279 & 151.235 & 13.265 & 2555.286 & 709.585 & 317.415 & 58.883 & 4196.725 & 941.891" 
# IIV 0.058 & 0.006 & 1.133 & 0.279 & 0.072 & 0.012 & 1.149 & 0.25 & 0.1 & 0.027 & 1.239 & 0.254"

apply(cbind(T.C1,T.C2,T.C3),1,paste,collapse=" & ")
# MMD 0.054 & 0.012 & 1 & 0 & 0.065 & 0.015 & 1 & 0 & 0.082 & 0.028 & 1 & 0" 
# WMD 0.069 & 0.009 & 1.354 & 0.295 & 0.081 & 0.013 & 1.31 & 0.245 & 0.099 & 0.031 & 1.258 & 0.199" 
# WMDF 0.068 & 0.008 & 1.386 & 0.449 & 0.079 & 0.011 & 1.326 & 0.364 & 0.097 & 0.026 & 1.262 & 0.301" 
# DL 7.691 & 0.397 & 157.875 & 51.547 & 7.864 & 0.685 & 133.522 & 39.562 & 8.313 & 1.27 & 111.363 & 25.499" 
# ESC6 84.211 & 3.246 & 1720.677 & 550.279 & 151.235 & 13.265 & 2555.286 & 709.585 & 317.415 & 58.883 & 4196.725 & 941.891" 
# IIV 0.058 & 0.006 & 1.133 & 0.279 & 0.072 & 0.012 & 1.149 & 0.25 & 0.1 & 0.027 & 1.239 & 0.254"

#=========================================================================================>


#=========================================================================================>
# Plot a power curve for different ICM estimators
gdat2<- function(gam,n=500,pz=18){
  datl=list()
  for (l in 1:R) {
    set.seed(l) #generate seed
    Z=mvrnorm(n=n,mu=rep(0,pz),Sigma = exp(-as.matrix(dist(1:pz))))
    Sig = diag(2); Sig[1,2]=Sig[2,1]=0.5
    set.seed(l+100)
    EU=mvrnorm(n=n,mu=c(0,0),Sigma = Sig)
    #generate endogenous covariate
    D = apply(Z,1,sum)/sqrt(pz) + EU[,2]
    #generate outcome
    Y = a + D*(b-gam) + EU[,1] #D is endogenous
    #save in a list
    datl[[l]]<- list(Y=Y,X=D,Z=Z)
  }
  datl
}

gamvec = seq(-0.15,0.15,length.out = 11) #specify vector of deviations from the null
#illustration
datl1d=gdat2(gam = gamvec[1])
MCfun1(j=1,datl = datl1d,b=b)

Bias1d=list()
for (l in 1:length(gamvec)) {
  datl1d=gdat2(gam = gamvec[l])
  Bias1d[[l]] = pbsapply(1:R, FUN=MCfun1,cl=5,datl=datl1d,b=b)
  cat("At gam = ",gamvec[l],"\n")
  print(summary(t(Bias1d[[l]])))
}

Pow_Mat = data.frame(matrix(NA,length(gamvec),7))
Pow_Mat[,1]=gamvec
names(Pow_Mat)=c("Gamma","MMD","WMD","WMDF","DL","ESC6","IIV")

for (l in 1:length(gamvec)) {
  Pow_Mat[l,-1] = apply(Bias1d[[l]],1,mean)[7:12]
}
Pow_Mat
# Gamma   MMD   WMD  WMDF    DL  ESC6   IIV
# 1  -0.15 0.997 0.628 1.000 0.962 0.997 1.000
# 2  -0.12 0.973 0.488 1.000 0.935 0.972 1.000
# 3  -0.09 0.857 0.347 1.000 0.896 0.854 1.000
# 4  -0.06 0.612 0.205 1.000 0.833 0.603 1.000
# 5  -0.03 0.253 0.096 1.000 0.747 0.251 1.000
# 6   0.00 0.066 0.049 1.000 0.640 0.065 1.000
# 7   0.03 0.102 0.061 1.000 0.526 0.106 1.000
# 8   0.06 0.359 0.125 0.992 0.377 0.365 0.990
# 9   0.09 0.750 0.252 0.850 0.244 0.754 0.842
# 10  0.12 0.953 0.409 0.415 0.135 0.957 0.401
# 11  0.15 0.998 0.591 0.091 0.113 0.999 0.089
pdf("Fig_Power_Slope.pdf")
plot(Pow_Mat[,1],Pow_Mat[,2],type = "l",ylim = c(-0.05,1.05),
     main = "Power Curve for the slope parameter",ylab = "",xlab = "")
lines(Pow_Mat[,1],Pow_Mat[,3],lty=2,col=2)
lines(Pow_Mat[,1],Pow_Mat[,4],lty=3,col=3)
lines(Pow_Mat[,1],Pow_Mat[,5],lty=4,col=4)
lines(Pow_Mat[,1],Pow_Mat[,6],lty=5,col=5)
lines(Pow_Mat[,1],Pow_Mat[,7],lty=6,col=6)
legend(-0.15,0.3,c("MMD","WMD","WMDF","DL","ESC6","IIV"),
       lty = 1:6,col = 1:6)
dev.off()
#=========================================================================================>