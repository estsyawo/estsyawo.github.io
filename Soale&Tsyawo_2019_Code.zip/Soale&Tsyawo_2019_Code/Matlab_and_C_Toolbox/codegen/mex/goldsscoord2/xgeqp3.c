/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * xgeqp3.c
 *
 * Code generation for function 'xgeqp3'
 *
 */

/* Include files */
#include "mwmathutil.h"
#include "rt_nonfinite.h"
#include "goldsscoord2.h"
#include "xgeqp3.h"
#include "goldsscoord2_emxutil.h"
#include "lapacke.h"

/* Function Definitions */
void xgeqp3(emxArray_real_T *A, real_T tau_data[], int32_T tau_size[1], int32_T
            jpvt[2])
{
  int32_T m;
  ptrdiff_t jpvt_t[2];
  ptrdiff_t m_t;
  ptrdiff_t info_t;
  int32_T i5;
  int32_T loop_ub;
  m = A->size[0];
  if (A->size[0] == 0) {
    tau_size[0] = 0;
    jpvt[0] = 1;
    jpvt[1] = 2;
  } else {
    m = muIntScalarMin_sint32(m, 2);
    tau_size[0] = m;
    jpvt_t[0] = (ptrdiff_t)0;
    jpvt_t[1] = (ptrdiff_t)0;
    m_t = (ptrdiff_t)A->size[0];
    info_t = LAPACKE_dgeqp3(102, m_t, (ptrdiff_t)2, &A->data[0], m_t, &jpvt_t[0],
      &tau_data[0]);
    if ((int32_T)info_t != 0) {
      i5 = A->size[0] * A->size[1];
      A->size[1] = 2;
      emxEnsureCapacity_real_T(A, i5);
      loop_ub = A->size[0];
      for (i5 = 0; i5 < loop_ub; i5++) {
        A->data[i5] = rtNaN;
      }

      loop_ub = A->size[0];
      for (i5 = 0; i5 < loop_ub; i5++) {
        A->data[i5 + A->size[0]] = rtNaN;
      }

      for (i5 = 0; i5 < m; i5++) {
        tau_data[i5] = rtNaN;
      }

      jpvt[0] = 1;
      jpvt[1] = 2;
    } else {
      jpvt[0] = (int32_T)jpvt_t[0];
      jpvt[1] = (int32_T)jpvt_t[1];
    }
  }
}

/* End of code generation (xgeqp3.c) */
