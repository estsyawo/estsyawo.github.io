#=========================================================================================>
# Authors: Nelly Charlotte Djuazon & Emmanuel Selorm Tsyawo
# Project: Quantile and Distribution Treatment Effects on the Treated with Possibly 
#          Non-Continuous Outcomes
# Date began:   Apr. 13, 2023
# Last Update:  March 28, 2026
# Place:        Tuscaloosa, AL
#=========================================================================================>
# Comment: Simulates and evaluates the functional overidentification tests, then saves 
#          rejection rates and power-curve outputs.
#=========================================================================================>
# Load packages, clear memory,

rm(list = ls()) #clear memory

#set working directory
get_script_dir <- function() {
  cmd_args <- commandArgs(trailingOnly = FALSE)
  file_arg <- grep("^--file=", cmd_args, value = TRUE)
  if (length(file_arg) > 0) {
    p <- sub("^--file=", "", file_arg[1])
    p <- gsub("~\\+~", " ", p)
    return(dirname(normalizePath(p, winslash = "/", mustWork = FALSE)))
  }
  if (requireNamespace("rstudioapi", quietly = TRUE)) {
    p <- tryCatch(rstudioapi::getActiveDocumentContext()$path, error = function(e) "")
    if (nzchar(p)) return(dirname(p))
  }
  getwd()
}

setwd(get_script_dir())

#=========================================================================================>
# Load packages and source functions
#=========================================================================================>
library(haven)
library(pbapply)
library(ggplot2)
source("Fonctions2.R")

#=========================================================================================>
# Load data and define simulation parameters
#=========================================================================================>
set.seed(1)

donnees <- read_dta("MonthlyPanel_tab3ABC.dta")
donnees$treat <- donnees$institu1

pre_treat_mes <- 4
post_treat_mes <- 8
G_values <- c("normal", "uniform", "identity")
eta.vec = seq(0,1,by=0.1)
R = 1000 #number of Monte Carlo Replications
cl = ceiling(parallel::detectCores()*(0.75))
#=========================================================================================>
# Calibrate Monte Carlo samples to the data
#=========================================================================================>

ygrid = sort(unique(donnees$totrob))
(ygrid = sort(ygrid[ygrid <=1.0]))# truncate of the support at 1.0
F00 <- stats::ecdf(donnees$totrob[(donnees$institu1==0)&(donnees$mes<= 6)])
F01 <- stats::ecdf(donnees$totrob[(donnees$institu1==0)&(donnees$mes>= 8)])
F10 <- stats::ecdf(donnees$totrob[(donnees$institu1==1)&(donnees$mes<= 6)])
F11 <- stats::ecdf(donnees$totrob[(donnees$institu1==1)&(donnees$mes>= 8)])


#test function for evaluating the empirical size and power of the CmV and KS test
dat.samp_Ditella <- function(seed, N, eta, ygrid, F00, F01, F10, F11){
  set.seed(seed)
  stopifnot(eta<= 1 & eta >=0)
  #D = rbinom(N,1,.5)
  D = sample(1:3,size = N,replace = T)
  t = ifelse(1:N<=N/2,0,1)
  id.11=which(D==1 & t==1); n.11 = length(id.11)
  id.10=which(D==1 & t==0); n.10 = length(id.10)
  
  id.21=which(D==2 & t==1); n.21 = length(id.21)
  id.20=which(D==2 & t==0); n.20 = length(id.20)
  
  id.31=which(D==3 & t==1); n.31 = length(id.31)
  id.30=which(D==3 & t==0); n.30 = length(id.30)
  
  Q00<- left.inv(ys=ygrid, Fs=F00(ygrid))
  Q01<- left.inv(ys=ygrid, Fs=F01(ygrid))
  Q10<- left.inv(ys=ygrid, Fs=F10(ygrid))
  Q11<- left.inv(ys=ygrid, Fs=F11(ygrid))
  #Q30<- left.inv(ys=ygrid, Fs=(eta*F10(ygrid)+(1-eta)*F00(ygrid)))
  Q30<- left.inv(ys=ygrid, Fs=F00(ygrid))
  #Q31<- left.inv(ys=ygrid, Fs=(eta*F11(ygrid)+(1-eta)*F01(ygrid)))
  FF <- seq_len(length(ygrid)) / length(ygrid)
  Q31 <- left.inv(ys=ygrid, Fs=(eta*FF + (1-eta)*F01(ygrid)))
  
  stopifnot((n.11+n.10+n.21+n.20+n.31+n.30)==N)
  Y = rep(NA,N)
  Y[id.11] = Q11(runif(n.11))
  Y[id.10] = Q10(runif(n.10))
  Y[id.21] = Q01(runif(n.21))
  Y[id.20] = Q00(runif(n.20))
  Y[id.31] = Q31(runif(n.31))
  Y[id.30] = Q30(runif(n.30))
  
  stopifnot(!any(is.na(Y)))
  
  data.frame(Y,D,t)
}

# Example usage:
# sim_ex <- dat.samp_Ditella(seed = 123, N = 2000, eta = 0.5,
#                            ygrid = ygrid, F00 = F00, F01 = F01, F10 = F10, F11 = F11)

#=========================================================================================>
# Use the DGP to test the generic overid function
#=========================================================================================>

run_control_test <- function(j, eta, G_name, N = 1500, B = 999,
                             alpha_levels = c(0.01, 0.05, 0.1)) {
  sim_raw <- dat.samp_Ditella(seed = j, N = N, eta = eta,
                              ygrid = ygrid, F00 = F00, F01 = F01, F10 = F10, F11 = F11)
  
  sim_data <- data.frame(
    totrob = sim_raw$Y,
    D = sim_raw$D,
    t = sim_raw$t
  )
  sim_data$observ <- seq_len(nrow(sim_data))
  sim_data$treat <- as.integer(sim_data$D == 1)
  sim_data$mes <- ifelse(sim_data$t == 0, pre_treat_mes, post_treat_mes)
  
  ygrid_sim <- sort(unique(sim_data$totrob))
  taus_sim <- round(ecdf(sim_data$totrob)(ygrid_sim), 6)
  
  res <- functional_overid_tests_generic(
    daten = sim_data,
    group_var = "D",
    treated_value = 1,
    control_values = c(2, 3),
    post_treat_mes = post_treat_mes,
    pre_treat_mes = pre_treat_mes,
    outcome_var = "totrob",
    time_var = "mes",
    unit_var = "observ",
    G = G_name,
    ygrid = ygrid_sim,
    taus = taus_sim,
    B = B,
    compare = "controls"
  )
  
  pvals <- lapply(res$control_tests, function(x) x$pvals)
  rej <- lapply(pvals, function(p) {
    sapply(alpha_levels, function(a) p$CvM < a)
  })
  
  list(results = res$control_tests, pvals = pvals, reject = rej)
}

# Example single run
out <- run_control_test(j = 123, eta = 0.95, G_name = G_values[1])

cat("Functional overid test results (simulated data) for G =", G_values[1], ":\n")
for (m in names(out$results)) {
  cat("\nPre period:", m, "\n")
  cat("CvM_n =", out$results[[m]]$tests$CvM, "\n")
  cat("KS_n  =", out$results[[m]]$tests$KS, "\n")
  cat("CvM p-value =", out$pvals[[m]]$CvM, "\n")
  cat("KS p-value  =", out$pvals[[m]]$KS, "\n")
  cat("Reject (CvM) at alpha 0.01/0.05/0.1:", paste(out$reject[[m]], collapse = ", "), "\n")
}

#=========================================================================================>
# Loop over eta values to estimate empirical size and power
#=========================================================================================>
alpha_levels <- c(0.01, 0.05, 0.1)
cores_to_use <- max(1, ceiling(parallel::detectCores() * 0.75))
all_eta_results <- list()
if (!dir.exists("output")) dir.create("output", recursive = TRUE)

for (G_name in G_values) {
  cat("\n==================================================\n")
  cat("Running overidentification simulation for G =", G_name, "\n")

  eta_results <- list()
  for (eta in eta.vec) {
    rej_mat_cvm <- matrix(0, nrow = R, ncol = length(alpha_levels))
    rej_mat_ks <- matrix(0, nrow = R, ncol = length(alpha_levels))
    one_run <- function(j) {
      out_j <- run_control_test(j = j, eta = eta, G_name = G_name, alpha_levels = alpha_levels)
      m <- names(out_j$reject)[1]
      c(out_j$reject[[m]], as.numeric(out_j$pvals[[m]]$KS < alpha_levels))
    }
    cl <- parallel::makeCluster(cores_to_use)
    on.exit(parallel::stopCluster(cl), add = TRUE)
    parallel::clusterExport(
      cl,
      varlist = c(
        "run_control_test", "dat.samp_Ditella", "ygrid", "F00", "F01", "F10", "F11",
        "pre_treat_mes", "post_treat_mes", "alpha_levels", "eta", "G_name"
      ),
      envir = environment()
    )
    parallel::clusterEvalQ(cl, {library(haven); source("Fonctions2.R")})
    mat <- pbapply::pbsapply(1:R, FUN = one_run, cl = cl)
    mat <- t(mat)
    rej_mat_cvm <- mat[, 1:length(alpha_levels), drop = FALSE]
    rej_mat_ks <- mat[, (length(alpha_levels) + 1):(2 * length(alpha_levels)), drop = FALSE]
    eta_results[[as.character(eta)]] <- list(
      CvM = colMeans(rej_mat_cvm),
      KS = colMeans(rej_mat_ks)
    )
  }

  out_file <- file.path("output", paste0("empirical_rejection_rates_", G_name, ".txt"))
  if (file.exists(out_file)) file.remove(out_file)

  cat("\nEmpirical rejection rates by eta (CvM and KS) for G =", G_name, ":\n")
  writeLines("eta CvM_01 CvM_05 CvM_10 KS_01 KS_05 KS_10", out_file)
  for (eta in names(eta_results)) {
    rates_cvm <- eta_results[[eta]]$CvM
    rates_ks <- eta_results[[eta]]$KS
    line <- paste(
      sprintf("%.3f", as.numeric(eta)),
      sprintf("%.3f", rates_cvm[1]),
      sprintf("%.3f", rates_cvm[2]),
      sprintf("%.3f", rates_cvm[3]),
      sprintf("%.3f", rates_ks[1]),
      sprintf("%.3f", rates_ks[2]),
      sprintf("%.3f", rates_ks[3])
    )
    cat(line, "\n")
    cat(line, "\n", file = out_file, append = TRUE)
  }

  plot_file <- file.path("output", paste0("Power_Curve_", G_name, ".pdf"))
  plot.pow(out_file, filename = plot_file)
  all_eta_results[[G_name]] <- eta_results
}

#=========================================================================================>
