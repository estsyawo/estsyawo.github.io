/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * kmeans.c
 *
 * Code generation for function 'kmeans'
 *
 */

/* Include files */
#include "mwmathutil.h"
#include "rt_nonfinite.h"
#include "CCRl_clus.h"
#include "kmeans.h"
#include "CCRl_clus_emxutil.h"
#include "rand.h"
#include "CCRl_clus_data.h"

/* Function Declarations */
static void b_distfun(emxArray_real_T *D, const emxArray_real_T *X, const
                      emxArray_real_T *C, const emxArray_int32_T *crows, int32_T
                      ncrows);
static void batchUpdate(const emxArray_real_T *X, int32_T k, emxArray_int32_T
  *idx, emxArray_real_T *C, emxArray_real_T *D, emxArray_int32_T *counts,
  boolean_T *converged, int32_T *iter);
static void distfun(emxArray_real_T *D, const emxArray_real_T *X, const
                    emxArray_real_T *C, int32_T crows);
static void gcentroids(emxArray_real_T *C, emxArray_int32_T *counts, const
  emxArray_real_T *X, const emxArray_int32_T *idx, const emxArray_int32_T
  *clusters, int32_T nclusters);
static void mindim2(const emxArray_real_T *D, emxArray_real_T *d,
                    emxArray_int32_T *idx);

/* Function Definitions */
static void b_distfun(emxArray_real_T *D, const emxArray_real_T *X, const
                      emxArray_real_T *C, const emxArray_int32_T *crows, int32_T
                      ncrows)
{
  int32_T n;
  int32_T i;
  int32_T cr;
  int32_T r;
  real_T a;
  n = X->size[0];
  for (i = 0; i < ncrows; i++) {
    cr = crows->data[i] - 1;
    for (r = 0; r < n; r++) {
      a = X->data[r] - C->data[cr];
      D->data[r + D->size[0] * cr] = a * a;
    }
  }
}

static void batchUpdate(const emxArray_real_T *X, int32_T k, emxArray_int32_T
  *idx, emxArray_real_T *C, emxArray_real_T *D, emxArray_int32_T *counts,
  boolean_T *converged, int32_T *iter)
{
  emxArray_int32_T *empties;
  int32_T n;
  int32_T i;
  emxArray_int32_T *previdx;
  int32_T lonely;
  emxArray_int32_T *moved;
  emxArray_int32_T *changed;
  int32_T j;
  int32_T nchanged;
  real_T prevtotsumD;
  emxArray_real_T *d;
  emxArray_int32_T *nidx;
  emxArray_boolean_T *b;
  int32_T exitg1;
  int32_T nempty;
  int32_T b_i;
  real_T maxd;
  int32_T from;
  boolean_T exitg2;
  int32_T b_n;
  uint32_T unnamed_idx_0;
  emlrtHeapReferenceStackEnterFcnR2012b(emlrtRootTLSGlobal);
  emxInit_int32_T(&empties, 1, true);
  n = X->size[0] - 1;
  i = empties->size[0];
  empties->size[0] = k;
  emxEnsureCapacity_int32_T(empties, i);
  for (i = 0; i < k; i++) {
    empties->data[i] = 0;
  }

  emxInit_int32_T(&previdx, 1, true);
  i = previdx->size[0];
  previdx->size[0] = X->size[0];
  emxEnsureCapacity_int32_T(previdx, i);
  lonely = X->size[0];
  for (i = 0; i < lonely; i++) {
    previdx->data[i] = 0;
  }

  emxInit_int32_T(&moved, 1, true);
  i = moved->size[0];
  moved->size[0] = X->size[0];
  emxEnsureCapacity_int32_T(moved, i);
  lonely = X->size[0];
  for (i = 0; i < lonely; i++) {
    moved->data[i] = 0;
  }

  emxInit_int32_T(&changed, 1, true);
  i = changed->size[0];
  changed->size[0] = k;
  emxEnsureCapacity_int32_T(changed, i);
  for (j = 0; j < k; j++) {
    changed->data[j] = j + 1;
  }

  nchanged = k;
  prevtotsumD = rtInf;
  *iter = 0;
  *converged = false;
  emxInit_real_T(&d, 1, true);
  emxInit_int32_T(&nidx, 1, true);
  emxInit_boolean_T(&b, 1, true);
  do {
    exitg1 = 0;
    (*iter)++;
    gcentroids(C, counts, X, idx, changed, nchanged);
    b_distfun(D, X, C, changed, nchanged);
    nempty = -1;
    for (j = 0; j < nchanged; j++) {
      if (counts->data[changed->data[j] - 1] == 0) {
        nempty++;
        empties->data[nempty] = changed->data[j];
      }
    }

    if (nempty + 1 > 0) {
      for (b_i = 0; b_i <= nempty; b_i++) {
        i = d->size[0];
        d->size[0] = n + 1;
        emxEnsureCapacity_real_T(d, i);
        d->data[0] = D->data[D->size[0] * (idx->data[0] - 1)];
        maxd = d->data[0];
        lonely = 0;
        for (j = 0; j <= n; j++) {
          d->data[j] = D->data[j + D->size[0] * (idx->data[j] - 1)];
          if (d->data[j] > maxd) {
            maxd = d->data[j];
            lonely = j;
          }
        }

        from = idx->data[lonely] - 1;
        if (counts->data[idx->data[lonely] - 1] < 2) {
          j = 0;
          exitg2 = false;
          while ((!exitg2) && (j <= n)) {
            if (counts->data[j] > 1) {
              from = j;
              exitg2 = true;
            } else {
              j++;
            }
          }

          j = 0;
          exitg2 = false;
          while ((!exitg2) && (j <= n)) {
            if (idx->data[j] == from + 1) {
              lonely = j;
              exitg2 = true;
            } else {
              j++;
            }
          }
        }

        C->data[empties->data[b_i] - 1] = X->data[lonely];
        counts->data[empties->data[b_i] - 1] = 1;
        idx->data[lonely] = empties->data[b_i];
        distfun(D, X, C, empties->data[b_i]);
        b_n = X->size[0];
        counts->data[from] = 0;
        C->data[from] = rtNaN;
        lonely = 0;
        C->data[from] = 0.0;
        for (i = 0; i < b_n; i++) {
          if (idx->data[i] == from + 1) {
            lonely++;
            C->data[from] += X->data[i];
          }
        }

        counts->data[from] = lonely;
        C->data[from] /= (real_T)lonely;
        distfun(D, X, C, from + 1);
        if (nchanged < k) {
          j = 0;
          exitg2 = false;
          while ((!exitg2) && ((j <= nchanged - 1) && (from + 1 != changed->
                   data[j]))) {
            if (from + 1 > changed->data[j]) {
              for (b_n = nchanged; b_n >= j + 1; b_n--) {
                changed->data[b_n] = changed->data[b_n - 1];
              }

              changed->data[j] = from + 1;
              nchanged++;
              exitg2 = true;
            } else {
              j++;
            }
          }
        }
      }
    }

    maxd = 0.0;
    for (b_i = 0; b_i <= n; b_i++) {
      maxd += D->data[b_i + D->size[0] * (idx->data[b_i] - 1)];
    }

    if (prevtotsumD <= maxd) {
      i = idx->size[0];
      idx->size[0] = previdx->size[0];
      emxEnsureCapacity_int32_T(idx, i);
      lonely = previdx->size[0];
      for (i = 0; i < lonely; i++) {
        idx->data[i] = previdx->data[i];
      }

      gcentroids(C, counts, X, previdx, changed, nchanged);
      (*iter)--;
      exitg1 = 1;
    } else if (*iter >= 100) {
      exitg1 = 1;
    } else {
      i = previdx->size[0];
      previdx->size[0] = idx->size[0];
      emxEnsureCapacity_int32_T(previdx, i);
      lonely = idx->size[0];
      for (i = 0; i < lonely; i++) {
        previdx->data[i] = idx->data[i];
      }

      prevtotsumD = maxd;
      mindim2(D, d, nidx);
      b_n = -1;
      for (b_i = 0; b_i <= n; b_i++) {
        if ((nidx->data[b_i] != previdx->data[b_i]) && (D->data[b_i + D->size[0]
             * (previdx->data[b_i] - 1)] > d->data[b_i])) {
          b_n++;
          moved->data[b_n] = b_i + 1;
          idx->data[b_i] = nidx->data[b_i];
        }
      }

      if (b_n + 1 == 0) {
        *converged = true;
        exitg1 = 1;
      } else {
        unnamed_idx_0 = (uint32_T)moved->size[0];
        i = b->size[0];
        b->size[0] = (int32_T)unnamed_idx_0;
        emxEnsureCapacity_boolean_T(b, i);
        lonely = (int32_T)unnamed_idx_0;
        for (i = 0; i < lonely; i++) {
          b->data[i] = false;
        }

        for (j = 0; j <= b_n; j++) {
          b->data[idx->data[moved->data[j] - 1] - 1] = true;
          b->data[previdx->data[moved->data[j] - 1] - 1] = true;
        }

        nchanged = 0;
        i = b->size[0];
        for (j = 0; j < i; j++) {
          if (b->data[j]) {
            nchanged++;
            changed->data[nchanged - 1] = j + 1;
          }
        }
      }
    }
  } while (exitg1 == 0);

  emxFree_boolean_T(&b);
  emxFree_int32_T(&nidx);
  emxFree_real_T(&d);
  emxFree_int32_T(&changed);
  emxFree_int32_T(&moved);
  emxFree_int32_T(&previdx);
  emxFree_int32_T(&empties);
  emlrtHeapReferenceStackLeaveFcnR2012b(emlrtRootTLSGlobal);
}

static void distfun(emxArray_real_T *D, const emxArray_real_T *X, const
                    emxArray_real_T *C, int32_T crows)
{
  int32_T n;
  int32_T r;
  real_T a;
  n = X->size[0];
  for (r = 0; r < n; r++) {
    a = X->data[r] - C->data[crows - 1];
    D->data[r + D->size[0] * (crows - 1)] = a * a;
  }
}

static void gcentroids(emxArray_real_T *C, emxArray_int32_T *counts, const
  emxArray_real_T *X, const emxArray_int32_T *idx, const emxArray_int32_T
  *clusters, int32_T nclusters)
{
  int32_T n;
  int32_T ic;
  int32_T clic;
  int32_T cc;
  int32_T i;
  n = X->size[0];
  for (ic = 0; ic < nclusters; ic++) {
    counts->data[clusters->data[ic] - 1] = 0;
    C->data[clusters->data[ic] - 1] = rtNaN;
  }

  for (ic = 0; ic < nclusters; ic++) {
    clic = clusters->data[ic];
    cc = 0;
    C->data[clusters->data[ic] - 1] = 0.0;
    for (i = 0; i < n; i++) {
      if (idx->data[i] == clic) {
        cc++;
        C->data[clic - 1] += X->data[i];
      }
    }

    counts->data[clusters->data[ic] - 1] = cc;
    C->data[clusters->data[ic] - 1] /= (real_T)cc;
  }
}

static void mindim2(const emxArray_real_T *D, emxArray_real_T *d,
                    emxArray_int32_T *idx)
{
  int32_T n;
  int32_T k;
  int32_T outsize_idx_0;
  int32_T i;
  n = D->size[0];
  k = D->size[1];
  outsize_idx_0 = D->size[0];
  i = d->size[0];
  d->size[0] = outsize_idx_0;
  emxEnsureCapacity_real_T(d, i);
  for (i = 0; i < outsize_idx_0; i++) {
    d->data[i] = rtInf;
  }

  i = idx->size[0];
  idx->size[0] = D->size[0];
  emxEnsureCapacity_int32_T(idx, i);
  outsize_idx_0 = D->size[0];
  for (i = 0; i < outsize_idx_0; i++) {
    idx->data[i] = 1;
  }

  for (outsize_idx_0 = 0; outsize_idx_0 < k; outsize_idx_0++) {
    for (i = 0; i < n; i++) {
      if (D->data[i + D->size[0] * outsize_idx_0] < d->data[i]) {
        idx->data[i] = outsize_idx_0 + 1;
        d->data[i] = D->data[i + D->size[0] * outsize_idx_0];
      }
    }
  }
}

void local_kmeans(const emxArray_real_T *X, int32_T k, emxArray_int32_T *idxbest,
                  emxArray_real_T *Cbest)
{
  int32_T n;
  real_T b_index;
  int32_T low_i;
  emxArray_real_T *D;
  int32_T high_i;
  emxArray_real_T *d;
  emxArray_real_T *sampleDist;
  boolean_T DNeedsComputing;
  int32_T c;
  boolean_T exitg1;
  emxArray_int32_T *crows;
  int32_T low_ip1;
  int32_T mid_i;
  emxArray_int32_T *nonEmpties;
  real_T pt;
  real_T u;
  emlrtHeapReferenceStackEnterFcnR2012b(emlrtRootTLSGlobal);
  n = X->size[0] - 1;
  b_index = c_rand();
  low_i = Cbest->size[0];
  Cbest->size[0] = k;
  emxEnsureCapacity_real_T(Cbest, low_i);
  for (low_i = 0; low_i < k; low_i++) {
    Cbest->data[low_i] = 0.0;
  }

  emxInit_real_T(&D, 2, true);
  Cbest->data[0] = X->data[(int32_T)(1.0 + muDoubleScalarFloor(b_index * (real_T)
    X->size[0])) - 1];
  low_i = D->size[0] * D->size[1];
  D->size[0] = X->size[0];
  D->size[1] = k;
  emxEnsureCapacity_real_T(D, low_i);
  high_i = X->size[0] * k;
  for (low_i = 0; low_i < high_i; low_i++) {
    D->data[low_i] = 0.0;
  }

  emxInit_real_T(&d, 1, true);
  distfun(D, X, Cbest, 1);
  high_i = D->size[0];
  low_i = d->size[0];
  d->size[0] = high_i;
  emxEnsureCapacity_real_T(d, low_i);
  for (low_i = 0; low_i < high_i; low_i++) {
    d->data[low_i] = D->data[low_i];
  }

  low_i = idxbest->size[0];
  idxbest->size[0] = X->size[0];
  emxEnsureCapacity_int32_T(idxbest, low_i);
  high_i = X->size[0];
  for (low_i = 0; low_i < high_i; low_i++) {
    idxbest->data[low_i] = 1;
  }

  emxInit_real_T(&sampleDist, 1, true);
  low_i = sampleDist->size[0];
  sampleDist->size[0] = X->size[0] + 1;
  emxEnsureCapacity_real_T(sampleDist, low_i);
  high_i = X->size[0];
  for (low_i = 0; low_i <= high_i; low_i++) {
    sampleDist->data[low_i] = 0.0;
  }

  DNeedsComputing = false;
  c = 2;
  exitg1 = false;
  while ((!exitg1) && (c <= k)) {
    b_index = 0.0;
    sampleDist->data[0] = 0.0;
    for (low_i = 0; low_i <= n; low_i++) {
      sampleDist->data[low_i + 1] = sampleDist->data[low_i] + d->data[low_i];
      b_index += d->data[low_i];
    }

    if ((b_index == 0.0) || (muDoubleScalarIsInf(b_index) || muDoubleScalarIsNaN
         (b_index))) {
      low_ip1 = k - c;
      mid_i = 0;
      low_i = idxbest->size[0];
      idxbest->size[0] = n + 1;
      emxEnsureCapacity_int32_T(idxbest, low_i);
      for (low_i = 0; low_i <= n; low_i++) {
        idxbest->data[low_i] = 0;
      }

      for (high_i = 0; high_i <= low_ip1; high_i++) {
        low_i = (low_ip1 - high_i) + 1;
        b_index = (n - mid_i) + 1;
        pt = (real_T)low_i / b_index;
        u = c_rand();
        while (u > pt) {
          mid_i++;
          b_index--;
          pt += (1.0 - pt) * ((real_T)low_i / b_index);
        }

        mid_i++;
        b_index = c_rand() * (real_T)(high_i + 1);
        b_index = muDoubleScalarFloor(b_index);
        idxbest->data[high_i] = idxbest->data[(int32_T)b_index];
        idxbest->data[(int32_T)b_index] = mid_i;
      }

      for (low_i = c; low_i <= k; low_i++) {
        Cbest->data[low_i - 1] = X->data[idxbest->data[low_i - c] - 1];
      }

      DNeedsComputing = true;
      exitg1 = true;
    } else {
      low_i = sampleDist->size[0];
      emxEnsureCapacity_real_T(sampleDist, low_i);
      high_i = sampleDist->size[0];
      for (low_i = 0; low_i < high_i; low_i++) {
        sampleDist->data[low_i] /= b_index;
      }

      b_index = c_rand();
      high_i = sampleDist->size[0];
      low_i = 1;
      low_ip1 = 2;
      while (high_i > low_ip1) {
        mid_i = (low_i >> 1) + (high_i >> 1);
        if (((low_i & 1) == 1) && ((high_i & 1) == 1)) {
          mid_i++;
        }

        if (b_index >= sampleDist->data[mid_i - 1]) {
          low_i = mid_i;
          low_ip1 = mid_i + 1;
        } else {
          high_i = mid_i;
        }
      }

      b_index = sampleDist->data[low_i - 1];
      if (sampleDist->data[low_i - 1] < 1.0) {
        while ((low_i <= n + 1) && (sampleDist->data[low_i] <= b_index)) {
          low_i++;
        }
      } else {
        while ((low_i >= 2) && (sampleDist->data[low_i - 2] >= b_index)) {
          low_i--;
        }
      }

      Cbest->data[c - 1] = X->data[low_i - 1];
      distfun(D, X, Cbest, c);
      for (low_i = 0; low_i <= n; low_i++) {
        if (D->data[low_i + D->size[0] * (c - 1)] < d->data[low_i]) {
          d->data[low_i] = D->data[low_i + D->size[0] * (c - 1)];
          idxbest->data[low_i] = c;
        }
      }

      c++;
    }
  }

  emxFree_real_T(&sampleDist);
  emxInit_int32_T(&crows, 1, true);
  if (DNeedsComputing) {
    low_i = crows->size[0];
    crows->size[0] = k;
    emxEnsureCapacity_int32_T(crows, low_i);
    for (c = 0; c < k; c++) {
      crows->data[c] = c + 1;
    }

    b_distfun(D, X, Cbest, crows, k);
    mindim2(D, d, idxbest);
  }

  emxFree_real_T(&d);
  low_i = crows->size[0];
  crows->size[0] = k;
  emxEnsureCapacity_int32_T(crows, low_i);
  for (low_i = 0; low_i < k; low_i++) {
    crows->data[low_i] = 0;
  }

  for (low_i = 0; low_i <= n; low_i++) {
    crows->data[idxbest->data[low_i] - 1]++;
  }

  emxInit_int32_T(&nonEmpties, 1, true);
  low_i = nonEmpties->size[0];
  nonEmpties->size[0] = k;
  emxEnsureCapacity_int32_T(nonEmpties, low_i);
  for (low_i = 0; low_i < k; low_i++) {
    nonEmpties->data[low_i] = 0;
  }

  batchUpdate(X, k, idxbest, Cbest, D, crows, &DNeedsComputing, &high_i);
  high_i = 0;
  for (low_i = 0; low_i < k; low_i++) {
    if (crows->data[low_i] > 0) {
      high_i++;
      nonEmpties->data[high_i - 1] = low_i + 1;
    }
  }

  emxFree_int32_T(&crows);
  b_distfun(D, X, Cbest, nonEmpties, high_i);
  emxFree_real_T(&D);
  emxFree_int32_T(&nonEmpties);
  emlrtHeapReferenceStackLeaveFcnR2012b(emlrtRootTLSGlobal);
}

/* End of code generation (kmeans.c) */
