setwd("C:/Users/Almeida/Dropbox/Nasah&Marcus (1)/Codes_Soale_Tsyawo_2018")
source("CC_Sequential_opt.R")
#source("CC_Sequential_lm.R")
source("Functions1.R")
source("Functions.R")
source("order_determination.R")
library(tictoc)
library(pracma)
library(quantreg)
library(glmnet)
library(mvtnorm)
library(pls)
library(dr)
library(HDCI)

#rm(list=ls())
### functions 
proj <- function(x){
  if(!class(x)=="matrix") x <- as.matrix(x)
 return(x%*%solve(t(x)%*%x)%*%t(x))
}

ar1cor <- function(p,rho){
 if(rho==0){
   sigma = diag(p)
  }else{
   sigma = rho^abs(outer(1:p,1:p,'-'))
   }
return(sigma)
}

matpower <- function(A,n){
  A = round((A+t(A))/2,7)
  tmp = eigen(A)
  return(tmp$vectors%*%diag((tmp$values)^n)%*%t(tmp$vectors))
}


pcrb <- function(X,Y,q){
 X = t((t(X)-apply(X,2,mean)))
 n = nrow(X)
 sigma = cov(X)
 C = (t(X)%*%Y)/n
 G = eigen(sigma)$vectors[,1:q]
 return(G%*%solve(t(G)%*%sigma%*%G)%*%t(G)%*%C)
}


plsb <- function(X,Y,q){
 X = t((t(X)-apply(X,2,mean)))
 n = nrow(X)
 sigma = cov(X)
 C = (t(X)%*%Y)/n
 G = C
 for(i in 1:(q-1)) G=cbind(G,matpower(sigma,i)%*%C)
 return(G%*%solve(t(G)%*%sigma%*%G)%*%t(G)%*%C)
}


###### Simulations for the linear case ########
n <- 30
p <- 36
h <- 2
nsim <- 1000
ncol <- 6 
params <- matrix(NA,nsim,ncol)
rho <- 0
#k <- 12

B1 <- rep(1:6, ceiling(p/6))
B2 <- B1[1:p]
bs <- c(-2:3)-0.5
beta <- bs[B2]

kstar=length(unique(beta))

for(j in 1:nsim){

set.seed(j)
#X = matrix(runif(n*p,-2,4.5),ncol = p)
sig = ar1cor(p,rho)
X=rmvnorm(n, mean=rep(0,p), sigma = sig)
Y = X%*%beta+rnorm(n)

### OLS
#betaOLS <- coef(lm(Y~X))[-1]

##### two-stage Lasso
lmdcv <- escv.glmnet(X, Y)
betaLASSO <- LassoOLS(X,Y, lambda = lmdcv$lambda.cv)$beta

##### CCR
### choosing k
CCrlsob1 <- CCRls(Y,X,model="lm")
 K <- 2:min(p,n)
 bic_Vec <- numeric()
 for(i in 1:length(K)){ 
    bic_Vec[i] <- CCRk2(k=K[i],betas = CCrlsob1$betas[-1],Y,X) 
  }
ks=(which.min(bic_Vec)+1)
 
CCrlsob <- CCRls(Y,X,model="lm")
CCRobj <- CCRk2(k=ks,betas = CCrlsob$betas[-1],Y,X)  ### k=(k-1)
betaCCR <- c(coef(CCRobj$regobj)[1],(coef(CCRobj$regobj)[-1][CCRobj$clus]))[-1]

#pcr_model <- pcr(Y~X, scale=TRUE,validation="CV",jackknife=TRUE)
#loadings(pcr_model)
#plot(RMSEP(pcr_model))
q=26
#betaPCR <- coef(jack.test(pcr_model,ncomp=q))
betaPCR <- pcrb(X,Y,q)


#plsr_model <- plsr(Y~X, scale=TRUE,validation="CV")
#plot(RMSEP(plsr_model))
q1 = 5
betaPLSR <- plsb(X,Y,q1)


#ladle(X,Y,5,nboot=200,method="sir",ytype="continuous")
#betaSIR <- dr(Y~X, numdir="2",method="sir",nslices=h)$evectors[,1]


#params[j,1] = Norm(beta-betaOLS,p=1)/p  #norm(proj(beta)-proj(betaOLS),type="F")^2  
params[j,2] = Norm(beta-betaLASSO,p=1)/p #norm(proj(beta)-proj(betaLASSO),type="F")^2  #
params[j,3] = Norm(beta-betaCCR,p=1)/p   #norm(proj(beta)-proj(betaCCR),type="F")^2   #
params[j,4] = Norm(beta-betaPCR,p=1)/p   #norm(proj(beta)-proj(betaPCR),type="F")^2   #
params[j,5] = Norm(beta-betaPLSR,p=1)/p  #norm(proj(beta)-proj(betaPLSR),type="F")^2   #
#params[j,6] = Norm(beta-betaSIR,p=1)/p   #norm(proj(beta)-proj(betaSIR),type="F")^2   #

}

round(apply(params,2,mean,na.rm=TRUE),5)
round(apply(params,2,median,na.rm=TRUE),5)
round(apply(params,2,sd,na.rm=TRUE),5)


########################################################################################
#
###################### Simulations for the non-linear case
n <- 90
p <- 36
nsim <- 1000
ncol <- 2
params <- matrix(NA,nsim,ncol)
rho <- 0

B1 <- rep(1:6, ceiling(p/6))
B2 <- B1[1:p]
bs <- c(-2:3)
beta <- bs[B2]

kstar=length(unique(beta))

for(j in 1:nsim){

set.seed(j)
#X = matrix(runif(n*p,-2,4.5),ncol = p)
sig = ar1cor(p,rho)
X=rmvnorm(n, mean=rep(0,p), sigma = sig)
Y = X%*%beta+rnorm(n)

### LAD
#betaLAD <- coef(rq(Y~X))[-1]

##### CCR
### choosing k
CCrlsob1 <- CCRls(Y,X,model="quantreg")
 K <- 2:min(p,n)
 bic_Vec <- numeric()
 for(i in 1:length(K)){ 
    bic_Vec[i] <- CCRk2(k=K[i],betas = CCrlsob1$betas[-1],Y,X) 
  }
ks=(which.min(bic_Vec)+1)
 
CCrlsob <- CCRls(Y,X,model="quantreg")
CCRobj <- CCRk2(k=ks,betas = CCrlsob$betas[-1],Y,X)  ### k=(k-1)
betaCCR <- c(coef(CCRobj$regobj)[1],(coef(CCRobj$regobj)[-1][CCRobj$clus]))[-1]


#params[j,1] = Norm(beta-betaLAD,p=1)/p  #norm(proj(beta)-proj(betaOLS),type="F")^2  
params[j,2] = Norm(beta-betaCCR,p=1)/p   #norm(proj(beta)-proj(betaCCR),type="F")^2   #
}

round(apply(params,2,mean,na.rm=TRUE),5)
round(apply(params,2,median,na.rm=TRUE),5)
round(apply(params,2,sd,na.rm=TRUE),5)














############# simulations using Lasso #########################
n <- 30
p <- 12
nrow <- 100
biases <- NULL
mses <- NULL
set.seed(14)
beta <- sample(-2:3,p,replace = TRUE) # simulate parameters
lambda <- 10^seq(10, -2, length = 100)
rho <- 0.5
for(j in 1:nrow){
set.seed(j)
#X = matrix(runif((n*(p-1)),-2,4.5),ncol = (p-1))
sig = ar1cor(p,rho)
X=rmvnorm(n, mean=rep(0,p), sigma = sig)
Y = X%*%beta+rnorm(n)

#train = sample(1:nrow(X), round(0.7*nrow(X)))
#test = c(1:nrow(X))[-c(train)]
fit_cv <- cv.glmnet(X,Y,alpha=1,lambda=lambda,nfold=5)
fit_lasso <- glmnet(X,Y,alpha=1,lambda=fit_cv$lambda.min)
betas <- coef(fit_lasso)
pred <- predict(fit_lasso, s=fit_cv$lambda.min, newx = X)
mse <- sum((pred - Y)^2)/fit_lasso$df

biases <- c(biases, Norm(beta[-1]-betas[-1],p=1)/p)
mses <- c(mses,mse)
}
round(mean(biases),5)
round(median(biases),5)
round(sd(biases),5)

round(mean(mses),5)
round(median(mses),5)
round(sd(mses),5)


##################### BIC search for K #######################
#                                                            #
##############################################################
n <- 90
p <- 36 
nrow <- 100
ncol <- 2
params <- matrix(NA,nrow,ncol)
kvec <- numeric()
rho <- 0.5
k <- 12
set.seed(14)
beta <- sample(-2:3,p,replace = TRUE) # simulate parameters
table(beta)
kstar=length(unique(beta))

for(i in 1:nrow){
  set.seed(i)
  sig = ar1cor(p,rho)
  X=rmvnorm(n, mean=rep(0,p), sigma = sig)
  Y = X%*%beta+rnorm(n)

 CCrlsob <- CCRls(Y,X,model="lm")
 K <- 2:k
 bic_Vec <- numeric()
 for(j in 1:length(K)){ 
    bic_Vec[j] <- CCRk2(k=K[j],betas = CCrlsob$betas[-1],Y,X) 
  }
 ks=(which.min(bic_Vec)+1)
 CCRobj <- CCRk2(k=ks,betas = CCrlsob$betas[-1],Y,X)
 BETS <- c(coef(CCRobj$regobj)[1],(coef(CCRobj$regobj)[-1][CCRobj$clus]))
 #bet <- coef(lm(Y~X))
 #params[i,1] <- Norm(beta-bet[-1],p=1)/p
 params[i,2] <- Norm(beta-BETS[-1],p=1)/p
 kvec[i] <- ks
 
}
round(mean(params[,1]),5);round(median(params[,1]),5);round(sd(params[,1]),5)
round(mean(params[,2]),5);round(median(params[,2]),5);round(sd(params[,2]),5)

table(kvec)




#################### Simulations using sequential methods without clusters #########
#
####################################################################################
n <- 30
p <-  24 #1.2*n
nrow <- 100
ncol <- p+3
params <- matrix(NA,nrow,ncol)
k <- 12
set.seed(14)
beta <- sample(-2:3,p,replace = TRUE) # simulate parameters

for(j in 1:nrow){
set.seed(j)
X = matrix(runif((n*(p-1)),-2,4.5),ncol = (p-1))
Y = cbind(1,X)%*%matrix(beta,ncol = 1)+rnorm(n)
CCrlsob <- CCRls(Y,X,model="lm") ## sequential method
bet <- coef(lm(Y~X))
params[j,1:p] <- CCrlsob$beta
params[j,(p+1)] <- CCrlsob$iter
params[j,(p+2)] <- Norm(beta[-1]-CCrlsob$beta[-1],p=1)/p
params[j,(p+3)] <- Norm(beta[-1]-bet[-1],p=1)/p
}
apply(params, 2, mean)
apply(params, 2, median)
apply(params, 2, sd)
#write.csv(params,"params1.csv")




############ cluster parameters ##################################

setwd("C:/Users/Almeida/Dropbox/Nasah&Marcus/Sim_results")
list.files()

n <- 30
p <- 1.2*n
k <- 6
set.seed(14)
beta <- sample(-2:3,p,replace = TRUE) 
params1 <- read.csv("cparams4_LAD for p = 1.2n.csv", header=T)
misclus <- numeric(2000)
for(i in 1:2000){
misclus[i] <- p-sum(diag(table(dcluspar(k,beta),dcluspar(k=7,as.numeric(params1[i,1:p])))))
}
summary(misclus)

#misclus[i] <- sum(abs(dcluspar(k,beta)-dcluspar(k,as.numeric(params1[i,1:p]))))



