/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * CCRls2_initialize.c
 *
 * Code generation for function 'CCRls2_initialize'
 *
 */

/* Include files */
#include "rt_nonfinite.h"
#include "CCRls2.h"
#include "CCRls2_initialize.h"
#include "_coder_CCRls2_mex.h"
#include "CCRls2_data.h"

/* Function Declarations */
static void CCRls2_once(void);

/* Function Definitions */
static void CCRls2_once(void)
{
  static const int32_T lineInfo[58] = { 4, 5, 6, 7, 9, 10, 11, 12, 13, 14, 16,
    17, 18, 19, 20, 21, 22, 23, 24, 27, 28, 29, 30, 31, 32, 33, 35, 36, 37, 38,
    40, 41, 42, 43, 44, 45, 46, 48, 49, 50, 51, 52, 53, 54, 55, 57, 58, 59, 60,
    61, 63, 64, 65, 66, 67, 68, 69, 70 };

  CCRls2_complete_name =
    "/Users/Selorm/Dropbox/Nasah_Marcus/Codes_Soale_Tsyawo_2018/Matlab_and_C_Toolbox/CCRls2.m>CCRls2(codegen)";
  isMexOutdated = emlrtProfilerCheckMEXOutdated();
  emlrtProfilerRegisterMEXFcn(CCRls2_complete_name,
    "/Users/Selorm/Dropbox/Nasah_Marcus/Codes_Soale_Tsyawo_2018/Matlab_and_C_Toolbox/CCRls2.m",
    "CCRls2", 58, lineInfo, isMexOutdated);
}

void CCRls2_initialize(void)
{
  mexFunctionCreateRootTLS();
  emlrtBreakCheckR2012bFlagVar = emlrtGetBreakCheckFlagAddressR2012b();
  emlrtClearAllocCountR2012b(emlrtRootTLSGlobal, false, 0U, 0);
  emlrtEnterRtStackR2012b(emlrtRootTLSGlobal);
  if (emlrtFirstTimeR2012b(emlrtRootTLSGlobal)) {
    CCRls2_once();
  }
}

/* End of code generation (CCRls2_initialize.c) */
