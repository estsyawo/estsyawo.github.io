library(pracma)
library(energy)
library(quantreg)
#---------------------------------------------------------------------------->
# the bootstrap covariance estimator
mdepreg.fit<- function(Y,X,Z=X,se="ker",Rmat=NULL,strtpar=NULL,Zmat=NULL,
                       B=999,Pwll=TRUE,hs=TRUE,ns=NULL,cls=NULL){ #l is a dummy counter
  X = as.matrix(X)
  #generate starting values use qreg
  if(is.null(strtpar)){
    if(is.null(ns)){ns=100}
    dmobj=diffmat2(u=Y[1:ns],Jx=X[1:ns,],Z=Z[1:ns,]) #pre-process data
    parq = jrq.wfit(x=as.matrix(dmobj$zJtld[,-1]), y=dmobj$m[,3], tau = 0.5, weights=dmobj$zJtld[,1])
    strtpar = parq$coefficients
  }
  #use starting values to obain parameter estimates
  par0=regdCov.lm(b0=strtpar,Y=Y,X=X,Z=Z,Zmat=Zmat)
  lc = X%*%c(par0)
  uo = Y - lc#; uo = uo-mean(uo)
  
  if(se=="ker"){
    #compute asymptotic covariance matrix
    vcdC=vcovdCov.Haj(theta=par0,Y=Y,X=X,Z=Z,Pwll=Pwll,hs=hs)
    ste = sqrt(diag(vcdC$vcdC))
  }else if(se=="boot"){
    #for the non-parametric bootstrap
    if(is.null(Rmat)){
      n = length(Y)
      Rmat = matrix(sample(1:n,n*B,replace = TRUE),n,B) #matrix to store randomly drawn matrices
    }
    fn=function(j){ #reg function
      id = Rmat[,j]
      thet=regdCov.lm(b0=strtpar,Y=Y[id],X=X[id,],Z=Z[id,],Zmat=Zmat[id,id])
      thet
    }
    if(is.null(cls)){
      mt = sapply(1:ncol(Rmat), fn)
      }else{mt = pbapply::pbsapply(1:ncol(Rmat), fn,cl=cls)}
    vcdC = list(); vcdC$vcdC=cov(t(mt))
    ste = apply(mt,1,IQR)/1.349 #robust estimate of the standard deviation
  }else if(se=="numderiv"){
    u.fun = function(par0,Y,X){Y - as.matrix(X)%*%c(par0)}
    Xg.fun = function(par0,X){X}
    
    vcdC=vcovdCov.Haj_nd(theta.hat=par0,u.fun=u.fun,Xg.fun=Xg.fun,Y=Y,X=X,Z=Z,
                         Intercept=F,hn.fun=NULL)
    ste = sqrt(diag(vcdC$vcdC))
    
  }else{stop("se method not recognised.")}
  
  #-----------------------------------------------------------------------------

  #-----------------------------------------------------------------------------
  
  res = list()
  res$coefficients = par0
  res$std.error = ste
  res$vcov = vcdC$vcdC
  res$residuals = uo 
  res$fitted.values = lc
  res$X = X; res$Z = Z
  res
}
#---------------------------------------------------------------------------->

#---------------------------------------------------------------------------->
# MDep fit with generic models via parameterised error u.fun(Y,X)
mdepreg.fit2<- function(u.fun,Xg.fun,Y,X,Z=X,Intercept=F,strtpar,Zmat=NULL,Rmat=NULL,
                        se="ker",B=399,cls=NULL,
                        Pwll=TRUE,hs=TRUE,ns=NULL){ #l is a dummy counter
  if(Intercept){
    X = as.matrix(cbind(X,1))
  }else{
    X = as.matrix(X)
  }
  
  #use starting values to obain parameter estimates
  par0=regdCov.nlm(b0=strtpar,u.fun=u.fun,Y=Y,X=X,Z=Z,Zmat=Zmat) 
  #compute asymptotic covariance matrix
  uo = u.fun(par0,Y,X)
  lc = Y - uo
  
  if(se=="ker"){
    Xg = Xg.fun(par0,X)
    vcdC = vcovdCov.Haj2(u=uo,Xg=Xg,Z=Z,Pwll=Pwll,hs=hs)
    ste = sqrt(diag(vcdC$vcdC))
  }else if(se=="boot"){
    #for the non-parametric bootstrap
    if(is.null(Rmat)){
      n = length(Y)
      Rmat = matrix(sample(1:n,n*B,replace = TRUE),n,B) #matrix to store randomly drawn matrices
    }
    fn=function(j){ #reg function
      id = Rmat[,j]
      thet=regdCov.nlm(b0=strtpar,u.fun=u.fun,Y=Y[id],X=X[id,],Z=Z[id,],
                       Zmat=Zmat[id,id])
      thet
    }
    if(is.null(cls)){
      mt = sapply(1:ncol(Rmat), fn)
    }else{mt = pbapply::pbsapply(1:ncol(Rmat), fn,cl=cls)}
    vcdC = list(); vcdC$vcdC=cov(t(mt))

    if(!is.null(nrow(mt))){
      ste = apply(mt,1,IQR)/1.349 #robust estimate of the standard deviation
      #ste = apply(mt,1,mad)/0.6745
    }else{
      ste = IQR(c(mt))/1.349 #robust estimate of the standard deviation
      #ste = mad(c(mt))/0.6745 #robust estimate of the standard deviation
    }
    
  }else if(se=="numderiv"){
    vcdC=vcovdCov.Haj_nd(theta.hat=par0,u.fun=u.fun,Xg.fun=Xg.fun,Y=Y,X=X,Z=Z,
                         Intercept=Intercept,hn.fun=NULL)
    ste = sqrt(diag(vcdC$vcdC))
    
    
  }else{stop("se method not recognised.")}
  
  res = list()
  res$coefficients = par0
  res$std.error = ste
  res$vcov = vcdC$vcdC
  res$residuals = uo #residuals contain the intercept
  res$fitted.values = lc
  res$X = X; res$Z = Z
  res
}
#---------------------------------------------------------------------------->


#-------------------------------
fdCov.lm <- function(b,Y,X,Z=X,Zmat=NULL,weights=NULL){
  X = as.matrix(X)
  b = c(b)
  if(length(b)!=ncol(X)){stop("Length of b and ncol(X) must be equal.")}
  if(is.null(weights)){
    u = Y-X%*%c(b)
  }else{
    u = (Y-X%*%c(b))*weights
  }
  n = length(Y)
  if(is.null(Zmat)){
    ans=n*dcov(u,Z)^2
  }else{
    if(ncol(Zmat)!=nrow(X)){stop("ncol(Zmat) is not equal to n.")}
  }
  ans
}
#-------------------------------

#-------------------------------
# function generating the error: u.fun(b,Y,X)
fdCov.nlm <- function(b,u.fun,Y,X,Z=X,Zmat=NULL){
  
  n = length(Y)
  if(is.null(Zmat)){
    ans=n*dcov(u.fun(b,Y,X), Z)^2
  }else{
    if(ncol(Zmat)!=nrow(X)){stop("ncol(Zmat) is not equal to n.")}
  }
  ans
}
#-------------------------------


#---------------------------------------------------------------------------->
regdCov.lm <- function(b0,Y,X,Z=X,Zmat=NULL,weights=NULL){
  X = as.matrix(X)
  if(ncol(X)==1){ #univariate case
    if(length(b0)==1){
      ans=optimise(f=fdCov.lm,interval=(b0+c(-1.5,1.5)),Y=Y,X=X,Z=Z,Zmat=Zmat,weights=weights)$minimum
    }else{
      ans=optimise(f=fdCov.lm,interval=b0,Y=Y,X=X,Z=Z,Zmat=Zmat,weights=weights)$minimum 
      }
  }else{
    ans=optim(par=b0,fn=fdCov.lm,Y=Y,X=X,Z=Z,Zmat=Zmat,weights=weights,control = list(maxit=2000))$par
  }
  ans
}
#---------------------------------------------------------------------------->


#---------------------------------------------------------------------------->
# fdCov.nlm(b,u.fun,Y,X,Z=X,Zmat=NULL)
regdCov.nlm <- function(b0,u.fun,Y,X,Z=X,Zmat=NULL){
  X = as.matrix(X)
  if(ncol(X)==1){ #univariate case
    if(length(b0)==1){
      ans=optimise(f=fdCov.nlm,interval=(b0+c(-1.5,1.5)),u.fun=u.fun,Y=Y,X=X,
                   Z=Z,Zmat=Zmat)$minimum
    }else{
      ans=optimise(f=fdCov.nlm,interval=b0,u.fun=u.fun,Y=Y,X=X,Z=Z,
                   Zmat=Zmat)$minimum 
    }
  }else{
    ans=optim(par=b0,fn=fdCov.nlm,u.fun=u.fun,Y=Y,X=X,Z=Z,Zmat=Zmat
              ,control = list(maxit=2000))$par
  }
  ans
}
#---------------------------------------------------------------------------->


#---------------------------------------------------------------------------->
diffmat<- function(v){
  v = as.matrix(v)
  n = nrow(v); nc = ncol(v)
  m = array(0,c(n,n,nc))
  for (i in 2:n) {
    for (j in 1:(i-1)) {
      m[i,j,] = v[i,]-v[j,]
      m[j,i,] = - m[i,j,]
    } #end for j
  } #end for i
  m
} #end function
#---------------------------------------------------------------------------->

#---------------------------------------------------------------------------->
# this version only supplies differencing for i<j; returns an n(n-1)/2 x (k+2)
# matrix
diffmat2<- function(u,Jx,Z){
  Jx = as.matrix(Jx)
  n = nrow(Jx); nc = ncol(Jx)
  m = matrix(0,n*(n-1)/2,(nc+3)) #extra two columns for storing indices i,j
  zJtld = matrix(0,n*(n-1)/2,(nc+1))#for storing differenced jacobians
  zhmat= U_center(as.matrix(dist(Z))) #double-centred Euclidean matrix of Z
  cnt = 0 #initialise counter
  for (j in 2:n) {
    for (i in 1:(j-1)) {
      cnt = cnt +1
      uij = u[i]-u[j]
      Jxij = Jx[i,]-Jx[j,]
      sij = zhmat[i,j]*(1-2*as.numeric(uij<0))*Jxij
      m[cnt, ] = c(i,j,uij,sij)
      zJtld[cnt, ] = c(zhmat[i,j],Jxij) 
    } #end for j
  } #end for i
  list(m=m,zJtld=zJtld)
} #end function
#---------------------------------------------------------------------------->


#---------------------------------------------------------------------------->
# compute the asymptotic variance-covariance matrix; this version uses the covariance
# of the Hajek projection of the score. Should be more computationally efficient.
# This accomodates clustering. 

vcovdCov.Haj<- function(theta,Y,X,Z=X,cluster=NULL,Pwll=TRUE,hs=TRUE,alpha=0.05){
  u = Y - as.matrix(X)%*%c(theta); u = u-mean(u)
  n = nrow(X); px = ncol(X)
  #compute Hall & Sheather (1988) bandwidth
  hn = quantreg::bandwidth.rq(p=0.5,n=n,hs=hs,alpha=alpha)
  uXtld=diffmat(cbind(u,X)) #note first element corresponds to utilde, the rest Xtilde
  if(Pwll){
    uhat = c(uXtld[,,1])
    hn <- sqrt(2)*hn*min(sqrt(var(u)),IQR(u)/1.34)
  }
  zhmat= U_center(as.matrix(dist(Z))) #double-centred Euclidean matrix of Z
  Hm = 0 #initialise Hessian
  Haj.Proj = matrix(NA,n,px) #to store Hajek Projections
  for (i in 1:n) {
    tmp.i=0
    for (j in (1:n)[-i]) {#j exclude i
      Iij = as.numeric(uXtld[i,j,1]<0) #indicator
      Xtij = matrix(c(uXtld[i,j,-1]),nrow = 1) #extract Xtilde for [i,j]
      tmp.H = zhmat[i,j]*t(Xtij)%*%Xtij
      Hm = Hm + tmp.H*as.numeric(abs(uXtld[i,j,1])<=hn)#update hessian
      tmp.i = tmp.i+c((1-2*Iij)*zhmat[i,j]*Xtij)
    } #end for j
    Haj.Proj[i,] = tmp.i/n
  } #end for i
  
  if(is.null(cluster)){Omg=4*cov(Haj.Proj)}
  else{
    idd = unique(cluster); Omg=0
    for (l in 1:length(idd)) {
      Omg = Omg + tcrossprod(c(apply(matrix(Haj.Proj[which(cluster==idd[l]),],ncol = px),2,sum)))
    }
    Omg=4*Omg/n
  }# end for else
  
  H=-Hm/(hn*n*(n-3));Hinv=solve(H); vcdC=Hinv%*%Omg%*%Hinv/n
  list(vcdC=vcdC,Omg=Omg,H=H)
}

#---------------------------------------------------------------------------->
# compute the asymptotic variance-covariance matrix; this version uses the covariance
# of the Hajek projection of the score. Should be more computationally efficient.
# This accomodates clustering. 

vcovdCov.Haj2<- function(u,Xg,Z,cluster=NULL,Pwll=TRUE,hs=TRUE,alpha=0.05){
  n = nrow(Xg); px = ncol(Xg)
  #compute Hall & Sheather (1988) bandwidth
  hn = quantreg::bandwidth.rq(p=0.5,n=n,hs=hs,alpha=alpha)
  uXtld=diffmat(cbind(u,Xg)) #note first element corresponds to utilde, the rest Xtilde
  if(Pwll){
    uhat = c(uXtld[,,1])
    hn <- sqrt(2)*hn*min(sqrt(var(u)),IQR(u)/1.34)
  }
  zhmat= U_center(as.matrix(dist(Z))) #double-centred Euclidean matrix of Z
  Hm = 0 #initialise Hessian
  Haj.Proj = matrix(NA,n,px) #to store Hajek Projections
  for (i in 1:n) {
    tmp.i=0
    for (j in (1:n)[-i]) {#j exclude i
      Iij = as.numeric(uXtld[i,j,1]<0) #indicator
      Xtij = matrix(c(uXtld[i,j,-1]),nrow = 1) #extract Xtilde for [i,j]
      tmp.H = zhmat[i,j]*t(Xtij)%*%Xtij
      Hm = Hm + tmp.H*as.numeric(abs(uXtld[i,j,1])<=hn)#update hessian
      tmp.i = tmp.i+c((1-2*Iij)*zhmat[i,j]*Xtij)
    } #end for j
    Haj.Proj[i,] = tmp.i/n
  } #end for i
  
  if(is.null(cluster)){Omg=4*cov(Haj.Proj)}
  else{
    idd = unique(cluster); Omg=0
    for (l in 1:length(idd)) {
      Omg = Omg + tcrossprod(c(apply(matrix(Haj.Proj[which(cluster==idd[l]),],ncol = px),2,sum)))
    }
    Omg=4*Omg/n
  }# end for else
  
  H=-Hm/(hn*n*(n-3));Hinv=solve(H); vcdC=Hinv%*%Omg%*%Hinv/n
  list(vcdC=vcdC,Omg=Omg,H=H)
}

#---------------------------------------------------------------------------->


#------------------------------------------------------------------------------
#use the numerical derivative to compute the Hessian matrix
vcovdCov.Haj_nd<- function(theta.hat,u.fun,Xg.fun,Y,X,Z=X,Intercept=F,cluster=NULL,
                           hn.fun=NULL){
  
  Xg = Xg.fun(theta.hat,X)
  u = u.fun(theta.hat,Y,X)

  n = nrow(X); px = ncol(Xg)
  if(is.null(hn.fun)){hn = 1/sqrt(n)}else{hn=hn.fun(n)}
  zhmat= U_center(as.matrix(dist(Z))) #double-centred Euclidean matrix of Z
  
  #-------------------- write score function
  score_fn<- function(theta){
    u = u.fun(theta,Y,X)
    Xg = Xg.fun(theta,X)
    
    uXtld=diffmat(cbind(u,Xg))
    
    Haj.Proj = matrix(NA,n,px) #to store Hajek Projections
    for (i in 1:n) {
      tmp.i=0
      for (j in (1:n)[-i]) {#j exclude i
        Iij = as.numeric(uXtld[i,j,1]<0) #indicator
        Xtij = matrix(c(uXtld[i,j,-1]),nrow = 1) #extract Xtilde for [i,j]
        tmp.i = tmp.i + c((1-2*Iij)*zhmat[i,j]*Xtij)
      } #end for j
      Haj.Proj[i,] = tmp.i
    } #end for i
    sqrt(n)*apply(Haj.Proj, 2, sum)/(n*(n-1))
  }#end score_fn()
  #-------------------- Compute the numerical Hessian - Jacobian of the score
  Hm = jacobian(f=score_fn,x0=theta.hat,heps = hn)
  #-------------------- Compute the covariance of the score
  uXtld=diffmat(cbind(u,Xg)) #note first element corresponds to utilde, the rest Xtilde
  Haj.Proj = matrix(NA,n,px) #to store Hajek Projections
  for (i in 1:n) {
    tmp.i=0
    for (j in (1:n)[-i]) {#j exclude i
      Iij = as.numeric(uXtld[i,j,1]<0) #indicator
      Xtij = matrix(c(uXtld[i,j,-1]),nrow = 1) #extract Xtilde for [i,j]
      tmp.i = tmp.i+c((1-2*Iij)*zhmat[i,j]*Xtij)
    } #end for j
    Haj.Proj[i,] = tmp.i/(n-1)
  } #end for i
  
  if(is.null(cluster)){
    Omg=4*crossprod(Haj.Proj)/n
    }
  else{
    idd = unique(cluster); Omg=0
    for (l in 1:length(idd)) {
      Omg = Omg + tcrossprod(c(apply(matrix(Haj.Proj[which(cluster==idd[l]),],ncol = px),2,sum)))
    }
    Omg=4*Omg/(n*(n-1))
  }# end for else
  
  Hinv=solve(Hm); 
  vcdC=Hinv%*%Omg%*%t(Hinv)
  list(vcdC=vcdC,Omg=Omg)
}

#---------------------------------------------------------------------------->


#---------------------------------------------------------------------------->
# modify Koenker's weighted Quantile regression algorithm to allow both 
# positive and negative weights
jrq.wfit = function (x, y, tau = 0.5, weights, method = "br", ...) 
{
  if (length(tau) > 1) {
    tau <- tau[1]
    warning("Multiple taus not allowed in rq.wfit: solution restricted to first element")
  }
  contr <- attr(x, "contrasts")
  wx <- x * weights
  wy <- y * weights
  fit <- switch(method, fn = rq.fit.fnb(wx, wy, tau = tau,...), 
                fnb = rq.fit.fnb(wx, wy, tau = tau, ...), 
                br = rq.fit.br(wx,wy, tau = tau, ...), 
                fnc = rq.fit.fnc(wx, wy, tau = tau,...), 
                sfn = rq.fit.sfn(wx, wy, tau = tau, ...), 
                pfn = rq.fit.pfn(wx, wy, tau = tau, ...), 
                {what <- paste("rq.fit.", method, sep = "")
                if (exists(what, mode = "function")) (get(what, mode = "function"))(x, y, ...)
                else stop(paste("unimplemented method:", method))})
  if (length(fit$sol)) 
    fit$fitted.values <- x %*% fit$sol[-(1:3), ]
  else fit$fitted.values <- x %*% fit$coef
  fit$residuals <- y - fit$fitted.values
  fit$contrasts <- attr(x, "contrasts")
  fit$weights <- weights
  fit
}
#---------------------------------------------------------------------------->

#---------------------------------------------------------------------------->
# Specification test of U indep. Z - Xu & He (2021)

spec_MDep.lm<- function(B,mdep.obj,strtpar=NULL,Rmat=NULL,Pwll=TRUE,hs=TRUE,
                        ns=NULL,seed=0,cl=2){
  n = length(mdep.obj$residuals)
  set.seed(seed)
  fn = function(j){
    eps = sample(mdep.obj$residuals,n,replace = T)
    Ystar = mdep.obj$fitted.values + eps
    obs=mdepreg.fit(Y=Ystar,X=mdep.obj$X,Z=mdep.obj$Z,strtpar=strtpar,Rmat=Rmat,
                    Pwll=Pwll,hs=hs,ns=ns)
    n*dcov(obs$residuals,mdep.obj$Z)^2
  }
  mean(pbapply::pbsapply(1:B,FUN = fn,cl=cl) > n*dcov(mdep.obj$residuals,
                                                              mdep.obj$Z)^2)
}
#---------------------------------------------------------------------------->

spec_MDep.lm2<- function(B,mdep.obj,strtpar=NULL,Rmat=NULL,Pwll=TRUE,hs=TRUE,
                         ns=NULL,seed=0,cl=2){
  n = length(mdep.obj$residuals)
  XZ<- cbind(mdep.obj$X,mdep.obj$Z)
  qr.XZ<- qr(XZ)
  XZ<- XZ[, qr.XZ$pivot[seq_len(qr.XZ$rank)]]
  set.seed(seed)
  fn = function(j){
    eps = sample(mdep.obj$residuals,n,replace = T)
    Ystar = mdep.obj$fitted.values + eps
    obs=mdepreg.fit(Y=Ystar,X=mdep.obj$X,Z=mdep.obj$Z,strtpar=strtpar,Rmat=Rmat,
                    Pwll=Pwll,hs=hs,ns=ns)
    n*dcov(obs$residuals,XZ)^2
  }
  mean(pbapply::pbsapply(1:B,FUN = fn,cl=cl) > n*dcov(mdep.obj$residuals,XZ)^2)
}
#---------------------------------------------------------------------------->