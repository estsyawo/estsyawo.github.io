---------------------------------------------ReadMe---------------------------------------------
Note: This file provides details on the replication of all output in the paper.

------------------------------------------------------------------------------------------------


------------------------------------------Input Files-------------------------------------------


------------------------------------------ Data Files

. Daten_2015_USD.txt: 	Data file of GDP per capita in constant 2015 USD of Benin & Togo

. Daten_2015_USD_More:	Data file of GDP per capita in constant 2015 USD of Benin, Togo, and all African countries for which the the Democracy Index never exceeded the 0.5 threshold over the 1960-2018 study period

. Daten_world-gdp-per-capita.csv:	Contains world GDP per capita data used in the computation in Footnote 15 of the manuscript.

------------------------------------------ R Files

. File_0_Main.R:	This is the master file for producing all output in the paper.

. File_0_Fonctions.R:	This file contains all functions used in the simulations and empirical applications. 

. File_1_PT_Illus.R:	This contains code for producing Figure 1 and Figure 2 in the manuscript.

. File_2a_Empirical.R:	This contains code for producing Figure 4, and Table 6.1 in the manuscript.

. File_2b_Empirical_More.R:	This contains code for producing Tables 6.2 and 6.3 in the manuscript.

. File_3a_Sim.R:	Compares the mean bias, median absolute deviation, root-mean squared error, and rejection rates at the 10%, 5%, 1% levels of competing estimators: DiD, SC, and BA with homogeneous treatment effects.

. File_3b_Sim.R:	Compares the mean bias, median absolute deviation, root-mean squared error, and rejection rates at the 10%, 5%, 1% levels of competing estimators: DiD, SC, and BA with heterogeneous treatment effects.

. File_3c_Sim.R:	Compares the power curves of t-tests at the 10%, 5%, 1% levels using competing estimators: DiD, SC, and BA with homogeneous treatment effects.


. File_3d_Sim.R:	Compares the power curves of identification tests (t-tests) at the 10%, 5%, 1% levels using competing tests: over-identifying restrictions using the DiD, SC, and BA and pre-tests using the DiD, SC, and BA


. File_3e_Sim.R:	Compares the mean bias, median absolute deviation, root-mean squared error, and rejection rates at the 10%, 5%, 1% levels of competing estimators: DiD, SC, and BA with homogeneous treatment effects but varying ratio of pre-treatment to post-treatment periods.
----------------------------------------------------------------------------------------------------


-----------------------------------------Output Files-----------------------------------------------
