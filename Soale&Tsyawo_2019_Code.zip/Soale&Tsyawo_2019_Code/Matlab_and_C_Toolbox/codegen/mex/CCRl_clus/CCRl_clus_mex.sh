MATLAB="/Applications/MATLAB_R2018b.app"
Arch=maci64
ENTRYPOINT=mexFunction
MAPFILE=$ENTRYPOINT'.map'
PREFDIR="/Users/Selorm/Library/Application Support/MathWorks/MATLAB/R2018b"
OPTSFILE_NAME="./setEnv.sh"
. $OPTSFILE_NAME
COMPILER=$CC
. $OPTSFILE_NAME
echo "# Make settings for CCRl_clus" > CCRl_clus_mex.mki
echo "CC=$CC" >> CCRl_clus_mex.mki
echo "CFLAGS=$CFLAGS" >> CCRl_clus_mex.mki
echo "CLIBS=$CLIBS" >> CCRl_clus_mex.mki
echo "COPTIMFLAGS=$COPTIMFLAGS" >> CCRl_clus_mex.mki
echo "CDEBUGFLAGS=$CDEBUGFLAGS" >> CCRl_clus_mex.mki
echo "CXX=$CXX" >> CCRl_clus_mex.mki
echo "CXXFLAGS=$CXXFLAGS" >> CCRl_clus_mex.mki
echo "CXXLIBS=$CXXLIBS" >> CCRl_clus_mex.mki
echo "CXXOPTIMFLAGS=$CXXOPTIMFLAGS" >> CCRl_clus_mex.mki
echo "CXXDEBUGFLAGS=$CXXDEBUGFLAGS" >> CCRl_clus_mex.mki
echo "LDFLAGS=$LDFLAGS" >> CCRl_clus_mex.mki
echo "LDOPTIMFLAGS=$LDOPTIMFLAGS" >> CCRl_clus_mex.mki
echo "LDDEBUGFLAGS=$LDDEBUGFLAGS" >> CCRl_clus_mex.mki
echo "Arch=$Arch" >> CCRl_clus_mex.mki
echo "LD=$LD" >> CCRl_clus_mex.mki
echo OMPFLAGS= >> CCRl_clus_mex.mki
echo OMPLINKFLAGS= >> CCRl_clus_mex.mki
echo "EMC_COMPILER=clang" >> CCRl_clus_mex.mki
echo "EMC_CONFIG=optim" >> CCRl_clus_mex.mki
"/Applications/MATLAB_R2018b.app/bin/maci64/gmake" -j 1 -B -f CCRl_clus_mex.mk
