#=============================================================================================>
# a single delta with a function f of xjt-1,xit-1, alf and rho
fn4S<- function(x,y,k) {-(0.5*y^4 + (x-y)^4)^.25} #k is a dummy input
fn2S<- function(x,y,k) {-(0.5*y^2 + (x-y)^2)} # ^.5 #k is a dummy input
# take a polynomial expansion of phi(xi,xj) to a power summed to k
polyexp_s<- function(xi,xj,k){
  nt = k*(k+3)/2 #number of terms in the expansion
  Z = rep(NA,nt)
  cnt = 0
  for (i in 0:k) {
    for (j in 0:(k-i)) {
      if(i!=0 | j!=0){
      cnt = cnt+1; #cat("cnt = ",cnt,"i = ",i,"j = ",j,"\n")
      Z[cnt] = (xi^i)*(xj^j)
      }
    }
  }
  Z
}

matexpsum<- function(M,k){
  Z = diag(ncol(M)); #print("Z is "); print(Z)
  A = 0; 
  for (i in 1:k) {
    #cat("Iter = \n",i)
    A = A + Z #; print("A is "); print(A)
    Z = Z%*%M #; print("Z is "); print(Z)
  }
  A+Z
}
#--------------------------------------------
#order of parameter vector: pars - first nt are delta, nt+1 is rho, nt+2 is alpha, and nt+3 is beta 
ncd_lmSs<- function(pars,Y,X,Tid,Pid,fun=fn4S,k=1,utid){
  #number of terms in the expansion
  if(identical(polyexp_s,fun)){nt = k*(k+3)/2}else{nt = k*(k+1)/2}
  if((nt+3)!=length(pars)){stop("Wrong length of parameter vector pars.")}
  deli = pars[1:nt]; rho = pars[nt+1]; alf = pars[nt+2]; bet = pars[nt+3];
  N = length(unique(Pid)) #extract N
  ID = which(Tid>=min(utid))
  Tp = max(utid) #extract T
  XX = rep(NA,length(Y)) # to store weighted covariates
  Xb = as.matrix(cbind(1,X))%*%matrix(c(alf,bet),ncol = 1) #collapse into a column vector
  Eye = diag(N)
  
  for (t in utid) {
    # construct weight matrix at t
    W = matrix(0,N,N)
    for (i in 1:N) {
      xit1 = X[(i-1)*Tp + t-1] #extract xi at t-1
      for (j in 1:N) {
        if(j!=i){
        xjt1 = X[(j-1)*Tp + t-1] #extract xj at t-1
        W[i,j] = exp(sum(c(fun(xit1,xjt1,k))*deli))
        }
      }
    } #end for i
    W = W/apply(W,1,sum) #row normalise
    W = W*rho #for stationarity and existence of (I-W)^{-1}
    idintv<- ((1:N)-1)*Tp + t
    #XX[idintv] = solve(Eye-W)%*%Xb[idintv] #use power series expansion instead
    XX[idintv] = matexpsum(W,30)%*%Xb[idintv]
    
  } #end for t
  sum((Y[ID]-XX[ID])^2)
}


#=============================================================================================>


#=============================================================================================>
# generate data for model with a single weight delta
gdat_dds<- function(N,Tp,seed,fun=fn4S,sder){
  if(!is.null(seed)){set.seed(seed)}; er = rnorm(N*Tp,sd=sder) 
  X = rnorm(N*Tp,1,1)
  Y = rep(NA,N*Tp) # vector of outcome variable
  XX = rep(NA,length(Y)) # to store weighted covariates
  
  # set parameters:
  rho=0.5; alf = 0.0; bet = 0.5
  delv = 0.8; #vector of deltas for individuals
  
  Xb = as.matrix(cbind(1,X))%*%matrix(c(alf,bet),ncol = 1) #collapse into a column vector
  Eye = diag(N)
  
  # individual and time identifiers:
  psID = sort(rep(1:N,Tp))
  tpID = rep(1:Tp,N)
  
  for (t in 2:Tp) {
    # construct weight matrix at t
    W = matrix(0,N,N)
    
    for (i in 1:N) {
      xit1 = X[(i-1)*Tp + t-1] #extract xi at t-1
      for (j in 1:N) {
        if(j!=i){
        xjt1 = X[(j-1)*Tp + t-1] #extract xj at t-1
        W[i,j] = exp(fun(xit1,xjt1)*delv)
        } #end if
      } #end for j
      
      # generate outcome at time 
      id=(i-1)*Tp + t
    } #end for i
    #InfW<- max(apply(W,1,sum)) * (1+1e-03)
    W = W/apply(W,1,sum) #row normalise
    W = W*rho #for stationarity and existence of (I-W)^{-1}
    
    idintv<- ((1:N)-1)*Tp + t
    G = solve(Eye-W)
    XX[idintv] = G%*%Xb[idintv]
    #Y[idintv] = XX[idintv] + er[idintv]
    Y[idintv] = XX[idintv] + G%*%matrix(er[idintv],ncol = 1)
  }
  dat<- data.frame(Y,X,psID,tpID)
  return(dat)
}
#=============================================================================================>

#-------------------------------------------------------------------->
# gradient function of ncd_lmSf()
grad_ncd_lmSs<- function(pars,Y,X,Tid,Pid,fun=fn4S,utid){
  deli = pars[1]; alf = pars[2]; rho = pars[3]
  N = length(unique(Pid)) #extract N
  ID = which(Tid>=min(utid))
  Tp = max(utid) #extract T
  XX=XX1=XX2 = rep(NA,length(Y)) # to store weighted covariates
  
  gradv<- rep(NA,3) #vector to store gradients
  
  for (t in utid) {
    # construct weight matrix at t
    W = matrix(NA,N,N)
    for (i in 1:N) {
      xit1 = X[(i-1)*Tp + t-1] #extract xi at t-1
      for (j in 1:N) {
        xjt1 = X[(j-1)*Tp + t-1] #extract xj at t-1
        W[i,j] = exp(fun(xit1,xjt1)*deli)
      }
      #row-normalise
      W[i,] = W[i,]/sum(W[i,])
      fz=function(z) {fun(xit1,z)}
      id=(i-1)*Tp + t
      idintv<- ((1:N)-1)*Tp + t
      idintv1<- ((1:N)-1)*Tp + t-1
      ZZ = fz(X[idintv1])
      XX[id] = sum(X[idintv]*W[i,])
      XX1[id] = sum(X[idintv]*ZZ*W[i,])
      XX2[id] = XX[id]*sum(ZZ*W[i,])
    }
  }
  err=Y[ID]-alf-rho*XX[ID]
  gradv[1] = -2*sum(rho*(XX1[ID]-XX2[ID])*err) #with respect to delta
  gradv[2] = -2*sum(err) #with respect to alpha
  gradv[3] = -2*sum(XX[ID]*err) #with respect to rho
  gradv
}
