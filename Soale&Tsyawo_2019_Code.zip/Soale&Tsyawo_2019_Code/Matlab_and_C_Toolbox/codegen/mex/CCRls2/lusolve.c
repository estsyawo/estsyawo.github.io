/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * lusolve.c
 *
 * Code generation for function 'lusolve'
 *
 */

/* Include files */
#include "mwmathutil.h"
#include "rt_nonfinite.h"
#include "CCRls2.h"
#include "lusolve.h"
#include "CCRls2_emxutil.h"
#include "CCRls2_data.h"
#include "lapacke.h"
#include "blas.h"

/* Function Definitions */
void lusolve(const emxArray_real_T *A, const real_T B_data[], const int32_T
             B_size[1], real_T X_data[], int32_T X_size[1])
{
  emxArray_real_T *X;
  emxArray_real_T *b_A;
  int32_T n;
  int32_T i3;
  int32_T loop_ub;
  emxArray_int32_T *ipiv;
  emxArray_ptrdiff_t *ipiv_t;
  int32_T i4;
  ptrdiff_t info_t;
  real_T temp;
  char_T DIAGA1;
  int32_T i5;
  char_T TRANSA1;
  char_T UPLO1;
  char_T SIDE1;
  ptrdiff_t m_t;
  ptrdiff_t n_t;
  ptrdiff_t lda_t;
  ptrdiff_t ldb_t;
  emlrtHeapReferenceStackEnterFcnR2012b(emlrtRootTLSGlobal);
  emxInit_real_T(&X, 1, true);
  emxInit_real_T(&b_A, 2, true);
  n = A->size[1];
  i3 = b_A->size[0] * b_A->size[1];
  b_A->size[0] = A->size[0];
  b_A->size[1] = A->size[1];
  emxEnsureCapacity_real_T(b_A, i3);
  loop_ub = A->size[0] * A->size[1];
  for (i3 = 0; i3 < loop_ub; i3++) {
    b_A->data[i3] = A->data[i3];
  }

  emxInit_int32_T(&ipiv, 2, true);
  if ((b_A->size[0] == 0) || (b_A->size[1] == 0)) {
    ipiv->size[0] = 1;
    ipiv->size[1] = 0;
  } else {
    emxInit_ptrdiff_t(&ipiv_t, 1, true);
    i3 = ipiv_t->size[0];
    i4 = muIntScalarMin_sint32(n, n);
    ipiv_t->size[0] = muIntScalarMax_sint32(i4, 1);
    emxEnsureCapacity_ptrdiff_t(ipiv_t, i3);
    info_t = LAPACKE_dgetrf_work(102, (ptrdiff_t)A->size[1], (ptrdiff_t)A->size
      [1], &b_A->data[0], (ptrdiff_t)A->size[1], &ipiv_t->data[0]);
    i3 = ipiv->size[0] * ipiv->size[1];
    ipiv->size[0] = 1;
    ipiv->size[1] = ipiv_t->size[0];
    emxEnsureCapacity_int32_T(ipiv, i3);
    if ((int32_T)info_t < 0) {
      i3 = b_A->size[0] * b_A->size[1];
      emxEnsureCapacity_real_T(b_A, i3);
      loop_ub = b_A->size[1];
      for (i3 = 0; i3 < loop_ub; i3++) {
        n = b_A->size[0];
        for (i5 = 0; i5 < n; i5++) {
          b_A->data[i5 + b_A->size[0] * i3] = rtNaN;
        }
      }

      i3 = ipiv->size[1] - 1;
      for (n = 0; n <= i3; n++) {
        ipiv->data[n] = n + 1;
      }
    } else {
      i3 = ipiv->size[1] - 1;
      for (n = 0; n <= i3; n++) {
        ipiv->data[n] = (int32_T)ipiv_t->data[n];
      }
    }

    emxFree_ptrdiff_t(&ipiv_t);
  }

  i3 = X->size[0];
  X->size[0] = B_size[0];
  emxEnsureCapacity_real_T(X, i3);
  loop_ub = B_size[0];
  for (i3 = 0; i3 < loop_ub; i3++) {
    X->data[i3] = B_data[i3];
  }

  i3 = A->size[1];
  for (n = 0; n <= i3 - 2; n++) {
    if (ipiv->data[n] != n + 1) {
      temp = X->data[n];
      X->data[n] = X->data[ipiv->data[n] - 1];
      X->data[ipiv->data[n] - 1] = temp;
    }
  }

  emxFree_int32_T(&ipiv);
  X_size[0] = X->size[0];
  loop_ub = X->size[0];
  for (i3 = 0; i3 < loop_ub; i3++) {
    X_data[i3] = X->data[i3];
  }

  emxFree_real_T(&X);
  if (A->size[1] >= 1) {
    temp = 1.0;
    DIAGA1 = 'U';
    TRANSA1 = 'N';
    UPLO1 = 'L';
    SIDE1 = 'L';
    m_t = (ptrdiff_t)A->size[1];
    n_t = (ptrdiff_t)1;
    lda_t = (ptrdiff_t)A->size[1];
    ldb_t = (ptrdiff_t)A->size[1];
    dtrsm(&SIDE1, &UPLO1, &TRANSA1, &DIAGA1, &m_t, &n_t, &temp, &b_A->data[0],
          &lda_t, &X_data[0], &ldb_t);
    temp = 1.0;
    DIAGA1 = 'N';
    TRANSA1 = 'N';
    UPLO1 = 'U';
    SIDE1 = 'L';
    m_t = (ptrdiff_t)A->size[1];
    n_t = (ptrdiff_t)1;
    lda_t = (ptrdiff_t)A->size[1];
    ldb_t = (ptrdiff_t)A->size[1];
    dtrsm(&SIDE1, &UPLO1, &TRANSA1, &DIAGA1, &m_t, &n_t, &temp, &b_A->data[0],
          &lda_t, &X_data[0], &ldb_t);
  }

  emxFree_real_T(&b_A);
  emlrtHeapReferenceStackLeaveFcnR2012b(emlrtRootTLSGlobal);
}

/* End of code generation (lusolve.c) */
