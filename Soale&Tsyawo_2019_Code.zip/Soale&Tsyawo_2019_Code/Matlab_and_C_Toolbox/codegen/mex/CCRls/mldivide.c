/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * mldivide.c
 *
 * Code generation for function 'mldivide'
 *
 */

/* Include files */
#include "mwmathutil.h"
#include "rt_nonfinite.h"
#include "CCRls.h"
#include "mldivide.h"
#include "CCRls_emxutil.h"
#include "xgetrf.h"
#include "xgeqp3.h"
#include "CCRls_data.h"
#include "blas.h"
#include "lapacke.h"

/* Function Definitions */
void b_mldivide(const emxArray_real_T *A, emxArray_real_T *B)
{
  emxArray_real_T *b_A;
  emxArray_real_T *tau;
  emxArray_int32_T *jpvt;
  emxArray_real_T *b_B;
  uint32_T unnamed_idx_0;
  int32_T maxmn;
  int32_T minmn;
  int32_T rankR;
  real_T tol;
  char_T DIAGA1;
  char_T TRANSA1;
  char_T UPLO1;
  char_T SIDE1;
  ptrdiff_t m_t;
  ptrdiff_t n_t;
  ptrdiff_t lda_t;
  ptrdiff_t ldb_t;
  ptrdiff_t nrc_t;
  ptrdiff_t info_t;
  emlrtHeapReferenceStackEnterFcnR2012b(emlrtRootTLSGlobal);
  emxInit_real_T(&b_A, 2, true);
  emxInit_real_T(&tau, 1, true);
  emxInit_int32_T(&jpvt, 2, true);
  emxInit_real_T(&b_B, 1, true);
  if ((A->size[0] == 0) || (A->size[1] == 0) || (B->size[0] == 0)) {
    unnamed_idx_0 = (uint32_T)A->size[1];
    maxmn = B->size[0];
    B->size[0] = (int32_T)unnamed_idx_0;
    emxEnsureCapacity_real_T(B, maxmn);
    minmn = (int32_T)unnamed_idx_0;
    for (maxmn = 0; maxmn < minmn; maxmn++) {
      B->data[maxmn] = 0.0;
    }
  } else if (A->size[0] == A->size[1]) {
    maxmn = b_A->size[0] * b_A->size[1];
    b_A->size[0] = A->size[0];
    b_A->size[1] = A->size[1];
    emxEnsureCapacity_real_T(b_A, maxmn);
    minmn = A->size[0] * A->size[1];
    for (maxmn = 0; maxmn < minmn; maxmn++) {
      b_A->data[maxmn] = A->data[maxmn];
    }

    xgetrf(A->size[1], A->size[1], b_A, A->size[1], jpvt, &minmn);
    maxmn = A->size[1];
    for (minmn = 0; minmn <= maxmn - 2; minmn++) {
      if (jpvt->data[minmn] != minmn + 1) {
        tol = B->data[minmn];
        B->data[minmn] = B->data[jpvt->data[minmn] - 1];
        B->data[jpvt->data[minmn] - 1] = tol;
      }
    }

    tol = 1.0;
    DIAGA1 = 'U';
    TRANSA1 = 'N';
    UPLO1 = 'L';
    SIDE1 = 'L';
    m_t = (ptrdiff_t)A->size[1];
    n_t = (ptrdiff_t)1;
    lda_t = (ptrdiff_t)A->size[1];
    ldb_t = (ptrdiff_t)A->size[1];
    dtrsm(&SIDE1, &UPLO1, &TRANSA1, &DIAGA1, &m_t, &n_t, &tol, &b_A->data[0],
          &lda_t, &B->data[0], &ldb_t);
    tol = 1.0;
    DIAGA1 = 'N';
    TRANSA1 = 'N';
    UPLO1 = 'U';
    SIDE1 = 'L';
    m_t = (ptrdiff_t)A->size[1];
    n_t = (ptrdiff_t)1;
    lda_t = (ptrdiff_t)A->size[1];
    ldb_t = (ptrdiff_t)A->size[1];
    dtrsm(&SIDE1, &UPLO1, &TRANSA1, &DIAGA1, &m_t, &n_t, &tol, &b_A->data[0],
          &lda_t, &B->data[0], &ldb_t);
  } else {
    maxmn = b_A->size[0] * b_A->size[1];
    b_A->size[0] = A->size[0];
    b_A->size[1] = A->size[1];
    emxEnsureCapacity_real_T(b_A, maxmn);
    minmn = A->size[0] * A->size[1];
    for (maxmn = 0; maxmn < minmn; maxmn++) {
      b_A->data[maxmn] = A->data[maxmn];
    }

    b_xgeqp3(b_A, tau, jpvt);
    rankR = 0;
    if (b_A->size[0] < b_A->size[1]) {
      minmn = b_A->size[0];
      maxmn = b_A->size[1];
    } else {
      minmn = b_A->size[1];
      maxmn = b_A->size[0];
    }

    if (minmn > 0) {
      tol = muDoubleScalarMin(1.4901161193847656E-8, 2.2204460492503131E-15 *
        (real_T)maxmn) * muDoubleScalarAbs(b_A->data[0]);
      while ((rankR < minmn) && (!(muDoubleScalarAbs(b_A->data[rankR + b_A->
                size[0] * rankR]) <= tol))) {
        rankR++;
      }
    }

    maxmn = b_B->size[0];
    b_B->size[0] = B->size[0];
    emxEnsureCapacity_real_T(b_B, maxmn);
    minmn = B->size[0];
    for (maxmn = 0; maxmn < minmn; maxmn++) {
      b_B->data[maxmn] = B->data[maxmn];
    }

    minmn = b_A->size[1];
    maxmn = B->size[0];
    B->size[0] = minmn;
    emxEnsureCapacity_real_T(B, maxmn);
    for (maxmn = 0; maxmn < minmn; maxmn++) {
      B->data[maxmn] = 0.0;
    }

    minmn = muIntScalarMin_sint32(b_A->size[0], b_A->size[1]);
    if ((b_A->size[0] != 0) && (b_A->size[1] != 0)) {
      nrc_t = (ptrdiff_t)b_B->size[0];
      info_t = LAPACKE_dormqr(102, 'L', 'T', nrc_t, (ptrdiff_t)1, (ptrdiff_t)
        minmn, &b_A->data[0], (ptrdiff_t)b_A->size[0], &tau->data[0], &b_B->
        data[0], nrc_t);
      if ((int32_T)info_t != 0) {
        minmn = b_B->size[0];
        maxmn = b_B->size[0];
        b_B->size[0] = minmn;
        emxEnsureCapacity_real_T(b_B, maxmn);
        for (maxmn = 0; maxmn < minmn; maxmn++) {
          b_B->data[maxmn] = rtNaN;
        }
      }
    }

    for (minmn = 0; minmn < rankR; minmn++) {
      B->data[jpvt->data[minmn] - 1] = b_B->data[minmn];
    }

    for (maxmn = rankR; maxmn >= 1; maxmn--) {
      B->data[jpvt->data[maxmn - 1] - 1] /= b_A->data[(maxmn + b_A->size[0] *
        (maxmn - 1)) - 1];
      for (minmn = 0; minmn <= maxmn - 2; minmn++) {
        B->data[jpvt->data[minmn] - 1] -= B->data[jpvt->data[maxmn - 1] - 1] *
          b_A->data[minmn + b_A->size[0] * (maxmn - 1)];
      }
    }
  }

  emxFree_real_T(&b_B);
  emxFree_int32_T(&jpvt);
  emxFree_real_T(&tau);
  emxFree_real_T(&b_A);
  emlrtHeapReferenceStackLeaveFcnR2012b(emlrtRootTLSGlobal);
}

void mldivide(const emxArray_real_T *A, const emxArray_real_T *B, real_T Y[2])
{
  emxArray_real_T *b_A;
  emxArray_real_T *b_B;
  int32_T minmn;
  int32_T maxmn;
  real_T tol;
  real_T tau_data[2];
  int32_T tau_size[1];
  int32_T jpvt[2];
  int32_T rankR;
  ptrdiff_t nrc_t;
  ptrdiff_t info_t;
  int32_T Y_tmp;
  emlrtHeapReferenceStackEnterFcnR2012b(emlrtRootTLSGlobal);
  emxInit_real_T(&b_A, 2, true);
  emxInit_real_T(&b_B, 1, true);
  if ((A->size[0] == 0) || (B->size[0] == 0)) {
    Y[0] = 0.0;
    Y[1] = 0.0;
  } else if (A->size[0] == 2) {
    if (muDoubleScalarAbs(A->data[1]) > muDoubleScalarAbs(A->data[0])) {
      minmn = 1;
      maxmn = 0;
    } else {
      minmn = 0;
      maxmn = 1;
    }

    tol = A->data[maxmn] / A->data[minmn];
    Y[1] = (B->data[maxmn] - B->data[minmn] * tol) / (A->data[maxmn + A->size[0]]
      - tol * A->data[minmn + A->size[0]]);
    Y[0] = (B->data[minmn] - Y[1] * A->data[minmn + A->size[0]]) / A->data[minmn];
  } else {
    minmn = b_A->size[0] * b_A->size[1];
    b_A->size[0] = A->size[0];
    b_A->size[1] = 2;
    emxEnsureCapacity_real_T(b_A, minmn);
    maxmn = A->size[0] * A->size[1];
    for (minmn = 0; minmn < maxmn; minmn++) {
      b_A->data[minmn] = A->data[minmn];
    }

    xgeqp3(b_A, tau_data, tau_size, jpvt);
    rankR = 0;
    if (b_A->size[0] < 2) {
      minmn = b_A->size[0];
      maxmn = 2;
    } else {
      minmn = 2;
      maxmn = b_A->size[0];
    }

    if (minmn > 0) {
      tol = muDoubleScalarMin(1.4901161193847656E-8, 2.2204460492503131E-15 *
        (real_T)maxmn) * muDoubleScalarAbs(b_A->data[0]);
      while ((rankR < minmn) && (!(muDoubleScalarAbs(b_A->data[rankR + b_A->
                size[0] * rankR]) <= tol))) {
        rankR++;
      }
    }

    minmn = b_B->size[0];
    b_B->size[0] = B->size[0];
    emxEnsureCapacity_real_T(b_B, minmn);
    maxmn = B->size[0];
    for (minmn = 0; minmn < maxmn; minmn++) {
      b_B->data[minmn] = B->data[minmn];
    }

    Y[0] = 0.0;
    Y[1] = 0.0;
    minmn = muIntScalarMin_sint32(b_A->size[0], 2);
    if (b_A->size[0] != 0) {
      nrc_t = (ptrdiff_t)b_B->size[0];
      info_t = LAPACKE_dormqr(102, 'L', 'T', nrc_t, (ptrdiff_t)1, (ptrdiff_t)
        minmn, &b_A->data[0], (ptrdiff_t)b_A->size[0], &tau_data[0], &b_B->data
        [0], nrc_t);
      if ((int32_T)info_t != 0) {
        maxmn = b_B->size[0];
        minmn = b_B->size[0];
        b_B->size[0] = maxmn;
        emxEnsureCapacity_real_T(b_B, minmn);
        for (minmn = 0; minmn < maxmn; minmn++) {
          b_B->data[minmn] = rtNaN;
        }
      }
    }

    for (minmn = 0; minmn < rankR; minmn++) {
      Y[jpvt[minmn] - 1] = b_B->data[minmn];
    }

    for (maxmn = rankR; maxmn >= 1; maxmn--) {
      Y_tmp = jpvt[maxmn - 1] - 1;
      Y[Y_tmp] /= b_A->data[(maxmn + b_A->size[0] * (maxmn - 1)) - 1];
      for (minmn = 0; minmn <= maxmn - 2; minmn++) {
        Y[jpvt[0] - 1] -= Y[Y_tmp] * b_A->data[b_A->size[0] * (maxmn - 1)];
      }
    }
  }

  emxFree_real_T(&b_B);
  emxFree_real_T(&b_A);
  emlrtHeapReferenceStackLeaveFcnR2012b(emlrtRootTLSGlobal);
}

/* End of code generation (mldivide.c) */
