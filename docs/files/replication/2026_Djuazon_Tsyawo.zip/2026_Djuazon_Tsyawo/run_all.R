#=========================================================================================>
# Authors: Nelly Charlotte Djuazon & Emmanuel Selorm Tsyawo
# Project: Quantile and Distribution Treatment Effects on the Treated with Possibly 
#          Non-Continuous Outcomes
# Date began:   Apr. 13, 2023
# Last Update:  March 28, 2026
# Place:        Tuscaloosa, AL
#=========================================================================================>
# Comment: Runs the full replication workflow by checking packages and executing all 
#          empirical and simulation scripts in sequence.
#=========================================================================================>
# Load packages, clear memory,

rm(list = ls()) #clear memory
#set working directory
get_script_dir <- function() {
  cmd_args <- commandArgs(trailingOnly = FALSE)
  file_arg <- grep("^--file=", cmd_args, value = TRUE)
  if (length(file_arg) > 0) {
    p <- sub("^--file=", "", file_arg[1])
    p <- gsub("~\\+~", " ", p)
    return(dirname(normalizePath(p, winslash = "/", mustWork = FALSE)))
  }
  if (requireNamespace("rstudioapi", quietly = TRUE)) {
    p <- tryCatch(rstudioapi::getActiveDocumentContext()$path, error = function(e) "")
    if (nzchar(p)) return(dirname(p))
  }
  getwd()
}

setwd(get_script_dir())
#=========================================================================================>
# Ensure all required packages are installed
output_dir <- "output"
if (!dir.exists(output_dir)) dir.create(output_dir, recursive = TRUE)

required_packages <- c(
  "ald",
  "dplyr",
  "ggplot2",
  "haven",
  "latex2exp",
  "pbapply",
  "plm",
  "purrr",
  "sandwich"
)

ensure_packages <- function(packages, repos = "https://cloud.r-project.org") {
  installed <- vapply(packages, requireNamespace, logical(1), quietly = TRUE)
  missing <- packages[!installed]

  cat("Checking required packages...\n")
  for (pkg in packages) {
    cat(sprintf("  - %s: %s\n", pkg, if (pkg %in% missing) "missing" else "available"))
  }

  if (length(missing) == 0) {
    cat("All required packages are already installed.\n")
    return(invisible(TRUE))
  }

  cat(
    "Warning: missing packages were detected. Installing them requires internet access",
    "and permission to install packages in this R environment.\n"
  )
  cat("Installing missing packages:", paste(missing, collapse = ", "), "\n")
  install.packages(missing, repos = repos)

  still_missing <- missing[!vapply(missing, requireNamespace, logical(1), quietly = TRUE)]
  if (length(still_missing) > 0) {
    stop(
      "Package installation failed for: ",
      paste(still_missing, collapse = ", "),
      ". Please install them manually and rerun run_all.R."
    )
  }

  cat("Missing packages installed successfully.\n")
  invisible(TRUE)
}
#=========================================================================================>
# Run scripts
run_script <- function(script_name) {
  cat("\n==================================================\n")
  cat("Running:", script_name, "\n")
  cat("Started:", format(Sys.time(), "%Y-%m-%d %H:%M:%S"), "\n")

  start_time <- Sys.time()
  script_env <- new.env(parent = globalenv())
  sys.source(script_name, envir = script_env)
  elapsed <- difftime(Sys.time(), start_time, units = "secs")

  cat("Finished:", script_name, "\n")
  cat("Elapsed:", round(as.numeric(elapsed), 2), "seconds\n")
} #end run_script

scripts_to_run <- c(
  "a_Empirical_Application.R",
  "b_Empirical_Application.R",
  "c_Empirical_Application_logis.R",
  "Sim_Main.R",
  "Sim_Overid_Test.R"
)

missing_scripts <- scripts_to_run[!file.exists(scripts_to_run)]
if (length(missing_scripts) > 0) {
  stop("Missing script(s): ", paste(missing_scripts, collapse = ", "))
}

ensure_packages(required_packages)

for (script_name in scripts_to_run) {
  run_script(script_name)
}

writeLines(capture.output(sessionInfo()), file.path(output_dir, "session_info.txt"))

cat("\nAll scripts completed successfully.\n")
#=========================================================================================>
