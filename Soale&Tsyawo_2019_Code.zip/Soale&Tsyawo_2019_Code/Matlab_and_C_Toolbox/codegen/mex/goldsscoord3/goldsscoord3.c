/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * goldsscoord3.c
 *
 * Code generation for function 'goldsscoord3'
 *
 */

/* Include files */
#include "mwmathutil.h"
#include "rt_nonfinite.h"
#include "goldsscoord3.h"
#include "goldsscoord3_emxutil.h"
#include "error.h"
#include "dot.h"
#include "power.h"
#include "sum.h"
#include "rng.h"
#include "kmeans.h"
#include "abs.h"
#include "eml_int_forloop_overflow_check.h"
#include "mean.h"
#include "log.h"
#include "mldivide.h"
#include "goldsscoord3_mexutil.h"
#include "goldsscoord3_data.h"
#include "blas.h"

/* Variable Definitions */
static emlrtRTEInfo emlrtRTEI = { 29,  /* lineNo */
  5,                                   /* colNo */
  "goldsscoord3",                      /* fName */
  "/home/selorm/Dropbox/Nasah_Marcus/Codes_Soale_Tsyawo_2018/Matlab_and_C_Toolbox/goldsscoord3.m"/* pName */
};

static emlrtRTEInfo b_emlrtRTEI = { 33,/* lineNo */
  5,                                   /* colNo */
  "goldsscoord3",                      /* fName */
  "/home/selorm/Dropbox/Nasah_Marcus/Codes_Soale_Tsyawo_2018/Matlab_and_C_Toolbox/goldsscoord3.m"/* pName */
};

static emlrtRTEInfo c_emlrtRTEI = { 53,/* lineNo */
  5,                                   /* colNo */
  "goldsscoord3",                      /* fName */
  "/home/selorm/Dropbox/Nasah_Marcus/Codes_Soale_Tsyawo_2018/Matlab_and_C_Toolbox/goldsscoord3.m"/* pName */
};

static emlrtRTEInfo d_emlrtRTEI = { 56,/* lineNo */
  5,                                   /* colNo */
  "goldsscoord3",                      /* fName */
  "/home/selorm/Dropbox/Nasah_Marcus/Codes_Soale_Tsyawo_2018/Matlab_and_C_Toolbox/goldsscoord3.m"/* pName */
};

static emlrtRTEInfo e_emlrtRTEI = { 65,/* lineNo */
  1,                                   /* colNo */
  "cordlinopt_clus3",                  /* fName */
  "/home/selorm/Dropbox/Nasah_Marcus/Codes_Soale_Tsyawo_2018/Matlab_and_C_Toolbox/cordlinopt_clus3.m"/* pName */
};

static emlrtRSInfo emlrtRSI = { 13,    /* lineNo */
  "goldsscoord3",                      /* fcnName */
  "/home/selorm/Dropbox/Nasah_Marcus/Codes_Soale_Tsyawo_2018/Matlab_and_C_Toolbox/goldsscoord3.m"/* pathName */
};

static emlrtRSInfo b_emlrtRSI = { 15,  /* lineNo */
  "goldsscoord3",                      /* fcnName */
  "/home/selorm/Dropbox/Nasah_Marcus/Codes_Soale_Tsyawo_2018/Matlab_and_C_Toolbox/goldsscoord3.m"/* pathName */
};

static emlrtRSInfo c_emlrtRSI = { 27,  /* lineNo */
  "goldsscoord3",                      /* fcnName */
  "/home/selorm/Dropbox/Nasah_Marcus/Codes_Soale_Tsyawo_2018/Matlab_and_C_Toolbox/goldsscoord3.m"/* pathName */
};

static emlrtRSInfo d_emlrtRSI = { 29,  /* lineNo */
  "goldsscoord3",                      /* fcnName */
  "/home/selorm/Dropbox/Nasah_Marcus/Codes_Soale_Tsyawo_2018/Matlab_and_C_Toolbox/goldsscoord3.m"/* pathName */
};

static emlrtRSInfo e_emlrtRSI = { 31,  /* lineNo */
  "goldsscoord3",                      /* fcnName */
  "/home/selorm/Dropbox/Nasah_Marcus/Codes_Soale_Tsyawo_2018/Matlab_and_C_Toolbox/goldsscoord3.m"/* pathName */
};

static emlrtRSInfo f_emlrtRSI = { 33,  /* lineNo */
  "goldsscoord3",                      /* fcnName */
  "/home/selorm/Dropbox/Nasah_Marcus/Codes_Soale_Tsyawo_2018/Matlab_and_C_Toolbox/goldsscoord3.m"/* pathName */
};

static emlrtRSInfo g_emlrtRSI = { 51,  /* lineNo */
  "goldsscoord3",                      /* fcnName */
  "/home/selorm/Dropbox/Nasah_Marcus/Codes_Soale_Tsyawo_2018/Matlab_and_C_Toolbox/goldsscoord3.m"/* pathName */
};

static emlrtRSInfo h_emlrtRSI = { 53,  /* lineNo */
  "goldsscoord3",                      /* fcnName */
  "/home/selorm/Dropbox/Nasah_Marcus/Codes_Soale_Tsyawo_2018/Matlab_and_C_Toolbox/goldsscoord3.m"/* pathName */
};

static emlrtRSInfo i_emlrtRSI = { 54,  /* lineNo */
  "goldsscoord3",                      /* fcnName */
  "/home/selorm/Dropbox/Nasah_Marcus/Codes_Soale_Tsyawo_2018/Matlab_and_C_Toolbox/goldsscoord3.m"/* pathName */
};

static emlrtRSInfo j_emlrtRSI = { 56,  /* lineNo */
  "goldsscoord3",                      /* fcnName */
  "/home/selorm/Dropbox/Nasah_Marcus/Codes_Soale_Tsyawo_2018/Matlab_and_C_Toolbox/goldsscoord3.m"/* pathName */
};

static emlrtRSInfo vb_emlrtRSI = { 37, /* lineNo */
  "function_handle",                   /* fcnName */
  "/usr/local/MATLAB/R2018b/toolbox/eml/eml/+coder/+internal/function_handle.m"/* pathName */
};

static emlrtRSInfo wb_emlrtRSI = { 22, /* lineNo */
  "goldsscoord3",                      /* fcnName */
  "/home/selorm/Dropbox/Nasah_Marcus/Codes_Soale_Tsyawo_2018/Matlab_and_C_Toolbox/goldsscoord3.m"/* pathName */
};

static emlrtRSInfo xb_emlrtRSI = { 23, /* lineNo */
  "cordlinopt_clus3",                  /* fcnName */
  "/home/selorm/Dropbox/Nasah_Marcus/Codes_Soale_Tsyawo_2018/Matlab_and_C_Toolbox/cordlinopt_clus3.m"/* pathName */
};

static emlrtRSInfo yb_emlrtRSI = { 24, /* lineNo */
  "cordlinopt_clus3",                  /* fcnName */
  "/home/selorm/Dropbox/Nasah_Marcus/Codes_Soale_Tsyawo_2018/Matlab_and_C_Toolbox/cordlinopt_clus3.m"/* pathName */
};

static emlrtRSInfo ac_emlrtRSI = { 26, /* lineNo */
  "cordlinopt_clus3",                  /* fcnName */
  "/home/selorm/Dropbox/Nasah_Marcus/Codes_Soale_Tsyawo_2018/Matlab_and_C_Toolbox/cordlinopt_clus3.m"/* pathName */
};

static emlrtRSInfo bc_emlrtRSI = { 29, /* lineNo */
  "cordlinopt_clus3",                  /* fcnName */
  "/home/selorm/Dropbox/Nasah_Marcus/Codes_Soale_Tsyawo_2018/Matlab_and_C_Toolbox/cordlinopt_clus3.m"/* pathName */
};

static emlrtRSInfo cc_emlrtRSI = { 30, /* lineNo */
  "cordlinopt_clus3",                  /* fcnName */
  "/home/selorm/Dropbox/Nasah_Marcus/Codes_Soale_Tsyawo_2018/Matlab_and_C_Toolbox/cordlinopt_clus3.m"/* pathName */
};

static emlrtRSInfo dc_emlrtRSI = { 38, /* lineNo */
  "cordlinopt_clus3",                  /* fcnName */
  "/home/selorm/Dropbox/Nasah_Marcus/Codes_Soale_Tsyawo_2018/Matlab_and_C_Toolbox/cordlinopt_clus3.m"/* pathName */
};

static emlrtRSInfo ec_emlrtRSI = { 41, /* lineNo */
  "cordlinopt_clus3",                  /* fcnName */
  "/home/selorm/Dropbox/Nasah_Marcus/Codes_Soale_Tsyawo_2018/Matlab_and_C_Toolbox/cordlinopt_clus3.m"/* pathName */
};

static emlrtRSInfo fc_emlrtRSI = { 43, /* lineNo */
  "cordlinopt_clus3",                  /* fcnName */
  "/home/selorm/Dropbox/Nasah_Marcus/Codes_Soale_Tsyawo_2018/Matlab_and_C_Toolbox/cordlinopt_clus3.m"/* pathName */
};

static emlrtRSInfo gc_emlrtRSI = { 48, /* lineNo */
  "cordlinopt_clus3",                  /* fcnName */
  "/home/selorm/Dropbox/Nasah_Marcus/Codes_Soale_Tsyawo_2018/Matlab_and_C_Toolbox/cordlinopt_clus3.m"/* pathName */
};

static emlrtRSInfo hc_emlrtRSI = { 59, /* lineNo */
  "cordlinopt_clus3",                  /* fcnName */
  "/home/selorm/Dropbox/Nasah_Marcus/Codes_Soale_Tsyawo_2018/Matlab_and_C_Toolbox/cordlinopt_clus3.m"/* pathName */
};

static emlrtRSInfo ic_emlrtRSI = { 64, /* lineNo */
  "cordlinopt_clus3",                  /* fcnName */
  "/home/selorm/Dropbox/Nasah_Marcus/Codes_Soale_Tsyawo_2018/Matlab_and_C_Toolbox/cordlinopt_clus3.m"/* pathName */
};

static emlrtRSInfo jc_emlrtRSI = { 65, /* lineNo */
  "cordlinopt_clus3",                  /* fcnName */
  "/home/selorm/Dropbox/Nasah_Marcus/Codes_Soale_Tsyawo_2018/Matlab_and_C_Toolbox/cordlinopt_clus3.m"/* pathName */
};

static emlrtRSInfo kc_emlrtRSI = { 52, /* lineNo */
  "eml_mtimes_helper",                 /* fcnName */
  "/usr/local/MATLAB/R2018b/toolbox/eml/lib/matlab/ops/eml_mtimes_helper.m"/* pathName */
};

static emlrtRSInfo lc_emlrtRSI = { 21, /* lineNo */
  "eml_mtimes_helper",                 /* fcnName */
  "/usr/local/MATLAB/R2018b/toolbox/eml/lib/matlab/ops/eml_mtimes_helper.m"/* pathName */
};

static emlrtRSInfo mc_emlrtRSI = { 114,/* lineNo */
  "mtimes",                            /* fcnName */
  "/usr/local/MATLAB/R2018b/toolbox/eml/eml/+coder/+internal/+blas/mtimes.m"/* pathName */
};

static emlrtRSInfo nc_emlrtRSI = { 118,/* lineNo */
  "mtimes",                            /* fcnName */
  "/usr/local/MATLAB/R2018b/toolbox/eml/eml/+coder/+internal/+blas/mtimes.m"/* pathName */
};

static emlrtRSInfo hf_emlrtRSI = { 15, /* lineNo */
  "min",                               /* fcnName */
  "/usr/local/MATLAB/R2018b/toolbox/eml/lib/matlab/datafun/min.m"/* pathName */
};

static emlrtRSInfo if_emlrtRSI = { 16, /* lineNo */
  "minOrMax",                          /* fcnName */
  "/usr/local/MATLAB/R2018b/toolbox/eml/eml/+coder/+internal/minOrMax.m"/* pathName */
};

static emlrtRSInfo jf_emlrtRSI = { 42, /* lineNo */
  "minOrMax",                          /* fcnName */
  "/usr/local/MATLAB/R2018b/toolbox/eml/eml/+coder/+internal/minOrMax.m"/* pathName */
};

static emlrtRSInfo kf_emlrtRSI = { 112,/* lineNo */
  "unaryMinOrMax",                     /* fcnName */
  "/usr/local/MATLAB/R2018b/toolbox/eml/eml/+coder/+internal/unaryMinOrMax.m"/* pathName */
};

static emlrtRSInfo lf_emlrtRSI = { 852,/* lineNo */
  "unaryMinOrMax",                     /* fcnName */
  "/usr/local/MATLAB/R2018b/toolbox/eml/eml/+coder/+internal/unaryMinOrMax.m"/* pathName */
};

static emlrtRSInfo mf_emlrtRSI = { 844,/* lineNo */
  "unaryMinOrMax",                     /* fcnName */
  "/usr/local/MATLAB/R2018b/toolbox/eml/eml/+coder/+internal/unaryMinOrMax.m"/* pathName */
};

static emlrtRSInfo nf_emlrtRSI = { 894,/* lineNo */
  "unaryMinOrMax",                     /* fcnName */
  "/usr/local/MATLAB/R2018b/toolbox/eml/eml/+coder/+internal/unaryMinOrMax.m"/* pathName */
};

static emlrtRSInfo of_emlrtRSI = { 910,/* lineNo */
  "unaryMinOrMax",                     /* fcnName */
  "/usr/local/MATLAB/R2018b/toolbox/eml/eml/+coder/+internal/unaryMinOrMax.m"/* pathName */
};

static emlrtRSInfo qf_emlrtRSI = { 38, /* lineNo */
  "fprintf",                           /* fcnName */
  "/usr/local/MATLAB/R2018b/toolbox/eml/lib/matlab/iofun/fprintf.m"/* pathName */
};

static emlrtMCInfo f_emlrtMCI = { 60,  /* lineNo */
  18,                                  /* colNo */
  "fprintf",                           /* fName */
  "/usr/local/MATLAB/R2018b/toolbox/eml/lib/matlab/iofun/fprintf.m"/* pName */
};

static emlrtRTEInfo f_emlrtRTEI = { 5, /* lineNo */
  1,                                   /* colNo */
  "goldsscoord3",                      /* fName */
  "/home/selorm/Dropbox/Nasah_Marcus/Codes_Soale_Tsyawo_2018/Matlab_and_C_Toolbox/goldsscoord3.m"/* pName */
};

static emlrtRTEInfo g_emlrtRTEI = { 7, /* lineNo */
  1,                                   /* colNo */
  "goldsscoord3",                      /* fName */
  "/home/selorm/Dropbox/Nasah_Marcus/Codes_Soale_Tsyawo_2018/Matlab_and_C_Toolbox/goldsscoord3.m"/* pName */
};

static emlrtRTEInfo h_emlrtRTEI = { 10,/* lineNo */
  1,                                   /* colNo */
  "goldsscoord3",                      /* fName */
  "/home/selorm/Dropbox/Nasah_Marcus/Codes_Soale_Tsyawo_2018/Matlab_and_C_Toolbox/goldsscoord3.m"/* pName */
};

static emlrtRTEInfo i_emlrtRTEI = { 12,/* lineNo */
  7,                                   /* colNo */
  "goldsscoord3",                      /* fName */
  "/home/selorm/Dropbox/Nasah_Marcus/Codes_Soale_Tsyawo_2018/Matlab_and_C_Toolbox/goldsscoord3.m"/* pName */
};

static emlrtRTEInfo j_emlrtRTEI = { 37,/* lineNo */
  13,                                  /* colNo */
  "function_handle",                   /* fName */
  "/usr/local/MATLAB/R2018b/toolbox/eml/eml/+coder/+internal/function_handle.m"/* pName */
};

static emlrtRTEInfo k_emlrtRTEI = { 6, /* lineNo */
  8,                                   /* colNo */
  "goldsscoord3",                      /* fName */
  "/home/selorm/Dropbox/Nasah_Marcus/Codes_Soale_Tsyawo_2018/Matlab_and_C_Toolbox/goldsscoord3.m"/* pName */
};

static emlrtRTEInfo l_emlrtRTEI = { 15,/* lineNo */
  20,                                  /* colNo */
  "goldsscoord3",                      /* fName */
  "/home/selorm/Dropbox/Nasah_Marcus/Codes_Soale_Tsyawo_2018/Matlab_and_C_Toolbox/goldsscoord3.m"/* pName */
};

static emlrtRTEInfo m_emlrtRTEI = { 15,/* lineNo */
  27,                                  /* colNo */
  "goldsscoord3",                      /* fName */
  "/home/selorm/Dropbox/Nasah_Marcus/Codes_Soale_Tsyawo_2018/Matlab_and_C_Toolbox/goldsscoord3.m"/* pName */
};

static emlrtRTEInfo n_emlrtRTEI = { 38,/* lineNo */
  15,                                  /* colNo */
  "goldsscoord3",                      /* fName */
  "/home/selorm/Dropbox/Nasah_Marcus/Codes_Soale_Tsyawo_2018/Matlab_and_C_Toolbox/goldsscoord3.m"/* pName */
};

static emlrtRTEInfo o_emlrtRTEI = { 36,/* lineNo */
  37,                                  /* colNo */
  "goldsscoord3",                      /* fName */
  "/home/selorm/Dropbox/Nasah_Marcus/Codes_Soale_Tsyawo_2018/Matlab_and_C_Toolbox/goldsscoord3.m"/* pName */
};

static emlrtRTEInfo p_emlrtRTEI = { 59,/* lineNo */
  15,                                  /* colNo */
  "goldsscoord3",                      /* fName */
  "/home/selorm/Dropbox/Nasah_Marcus/Codes_Soale_Tsyawo_2018/Matlab_and_C_Toolbox/goldsscoord3.m"/* pName */
};

static emlrtRTEInfo q_emlrtRTEI = { 62,/* lineNo */
  15,                                  /* colNo */
  "goldsscoord3",                      /* fName */
  "/home/selorm/Dropbox/Nasah_Marcus/Codes_Soale_Tsyawo_2018/Matlab_and_C_Toolbox/goldsscoord3.m"/* pName */
};

static emlrtRTEInfo r_emlrtRTEI = { 59,/* lineNo */
  38,                                  /* colNo */
  "goldsscoord3",                      /* fName */
  "/home/selorm/Dropbox/Nasah_Marcus/Codes_Soale_Tsyawo_2018/Matlab_and_C_Toolbox/goldsscoord3.m"/* pName */
};

static emlrtRTEInfo s_emlrtRTEI = { 62,/* lineNo */
  38,                                  /* colNo */
  "goldsscoord3",                      /* fName */
  "/home/selorm/Dropbox/Nasah_Marcus/Codes_Soale_Tsyawo_2018/Matlab_and_C_Toolbox/goldsscoord3.m"/* pName */
};

static emlrtRTEInfo t_emlrtRTEI = { 27,/* lineNo */
  6,                                   /* colNo */
  "goldsscoord3",                      /* fName */
  "/home/selorm/Dropbox/Nasah_Marcus/Codes_Soale_Tsyawo_2018/Matlab_and_C_Toolbox/goldsscoord3.m"/* pName */
};

static emlrtRTEInfo u_emlrtRTEI = { 1, /* lineNo */
  33,                                  /* colNo */
  "goldsscoord3",                      /* fName */
  "/home/selorm/Dropbox/Nasah_Marcus/Codes_Soale_Tsyawo_2018/Matlab_and_C_Toolbox/goldsscoord3.m"/* pName */
};

static emlrtRTEInfo v_emlrtRTEI = { 51,/* lineNo */
  6,                                   /* colNo */
  "goldsscoord3",                      /* fName */
  "/home/selorm/Dropbox/Nasah_Marcus/Codes_Soale_Tsyawo_2018/Matlab_and_C_Toolbox/goldsscoord3.m"/* pName */
};

static emlrtRTEInfo ab_emlrtRTEI = { 22,/* lineNo */
  5,                                   /* colNo */
  "goldsscoord3",                      /* fName */
  "/home/selorm/Dropbox/Nasah_Marcus/Codes_Soale_Tsyawo_2018/Matlab_and_C_Toolbox/goldsscoord3.m"/* pName */
};

static emlrtRTEInfo cc_emlrtRTEI = { 22,/* lineNo */
  51,                                  /* colNo */
  "goldsscoord3",                      /* fName */
  "/home/selorm/Dropbox/Nasah_Marcus/Codes_Soale_Tsyawo_2018/Matlab_and_C_Toolbox/goldsscoord3.m"/* pName */
};

static emlrtRTEInfo dc_emlrtRTEI = { 25,/* lineNo */
  9,                                   /* colNo */
  "colon",                             /* fName */
  "/usr/local/MATLAB/R2018b/toolbox/eml/lib/matlab/ops/colon.m"/* pName */
};

static emlrtRTEInfo ec_emlrtRTEI = { 26,/* lineNo */
  17,                                  /* colNo */
  "cordlinopt_clus3",                  /* fName */
  "/home/selorm/Dropbox/Nasah_Marcus/Codes_Soale_Tsyawo_2018/Matlab_and_C_Toolbox/cordlinopt_clus3.m"/* pName */
};

static emlrtRTEInfo fc_emlrtRTEI = { 22,/* lineNo */
  5,                                   /* colNo */
  "cordlinopt_clus3",                  /* fName */
  "/home/selorm/Dropbox/Nasah_Marcus/Codes_Soale_Tsyawo_2018/Matlab_and_C_Toolbox/cordlinopt_clus3.m"/* pName */
};

static emlrtRTEInfo gc_emlrtRTEI = { 26,/* lineNo */
  15,                                  /* colNo */
  "cordlinopt_clus3",                  /* fName */
  "/home/selorm/Dropbox/Nasah_Marcus/Codes_Soale_Tsyawo_2018/Matlab_and_C_Toolbox/cordlinopt_clus3.m"/* pName */
};

static emlrtRTEInfo hc_emlrtRTEI = { 23,/* lineNo */
  17,                                  /* colNo */
  "cordlinopt_clus3",                  /* fName */
  "/home/selorm/Dropbox/Nasah_Marcus/Codes_Soale_Tsyawo_2018/Matlab_and_C_Toolbox/cordlinopt_clus3.m"/* pName */
};

static emlrtRTEInfo ic_emlrtRTEI = { 26,/* lineNo */
  13,                                  /* colNo */
  "cordlinopt_clus3",                  /* fName */
  "/home/selorm/Dropbox/Nasah_Marcus/Codes_Soale_Tsyawo_2018/Matlab_and_C_Toolbox/cordlinopt_clus3.m"/* pName */
};

static emlrtRTEInfo jc_emlrtRTEI = { 23,/* lineNo */
  13,                                  /* colNo */
  "cordlinopt_clus3",                  /* fName */
  "/home/selorm/Dropbox/Nasah_Marcus/Codes_Soale_Tsyawo_2018/Matlab_and_C_Toolbox/cordlinopt_clus3.m"/* pName */
};

static emlrtRTEInfo kc_emlrtRTEI = { 118,/* lineNo */
  13,                                  /* colNo */
  "mtimes",                            /* fName */
  "/usr/local/MATLAB/R2018b/toolbox/eml/eml/+coder/+internal/+blas/mtimes.m"/* pName */
};

static emlrtRTEInfo lc_emlrtRTEI = { 23,/* lineNo */
  21,                                  /* colNo */
  "cordlinopt_clus3",                  /* fName */
  "/home/selorm/Dropbox/Nasah_Marcus/Codes_Soale_Tsyawo_2018/Matlab_and_C_Toolbox/cordlinopt_clus3.m"/* pName */
};

static emlrtRTEInfo mc_emlrtRTEI = { 30,/* lineNo */
  23,                                  /* colNo */
  "cordlinopt_clus3",                  /* fName */
  "/home/selorm/Dropbox/Nasah_Marcus/Codes_Soale_Tsyawo_2018/Matlab_and_C_Toolbox/cordlinopt_clus3.m"/* pName */
};

static emlrtRTEInfo nc_emlrtRTEI = { 32,/* lineNo */
  9,                                   /* colNo */
  "cordlinopt_clus3",                  /* fName */
  "/home/selorm/Dropbox/Nasah_Marcus/Codes_Soale_Tsyawo_2018/Matlab_and_C_Toolbox/cordlinopt_clus3.m"/* pName */
};

static emlrtRTEInfo oc_emlrtRTEI = { 23,/* lineNo */
  11,                                  /* colNo */
  "cordlinopt_clus3",                  /* fName */
  "/home/selorm/Dropbox/Nasah_Marcus/Codes_Soale_Tsyawo_2018/Matlab_and_C_Toolbox/cordlinopt_clus3.m"/* pName */
};

static emlrtRTEInfo pc_emlrtRTEI = { 24,/* lineNo */
  25,                                  /* colNo */
  "cordlinopt_clus3",                  /* fName */
  "/home/selorm/Dropbox/Nasah_Marcus/Codes_Soale_Tsyawo_2018/Matlab_and_C_Toolbox/cordlinopt_clus3.m"/* pName */
};

static emlrtRTEInfo qc_emlrtRTEI = { 64,/* lineNo */
  17,                                  /* colNo */
  "cordlinopt_clus3",                  /* fName */
  "/home/selorm/Dropbox/Nasah_Marcus/Codes_Soale_Tsyawo_2018/Matlab_and_C_Toolbox/cordlinopt_clus3.m"/* pName */
};

static emlrtRTEInfo rc_emlrtRTEI = { 37,/* lineNo */
  5,                                   /* colNo */
  "cordlinopt_clus3",                  /* fName */
  "/home/selorm/Dropbox/Nasah_Marcus/Codes_Soale_Tsyawo_2018/Matlab_and_C_Toolbox/cordlinopt_clus3.m"/* pName */
};

static emlrtRTEInfo sc_emlrtRTEI = { 64,/* lineNo */
  15,                                  /* colNo */
  "cordlinopt_clus3",                  /* fName */
  "/home/selorm/Dropbox/Nasah_Marcus/Codes_Soale_Tsyawo_2018/Matlab_and_C_Toolbox/cordlinopt_clus3.m"/* pName */
};

static emlrtRTEInfo tc_emlrtRTEI = { 38,/* lineNo */
  17,                                  /* colNo */
  "cordlinopt_clus3",                  /* fName */
  "/home/selorm/Dropbox/Nasah_Marcus/Codes_Soale_Tsyawo_2018/Matlab_and_C_Toolbox/cordlinopt_clus3.m"/* pName */
};

static emlrtRTEInfo uc_emlrtRTEI = { 64,/* lineNo */
  13,                                  /* colNo */
  "cordlinopt_clus3",                  /* fName */
  "/home/selorm/Dropbox/Nasah_Marcus/Codes_Soale_Tsyawo_2018/Matlab_and_C_Toolbox/cordlinopt_clus3.m"/* pName */
};

static emlrtRTEInfo vc_emlrtRTEI = { 38,/* lineNo */
  13,                                  /* colNo */
  "cordlinopt_clus3",                  /* fName */
  "/home/selorm/Dropbox/Nasah_Marcus/Codes_Soale_Tsyawo_2018/Matlab_and_C_Toolbox/cordlinopt_clus3.m"/* pName */
};

static emlrtRTEInfo wc_emlrtRTEI = { 38,/* lineNo */
  21,                                  /* colNo */
  "cordlinopt_clus3",                  /* fName */
  "/home/selorm/Dropbox/Nasah_Marcus/Codes_Soale_Tsyawo_2018/Matlab_and_C_Toolbox/cordlinopt_clus3.m"/* pName */
};

static emlrtRTEInfo xc_emlrtRTEI = { 38,/* lineNo */
  5,                                   /* colNo */
  "cordlinopt_clus3",                  /* fName */
  "/home/selorm/Dropbox/Nasah_Marcus/Codes_Soale_Tsyawo_2018/Matlab_and_C_Toolbox/cordlinopt_clus3.m"/* pName */
};

static emlrtRTEInfo yc_emlrtRTEI = { 70,/* lineNo */
  6,                                   /* colNo */
  "cordlinopt_clus3",                  /* fName */
  "/home/selorm/Dropbox/Nasah_Marcus/Codes_Soale_Tsyawo_2018/Matlab_and_C_Toolbox/cordlinopt_clus3.m"/* pName */
};

static emlrtRTEInfo ad_emlrtRTEI = { 59,/* lineNo */
  29,                                  /* colNo */
  "cordlinopt_clus3",                  /* fName */
  "/home/selorm/Dropbox/Nasah_Marcus/Codes_Soale_Tsyawo_2018/Matlab_and_C_Toolbox/cordlinopt_clus3.m"/* pName */
};

static emlrtRTEInfo bd_emlrtRTEI = { 41,/* lineNo */
  18,                                  /* colNo */
  "cordlinopt_clus3",                  /* fName */
  "/home/selorm/Dropbox/Nasah_Marcus/Codes_Soale_Tsyawo_2018/Matlab_and_C_Toolbox/cordlinopt_clus3.m"/* pName */
};

static emlrtRTEInfo cd_emlrtRTEI = { 43,/* lineNo */
  22,                                  /* colNo */
  "cordlinopt_clus3",                  /* fName */
  "/home/selorm/Dropbox/Nasah_Marcus/Codes_Soale_Tsyawo_2018/Matlab_and_C_Toolbox/cordlinopt_clus3.m"/* pName */
};

static emlrtRTEInfo dd_emlrtRTEI = { 70,/* lineNo */
  16,                                  /* colNo */
  "cordlinopt_clus3",                  /* fName */
  "/home/selorm/Dropbox/Nasah_Marcus/Codes_Soale_Tsyawo_2018/Matlab_and_C_Toolbox/cordlinopt_clus3.m"/* pName */
};

static emlrtRTEInfo ed_emlrtRTEI = { 45,/* lineNo */
  9,                                   /* colNo */
  "cordlinopt_clus3",                  /* fName */
  "/home/selorm/Dropbox/Nasah_Marcus/Codes_Soale_Tsyawo_2018/Matlab_and_C_Toolbox/cordlinopt_clus3.m"/* pName */
};

static emlrtRTEInfo fd_emlrtRTEI = { 48,/* lineNo */
  19,                                  /* colNo */
  "cordlinopt_clus3",                  /* fName */
  "/home/selorm/Dropbox/Nasah_Marcus/Codes_Soale_Tsyawo_2018/Matlab_and_C_Toolbox/cordlinopt_clus3.m"/* pName */
};

static emlrtRTEInfo gd_emlrtRTEI = { 23,/* lineNo */
  5,                                   /* colNo */
  "cordlinopt_clus3",                  /* fName */
  "/home/selorm/Dropbox/Nasah_Marcus/Codes_Soale_Tsyawo_2018/Matlab_and_C_Toolbox/cordlinopt_clus3.m"/* pName */
};

static emlrtRTEInfo hd_emlrtRTEI = { 30,/* lineNo */
  7,                                   /* colNo */
  "cordlinopt_clus3",                  /* fName */
  "/home/selorm/Dropbox/Nasah_Marcus/Codes_Soale_Tsyawo_2018/Matlab_and_C_Toolbox/cordlinopt_clus3.m"/* pName */
};

static emlrtRTEInfo id_emlrtRTEI = { 22,/* lineNo */
  11,                                  /* colNo */
  "cordlinopt_clus3",                  /* fName */
  "/home/selorm/Dropbox/Nasah_Marcus/Codes_Soale_Tsyawo_2018/Matlab_and_C_Toolbox/cordlinopt_clus3.m"/* pName */
};

static emlrtBCInfo emlrtBCI = { -1,    /* iFirst */
  -1,                                  /* iLast */
  17,                                  /* lineNo */
  8,                                   /* colNo */
  "Xdot",                              /* aName */
  "goldsscoord3",                      /* fName */
  "/home/selorm/Dropbox/Nasah_Marcus/Codes_Soale_Tsyawo_2018/Matlab_and_C_Toolbox/goldsscoord3.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo b_emlrtBCI = { -1,  /* iFirst */
  -1,                                  /* iLast */
  15,                                  /* lineNo */
  31,                                  /* colNo */
  "X",                                 /* aName */
  "goldsscoord3",                      /* fName */
  "/home/selorm/Dropbox/Nasah_Marcus/Codes_Soale_Tsyawo_2018/Matlab_and_C_Toolbox/goldsscoord3.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo c_emlrtBCI = { -1,  /* iFirst */
  -1,                                  /* iLast */
  15,                                  /* lineNo */
  24,                                  /* colNo */
  "X",                                 /* aName */
  "goldsscoord3",                      /* fName */
  "/home/selorm/Dropbox/Nasah_Marcus/Codes_Soale_Tsyawo_2018/Matlab_and_C_Toolbox/goldsscoord3.m",/* pName */
  0                                    /* checkKind */
};

static emlrtECInfo emlrtECI = { -1,    /* nDims */
  12,                                  /* lineNo */
  4,                                   /* colNo */
  "goldsscoord3",                      /* fName */
  "/home/selorm/Dropbox/Nasah_Marcus/Codes_Soale_Tsyawo_2018/Matlab_and_C_Toolbox/goldsscoord3.m"/* pName */
};

static emlrtBCInfo d_emlrtBCI = { -1,  /* iFirst */
  -1,                                  /* iLast */
  12,                                  /* lineNo */
  18,                                  /* colNo */
  "X",                                 /* aName */
  "goldsscoord3",                      /* fName */
  "/home/selorm/Dropbox/Nasah_Marcus/Codes_Soale_Tsyawo_2018/Matlab_and_C_Toolbox/goldsscoord3.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo e_emlrtBCI = { -1,  /* iFirst */
  -1,                                  /* iLast */
  14,                                  /* lineNo */
  4,                                   /* colNo */
  "bets",                              /* aName */
  "goldsscoord3",                      /* fName */
  "/home/selorm/Dropbox/Nasah_Marcus/Codes_Soale_Tsyawo_2018/Matlab_and_C_Toolbox/goldsscoord3.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo f_emlrtBCI = { -1,  /* iFirst */
  -1,                                  /* iLast */
  15,                                  /* lineNo */
  4,                                   /* colNo */
  "Xdot",                              /* aName */
  "goldsscoord3",                      /* fName */
  "/home/selorm/Dropbox/Nasah_Marcus/Codes_Soale_Tsyawo_2018/Matlab_and_C_Toolbox/goldsscoord3.m",/* pName */
  0                                    /* checkKind */
};

static emlrtRTEInfo ce_emlrtRTEI = { 83,/* lineNo */
  23,                                  /* colNo */
  "eml_mtimes_helper",                 /* fName */
  "/usr/local/MATLAB/R2018b/toolbox/eml/lib/matlab/ops/eml_mtimes_helper.m"/* pName */
};

static emlrtRTEInfo de_emlrtRTEI = { 88,/* lineNo */
  23,                                  /* colNo */
  "eml_mtimes_helper",                 /* fName */
  "/usr/local/MATLAB/R2018b/toolbox/eml/lib/matlab/ops/eml_mtimes_helper.m"/* pName */
};

static emlrtRTEInfo ee_emlrtRTEI = { 77,/* lineNo */
  27,                                  /* colNo */
  "unaryMinOrMax",                     /* fName */
  "/usr/local/MATLAB/R2018b/toolbox/eml/eml/+coder/+internal/unaryMinOrMax.m"/* pName */
};

static emlrtECInfo b_emlrtECI = { -1,  /* nDims */
  70,                                  /* lineNo */
  1,                                   /* colNo */
  "cordlinopt_clus3",                  /* fName */
  "/home/selorm/Dropbox/Nasah_Marcus/Codes_Soale_Tsyawo_2018/Matlab_and_C_Toolbox/cordlinopt_clus3.m"/* pName */
};

static emlrtBCInfo yb_emlrtBCI = { -1, /* iFirst */
  -1,                                  /* iLast */
  70,                                  /* lineNo */
  8,                                   /* colNo */
  "klus",                              /* aName */
  "cordlinopt_clus3",                  /* fName */
  "/home/selorm/Dropbox/Nasah_Marcus/Codes_Soale_Tsyawo_2018/Matlab_and_C_Toolbox/cordlinopt_clus3.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo ac_emlrtBCI = { -1, /* iFirst */
  -1,                                  /* iLast */
  70,                                  /* lineNo */
  6,                                   /* colNo */
  "klus",                              /* aName */
  "cordlinopt_clus3",                  /* fName */
  "/home/selorm/Dropbox/Nasah_Marcus/Codes_Soale_Tsyawo_2018/Matlab_and_C_Toolbox/cordlinopt_clus3.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo bc_emlrtBCI = { -1, /* iFirst */
  -1,                                  /* iLast */
  70,                                  /* lineNo */
  31,                                  /* colNo */
  "clus",                              /* aName */
  "cordlinopt_clus3",                  /* fName */
  "/home/selorm/Dropbox/Nasah_Marcus/Codes_Soale_Tsyawo_2018/Matlab_and_C_Toolbox/cordlinopt_clus3.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo cc_emlrtBCI = { -1, /* iFirst */
  -1,                                  /* iLast */
  70,                                  /* lineNo */
  25,                                  /* colNo */
  "clus",                              /* aName */
  "cordlinopt_clus3",                  /* fName */
  "/home/selorm/Dropbox/Nasah_Marcus/Codes_Soale_Tsyawo_2018/Matlab_and_C_Toolbox/cordlinopt_clus3.m",/* pName */
  0                                    /* checkKind */
};

static emlrtDCInfo c_emlrtDCI = { 70,  /* lineNo */
  25,                                  /* colNo */
  "cordlinopt_clus3",                  /* fName */
  "/home/selorm/Dropbox/Nasah_Marcus/Codes_Soale_Tsyawo_2018/Matlab_and_C_Toolbox/cordlinopt_clus3.m",/* pName */
  1                                    /* checkKind */
};

static emlrtECInfo c_emlrtECI = { -1,  /* nDims */
  64,                                  /* lineNo */
  13,                                  /* colNo */
  "cordlinopt_clus3",                  /* fName */
  "/home/selorm/Dropbox/Nasah_Marcus/Codes_Soale_Tsyawo_2018/Matlab_and_C_Toolbox/cordlinopt_clus3.m"/* pName */
};

static emlrtBCInfo dc_emlrtBCI = { -1, /* iFirst */
  -1,                                  /* iLast */
  59,                                  /* lineNo */
  33,                                  /* colNo */
  "X",                                 /* aName */
  "cordlinopt_clus3",                  /* fName */
  "/home/selorm/Dropbox/Nasah_Marcus/Codes_Soale_Tsyawo_2018/Matlab_and_C_Toolbox/cordlinopt_clus3.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo ec_emlrtBCI = { -1, /* iFirst */
  -1,                                  /* iLast */
  52,                                  /* lineNo */
  24,                                  /* colNo */
  "id",                                /* aName */
  "cordlinopt_clus3",                  /* fName */
  "/home/selorm/Dropbox/Nasah_Marcus/Codes_Soale_Tsyawo_2018/Matlab_and_C_Toolbox/cordlinopt_clus3.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo fc_emlrtBCI = { -1, /* iFirst */
  -1,                                  /* iLast */
  42,                                  /* lineNo */
  16,                                  /* colNo */
  "clus",                              /* aName */
  "cordlinopt_clus3",                  /* fName */
  "/home/selorm/Dropbox/Nasah_Marcus/Codes_Soale_Tsyawo_2018/Matlab_and_C_Toolbox/cordlinopt_clus3.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo gc_emlrtBCI = { -1, /* iFirst */
  -1,                                  /* iLast */
  41,                                  /* lineNo */
  22,                                  /* colNo */
  "X",                                 /* aName */
  "cordlinopt_clus3",                  /* fName */
  "/home/selorm/Dropbox/Nasah_Marcus/Codes_Soale_Tsyawo_2018/Matlab_and_C_Toolbox/cordlinopt_clus3.m",/* pName */
  0                                    /* checkKind */
};

static emlrtECInfo d_emlrtECI = { -1,  /* nDims */
  38,                                  /* lineNo */
  11,                                  /* colNo */
  "cordlinopt_clus3",                  /* fName */
  "/home/selorm/Dropbox/Nasah_Marcus/Codes_Soale_Tsyawo_2018/Matlab_and_C_Toolbox/cordlinopt_clus3.m"/* pName */
};

static emlrtECInfo e_emlrtECI = { -1,  /* nDims */
  32,                                  /* lineNo */
  1,                                   /* colNo */
  "cordlinopt_clus3",                  /* fName */
  "/home/selorm/Dropbox/Nasah_Marcus/Codes_Soale_Tsyawo_2018/Matlab_and_C_Toolbox/cordlinopt_clus3.m"/* pName */
};

static emlrtBCInfo hc_emlrtBCI = { -1, /* iFirst */
  -1,                                  /* iLast */
  32,                                  /* lineNo */
  16,                                  /* colNo */
  "clus",                              /* aName */
  "cordlinopt_clus3",                  /* fName */
  "/home/selorm/Dropbox/Nasah_Marcus/Codes_Soale_Tsyawo_2018/Matlab_and_C_Toolbox/cordlinopt_clus3.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo ic_emlrtBCI = { -1, /* iFirst */
  -1,                                  /* iLast */
  32,                                  /* lineNo */
  10,                                  /* colNo */
  "clus",                              /* aName */
  "cordlinopt_clus3",                  /* fName */
  "/home/selorm/Dropbox/Nasah_Marcus/Codes_Soale_Tsyawo_2018/Matlab_and_C_Toolbox/cordlinopt_clus3.m",/* pName */
  0                                    /* checkKind */
};

static emlrtDCInfo d_emlrtDCI = { 32,  /* lineNo */
  10,                                  /* colNo */
  "cordlinopt_clus3",                  /* fName */
  "/home/selorm/Dropbox/Nasah_Marcus/Codes_Soale_Tsyawo_2018/Matlab_and_C_Toolbox/cordlinopt_clus3.m",/* pName */
  1                                    /* checkKind */
};

static emlrtBCInfo jc_emlrtBCI = { -1, /* iFirst */
  -1,                                  /* iLast */
  32,                                  /* lineNo */
  29,                                  /* colNo */
  "klus",                              /* aName */
  "cordlinopt_clus3",                  /* fName */
  "/home/selorm/Dropbox/Nasah_Marcus/Codes_Soale_Tsyawo_2018/Matlab_and_C_Toolbox/cordlinopt_clus3.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo kc_emlrtBCI = { -1, /* iFirst */
  -1,                                  /* iLast */
  30,                                  /* lineNo */
  38,                                  /* colNo */
  "bets",                              /* aName */
  "cordlinopt_clus3",                  /* fName */
  "/home/selorm/Dropbox/Nasah_Marcus/Codes_Soale_Tsyawo_2018/Matlab_and_C_Toolbox/cordlinopt_clus3.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo lc_emlrtBCI = { -1, /* iFirst */
  -1,                                  /* iLast */
  30,                                  /* lineNo */
  32,                                  /* colNo */
  "bets",                              /* aName */
  "cordlinopt_clus3",                  /* fName */
  "/home/selorm/Dropbox/Nasah_Marcus/Codes_Soale_Tsyawo_2018/Matlab_and_C_Toolbox/cordlinopt_clus3.m",/* pName */
  0                                    /* checkKind */
};

static emlrtDCInfo e_emlrtDCI = { 30,  /* lineNo */
  32,                                  /* colNo */
  "cordlinopt_clus3",                  /* fName */
  "/home/selorm/Dropbox/Nasah_Marcus/Codes_Soale_Tsyawo_2018/Matlab_and_C_Toolbox/cordlinopt_clus3.m",/* pName */
  1                                    /* checkKind */
};

static emlrtECInfo f_emlrtECI = { -1,  /* nDims */
  26,                                  /* lineNo */
  13,                                  /* colNo */
  "cordlinopt_clus3",                  /* fName */
  "/home/selorm/Dropbox/Nasah_Marcus/Codes_Soale_Tsyawo_2018/Matlab_and_C_Toolbox/cordlinopt_clus3.m"/* pName */
};

static emlrtBCInfo mc_emlrtBCI = { -1, /* iFirst */
  -1,                                  /* iLast */
  24,                                  /* lineNo */
  29,                                  /* colNo */
  "X",                                 /* aName */
  "cordlinopt_clus3",                  /* fName */
  "/home/selorm/Dropbox/Nasah_Marcus/Codes_Soale_Tsyawo_2018/Matlab_and_C_Toolbox/cordlinopt_clus3.m",/* pName */
  0                                    /* checkKind */
};

static emlrtECInfo g_emlrtECI = { -1,  /* nDims */
  23,                                  /* lineNo */
  11,                                  /* colNo */
  "cordlinopt_clus3",                  /* fName */
  "/home/selorm/Dropbox/Nasah_Marcus/Codes_Soale_Tsyawo_2018/Matlab_and_C_Toolbox/cordlinopt_clus3.m"/* pName */
};

static emlrtBCInfo nc_emlrtBCI = { -1, /* iFirst */
  -1,                                  /* iLast */
  23,                                  /* lineNo */
  17,                                  /* colNo */
  "X",                                 /* aName */
  "cordlinopt_clus3",                  /* fName */
  "/home/selorm/Dropbox/Nasah_Marcus/Codes_Soale_Tsyawo_2018/Matlab_and_C_Toolbox/cordlinopt_clus3.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo oc_emlrtBCI = { -1, /* iFirst */
  -1,                                  /* iLast */
  23,                                  /* lineNo */
  28,                                  /* colNo */
  "bets",                              /* aName */
  "cordlinopt_clus3",                  /* fName */
  "/home/selorm/Dropbox/Nasah_Marcus/Codes_Soale_Tsyawo_2018/Matlab_and_C_Toolbox/cordlinopt_clus3.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo pc_emlrtBCI = { -1, /* iFirst */
  -1,                                  /* iLast */
  24,                                  /* lineNo */
  33,                                  /* colNo */
  "Xdot",                              /* aName */
  "cordlinopt_clus3",                  /* fName */
  "/home/selorm/Dropbox/Nasah_Marcus/Codes_Soale_Tsyawo_2018/Matlab_and_C_Toolbox/cordlinopt_clus3.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo qc_emlrtBCI = { -1, /* iFirst */
  -1,                                  /* iLast */
  24,                                  /* lineNo */
  5,                                   /* colNo */
  "bets",                              /* aName */
  "cordlinopt_clus3",                  /* fName */
  "/home/selorm/Dropbox/Nasah_Marcus/Codes_Soale_Tsyawo_2018/Matlab_and_C_Toolbox/cordlinopt_clus3.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo rc_emlrtBCI = { -1, /* iFirst */
  -1,                                  /* iLast */
  38,                                  /* lineNo */
  17,                                  /* colNo */
  "X",                                 /* aName */
  "cordlinopt_clus3",                  /* fName */
  "/home/selorm/Dropbox/Nasah_Marcus/Codes_Soale_Tsyawo_2018/Matlab_and_C_Toolbox/cordlinopt_clus3.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo sc_emlrtBCI = { -1, /* iFirst */
  -1,                                  /* iLast */
  38,                                  /* lineNo */
  28,                                  /* colNo */
  "bets",                              /* aName */
  "cordlinopt_clus3",                  /* fName */
  "/home/selorm/Dropbox/Nasah_Marcus/Codes_Soale_Tsyawo_2018/Matlab_and_C_Toolbox/cordlinopt_clus3.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo tc_emlrtBCI = { -1, /* iFirst */
  -1,                                  /* iLast */
  59,                                  /* lineNo */
  37,                                  /* colNo */
  "Xdot",                              /* aName */
  "cordlinopt_clus3",                  /* fName */
  "/home/selorm/Dropbox/Nasah_Marcus/Codes_Soale_Tsyawo_2018/Matlab_and_C_Toolbox/cordlinopt_clus3.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo uc_emlrtBCI = { -1, /* iFirst */
  -1,                                  /* iLast */
  59,                                  /* lineNo */
  9,                                   /* colNo */
  "bets",                              /* aName */
  "cordlinopt_clus3",                  /* fName */
  "/home/selorm/Dropbox/Nasah_Marcus/Codes_Soale_Tsyawo_2018/Matlab_and_C_Toolbox/cordlinopt_clus3.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo vc_emlrtBCI = { -1, /* iFirst */
  -1,                                  /* iLast */
  41,                                  /* lineNo */
  26,                                  /* colNo */
  "Xdot",                              /* aName */
  "cordlinopt_clus3",                  /* fName */
  "/home/selorm/Dropbox/Nasah_Marcus/Codes_Soale_Tsyawo_2018/Matlab_and_C_Toolbox/cordlinopt_clus3.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo wc_emlrtBCI = { -1, /* iFirst */
  -1,                                  /* iLast */
  48,                                  /* lineNo */
  23,                                  /* colNo */
  "bets",                              /* aName */
  "cordlinopt_clus3",                  /* fName */
  "/home/selorm/Dropbox/Nasah_Marcus/Codes_Soale_Tsyawo_2018/Matlab_and_C_Toolbox/cordlinopt_clus3.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo xc_emlrtBCI = { -1, /* iFirst */
  -1,                                  /* iLast */
  49,                                  /* lineNo */
  9,                                   /* colNo */
  "bets",                              /* aName */
  "cordlinopt_clus3",                  /* fName */
  "/home/selorm/Dropbox/Nasah_Marcus/Codes_Soale_Tsyawo_2018/Matlab_and_C_Toolbox/cordlinopt_clus3.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo yc_emlrtBCI = { -1, /* iFirst */
  -1,                                  /* iLast */
  55,                                  /* lineNo */
  9,                                   /* colNo */
  "clus",                              /* aName */
  "cordlinopt_clus3",                  /* fName */
  "/home/selorm/Dropbox/Nasah_Marcus/Codes_Soale_Tsyawo_2018/Matlab_and_C_Toolbox/cordlinopt_clus3.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo ad_emlrtBCI = { -1, /* iFirst */
  -1,                                  /* iLast */
  56,                                  /* lineNo */
  23,                                  /* colNo */
  "bets",                              /* aName */
  "cordlinopt_clus3",                  /* fName */
  "/home/selorm/Dropbox/Nasah_Marcus/Codes_Soale_Tsyawo_2018/Matlab_and_C_Toolbox/cordlinopt_clus3.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo bd_emlrtBCI = { -1, /* iFirst */
  -1,                                  /* iLast */
  56,                                  /* lineNo */
  9,                                   /* colNo */
  "clmns",                             /* aName */
  "cordlinopt_clus3",                  /* fName */
  "/home/selorm/Dropbox/Nasah_Marcus/Codes_Soale_Tsyawo_2018/Matlab_and_C_Toolbox/cordlinopt_clus3.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo cd_emlrtBCI = { -1, /* iFirst */
  -1,                                  /* iLast */
  52,                                  /* lineNo */
  14,                                  /* colNo */
  "bets",                              /* aName */
  "cordlinopt_clus3",                  /* fName */
  "/home/selorm/Dropbox/Nasah_Marcus/Codes_Soale_Tsyawo_2018/Matlab_and_C_Toolbox/cordlinopt_clus3.m",/* pName */
  0                                    /* checkKind */
};

static emlrtRSInfo wf_emlrtRSI = { 60, /* lineNo */
  "fprintf",                           /* fcnName */
  "/usr/local/MATLAB/R2018b/toolbox/eml/lib/matlab/iofun/fprintf.m"/* pathName */
};

/* Function Declarations */
static void __anon_fcn(const emlrtStack *sp, const emxArray_real_T *Y, const
  emxArray_real_T *X, real_T nC, const emxArray_real_T *Xdot, const
  emxArray_real_T *clus, real_T k, emxArray_real_T *bets, emxArray_real_T
  *varargout_2, real_T *varargout_3);
static const mxArray *e_feval(const emlrtStack *sp, const mxArray *b, const
  mxArray *c, const mxArray *d, const mxArray *e, const mxArray *f, const
  mxArray *g, emlrtMCInfo *location);

/* Function Definitions */
static void __anon_fcn(const emlrtStack *sp, const emxArray_real_T *Y, const
  emxArray_real_T *X, real_T nC, const emxArray_real_T *Xdot, const
  emxArray_real_T *clus, real_T k, emxArray_real_T *bets, emxArray_real_T
  *varargout_2, real_T *varargout_3)
{
  emxArray_real_T *b_clus;
  int32_T i14;
  int32_T loop_ub;
  int32_T p;
  real_T cnt;
  emxArray_boolean_T *id;
  emxArray_real_T *err;
  emxArray_int32_T *r2;
  emxArray_uint32_T *y;
  emxArray_real_T *a;
  emxArray_real_T *b;
  emxArray_int32_T *a_tmp;
  emxArray_real_T *b_Y;
  emxArray_real_T *b_X;
  int32_T j;
  int32_T i15;
  int32_T end;
  int32_T i;
  int32_T n;
  real_T alpha1;
  real_T beta1;
  ptrdiff_t m_t;
  ptrdiff_t n_t;
  ptrdiff_t k_t;
  ptrdiff_t lda_t;
  ptrdiff_t ldb_t;
  ptrdiff_t ldc_t;
  char_T TRANSA;
  char_T TRANSB;
  int32_T i16;
  emxArray_real_T *clmns;
  int32_T lk;
  int32_T c_clus[2];
  emxArray_int32_T *r3;
  emxArray_int32_T *r4;
  emxArray_real_T *bj;
  int32_T exitg1;
  const mxArray *b_y;
  const mxArray *m41;
  static const int32_T iv28[2] = { 1, 7 };

  static const char_T u[7] = { 'f', 'p', 'r', 'i', 'n', 't', 'f' };

  const mxArray *c_y;
  const mxArray *m42;
  static const int32_T iv29[2] = { 1, 49 };

  static const char_T b_u[49] = { '\\', 'n', ' ', 'I', 'n', 'n', 'e', 'r', ' ',
    'i', 't', 'e', 'r', ' ', '=', ' ', '%', 'u', ' ', 'R', 'S', 'S', ' ', '=',
    ' ', '%', '0', '.', '5', 'f', ' ', 'a', 'n', 'd', ' ', 'd', 'e', 'v', ' ',
    '=', ' ', '%', '0', '.', '5', 'f', ' ', '\\', 'n' };

  const mxArray *d_y;
  const mxArray *m43;
  uint64_T u1;
  real_T nbytes;
  int32_T b_a_tmp[1];
  int32_T idx;
  boolean_T overflow;
  boolean_T exitg2;
  emlrtStack st;
  emlrtStack b_st;
  emlrtStack c_st;
  emlrtStack d_st;
  emlrtStack e_st;
  emlrtStack f_st;
  emlrtStack g_st;
  emlrtStack h_st;
  emlrtStack i_st;
  st.prev = sp;
  st.tls = sp->tls;
  b_st.prev = &st;
  b_st.tls = st.tls;
  c_st.prev = &b_st;
  c_st.tls = b_st.tls;
  d_st.prev = &c_st;
  d_st.tls = c_st.tls;
  e_st.prev = &d_st;
  e_st.tls = d_st.tls;
  f_st.prev = &e_st;
  f_st.tls = e_st.tls;
  g_st.prev = &f_st;
  g_st.tls = f_st.tls;
  h_st.prev = &g_st;
  h_st.tls = g_st.tls;
  i_st.prev = &h_st;
  i_st.tls = h_st.tls;
  emlrtHeapReferenceStackEnterFcnR2012b(sp);
  emxInit_real_T(sp, &b_clus, 2, &cc_emlrtRTEI, true);
  st.site = &wb_emlrtRSI;
  i14 = b_clus->size[0] * b_clus->size[1];
  b_clus->size[0] = 1;
  b_clus->size[1] = clus->size[1];
  emxEnsureCapacity_real_T(&st, b_clus, i14, &cc_emlrtRTEI);
  loop_ub = clus->size[0] * clus->size[1];
  for (i14 = 0; i14 < loop_ub; i14++) {
    b_clus->data[i14] = clus->data[i14];
  }

  /*  use coordinate descent to estimate linear regression */
  /*  and incorporate covariate clustering into k clusters. */
  /*  inputs: */
  /*  Y - vector of outcome variable */
  /*  X - matrix of p covariates, including 1's for intercept */
  /*  k - number of clusters */
  /*  nC - the first nC covariates in X are not to be clustered. nC=1 if only */
  /*  intercept is excluded from clustering. */
  /*  bets - vector of p betas */
  /*  Xdot - sum of squares of each column of X */
  /*  clus - clustering of X into k clusters */
  /*  */
  p = X->size[1];
  cnt = 0.0;

  /* counter */
  /*  Initial unconstrained coordinate descent algorithm */
  i14 = X->size[1];
  emxInit_boolean_T(&st, &id, 2, &fc_emlrtRTEI, true);
  emxInit_real_T(&st, &err, 1, &gd_emlrtRTEI, true);
  emxInit_int32_T(&st, &r2, 2, &ab_emlrtRTEI, true);
  emxInit_uint32_T(&st, &y, 2, &id_emlrtRTEI, true);
  emxInit_real_T(&st, &a, 2, &jc_emlrtRTEI, true);
  emxInit_real_T(&st, &b, 1, &lc_emlrtRTEI, true);
  emxInit_int32_T(&st, &a_tmp, 1, &hc_emlrtRTEI, true);
  emxInit_real_T(&st, &b_Y, 1, &oc_emlrtRTEI, true);
  emxInit_real_T(&st, &b_X, 1, &pc_emlrtRTEI, true);
  for (j = 0; j < i14; j++) {
    if (p < 1) {
      y->size[0] = 1;
      y->size[1] = 0;
    } else {
      i15 = y->size[0] * y->size[1];
      y->size[0] = 1;
      y->size[1] = p;
      emxEnsureCapacity_uint32_T(&st, y, i15, &dc_emlrtRTEI);
      loop_ub = p - 1;
      for (i15 = 0; i15 <= loop_ub; i15++) {
        y->data[i15] = 1U + i15;
      }
    }

    i15 = id->size[0] * id->size[1];
    id->size[0] = 1;
    id->size[1] = y->size[1];
    emxEnsureCapacity_boolean_T(&st, id, i15, &fc_emlrtRTEI);
    loop_ub = y->size[0] * y->size[1];
    for (i15 = 0; i15 < loop_ub; i15++) {
      id->data[i15] = ((int32_T)y->data[i15] != j + 1);
    }

    end = id->size[1] - 1;
    loop_ub = 0;
    for (i = 0; i <= end; i++) {
      if (id->data[i]) {
        loop_ub++;
      }
    }

    i15 = r2->size[0] * r2->size[1];
    r2->size[0] = 1;
    r2->size[1] = loop_ub;
    emxEnsureCapacity_int32_T(&st, r2, i15, &ab_emlrtRTEI);
    n = 0;
    for (i = 0; i <= end; i++) {
      if (id->data[i]) {
        r2->data[n] = i + 1;
        n++;
      }
    }

    b_st.site = &xb_emlrtRSI;
    i15 = a_tmp->size[0];
    a_tmp->size[0] = r2->size[1];
    emxEnsureCapacity_int32_T(&b_st, a_tmp, i15, &hc_emlrtRTEI);
    loop_ub = r2->size[1];
    for (i15 = 0; i15 < loop_ub; i15++) {
      a_tmp->data[i15] = r2->data[i15];
    }

    n = X->size[1];
    loop_ub = X->size[0];
    i15 = a->size[0] * a->size[1];
    a->size[0] = loop_ub;
    a->size[1] = a_tmp->size[0];
    emxEnsureCapacity_real_T(&b_st, a, i15, &jc_emlrtRTEI);
    i = a_tmp->size[0];
    for (i15 = 0; i15 < i; i15++) {
      for (i16 = 0; i16 < loop_ub; i16++) {
        end = a_tmp->data[i15];
        if ((end < 1) || (end > n)) {
          emlrtDynamicBoundsCheckR2012b(end, 1, n, &nc_emlrtBCI, &b_st);
        }

        a->data[i16 + a->size[0] * i15] = X->data[i16 + X->size[0] * (end - 1)];
      }
    }

    n = bets->size[1];
    i15 = b->size[0];
    b->size[0] = a_tmp->size[0];
    emxEnsureCapacity_real_T(&b_st, b, i15, &lc_emlrtRTEI);
    loop_ub = a_tmp->size[0];
    for (i15 = 0; i15 < loop_ub; i15++) {
      i16 = a_tmp->data[i15];
      if ((i16 < 1) || (i16 > n)) {
        emlrtDynamicBoundsCheckR2012b(i16, 1, n, &oc_emlrtBCI, &b_st);
      }

      b->data[i15] = bets->data[i16 - 1];
    }

    c_st.site = &lc_emlrtRSI;
    if (a_tmp->size[0] != b->size[0]) {
      i15 = X->size[0];
      if (((i15 == 1) && (a_tmp->size[0] == 1)) || (b->size[0] == 1)) {
        emlrtErrorWithMessageIdR2018a(&c_st, &ce_emlrtRTEI,
          "Coder:toolbox:mtimes_noDynamicScalarExpansion",
          "Coder:toolbox:mtimes_noDynamicScalarExpansion", 0);
      } else {
        emlrtErrorWithMessageIdR2018a(&c_st, &de_emlrtRTEI, "MATLAB:innerdim",
          "MATLAB:innerdim", 0);
      }
    }

    if ((a_tmp->size[0] == 1) || (b->size[0] == 1)) {
      i15 = err->size[0];
      err->size[0] = a->size[0];
      emxEnsureCapacity_real_T(&b_st, err, i15, &jc_emlrtRTEI);
      loop_ub = a->size[0];
      for (i15 = 0; i15 < loop_ub; i15++) {
        err->data[i15] = 0.0;
        i = a->size[1];
        for (i16 = 0; i16 < i; i16++) {
          err->data[i15] += a->data[i15 + a->size[0] * i16] * b->data[i16];
        }
      }
    } else {
      c_st.site = &kc_emlrtRSI;
      i15 = X->size[0];
      if ((i15 == 0) || (a_tmp->size[0] == 0) || (b->size[0] == 0)) {
        loop_ub = X->size[0];
        i15 = err->size[0];
        err->size[0] = loop_ub;
        emxEnsureCapacity_real_T(&c_st, err, i15, &jc_emlrtRTEI);
        for (i15 = 0; i15 < loop_ub; i15++) {
          err->data[i15] = 0.0;
        }
      } else {
        d_st.site = &mc_emlrtRSI;
        d_st.site = &nc_emlrtRSI;
        alpha1 = 1.0;
        beta1 = 0.0;
        i15 = X->size[0];
        m_t = (ptrdiff_t)i15;
        n_t = (ptrdiff_t)1;
        k_t = (ptrdiff_t)a_tmp->size[0];
        i15 = X->size[0];
        lda_t = (ptrdiff_t)i15;
        ldb_t = (ptrdiff_t)a_tmp->size[0];
        i15 = X->size[0];
        ldc_t = (ptrdiff_t)i15;
        i15 = X->size[0];
        i16 = err->size[0];
        err->size[0] = i15;
        emxEnsureCapacity_real_T(&d_st, err, i16, &kc_emlrtRTEI);
        TRANSA = 'N';
        TRANSB = 'N';
        dgemm(&TRANSA, &TRANSB, &m_t, &n_t, &k_t, &alpha1, &a->data[0], &lda_t,
              &b->data[0], &ldb_t, &beta1, &err->data[0], &ldc_t);
      }
    }

    i15 = Y->size[0];
    i16 = err->size[0];
    if (i15 != i16) {
      emlrtSizeEqCheck1DR2012b(i15, i16, &g_emlrtECI, &st);
    }

    i15 = b_Y->size[0];
    b_Y->size[0] = Y->size[0];
    emxEnsureCapacity_real_T(&st, b_Y, i15, &oc_emlrtRTEI);
    loop_ub = Y->size[0];
    for (i15 = 0; i15 < loop_ub; i15++) {
      b_Y->data[i15] = Y->data[i15] - err->data[i15];
    }

    loop_ub = X->size[0];
    i15 = X->size[1];
    i16 = 1 + j;
    if ((i16 < 1) || (i16 > i15)) {
      emlrtDynamicBoundsCheckR2012b(i16, 1, i15, &mc_emlrtBCI, &st);
    }

    i15 = b_X->size[0];
    b_X->size[0] = loop_ub;
    emxEnsureCapacity_real_T(&st, b_X, i15, &pc_emlrtRTEI);
    for (i15 = 0; i15 < loop_ub; i15++) {
      b_X->data[i15] = X->data[i15 + X->size[0] * (i16 - 1)];
    }

    i15 = Xdot->size[1];
    i16 = 1 + j;
    if ((i16 < 1) || (i16 > i15)) {
      emlrtDynamicBoundsCheckR2012b(i16, 1, i15, &pc_emlrtBCI, &st);
    }

    i15 = bets->size[1];
    end = 1 + j;
    if ((end < 1) || (end > i15)) {
      emlrtDynamicBoundsCheckR2012b(end, 1, i15, &qc_emlrtBCI, &st);
    }

    b_st.site = &yb_emlrtRSI;
    bets->data[end - 1] = dot(&b_st, b_Y, b_X) / Xdot->data[i16 - 1];

    /* update directly for non-clustered */
    if (*emlrtBreakCheckR2012bFlagVar != 0) {
      emlrtBreakCheckR2012b(&st);
    }
  }

  emxFree_int32_T(&r2);

  /*  end for j */
  b_st.site = &ac_emlrtRSI;
  loop_ub = bets->size[1];
  i14 = b->size[0];
  b->size[0] = loop_ub;
  emxEnsureCapacity_real_T(&b_st, b, i14, &ec_emlrtRTEI);
  for (i14 = 0; i14 < loop_ub; i14++) {
    b->data[i14] = bets->data[i14];
  }

  c_st.site = &lc_emlrtRSI;
  if (X->size[1] != b->size[0]) {
    if (((X->size[0] == 1) && (X->size[1] == 1)) || (b->size[0] == 1)) {
      emlrtErrorWithMessageIdR2018a(&c_st, &ce_emlrtRTEI,
        "Coder:toolbox:mtimes_noDynamicScalarExpansion",
        "Coder:toolbox:mtimes_noDynamicScalarExpansion", 0);
    } else {
      emlrtErrorWithMessageIdR2018a(&c_st, &de_emlrtRTEI, "MATLAB:innerdim",
        "MATLAB:innerdim", 0);
    }
  }

  if ((X->size[1] == 1) || (b->size[0] == 1)) {
    i14 = err->size[0];
    err->size[0] = X->size[0];
    emxEnsureCapacity_real_T(&b_st, err, i14, &gc_emlrtRTEI);
    loop_ub = X->size[0];
    for (i14 = 0; i14 < loop_ub; i14++) {
      err->data[i14] = 0.0;
      i = X->size[1];
      for (i15 = 0; i15 < i; i15++) {
        err->data[i14] += X->data[i14 + X->size[0] * i15] * b->data[i15];
      }
    }
  } else {
    c_st.site = &kc_emlrtRSI;
    if ((X->size[0] == 0) || (X->size[1] == 0) || (b->size[0] == 0)) {
      i14 = err->size[0];
      err->size[0] = X->size[0];
      emxEnsureCapacity_real_T(&c_st, err, i14, &gc_emlrtRTEI);
      loop_ub = X->size[0];
      for (i14 = 0; i14 < loop_ub; i14++) {
        err->data[i14] = 0.0;
      }
    } else {
      d_st.site = &mc_emlrtRSI;
      d_st.site = &nc_emlrtRSI;
      alpha1 = 1.0;
      beta1 = 0.0;
      m_t = (ptrdiff_t)X->size[0];
      n_t = (ptrdiff_t)1;
      k_t = (ptrdiff_t)X->size[1];
      lda_t = (ptrdiff_t)X->size[0];
      ldb_t = (ptrdiff_t)X->size[1];
      ldc_t = (ptrdiff_t)X->size[0];
      i14 = err->size[0];
      err->size[0] = X->size[0];
      emxEnsureCapacity_real_T(&d_st, err, i14, &kc_emlrtRTEI);
      TRANSA = 'N';
      TRANSB = 'N';
      dgemm(&TRANSA, &TRANSB, &m_t, &n_t, &k_t, &alpha1, &X->data[0], &lda_t,
            &b->data[0], &ldb_t, &beta1, &err->data[0], &ldc_t);
    }
  }

  i14 = Y->size[0];
  i15 = err->size[0];
  if (i14 != i15) {
    emlrtSizeEqCheck1DR2012b(i14, i15, &f_emlrtECI, &st);
  }

  i14 = b_Y->size[0];
  b_Y->size[0] = Y->size[0];
  emxEnsureCapacity_real_T(&st, b_Y, i14, &ic_emlrtRTEI);
  loop_ub = Y->size[0];
  for (i14 = 0; i14 < loop_ub; i14++) {
    b_Y->data[i14] = Y->data[i14] - err->data[i14];
  }

  b_st.site = &ac_emlrtRSI;
  power(&b_st, b_Y, err);
  b_st.site = &ac_emlrtRSI;
  *varargout_3 = sum(&b_st, err);

  /*  initial RSS0 */
  /*  Initial clustering */
  b_st.site = &bc_emlrtRSI;
  rng(&b_st);

  /*  For reproducibility */
  if (nC + 1.0 > X->size[1]) {
    i14 = 0;
    i16 = 0;
  } else {
    i14 = bets->size[1];
    if (nC + 1.0 != (int32_T)muDoubleScalarFloor(nC + 1.0)) {
      emlrtIntegerCheckR2012b(nC + 1.0, &e_emlrtDCI, &st);
    }

    i15 = (int32_T)(nC + 1.0);
    if ((i15 < 1) || (i15 > i14)) {
      emlrtDynamicBoundsCheckR2012b(i15, 1, i14, &lc_emlrtBCI, &st);
    }

    i14 = i15 - 1;
    i15 = bets->size[1];
    i16 = X->size[1];
    if ((i16 < 1) || (i16 > i15)) {
      emlrtDynamicBoundsCheckR2012b(i16, 1, i15, &kc_emlrtBCI, &st);
    }
  }

  i15 = b_Y->size[0];
  loop_ub = i16 - i14;
  b_Y->size[0] = loop_ub;
  emxEnsureCapacity_real_T(&st, b_Y, i15, &mc_emlrtRTEI);
  for (i15 = 0; i15 < loop_ub; i15++) {
    b_Y->data[i15] = bets->data[i14 + i15];
  }

  emxInit_real_T(&st, &clmns, 1, &hd_emlrtRTEI, true);
  b_st.site = &cc_emlrtRSI;
  kmeans(&b_st, b_Y, k, varargout_2, clmns);

  /*  bets of length p */
  lk = varargout_2->size[0];
  if (1 > varargout_2->size[0]) {
    i15 = 0;
  } else {
    i14 = varargout_2->size[0];
    i15 = varargout_2->size[0];
    if ((i15 < 1) || (i15 > i14)) {
      emlrtDynamicBoundsCheckR2012b(i15, 1, i14, &jc_emlrtBCI, &st);
    }
  }

  if (nC + 1.0 > X->size[1]) {
    i14 = 0;
    end = 0;
  } else {
    i14 = clus->size[1];
    if (nC + 1.0 != (int32_T)muDoubleScalarFloor(nC + 1.0)) {
      emlrtIntegerCheckR2012b(nC + 1.0, &d_emlrtDCI, &st);
    }

    i16 = (int32_T)(nC + 1.0);
    if ((i16 < 1) || (i16 > i14)) {
      emlrtDynamicBoundsCheckR2012b(i16, 1, i14, &ic_emlrtBCI, &st);
    }

    i14 = i16 - 1;
    i16 = clus->size[1];
    end = X->size[1];
    if ((end < 1) || (end > i16)) {
      emlrtDynamicBoundsCheckR2012b(end, 1, i16, &hc_emlrtBCI, &st);
    }
  }

  i16 = a_tmp->size[0];
  loop_ub = end - i14;
  a_tmp->size[0] = loop_ub;
  emxEnsureCapacity_int32_T(&st, a_tmp, i16, &nc_emlrtRTEI);
  for (i16 = 0; i16 < loop_ub; i16++) {
    a_tmp->data[i16] = i14 + i16;
  }

  c_clus[0] = 1;
  c_clus[1] = a_tmp->size[0];
  emlrtSubAssignSizeCheckR2012b(&c_clus[0], 2, &i15, 1, &e_emlrtECI, &st);
  n = a_tmp->size[0];
  for (i14 = 0; i14 < n; i14++) {
    b_clus->data[a_tmp->data[i14]] = varargout_2->data[i14];
  }

  /*  to run in a while loop */
  emxInit_int32_T(&st, &r3, 2, &ab_emlrtRTEI, true);
  emxInit_int32_T(&st, &r4, 2, &ab_emlrtRTEI, true);
  emxInit_real_T(&st, &bj, 2, &fd_emlrtRTEI, true);
  do {
    exitg1 = 0;
    cnt++;
    for (j = 0; j < p; j++) {
      if (p < 1) {
        y->size[0] = 1;
        y->size[1] = 0;
      } else {
        i14 = y->size[0] * y->size[1];
        y->size[0] = 1;
        y->size[1] = p;
        emxEnsureCapacity_uint32_T(&st, y, i14, &dc_emlrtRTEI);
        loop_ub = p - 1;
        for (i14 = 0; i14 <= loop_ub; i14++) {
          y->data[i14] = 1U + i14;
        }
      }

      i14 = id->size[0] * id->size[1];
      id->size[0] = 1;
      id->size[1] = y->size[1];
      emxEnsureCapacity_boolean_T(&st, id, i14, &rc_emlrtRTEI);
      loop_ub = y->size[0] * y->size[1];
      for (i14 = 0; i14 < loop_ub; i14++) {
        id->data[i14] = ((int32_T)y->data[i14] != j + 1);
      }

      end = id->size[1] - 1;
      loop_ub = 0;
      for (i = 0; i <= end; i++) {
        if (id->data[i]) {
          loop_ub++;
        }
      }

      i14 = r3->size[0] * r3->size[1];
      r3->size[0] = 1;
      r3->size[1] = loop_ub;
      emxEnsureCapacity_int32_T(&st, r3, i14, &ab_emlrtRTEI);
      n = 0;
      for (i = 0; i <= end; i++) {
        if (id->data[i]) {
          r3->data[n] = i + 1;
          n++;
        }
      }

      b_st.site = &dc_emlrtRSI;
      i14 = a_tmp->size[0];
      a_tmp->size[0] = r3->size[1];
      emxEnsureCapacity_int32_T(&b_st, a_tmp, i14, &tc_emlrtRTEI);
      loop_ub = r3->size[1];
      for (i14 = 0; i14 < loop_ub; i14++) {
        a_tmp->data[i14] = r3->data[i14];
      }

      n = X->size[1];
      loop_ub = X->size[0];
      i14 = a->size[0] * a->size[1];
      a->size[0] = loop_ub;
      a->size[1] = a_tmp->size[0];
      emxEnsureCapacity_real_T(&b_st, a, i14, &vc_emlrtRTEI);
      i = a_tmp->size[0];
      for (i14 = 0; i14 < i; i14++) {
        for (i15 = 0; i15 < loop_ub; i15++) {
          i16 = a_tmp->data[i14];
          if ((i16 < 1) || (i16 > n)) {
            emlrtDynamicBoundsCheckR2012b(i16, 1, n, &rc_emlrtBCI, &b_st);
          }

          a->data[i15 + a->size[0] * i14] = X->data[i15 + X->size[0] * (i16 - 1)];
        }
      }

      n = bets->size[1];
      i14 = b->size[0];
      b->size[0] = a_tmp->size[0];
      emxEnsureCapacity_real_T(&b_st, b, i14, &wc_emlrtRTEI);
      loop_ub = a_tmp->size[0];
      for (i14 = 0; i14 < loop_ub; i14++) {
        i15 = a_tmp->data[i14];
        if ((i15 < 1) || (i15 > n)) {
          emlrtDynamicBoundsCheckR2012b(i15, 1, n, &sc_emlrtBCI, &b_st);
        }

        b->data[i14] = bets->data[i15 - 1];
      }

      c_st.site = &lc_emlrtRSI;
      if (a_tmp->size[0] != b->size[0]) {
        i14 = X->size[0];
        if (((i14 == 1) && (a_tmp->size[0] == 1)) || (b->size[0] == 1)) {
          emlrtErrorWithMessageIdR2018a(&c_st, &ce_emlrtRTEI,
            "Coder:toolbox:mtimes_noDynamicScalarExpansion",
            "Coder:toolbox:mtimes_noDynamicScalarExpansion", 0);
        } else {
          emlrtErrorWithMessageIdR2018a(&c_st, &de_emlrtRTEI, "MATLAB:innerdim",
            "MATLAB:innerdim", 0);
        }
      }

      if ((a_tmp->size[0] == 1) || (b->size[0] == 1)) {
        i14 = err->size[0];
        err->size[0] = a->size[0];
        emxEnsureCapacity_real_T(&b_st, err, i14, &vc_emlrtRTEI);
        loop_ub = a->size[0];
        for (i14 = 0; i14 < loop_ub; i14++) {
          err->data[i14] = 0.0;
          i = a->size[1];
          for (i15 = 0; i15 < i; i15++) {
            err->data[i14] += a->data[i14 + a->size[0] * i15] * b->data[i15];
          }
        }
      } else {
        c_st.site = &kc_emlrtRSI;
        i14 = X->size[0];
        if ((i14 == 0) || (a_tmp->size[0] == 0) || (b->size[0] == 0)) {
          loop_ub = X->size[0];
          i14 = err->size[0];
          err->size[0] = loop_ub;
          emxEnsureCapacity_real_T(&c_st, err, i14, &vc_emlrtRTEI);
          for (i14 = 0; i14 < loop_ub; i14++) {
            err->data[i14] = 0.0;
          }
        } else {
          d_st.site = &mc_emlrtRSI;
          d_st.site = &nc_emlrtRSI;
          alpha1 = 1.0;
          beta1 = 0.0;
          i14 = X->size[0];
          m_t = (ptrdiff_t)i14;
          n_t = (ptrdiff_t)1;
          k_t = (ptrdiff_t)a_tmp->size[0];
          i14 = X->size[0];
          lda_t = (ptrdiff_t)i14;
          ldb_t = (ptrdiff_t)a_tmp->size[0];
          i14 = X->size[0];
          ldc_t = (ptrdiff_t)i14;
          i14 = X->size[0];
          i15 = err->size[0];
          err->size[0] = i14;
          emxEnsureCapacity_real_T(&d_st, err, i15, &kc_emlrtRTEI);
          TRANSA = 'N';
          TRANSB = 'N';
          dgemm(&TRANSA, &TRANSB, &m_t, &n_t, &k_t, &alpha1, &a->data[0], &lda_t,
                &b->data[0], &ldb_t, &beta1, &err->data[0], &ldc_t);
        }
      }

      i14 = Y->size[0];
      i15 = err->size[0];
      if (i14 != i15) {
        emlrtSizeEqCheck1DR2012b(i14, i15, &d_emlrtECI, &st);
      }

      i14 = err->size[0];
      err->size[0] = Y->size[0];
      emxEnsureCapacity_real_T(&st, err, i14, &xc_emlrtRTEI);
      loop_ub = Y->size[0];
      for (i14 = 0; i14 < loop_ub; i14++) {
        err->data[i14] = Y->data[i14] - err->data[i14];
      }

      if (1.0 + (real_T)j > nC) {
        loop_ub = X->size[0];
        i14 = X->size[1];
        i15 = 1 + j;
        if ((i15 < 1) || (i15 > i14)) {
          emlrtDynamicBoundsCheckR2012b(i15, 1, i14, &gc_emlrtBCI, &st);
        }

        i14 = b_X->size[0];
        b_X->size[0] = loop_ub;
        emxEnsureCapacity_real_T(&st, b_X, i14, &bd_emlrtRTEI);
        for (i14 = 0; i14 < loop_ub; i14++) {
          b_X->data[i14] = X->data[i14 + X->size[0] * (i15 - 1)];
        }

        i14 = Xdot->size[1];
        i15 = 1 + j;
        if ((i15 < 1) || (i15 > i14)) {
          emlrtDynamicBoundsCheckR2012b(i15, 1, i14, &vc_emlrtBCI, &st);
        }

        b_st.site = &ec_emlrtRSI;
        alpha1 = dot(&b_st, err, b_X) / Xdot->data[i15 - 1];
        i14 = b_clus->size[1];
        i15 = 1 + j;
        if ((i15 < 1) || (i15 > i14)) {
          emlrtDynamicBoundsCheckR2012b(i15, 1, i14, &fc_emlrtBCI, &st);
        }

        /* identify current cluster assignment */
        i14 = b_Y->size[0];
        b_Y->size[0] = clmns->size[0];
        emxEnsureCapacity_real_T(&st, b_Y, i14, &cd_emlrtRTEI);
        loop_ub = clmns->size[0];
        for (i14 = 0; i14 < loop_ub; i14++) {
          b_Y->data[i14] = clmns->data[i14] - alpha1;
        }

        b_st.site = &fc_emlrtRSI;
        b_abs(&b_st, b_Y, err);
        b_st.site = &fc_emlrtRSI;
        c_st.site = &hf_emlrtRSI;
        d_st.site = &if_emlrtRSI;
        e_st.site = &jf_emlrtRSI;
        if (err->size[0] < 1) {
          emlrtErrorWithMessageIdR2018a(&e_st, &ee_emlrtRTEI,
            "Coder:toolbox:eml_min_or_max_varDimZero",
            "Coder:toolbox:eml_min_or_max_varDimZero", 0);
        }

        f_st.site = &kf_emlrtRSI;
        n = err->size[0];
        if (err->size[0] <= 2) {
          if (err->size[0] == 1) {
            idx = 1;
          } else if ((err->data[0] > err->data[1]) || (muDoubleScalarIsNaN
                      (err->data[0]) && (!muDoubleScalarIsNaN(err->data[1])))) {
            idx = 2;
          } else {
            idx = 1;
          }
        } else {
          g_st.site = &mf_emlrtRSI;
          if (!muDoubleScalarIsNaN(err->data[0])) {
            idx = 1;
          } else {
            idx = 0;
            h_st.site = &nf_emlrtRSI;
            overflow = (err->size[0] > 2147483646);
            if (overflow) {
              i_st.site = &fb_emlrtRSI;
              check_forloop_overflow_error(&i_st);
            }

            i = 2;
            exitg2 = false;
            while ((!exitg2) && (i <= err->size[0])) {
              if (!muDoubleScalarIsNaN(err->data[i - 1])) {
                idx = i;
                exitg2 = true;
              } else {
                i++;
              }
            }
          }

          if (idx == 0) {
            idx = 1;
          } else {
            g_st.site = &lf_emlrtRSI;
            beta1 = err->data[idx - 1];
            end = idx + 1;
            h_st.site = &of_emlrtRSI;
            overflow = ((idx + 1 <= err->size[0]) && (err->size[0] > 2147483646));
            if (overflow) {
              i_st.site = &fb_emlrtRSI;
              check_forloop_overflow_error(&i_st);
            }

            for (i = end; i <= n; i++) {
              if (beta1 > err->data[i - 1]) {
                beta1 = err->data[i - 1];
                idx = i;
              }
            }
          }
        }

        /*  identify nearest cluster centre */
        if (idx != b_clus->data[j]) {
          i14 = id->size[0] * id->size[1];
          id->size[0] = 1;
          id->size[1] = b_clus->size[1];
          emxEnsureCapacity_boolean_T(&st, id, i14, &ed_emlrtRTEI);
          loop_ub = b_clus->size[0] * b_clus->size[1];
          for (i14 = 0; i14 < loop_ub; i14++) {
            id->data[i14] = (b_clus->data[i14] == idx);
          }

          /* update clustered j; */
          end = id->size[1] - 1;
          loop_ub = 0;
          for (i = 0; i <= end; i++) {
            if (id->data[i]) {
              loop_ub++;
            }
          }

          i14 = r4->size[0] * r4->size[1];
          r4->size[0] = 1;
          r4->size[1] = loop_ub;
          emxEnsureCapacity_int32_T(&st, r4, i14, &ab_emlrtRTEI);
          n = 0;
          for (i = 0; i <= end; i++) {
            if (id->data[i]) {
              r4->data[n] = i + 1;
              n++;
            }
          }

          n = bets->size[1];
          i14 = bj->size[0] * bj->size[1];
          bj->size[0] = 1;
          bj->size[1] = 1 + r4->size[1];
          emxEnsureCapacity_real_T(&st, bj, i14, &fd_emlrtRTEI);
          bj->data[0] = alpha1;
          loop_ub = r4->size[1];
          for (i14 = 0; i14 < loop_ub; i14++) {
            i15 = r4->data[i14];
            if ((i15 < 1) || (i15 > n)) {
              emlrtDynamicBoundsCheckR2012b(i15, 1, n, &wc_emlrtBCI, &st);
            }

            bj->data[i14 + 1] = bets->data[i15 - 1];
          }

          b_st.site = &gc_emlrtRSI;
          alpha1 = mean(&b_st, bj);
          i14 = bets->size[1];
          i15 = 1 + j;
          if ((i15 < 1) || (i15 > i14)) {
            emlrtDynamicBoundsCheckR2012b(i15, 1, i14, &xc_emlrtBCI, &st);
          }

          bets->data[i15 - 1] = alpha1;
          i14 = id->size[1];
          for (n = 0; n < i14; n++) {
            i15 = id->size[1];
            i16 = 1 + n;
            if ((i16 < 1) || (i16 > i15)) {
              emlrtDynamicBoundsCheckR2012b(i16, 1, i15, &ec_emlrtBCI, &st);
            }

            loop_ub = 0;
            if (id->data[n]) {
              loop_ub = 1;
            }

            i15 = bets->size[1];
            for (i16 = 0; i16 < loop_ub; i16++) {
              if (1 > i15) {
                emlrtDynamicBoundsCheckR2012b(1, 1, i15, &cd_emlrtBCI, &st);
              }

              bets->data[0] = alpha1;
            }

            if (*emlrtBreakCheckR2012bFlagVar != 0) {
              emlrtBreakCheckR2012b(&st);
            }
          }

          /*  end for */
          i14 = b_clus->size[1];
          i15 = 1 + j;
          if ((i15 < 1) || (i15 > i14)) {
            emlrtDynamicBoundsCheckR2012b(i15, 1, i14, &yc_emlrtBCI, &st);
          }

          b_clus->data[i15 - 1] = idx;

          /* update j's cluster */
          i14 = bets->size[1];
          i15 = 1 + j;
          if ((i15 < 1) || (i15 > i14)) {
            emlrtDynamicBoundsCheckR2012b(i15, 1, i14, &ad_emlrtBCI, &st);
          }

          i14 = clmns->size[0];
          if ((idx < 1) || (idx > i14)) {
            emlrtDynamicBoundsCheckR2012b(idx, 1, i14, &bd_emlrtBCI, &st);
          }

          clmns->data[idx - 1] = bets->data[i15 - 1];

          /* update cluster mean beta */
        }
      } else {
        loop_ub = X->size[0];
        i14 = X->size[1];
        i15 = 1 + j;
        if ((i15 < 1) || (i15 > i14)) {
          emlrtDynamicBoundsCheckR2012b(i15, 1, i14, &dc_emlrtBCI, &st);
        }

        i14 = b_X->size[0];
        b_X->size[0] = loop_ub;
        emxEnsureCapacity_real_T(&st, b_X, i14, &ad_emlrtRTEI);
        for (i14 = 0; i14 < loop_ub; i14++) {
          b_X->data[i14] = X->data[i14 + X->size[0] * (i15 - 1)];
        }

        i14 = Xdot->size[1];
        i15 = 1 + j;
        if ((i15 < 1) || (i15 > i14)) {
          emlrtDynamicBoundsCheckR2012b(i15, 1, i14, &tc_emlrtBCI, &st);
        }

        i14 = bets->size[1];
        i16 = 1 + j;
        if ((i16 < 1) || (i16 > i14)) {
          emlrtDynamicBoundsCheckR2012b(i16, 1, i14, &uc_emlrtBCI, &st);
        }

        b_st.site = &hc_emlrtRSI;
        bets->data[i16 - 1] = dot(&b_st, err, b_X) / Xdot->data[i15 - 1];

        /* update directly for non-clustered */
      }

      /* end if(j>nC) */
      if (*emlrtBreakCheckR2012bFlagVar != 0) {
        emlrtBreakCheckR2012b(&st);
      }
    }

    /*  end for j */
    /*  Compute RSS & check convergence */
    b_st.site = &ic_emlrtRSI;
    loop_ub = bets->size[1];
    i14 = b->size[0];
    b->size[0] = loop_ub;
    emxEnsureCapacity_real_T(&b_st, b, i14, &qc_emlrtRTEI);
    for (i14 = 0; i14 < loop_ub; i14++) {
      b->data[i14] = bets->data[i14];
    }

    c_st.site = &lc_emlrtRSI;
    if (X->size[1] != b->size[0]) {
      if (((X->size[0] == 1) && (X->size[1] == 1)) || (b->size[0] == 1)) {
        emlrtErrorWithMessageIdR2018a(&c_st, &ce_emlrtRTEI,
          "Coder:toolbox:mtimes_noDynamicScalarExpansion",
          "Coder:toolbox:mtimes_noDynamicScalarExpansion", 0);
      } else {
        emlrtErrorWithMessageIdR2018a(&c_st, &de_emlrtRTEI, "MATLAB:innerdim",
          "MATLAB:innerdim", 0);
      }
    }

    if ((X->size[1] == 1) || (b->size[0] == 1)) {
      i14 = err->size[0];
      err->size[0] = X->size[0];
      emxEnsureCapacity_real_T(&b_st, err, i14, &sc_emlrtRTEI);
      loop_ub = X->size[0];
      for (i14 = 0; i14 < loop_ub; i14++) {
        err->data[i14] = 0.0;
        i = X->size[1];
        for (i15 = 0; i15 < i; i15++) {
          err->data[i14] += X->data[i14 + X->size[0] * i15] * b->data[i15];
        }
      }
    } else {
      c_st.site = &kc_emlrtRSI;
      if ((X->size[0] == 0) || (X->size[1] == 0) || (b->size[0] == 0)) {
        i14 = err->size[0];
        err->size[0] = X->size[0];
        emxEnsureCapacity_real_T(&c_st, err, i14, &sc_emlrtRTEI);
        loop_ub = X->size[0];
        for (i14 = 0; i14 < loop_ub; i14++) {
          err->data[i14] = 0.0;
        }
      } else {
        d_st.site = &mc_emlrtRSI;
        d_st.site = &nc_emlrtRSI;
        alpha1 = 1.0;
        beta1 = 0.0;
        m_t = (ptrdiff_t)X->size[0];
        n_t = (ptrdiff_t)1;
        k_t = (ptrdiff_t)X->size[1];
        lda_t = (ptrdiff_t)X->size[0];
        ldb_t = (ptrdiff_t)X->size[1];
        ldc_t = (ptrdiff_t)X->size[0];
        i14 = err->size[0];
        err->size[0] = X->size[0];
        emxEnsureCapacity_real_T(&d_st, err, i14, &kc_emlrtRTEI);
        TRANSA = 'N';
        TRANSB = 'N';
        dgemm(&TRANSA, &TRANSB, &m_t, &n_t, &k_t, &alpha1, &X->data[0], &lda_t,
              &b->data[0], &ldb_t, &beta1, &err->data[0], &ldc_t);
      }
    }

    i14 = Y->size[0];
    i15 = err->size[0];
    if (i14 != i15) {
      emlrtSizeEqCheck1DR2012b(i14, i15, &c_emlrtECI, &st);
    }

    i14 = b_Y->size[0];
    b_Y->size[0] = Y->size[0];
    emxEnsureCapacity_real_T(&st, b_Y, i14, &uc_emlrtRTEI);
    loop_ub = Y->size[0];
    for (i14 = 0; i14 < loop_ub; i14++) {
      b_Y->data[i14] = Y->data[i14] - err->data[i14];
    }

    b_st.site = &ic_emlrtRSI;
    power(&b_st, b_Y, err);
    b_st.site = &ic_emlrtRSI;
    alpha1 = sum(&b_st, err);
    beta1 = (*varargout_3 - alpha1) / (1.0E-20 + muDoubleScalarAbs(*varargout_3));
    b_st.site = &jc_emlrtRSI;
    c_st.site = &qf_emlrtRSI;
    b_y = NULL;
    m41 = emlrtCreateCharArray(2, iv28);
    emlrtInitCharArrayR2013a(&c_st, 7, m41, &u[0]);
    emlrtAssign(&b_y, m41);
    c_y = NULL;
    m42 = emlrtCreateCharArray(2, iv29);
    emlrtInitCharArrayR2013a(&c_st, 49, m42, &b_u[0]);
    emlrtAssign(&c_y, m42);
    d_y = NULL;
    m43 = emlrtCreateNumericMatrix(1, 1, mxUINT64_CLASS, mxREAL);
    if (cnt < 1.8446744073709552E+19) {
      u1 = (uint64_T)cnt;
    } else {
      u1 = MAX_uint64_T;
    }

    *(uint64_T *)emlrtMxGetData(m43) = u1;
    emlrtAssign(&d_y, m43);
    d_st.site = &wf_emlrtRSI;
    nbytes = c_emlrt_marshallIn(&d_st, e_feval(&d_st, b_y, emlrt_marshallOut(1.0),
      c_y, d_y, emlrt_marshallOut(alpha1), emlrt_marshallOut(beta1), &f_emlrtMCI),
      "feval");
    emlrtDisplayR2012b(emlrt_marshallOut(nbytes), "ans", &e_emlrtRTEI, &st);
    if (beta1 <= 1.0E-10) {
      exitg1 = 1;
    } else {
      *varargout_3 = alpha1;

      /* update RSS */
      if (nC + 1.0 > p) {
        i14 = 0;
        i15 = 0;
      } else {
        i14 = b_clus->size[1];
        if (nC + 1.0 != (int32_T)muDoubleScalarFloor(nC + 1.0)) {
          emlrtIntegerCheckR2012b(nC + 1.0, &c_emlrtDCI, &st);
        }

        i15 = (int32_T)(nC + 1.0);
        if ((i15 < 1) || (i15 > i14)) {
          emlrtDynamicBoundsCheckR2012b(i15, 1, i14, &cc_emlrtBCI, &st);
        }

        i14 = i15 - 1;
        i15 = b_clus->size[1];
        if ((p < 1) || (p > i15)) {
          emlrtDynamicBoundsCheckR2012b(p, 1, i15, &bc_emlrtBCI, &st);
        }

        i15 = p;
      }

      if (1 > lk) {
        loop_ub = 0;
      } else {
        i16 = varargout_2->size[0];
        if (1 > i16) {
          emlrtDynamicBoundsCheckR2012b(1, 1, i16, &ac_emlrtBCI, &st);
        }

        i16 = varargout_2->size[0];
        if (lk > i16) {
          emlrtDynamicBoundsCheckR2012b(lk, 1, i16, &yb_emlrtBCI, &st);
        }

        loop_ub = lk;
      }

      i16 = a_tmp->size[0];
      a_tmp->size[0] = loop_ub;
      emxEnsureCapacity_int32_T(&st, a_tmp, i16, &yc_emlrtRTEI);
      for (i16 = 0; i16 < loop_ub; i16++) {
        a_tmp->data[i16] = i16;
      }

      b_a_tmp[0] = a_tmp->size[0];
      i16 = bj->size[0] * bj->size[1];
      bj->size[0] = 1;
      loop_ub = i15 - i14;
      bj->size[1] = loop_ub;
      emxEnsureCapacity_real_T(&st, bj, i16, &dd_emlrtRTEI);
      for (i15 = 0; i15 < loop_ub; i15++) {
        bj->data[i15] = b_clus->data[i14 + i15];
      }

      c_clus[0] = bj->size[0];
      c_clus[1] = bj->size[1];
      emlrtSubAssignSizeCheckR2012b(&b_a_tmp[0], 1, &c_clus[0], 2, &b_emlrtECI,
        &st);
      n = a_tmp->size[0];
      for (i15 = 0; i15 < n; i15++) {
        varargout_2->data[a_tmp->data[i15]] = b_clus->data[i14 + i15];
      }

      /*  update clusters */
      if (*emlrtBreakCheckR2012bFlagVar != 0) {
        emlrtBreakCheckR2012b(&st);
      }
    }
  } while (exitg1 == 0);

  emxFree_real_T(&bj);
  emxFree_real_T(&b_X);
  emxFree_real_T(&b_Y);
  emxFree_int32_T(&a_tmp);
  emxFree_real_T(&b);
  emxFree_real_T(&a);
  emxFree_uint32_T(&y);
  emxFree_int32_T(&r4);
  emxFree_int32_T(&r3);
  emxFree_real_T(&clmns);
  emxFree_real_T(&err);
  emxFree_boolean_T(&id);
  emxFree_real_T(&b_clus);

  /*  end while loop */
  emlrtHeapReferenceStackLeaveFcnR2012b(sp);
}

static const mxArray *e_feval(const emlrtStack *sp, const mxArray *b, const
  mxArray *c, const mxArray *d, const mxArray *e, const mxArray *f, const
  mxArray *g, emlrtMCInfo *location)
{
  const mxArray *pArrays[6];
  const mxArray *m40;
  pArrays[0] = b;
  pArrays[1] = c;
  pArrays[2] = d;
  pArrays[3] = e;
  pArrays[4] = f;
  pArrays[5] = g;
  return emlrtCallMATLABR2012b(sp, 1, &m40, 6, pArrays, "feval", true, location);
}

void goldsscoord3(const emlrtStack *sp, const emxArray_real_T *Y, const
                  emxArray_real_T *X, real_T nC, real_T a, real_T b, real_T
                  *optk, emxArray_real_T *clus, emxArray_real_T *bets, real_T
                  *BIC)
{
  emxArray_real_T *Xdot;
  int32_T nd;
  int32_T i0;
  int32_T loop_ub;
  emxArray_real_T *X0;
  emxArray_int32_T *r0;
  emxArray_real_T *b_X;
  emxArray_real_T *c_X;
  int32_T j;
  emxArray_real_T *bets_d;
  int32_T i1;
  int32_T i2;
  real_T c_tmp;
  real_T c;
  real_T d;
  int32_T iv0[1];
  real_T coef0[2];
  emxArray_real_T *r1;
  real_T fd;
  const mxArray *y;
  const mxArray *m0;
  static const int32_T iv1[2] = { 1, 7 };

  static const char_T u[7] = { 'f', 'p', 'r', 'i', 'n', 't', 'f' };

  const mxArray *b_y;
  const mxArray *m1;
  static const int32_T iv2[2] = { 1, 42 };

  static const char_T b_u[42] = { '\\', 'n', ' ', 'O', 'u', 't', 'e', 'r', ' ',
    'i', 't', 'e', 'r', ' ', '=', ' ', '%', 'u', ',', ' ', 'k', ' ', '=', ' ',
    '%', 'u', ',', ' ', 'B', 'I', 'C', ' ', '=', ' ', '%', '0', '.', '5', 'f',
    ' ', '\\', 'n' };

  const mxArray *c_y;
  const mxArray *m2;
  const mxArray *d_y;
  const mxArray *m3;
  uint64_T u0;
  real_T fc;
  real_T cnt;
  const mxArray *m4;
  static const int32_T iv3[2] = { 1, 7 };

  const mxArray *m5;
  static const int32_T iv4[2] = { 1, 42 };

  const mxArray *m6;
  const mxArray *m7;
  emxArray_real_T *varargout_1;
  const mxArray *m8;
  static const int32_T iv5[2] = { 1, 7 };

  const mxArray *m9;
  static const int32_T iv6[2] = { 1, 42 };

  const mxArray *m10;
  const mxArray *m11;
  const mxArray *m12;
  static const int32_T iv7[2] = { 1, 7 };

  const mxArray *m13;
  static const int32_T iv8[2] = { 1, 42 };

  const mxArray *m14;
  const mxArray *m15;
  emlrtStack st;
  emlrtStack b_st;
  emlrtStack c_st;
  st.prev = sp;
  st.tls = sp->tls;
  b_st.prev = &st;
  b_st.tls = st.tls;
  c_st.prev = &b_st;
  c_st.tls = b_st.tls;
  emlrtHeapReferenceStackEnterFcnR2012b(sp);
  emxInit_real_T(sp, &Xdot, 2, &f_emlrtRTEI, true);

  /*  Golden Section Search for coordinate descent linear reg */
  nd = X->size[0];
  i0 = Xdot->size[0] * Xdot->size[1];
  Xdot->size[0] = 1;
  Xdot->size[1] = X->size[1];
  emxEnsureCapacity_real_T(sp, Xdot, i0, &f_emlrtRTEI);
  loop_ub = X->size[1];
  for (i0 = 0; i0 < loop_ub; i0++) {
    Xdot->data[i0] = 0.0;
  }

  i0 = bets->size[0] * bets->size[1];
  bets->size[0] = 1;
  bets->size[1] = X->size[1];
  emxEnsureCapacity_real_T(sp, bets, i0, &g_emlrtRTEI);
  loop_ub = X->size[1];
  for (i0 = 0; i0 < loop_ub; i0++) {
    bets->data[i0] = 0.0;
  }

  emxInit_real_T(sp, &X0, 2, &h_emlrtRTEI, true);

  /* counter */
  /*  initialise parameters */
  i0 = X0->size[0] * X0->size[1];
  X0->size[0] = X->size[0];
  X0->size[1] = 2;
  emxEnsureCapacity_real_T(sp, X0, i0, &h_emlrtRTEI);
  loop_ub = X->size[0] << 1;
  for (i0 = 0; i0 < loop_ub; i0++) {
    X0->data[i0] = 1.0;
  }

  /*  for the initialisation of coefficients */
  i0 = X->size[1];
  emxInit_int32_T(sp, &r0, 1, &u_emlrtRTEI, true);
  emxInit_real_T(sp, &b_X, 1, &l_emlrtRTEI, true);
  emxInit_real_T(sp, &c_X, 1, &m_emlrtRTEI, true);
  for (j = 0; j <= i0 - 2; j++) {
    /* intercept initialised at zero */
    loop_ub = X0->size[0];
    i1 = r0->size[0];
    r0->size[0] = loop_ub;
    emxEnsureCapacity_int32_T(sp, r0, i1, &i_emlrtRTEI);
    for (i1 = 0; i1 < loop_ub; i1++) {
      r0->data[i1] = i1;
    }

    i1 = X->size[1];
    i2 = 2 + j;
    if ((i2 < 1) || (i2 > i1)) {
      emlrtDynamicBoundsCheckR2012b(i2, 1, i1, &d_emlrtBCI, sp);
    }

    i1 = X->size[0];
    iv0[0] = r0->size[0];
    emlrtSubAssignSizeCheckR2012b(&iv0[0], 1, &i1, 1, &emlrtECI, sp);
    loop_ub = X->size[0] - 1;
    for (i1 = 0; i1 <= loop_ub; i1++) {
      X0->data[r0->data[i1] + X0->size[0]] = X->data[i1 + X->size[0] * (j + 1)];
    }

    st.site = &emlrtRSI;
    mldivide(&st, X0, Y, coef0);
    i1 = bets->size[1];
    i2 = 2 + j;
    if ((i2 < 1) || (i2 > i1)) {
      emlrtDynamicBoundsCheckR2012b(i2, 1, i1, &e_emlrtBCI, sp);
    }

    bets->data[i2 - 1] = coef0[1];
    loop_ub = X->size[0];
    i1 = X->size[1];
    i2 = 2 + j;
    if ((i2 < 1) || (i2 > i1)) {
      emlrtDynamicBoundsCheckR2012b(i2, 1, i1, &c_emlrtBCI, sp);
    }

    i1 = b_X->size[0];
    b_X->size[0] = loop_ub;
    emxEnsureCapacity_real_T(sp, b_X, i1, &l_emlrtRTEI);
    for (i1 = 0; i1 < loop_ub; i1++) {
      b_X->data[i1] = X->data[i1 + X->size[0] * (i2 - 1)];
    }

    loop_ub = X->size[0];
    i1 = X->size[1];
    i2 = 2 + j;
    if ((i2 < 1) || (i2 > i1)) {
      emlrtDynamicBoundsCheckR2012b(i2, 1, i1, &b_emlrtBCI, sp);
    }

    i1 = c_X->size[0];
    c_X->size[0] = loop_ub;
    emxEnsureCapacity_real_T(sp, c_X, i1, &m_emlrtRTEI);
    for (i1 = 0; i1 < loop_ub; i1++) {
      c_X->data[i1] = X->data[i1 + X->size[0] * (i2 - 1)];
    }

    i1 = Xdot->size[1];
    i2 = 2 + j;
    if ((i2 < 1) || (i2 > i1)) {
      emlrtDynamicBoundsCheckR2012b(i2, 1, i1, &f_emlrtBCI, sp);
    }

    st.site = &b_emlrtRSI;
    Xdot->data[i2 - 1] = dot(&st, b_X, c_X);

    /* sum of squared X[,j] */
    if (*emlrtBreakCheckR2012bFlagVar != 0) {
      emlrtBreakCheckR2012b(sp);
    }
  }

  emxFree_int32_T(&r0);
  emxFree_real_T(&X0);
  emxInit_real_T(sp, &bets_d, 2, &t_emlrtRTEI, true);
  i0 = Xdot->size[1];
  if (1 > i0) {
    emlrtDynamicBoundsCheckR2012b(1, 1, i0, &emlrtBCI, sp);
  }

  Xdot->data[0] = X->size[0];

  /* sum of squared X[,1] (intercept) */
  /*  begin golden section search optimisation for k */
  /* define function in k */
  c_tmp = (b - a) / 1.6180339887498949;
  c = muDoubleScalarCeil(b - c_tmp);
  d = muDoubleScalarFloor(a + c_tmp);
  st.site = &c_emlrtRSI;
  i0 = bets_d->size[0] * bets_d->size[1];
  bets_d->size[0] = 1;
  bets_d->size[1] = bets->size[1];
  emxEnsureCapacity_real_T(&st, bets_d, i0, &j_emlrtRTEI);
  loop_ub = bets->size[0] * bets->size[1];
  for (i0 = 0; i0 < loop_ub; i0++) {
    bets_d->data[i0] = bets->data[i0];
  }

  emxInit_real_T(&st, &r1, 2, &k_emlrtRTEI, true);
  i0 = r1->size[0] * r1->size[1];
  r1->size[0] = 1;
  r1->size[1] = X->size[1];
  emxEnsureCapacity_real_T(&st, r1, i0, &k_emlrtRTEI);
  loop_ub = X->size[1];
  for (i0 = 0; i0 < loop_ub; i0++) {
    r1->data[i0] = 0.0;
  }

  b_st.site = &vb_emlrtRSI;
  __anon_fcn(&b_st, Y, X, nC, Xdot, r1, d, bets_d, clus, &c_tmp);
  st.site = &c_emlrtRSI;
  c_tmp /= (real_T)X->size[0];
  st.site = &c_emlrtRSI;
  b_log(&st, &c_tmp);
  fd = (real_T)X->size[0] * c_tmp + d * muDoubleScalarLog(X->size[0]);

  /* print */
  st.site = &d_emlrtRSI;
  b_st.site = &qf_emlrtRSI;
  y = NULL;
  m0 = emlrtCreateCharArray(2, iv1);
  emlrtInitCharArrayR2013a(&b_st, 7, m0, &u[0]);
  emlrtAssign(&y, m0);
  b_y = NULL;
  m1 = emlrtCreateCharArray(2, iv2);
  emlrtInitCharArrayR2013a(&b_st, 42, m1, &b_u[0]);
  emlrtAssign(&b_y, m1);
  c_y = NULL;
  m2 = emlrtCreateNumericMatrix(1, 1, mxUINT64_CLASS, mxREAL);
  *(uint64_T *)emlrtMxGetData(m2) = 1UL;
  emlrtAssign(&c_y, m2);
  d_y = NULL;
  m3 = emlrtCreateNumericMatrix(1, 1, mxUINT64_CLASS, mxREAL);
  if (c < 1.8446744073709552E+19) {
    if (c >= 0.0) {
      u0 = (uint64_T)c;
    } else {
      u0 = 0UL;
    }
  } else if (c >= 1.8446744073709552E+19) {
    u0 = MAX_uint64_T;
  } else {
    u0 = 0UL;
  }

  *(uint64_T *)emlrtMxGetData(m3) = u0;
  emlrtAssign(&d_y, m3);
  c_st.site = &wf_emlrtRSI;
  c_tmp = c_emlrt_marshallIn(&c_st, e_feval(&c_st, y, emlrt_marshallOut(1.0),
    b_y, c_y, d_y, emlrt_marshallOut(fd), &f_emlrtMCI), "feval");
  emlrtDisplayR2012b(emlrt_marshallOut(c_tmp), "ans", &emlrtRTEI, sp);
  st.site = &e_emlrtRSI;
  i0 = bets->size[0] * bets->size[1];
  bets->size[0] = 1;
  bets->size[1] = bets_d->size[1];
  emxEnsureCapacity_real_T(&st, bets, i0, &j_emlrtRTEI);
  loop_ub = bets_d->size[0] * bets_d->size[1];
  for (i0 = 0; i0 < loop_ub; i0++) {
    bets->data[i0] = bets_d->data[i0];
  }

  i0 = r1->size[0] * r1->size[1];
  r1->size[0] = 1;
  r1->size[1] = X->size[1];
  emxEnsureCapacity_real_T(&st, r1, i0, &k_emlrtRTEI);
  loop_ub = X->size[1];
  for (i0 = 0; i0 < loop_ub; i0++) {
    r1->data[i0] = 0.0;
  }

  b_st.site = &vb_emlrtRSI;
  __anon_fcn(&b_st, Y, X, nC, Xdot, r1, c, bets, b_X, &c_tmp);
  st.site = &e_emlrtRSI;
  c_tmp /= (real_T)X->size[0];
  if (c_tmp < 0.0) {
    b_st.site = &rf_emlrtRSI;
    d_error(&b_st);
  }

  c_tmp = muDoubleScalarLog(c_tmp);
  st.site = &e_emlrtRSI;
  fc = (real_T)X->size[0] * c_tmp + c * muDoubleScalarLog(X->size[0]);
  cnt = 2.0;

  /* print */
  st.site = &f_emlrtRSI;
  b_st.site = &qf_emlrtRSI;
  y = NULL;
  m4 = emlrtCreateCharArray(2, iv3);
  emlrtInitCharArrayR2013a(&b_st, 7, m4, &u[0]);
  emlrtAssign(&y, m4);
  b_y = NULL;
  m5 = emlrtCreateCharArray(2, iv4);
  emlrtInitCharArrayR2013a(&b_st, 42, m5, &b_u[0]);
  emlrtAssign(&b_y, m5);
  c_y = NULL;
  m6 = emlrtCreateNumericMatrix(1, 1, mxUINT64_CLASS, mxREAL);
  *(uint64_T *)emlrtMxGetData(m6) = 2UL;
  emlrtAssign(&c_y, m6);
  d_y = NULL;
  m7 = emlrtCreateNumericMatrix(1, 1, mxUINT64_CLASS, mxREAL);
  if (c < 1.8446744073709552E+19) {
    if (c >= 0.0) {
      u0 = (uint64_T)c;
    } else {
      u0 = 0UL;
    }
  } else if (c >= 1.8446744073709552E+19) {
    u0 = MAX_uint64_T;
  } else {
    u0 = 0UL;
  }

  *(uint64_T *)emlrtMxGetData(m7) = u0;
  emlrtAssign(&d_y, m7);
  c_st.site = &wf_emlrtRSI;
  c_tmp = c_emlrt_marshallIn(&c_st, e_feval(&c_st, y, emlrt_marshallOut(1.0),
    b_y, c_y, d_y, emlrt_marshallOut(fc), &f_emlrtMCI), "feval");
  emlrtDisplayR2012b(emlrt_marshallOut(c_tmp), "ans", &b_emlrtRTEI, sp);
  if (fc <= fd) {
    *optk = c;
    *BIC = fc;
    i0 = clus->size[0];
    clus->size[0] = b_X->size[0];
    emxEnsureCapacity_real_T(sp, clus, i0, &o_emlrtRTEI);
    loop_ub = b_X->size[0];
    for (i0 = 0; i0 < loop_ub; i0++) {
      clus->data[i0] = b_X->data[i0];
    }
  } else {
    *optk = d;
    i0 = bets->size[0] * bets->size[1];
    bets->size[0] = 1;
    bets->size[1] = bets_d->size[1];
    emxEnsureCapacity_real_T(sp, bets, i0, &n_emlrtRTEI);
    loop_ub = bets_d->size[0] * bets_d->size[1];
    for (i0 = 0; i0 < loop_ub; i0++) {
      bets->data[i0] = bets_d->data[i0];
    }

    *BIC = fd;
  }

  /*  end if */
  /*     %% begin while loop */
  emxInit_real_T(sp, &varargout_1, 2, &v_emlrtRTEI, true);
  while (muDoubleScalarAbs(c - d) > 1.0) {
    if (fc <= fd) {
      b = d;
    } else {
      a = c;
    }

    /*  end if */
    c_tmp = (b - a) / 1.6180339887498949;
    c = muDoubleScalarCeil(b - c_tmp);
    d = muDoubleScalarFloor(a + c_tmp);
    st.site = &g_emlrtRSI;
    i0 = varargout_1->size[0] * varargout_1->size[1];
    varargout_1->size[0] = 1;
    varargout_1->size[1] = bets_d->size[1];
    emxEnsureCapacity_real_T(&st, varargout_1, i0, &j_emlrtRTEI);
    loop_ub = bets_d->size[0] * bets_d->size[1];
    for (i0 = 0; i0 < loop_ub; i0++) {
      varargout_1->data[i0] = bets_d->data[i0];
    }

    i0 = r1->size[0] * r1->size[1];
    r1->size[0] = 1;
    r1->size[1] = X->size[1];
    emxEnsureCapacity_real_T(&st, r1, i0, &k_emlrtRTEI);
    loop_ub = X->size[1];
    for (i0 = 0; i0 < loop_ub; i0++) {
      r1->data[i0] = 0.0;
    }

    b_st.site = &vb_emlrtRSI;
    __anon_fcn(&b_st, Y, X, nC, Xdot, r1, c, varargout_1, b_X, &c_tmp);
    st.site = &g_emlrtRSI;
    c_tmp /= (real_T)nd;
    if (c_tmp < 0.0) {
      b_st.site = &rf_emlrtRSI;
      d_error(&b_st);
    }

    c_tmp = muDoubleScalarLog(c_tmp);
    st.site = &g_emlrtRSI;
    fc = (real_T)nd * c_tmp + c * muDoubleScalarLog(nd);
    cnt++;

    /* print */
    st.site = &h_emlrtRSI;
    b_st.site = &qf_emlrtRSI;
    y = NULL;
    m8 = emlrtCreateCharArray(2, iv5);
    emlrtInitCharArrayR2013a(&b_st, 7, m8, &u[0]);
    emlrtAssign(&y, m8);
    b_y = NULL;
    m9 = emlrtCreateCharArray(2, iv6);
    emlrtInitCharArrayR2013a(&b_st, 42, m9, &b_u[0]);
    emlrtAssign(&b_y, m9);
    c_y = NULL;
    m10 = emlrtCreateNumericMatrix(1, 1, mxUINT64_CLASS, mxREAL);
    if (cnt < 1.8446744073709552E+19) {
      u0 = (uint64_T)cnt;
    } else {
      u0 = MAX_uint64_T;
    }

    *(uint64_T *)emlrtMxGetData(m10) = u0;
    emlrtAssign(&c_y, m10);
    d_y = NULL;
    m11 = emlrtCreateNumericMatrix(1, 1, mxUINT64_CLASS, mxREAL);
    if (c < 1.8446744073709552E+19) {
      if (c >= 0.0) {
        u0 = (uint64_T)c;
      } else {
        u0 = 0UL;
      }
    } else if (c >= 1.8446744073709552E+19) {
      u0 = MAX_uint64_T;
    } else {
      u0 = 0UL;
    }

    *(uint64_T *)emlrtMxGetData(m11) = u0;
    emlrtAssign(&d_y, m11);
    c_st.site = &wf_emlrtRSI;
    c_tmp = c_emlrt_marshallIn(&c_st, e_feval(&c_st, y, emlrt_marshallOut(1.0),
      b_y, c_y, d_y, emlrt_marshallOut(fc), &f_emlrtMCI), "feval");
    emlrtDisplayR2012b(emlrt_marshallOut(c_tmp), "ans", &c_emlrtRTEI, sp);
    st.site = &i_emlrtRSI;
    i0 = bets_d->size[0] * bets_d->size[1];
    bets_d->size[0] = 1;
    bets_d->size[1] = varargout_1->size[1];
    emxEnsureCapacity_real_T(&st, bets_d, i0, &j_emlrtRTEI);
    loop_ub = varargout_1->size[0] * varargout_1->size[1];
    for (i0 = 0; i0 < loop_ub; i0++) {
      bets_d->data[i0] = varargout_1->data[i0];
    }

    i0 = r1->size[0] * r1->size[1];
    r1->size[0] = 1;
    r1->size[1] = X->size[1];
    emxEnsureCapacity_real_T(&st, r1, i0, &k_emlrtRTEI);
    loop_ub = X->size[1];
    for (i0 = 0; i0 < loop_ub; i0++) {
      r1->data[i0] = 0.0;
    }

    b_st.site = &vb_emlrtRSI;
    __anon_fcn(&b_st, Y, X, nC, Xdot, r1, d, bets_d, c_X, &c_tmp);
    st.site = &i_emlrtRSI;
    c_tmp /= (real_T)nd;
    if (c_tmp < 0.0) {
      b_st.site = &rf_emlrtRSI;
      d_error(&b_st);
    }

    c_tmp = muDoubleScalarLog(c_tmp);
    st.site = &i_emlrtRSI;
    fd = (real_T)nd * c_tmp + d * muDoubleScalarLog(nd);
    cnt++;

    /* print */
    st.site = &j_emlrtRSI;
    b_st.site = &qf_emlrtRSI;
    y = NULL;
    m12 = emlrtCreateCharArray(2, iv7);
    emlrtInitCharArrayR2013a(&b_st, 7, m12, &u[0]);
    emlrtAssign(&y, m12);
    b_y = NULL;
    m13 = emlrtCreateCharArray(2, iv8);
    emlrtInitCharArrayR2013a(&b_st, 42, m13, &b_u[0]);
    emlrtAssign(&b_y, m13);
    c_y = NULL;
    m14 = emlrtCreateNumericMatrix(1, 1, mxUINT64_CLASS, mxREAL);
    if (cnt < 1.8446744073709552E+19) {
      u0 = (uint64_T)cnt;
    } else {
      u0 = MAX_uint64_T;
    }

    *(uint64_T *)emlrtMxGetData(m14) = u0;
    emlrtAssign(&c_y, m14);
    d_y = NULL;
    m15 = emlrtCreateNumericMatrix(1, 1, mxUINT64_CLASS, mxREAL);
    if (c < 1.8446744073709552E+19) {
      if (c >= 0.0) {
        u0 = (uint64_T)c;
      } else {
        u0 = 0UL;
      }
    } else if (c >= 1.8446744073709552E+19) {
      u0 = MAX_uint64_T;
    } else {
      u0 = 0UL;
    }

    *(uint64_T *)emlrtMxGetData(m15) = u0;
    emlrtAssign(&d_y, m15);
    c_st.site = &wf_emlrtRSI;
    c_tmp = c_emlrt_marshallIn(&c_st, e_feval(&c_st, y, emlrt_marshallOut(1.0),
      b_y, c_y, d_y, emlrt_marshallOut(fd), &f_emlrtMCI), "feval");
    emlrtDisplayR2012b(emlrt_marshallOut(c_tmp), "ans", &d_emlrtRTEI, sp);
    if (fc < *BIC) {
      *optk = c;
      i0 = bets->size[0] * bets->size[1];
      bets->size[0] = 1;
      bets->size[1] = varargout_1->size[1];
      emxEnsureCapacity_real_T(sp, bets, i0, &p_emlrtRTEI);
      loop_ub = varargout_1->size[0] * varargout_1->size[1];
      for (i0 = 0; i0 < loop_ub; i0++) {
        bets->data[i0] = varargout_1->data[i0];
      }

      *BIC = fc;
      i0 = clus->size[0];
      clus->size[0] = b_X->size[0];
      emxEnsureCapacity_real_T(sp, clus, i0, &r_emlrtRTEI);
      loop_ub = b_X->size[0];
      for (i0 = 0; i0 < loop_ub; i0++) {
        clus->data[i0] = b_X->data[i0];
      }
    }

    if (fd < *BIC) {
      *optk = d;
      i0 = bets->size[0] * bets->size[1];
      bets->size[0] = 1;
      bets->size[1] = bets_d->size[1];
      emxEnsureCapacity_real_T(sp, bets, i0, &q_emlrtRTEI);
      loop_ub = bets_d->size[0] * bets_d->size[1];
      for (i0 = 0; i0 < loop_ub; i0++) {
        bets->data[i0] = bets_d->data[i0];
      }

      *BIC = fd;
      i0 = clus->size[0];
      clus->size[0] = c_X->size[0];
      emxEnsureCapacity_real_T(sp, clus, i0, &s_emlrtRTEI);
      loop_ub = c_X->size[0];
      for (i0 = 0; i0 < loop_ub; i0++) {
        clus->data[i0] = c_X->data[i0];
      }
    }

    if (*emlrtBreakCheckR2012bFlagVar != 0) {
      emlrtBreakCheckR2012b(sp);
    }
  }

  emxFree_real_T(&c_X);
  emxFree_real_T(&b_X);
  emxFree_real_T(&r1);
  emxFree_real_T(&varargout_1);
  emxFree_real_T(&bets_d);
  emxFree_real_T(&Xdot);

  /* end while loop */
  emlrtHeapReferenceStackLeaveFcnR2012b(sp);
}

/* End of code generation (goldsscoord3.c) */
