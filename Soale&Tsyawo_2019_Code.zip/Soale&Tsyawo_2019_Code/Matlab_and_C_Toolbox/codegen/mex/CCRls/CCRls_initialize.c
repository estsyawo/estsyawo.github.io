/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * CCRls_initialize.c
 *
 * Code generation for function 'CCRls_initialize'
 *
 */

/* Include files */
#include "rt_nonfinite.h"
#include "CCRls.h"
#include "CCRls_initialize.h"
#include "_coder_CCRls_mex.h"
#include "CCRls_data.h"

/* Function Definitions */
void CCRls_initialize(void)
{
  mexFunctionCreateRootTLS();
  emlrtClearAllocCountR2012b(emlrtRootTLSGlobal, false, 0U, 0);
  emlrtEnterRtStackR2012b(emlrtRootTLSGlobal);
  emlrtFirstTimeR2012b(emlrtRootTLSGlobal);
}

/* End of code generation (CCRls_initialize.c) */
