# Replication Package

This package contains the simulation code, calibration inputs, and retained Monte Carlo outputs for:

Emmanuel Selorm Tsyawo, "Limit Theory for U-Statistics under Clustered and Weakly Dependent Data".

The code reproduces the two Monte Carlo arms reported in the paper:

1. clustered sampling: order-2 Gini mean difference and order-3 third L-moment;
2. weak dependence: order-2 Kendall's tau and order-3 Spearman's rho.

## Folder Structure

- `R/`: R scripts for setup, simulation functions, and the main runner.
- `src/`: C++ helpers called through `Rcpp`.
- `data/`: calibration inputs used by the simulations.
- `output/`: retained manuscript-facing simulation outputs.

## Software

The scripts use R with the packages `Rcpp`, `pbapply`, and `sandwich`. The setup script checks for these packages and installs missing ones from CRAN when needed.

## Reproduction

From the package root, run:

```sh
cd R
Rscript run_all.R
```

This reruns the full manuscript simulation design with 2000 Monte Carlo replications per design point and writes timestamped output files to `output/`.

## Included Outputs

The `output/` folder contains the retained manuscript-facing outputs:

- `clustered_gini_l3_reps2000_20260821_094217_summary_grid.csv`
- `clustered_gini_l3_reps2000_20260821_094217_table.txt`
- `ned_rank_reps2000_20260807_115458_summary_grid.csv`
- `ned_rank_reps2000_20260807_115458_table.txt`

New runs create additional timestamped files in the same folder.

## Calibration Inputs

- `data/park_shin_PI.txt` is the county-income calibration input used to form the clustered simulation design.
- `data/tong_hansen_ned_sim_calibration_selected.csv` contains the selected market-sector calibration values used in the weak-dependence simulation design.

The simulations are calibrated to the empirical applications discussed in the paper; the package does not redistribute the full external replication archives from the source papers.
