#=========================================================================================>
# Authors: Gilles Koumou & Emmanuel Selorm Tsyawo
# Project: Difference-in-differences with as few as two cross-sectional units\\ 
#-- A new perspective to the democracy-growth debate
# Date begun: Sept. 13, 2022
# Date last updated:   Oct. 2, 2025
# Place:        Tuscaloosa
# Purpose: Simulations
#=========================================================================================>
rm(list=ls()) # clear entire memory
library(tseries)
library(lmtest)
library(sandwich)
library(parallel)
library(pbapply)
#setwd(dirname(rstudioapi::getActiveDocumentContext()$path)) #set working directory path to source file
#=========================================================================================>
source("File_0_Fonctions.R")
#=========================================================================================>
#Comments:
# Compare the mean bias, median absolute deviation, root-mean squared error, and
# rejection rates at the 10%, 5%, 1% levels of competing estimators: DiD, SC, and BA
# with homogeneous treatment effects.
#=========================================================================================>
# Set parameters
R=10000 #number of Monte Carlo Samples
a=0.5 #difference in counterfactual group mean outcomes
n.vec=c(25,50,100,200,400) #vector samples sizes nT,nTau
cl=floor(detectCores()/2) #number of cores for parallel computation
#=========================================================================================>


#===============================================================================
#start.time<- Sys.time()
#===============================================================================


#=========================================================================================>
# DGP_1: MDS; alf0=alf1; phi(t) = 0; nu_t = 0
MC_Res_DGP_1 = MC_DGP(out.file="out_DGP_1.txt",n.vec=n.vec,R=R,ATT=0.0,error.type="MDS",
                      alph=c(a,a),phi=NULL,eta=NULL,
                      t.X="Level",se.type="NW",cl=cl)
#=========================================================================================>


#=========================================================================================>
# DGP_2: MDS; alf0=-alf1; phi(t) = 0; nu_t = 0
MC_Res_DGP_2 = MC_DGP(out.file="out_DGP_2.txt",n.vec=n.vec,R=R,ATT=0.0,error.type="MDS",
                      alph=c(a,-a),phi=NULL,eta=NULL,
                      t.X="Level",se.type="NW",cl=cl)
#=========================================================================================>


#=========================================================================================>
# DGP_3: MDS; alf0=alf1; phi(t) = 1{t>=4}*sqrt{2}; nu_t = 0
phi_3<- function(var.time){(var.time>=4)*sqrt(2)}; phi_3=Vectorize(phi_3)
MC_Res_DGP_3 = MC_DGP(out.file="out_DGP_3.txt",n.vec=n.vec,R=R,ATT=0.0,error.type="MDS",
                      alph=c(a,a),phi=phi_3,eta=NULL,
                      t.X="Level",se.type="NW",cl=cl)
#=========================================================================================>


#=========================================================================================>
# DGP_4A: MDS; alf0=alf1; phi(t) = 0; eta = 0.9
MC_Res_DGP_4A = MC_DGP(out.file="out_DGP_4A.txt",n.vec=n.vec,R=R,ATT=0.0,error.type="MDS",
                      alph=c(a,a),phi=NULL,eta=0.9,
                      t.X="Level",se.type="NW",cl=cl)
#=========================================================================================>


#=========================================================================================>
# DGP_4B: MDS; alf0=alf1; phi(t) = 0; eta = 0.25; necessary & sufficient identification condition
MC_Res_DGP_4B = MC_DGP(out.file="out_DGP_4B.txt",n.vec=n.vec,R=R,ATT=0.0,error.type="MDS",
                       alph=c(a,a),phi=NULL,eta=0.25,
                       t.X="Level",se.type="NW",nu.suff=TRUE,cl=cl)
#=========================================================================================>


#=========================================================================================>
# DGP_5: GARCH(1,1) errors
MC_Res_DGP_5 = MC_DGP(out.file="out_DGP_5.txt",n.vec=n.vec,R=R,ATT=0.0,error.type="GARCH",
                      alph=c(a,a),phi=NULL,eta=NULL,
                      t.X="Level",se.type="NW",cl=cl)
#=========================================================================================>


#=========================================================================================>
# DGP_6: MA(1) errors
MC_Res_DGP_6 = MC_DGP(out.file="out_DGP_6.txt",n.vec=n.vec,R=R,ATT=0.0,error.type="MA",
                      alph=c(a,a),phi=NULL,eta=NULL,
                      t.X="Level",se.type="NW",q=1,cl=cl)
#=========================================================================================>


#=========================================================================================>
# DGP_7: AR(1) untreated potential outcomes
MC_Res_DGP_7 = MC_DGP(out.file="out_DGP_7.txt",n.vec=n.vec,R=R,ATT=0.0,error.type="AR",
                      alph=c(a,a),phi=cos,eta=NULL,
                      t.X="Lag",se.type="NW",cl=cl)
#=========================================================================================>


#=========================================================================================>
# DGP_8: Unit root untreated potential outcomes
MC_Res_DGP_8 = MC_DGP(out.file="out_DGP_8.txt",n.vec=n.vec,R=R,ATT=0.0,error.type="Unit.Root",
                      alph=c(a,a),phi=NULL,eta=NULL,
                      t.X="Diff",se.type="NW",cl=cl)
#=========================================================================================>


#=========================================================================================>
# DGP_9: Common quadratic trend
phi.9<- function(var.time){var.time+var.time^2/500}; phi.9=Vectorize(phi.9)
MC_Res_DGP_9 = MC_DGP(out.file="out_DGP_9.txt",n.vec=n.vec,R=R,ATT=0.0,error.type="White.Noise",
                      alph=c(a,a),phi=phi.9,eta=NULL,
                      t.X="Level",se.type="NW",cl=cl)
#=========================================================================================>


#=========================================================================================>
# DGP_10: Deterministic time trend in the untreated potential outcome of the treated group
MC_Res_DGP_10 = MC_DGP(out.file="out_DGP_10.txt",n.vec=n.vec,R=R,ATT=0.0,error.type="Trend",
                      alph=c(a,a),phi=NULL,eta=NULL,
                      t.X="Trend",se.type="NW",cl=cl)
#=========================================================================================>


#===============================================================================

cat("See working directory for output tables and plots \n ")

#===============================================================================
# end.time<- Sys.time()
# print(end.time-start.time)
#===============================================================================

















