#===============================================================================
# JT05_Fonctions.R
# Core helper functions used by the output-generating scripts in this project.
# Each function includes brief documentation on its purpose, inputs, and output.
#===============================================================================

# Purpose: Compute the pivotal chi-squared specification test for linear IV models.
# Input: `rObj` is an `ivreg` fit, `X` and `Z` are regressor/instrument matrices,
# `Kern` selects the kernel, `h.fun` optionally defines the targeting function,
# and `alf` is the Euclidean-alpha kernel exponent.
# Output: A list containing the chi-squared statistic, p-value, degrees of
# freedom, estimated moments, covariance matrix, and generalized inverse.
specLM.Chi <- function(rObj, X, Z, Kern = "Gauss", h.fun = NULL, alf = 1.0) {
  U <- rObj$residuals / sd(rObj$residuals)
  n <- length(U)
  df <- 1
  Z <- as.matrix(cbind(1, Z))
  X <- as.matrix(cbind(1, X))

  if (is.null(h.fun)) {
    hZ <- exp(apply(Z[, -1], 1, sum) / sqrt(ncol(Z) - 1))
  } else {
    hZ <- h.fun(Z)
  }
  V <- cbind(hZ, U - hZ)

  Ker <- Kern.fun2(Z, Kern = Kern, alf = alf)
  diag(Ker) <- 0.0

  delta_V <- c(t(V) %*% Ker %*% U / (n * (n - 1)))
  psi.1 <- 0.5 * (c(U) * Ker %*% V + c(Ker %*% c(U)) * V) / (n - 1)
  Xi <- -X
  Ut <- cbind(0, U)
  Mn <- t(V + Ut) %*% Ker %*% Xi
  Mn <- Mn / (n * (n - 1))
  Omg <- cov(2 * psi.1 + t(Mn %*% solve(t(Z) %*% X / n) %*% t(Z * U)))

  EOmg <- eigen(Omg)
  id <- which(EOmg$values >= EOmg$values[1] * n^(-1 / 3))
  EOmg$values[-id] <- 0
  EOmg$values[id] <- 1 / c(EOmg$values[id])
  OmgGInv <- EOmg$vectors %*% diag(EOmg$values) %*% t(EOmg$vectors)

  chi2 <- n * c(t(delta_V) %*% OmgGInv %*% delta_V)
  p.value <- 1 - pchisq(chi2, df = df)

  list(
    chi2 = chi2,
    p.value = p.value,
    df = df,
    delta = delta_V,
    Omg = Omg,
    OmgGInv = OmgGInv,
    lam.OmgGInv = EOmg$values
  )
}

#===============================================================================

# Purpose: Build the influence-function ingredients for logit-based GLM tests.
# Input: `rObj` is a fitted logit `glm` object with `x = TRUE`.
# Output: A list containing the observation-level influence matrix and the
# derivative matrix used in the chi-squared test covariance adjustment.
infl.fun.logit <- function(rObj) {
  dot_X <- as.matrix(rObj$x * (2 * rObj$y - 1))
  n <- length(rObj$y)
  probs <- plogis(dot_X %*% rObj$coefficients)
  Weights <- probs * (1 - probs)
  Hess <- (t(dot_X) %*% diag(as.vector(Weights)) %*% dot_X) / n
  score <- dot_X * (1 - matrix(probs, nrow = length(probs),
                               ncol = ncol(dot_X), byrow = FALSE))
  IF_mat <- score %*% solve(Hess)

  LC <- as.matrix(rObj$x) %*% rObj$coefficients
  Gmat <- rObj$x * c(dlogis(LC))

  list(IF_mat = IF_mat, Gmat = Gmat)
}

#===============================================================================

# Purpose: Compute the pivotal chi-squared specification test for logit models.
# Input: `rObj` is a fitted logit `glm`, `Kern` selects the kernel, `h.fun`
# optionally overrides the default targeting function, and `alf` is the
# Euclidean-alpha kernel exponent.
# Output: A list containing the chi-squared statistic, p-value, degrees of
# freedom, estimated moments, covariance matrix, and generalized inverse.
spec.logit.Chi <- function(rObj, Kern = "Gauss", h.fun = NULL, alf = 1.0) {
  U <- rObj$y - rObj$fitted.values
  sd.U <- sd(U)
  U <- U / sd.U
  n <- length(U)
  df <- 1
  infl.obj <- infl.fun.logit(rObj)
  Z <- rObj$x

  if (is.null(h.fun)) {
    hZ <- exp(apply(Z[, -1], 1, sum) / sqrt(ncol(Z) - 1))
  } else {
    hZ <- h.fun(Z)
  }
  hZ <- 2 * hZ / sd(hZ)
  V <- cbind(hZ, U - hZ)

  Ker <- Kern.fun2(Z, Kern = Kern, alf = alf)
  diag(Ker) <- 0.0
  delta_h <- c(t(V) %*% Ker %*% U / (n * (n - 1)))

  psi.1 <- 0.5 * (c(U) * Ker %*% V + c(Ker %*% c(U)) * V) / (n - 1)
  Xi <- -infl.obj$Gmat / sd.U
  Ut <- cbind(0, U)
  Mn <- t(V + Ut) %*% Ker %*% Xi
  Mn <- Mn / (n * (n - 1))
  Omg <- cov(2 * psi.1 + t(Mn %*% t(infl.obj$IF_mat)))

  EOmg <- eigen(Omg)
  id <- which(EOmg$values >= EOmg$values[1] * n^(-1 / 3))
  EOmg$values[-id] <- 0
  EOmg$values[id] <- 1 / c(EOmg$values[id])
  OmgGInv <- EOmg$vectors %*% diag(EOmg$values) %*% t(EOmg$vectors)

  chi2 <- n * c(t(delta_h) %*% OmgGInv %*% delta_h)
  p.value <- 1 - pchisq(chi2, df = df)

  list(
    chi2 = chi2,
    p.value = p.value,
    df = df,
    delta = delta_h,
    Omg = Omg,
    OmgGInv = OmgGInv,
    lam.OmgGInv = EOmg$values
  )
}

#===============================================================================

# Purpose: Compute the pivotal chi-squared test of mean independence.
# Input: `U` is the scalar outcome, `Z` is the conditioning variable matrix,
# `Kern` selects the kernel, `h.fun` and `V.fun` optionally redefine the
# moment basis, `cn.fun` chooses retained eigencomponents, and `df` sets
# degrees of freedom when supplied.
# Output: A list containing the chi-squared statistic, p-value, degrees of
# freedom, estimated moments, covariance matrix, and generalized inverse.
MI_Spec.Chi <- function(U, Z, Kern = "Gauss", h.fun = NULL, V.fun = NULL,
                        cn.fun = NULL, df = 1) {
  U <- (U - mean(U)) / sd(U)
  Ker <- Kern.fun(Z, Kern = Kern)
  diag(Ker) <- 0.0
  n <- length(U)
  X <- matrix(1, n, 1)

  if (is.null(h.fun)) {
    hZ <- exp(apply(Z, 1, sum) / sqrt(ncol(Z)))
  } else {
    hZ <- h.fun(Z)
  }

  if (is.null(V.fun)) {
    V <- cbind(hZ, U - hZ)
  } else {
    V <- V.fun(U, Z)
  }

  delta_V <- c(t(V) %*% Ker %*% U / (n * (n - 1)))
  psi.1 <- 0.5 * (c(U) * Ker %*% V + c(Ker %*% c(U)) * V) / (n - 1)
  Vt <- V
  Vt[, 2] <- Vt[, 2] + U
  Mn <- -t(Vt) %*% Ker %*% X
  Mn <- Mn / (n * (n - 1))
  Omg <- cov(2 * psi.1 + t(Mn %*% solve(t(X) %*% X / n) %*% t(X * U)))

  EOmg <- eigen(Omg)
  if (is.null(cn.fun)) {
    id <- which(EOmg$values >= EOmg$values[1] * n^(-1 / 3))
  } else {
    id <- cn.fun(EOmg$values, n)
  }

  EOmg$values[-id] <- 0
  EOmg$values[id] <- 1 / c(EOmg$values[id])
  OmgGInv <- EOmg$vectors %*% diag(EOmg$values) %*% t(EOmg$vectors)

  if (is.null(df)) {
    df <- length(which(EOmg$values != 0))
  }

  chi2 <- n * c(t(delta_V) %*% OmgGInv %*% delta_V)
  p.value <- 1 - pchisq(chi2, df = df)

  list(
    chi2 = chi2,
    p.value = p.value,
    df = df,
    delta = delta_V,
    Omg = Omg,
    OmgGInv = OmgGInv,
    lam.OmgGInv = EOmg$values
  )
}

#===============================================================================

# Purpose: Test the joint null E[U|Z] = E[U] = 0 using the chi-squared approach.
# Input: `U` is the scalar outcome, `Z` is the conditioning variable matrix,
# `Kern` selects the kernel, `h.fun` and `V.fun` optionally redefine the
# moment basis, `cn.fun` chooses retained eigencomponents, and `df` sets
# degrees of freedom when supplied.
# Output: A list containing the chi-squared statistic, p-value, degrees of
# freedom, estimated moments, covariance matrix, and generalized inverse.
MIndep.Chi.star <- function(U, Z, Kern = "Gauss", h.fun = NULL, V.fun = NULL,
                            df = 1, cn.fun = NULL) {
  n <- length(U)
  U.tilde <- U - mean(U)

  if (is.null(h.fun)) {
    hZ <- exp(apply(Z, 1, sum) / sqrt(ncol(Z)))
  } else {
    hZ <- h.fun(Z)
  }

  if (is.null(V.fun)) {
    V <- cbind(hZ, U.tilde - hZ)
  } else {
    V <- V.fun(U, Z)
  }

  Ker <- Kern.fun(Z, Kern = Kern)
  V.tilde <- V
  for (j in 1:ncol(V)) {
    V.tilde[, j] <- V.tilde[, j] - mean(V.tilde[, j])
  }

  delta_V <- c(t(V) %*% Ker %*% U.tilde / (n * (n - 1)))
  delta_V_star <- delta_V + apply(V, 2, mean) * mean(U) *
    (sum(abs(Ker)) / (n * (n - 1)))

  mV.tilde <- Ker %*% V.tilde / (n - 1)
  E.mV <- apply(Ker %*% V / (n - 1), 2, mean)
  for (j in 1:ncol(mV.tilde)) {
    mV.tilde[, j] <- mV.tilde[, j] - E.mV[j]
  }

  mU.tilde <- Ker %*% U.tilde / (n - 1)
  E.mU <- mean(Ker %*% U / (n - 1))
  mU.tilde <- mU.tilde - E.mU

  K.Z <- apply(abs(Ker), 1, sum) / (n - 1) - (sum(abs(Ker)) / (n * (n - 1)))
  qZU <- mV.tilde * U.tilde + V.tilde * c(mU.tilde) +
    2 * mean(U) * K.Z %*% t(apply(V, 2, mean))

  Omg <- cov(qZU)

  EOmg <- eigen(Omg)
  if (is.null(cn.fun)) {
    id <- which(EOmg$values >= EOmg$values[1] * n^(-1 / 3))
  } else {
    id <- cn.fun(EOmg$values, n)
  }

  EOmg$values[-id] <- 0
  EOmg$values[id] <- 1 / c(EOmg$values[id])
  OmgGInv <- EOmg$vectors %*% diag(EOmg$values) %*% t(EOmg$vectors)

  if (is.null(df)) {
    df <- length(which(EOmg$values != 0))
  }

  chi2 <- n * c(t(delta_V_star) %*% OmgGInv %*% delta_V_star)
  p.value <- 1 - pchisq(chi2, df = df)

  list(
    chi2 = chi2,
    df = df,
    p.value = p.value,
    Omg = Omg,
    OmgGInv = OmgGInv,
    lam.OmgGInv = EOmg$values,
    delta_V_star = delta_V_star
  )
}

#===============================================================================

# Purpose: Run one Monte Carlo replication for the linear-model comparison.
# Input: `j` selects a dataset from `datl`, `wmat` stores bootstrap weights,
# `Kern` selects the kernel, and `h.fun` optionally overrides the default
# targeting function.
# Output: A named numeric vector of rejection indicators and timing measures.
MCfun.type <- function(j = NULL, datl, wmat, Kern = "Gauss", h.fun = NULL) {
  dat <- datl[[j]]
  Y <- dat$Y
  X <- as.matrix(dat$X)
  Z <- as.matrix(dat$Z)
  rObj <- ivreg::ivreg(Y ~ X | Z, x = TRUE, y = TRUE)

  timeChi.tn <- system.time((obj.Chi2 <- specLM.Chi(rObj, X, Z, Kern = Kern,
                                                    h.fun = h.fun)))
  timeM.WB <- system.time((WB <- speclmb.test(rObj, Kern = Kern, wmat = wmat)))
  timeM.MB <- system.time((MB <- speclm_mul.test(rObj, Kern = Kern,
                                                 wmat = wmat)))

  tms <- c(timeChi.tn[3],
           timeM.MB[3], timeM.MB[3] / timeChi.tn[3],
           timeM.WB[3], timeM.WB[3] / timeChi.tn[3])
  names(tms) <- c("Time_Chi2", "Time_MB", "Rel_MB", "Time_WB", "Rel_WB")

  p.Chi2 <- (c(obj.Chi2$p.value <= levls)) * 1
  names(p.Chi2) <- c("Chi2_0.10", "Chi2_0.05", "Chi2_0.01")
  p.MB <- (MB$p.value <= levls) * 1
  names(p.MB) <- c("MB_0.10", "MB_0.05", "MB_0.01")
  p.WB <- (WB$p.value <= levls) * 1
  names(p.WB) <- c("WB_0.10", "WB_0.05", "WB_0.01")

  c(p.Chi2, p.MB, p.WB, tms)
}

#===============================================================================

# Purpose: Run one Monte Carlo replication for the nonlinear logit comparison.
# Input: `j` selects a dataset from `datl`, `wmat` stores bootstrap weights,
# `Kern` selects the kernel, and `h.fun` optionally overrides the default
# targeting function.
# Output: A named numeric vector of rejection indicators and timing measures.
MC_glm.type <- function(j = NULL, datl, wmat, Kern = "Gauss", h.fun = NULL) {
  dat <- datl[[j]]
  Y <- dat$Y
  X <- as.matrix(dat$X)

  rObj <- stats::glm(Y ~ X, family = binomial(link = "logit"), x = TRUE)

  timeChi.tn <- system.time((obj.Chi2 <- spec.logit.Chi(rObj, Kern = Kern,
                                                        h.fun = h.fun)))
  timeM.SS <- system.time((SS <- pstest(d = rObj$y, pscore = rObj$fit,
                                        xpscore = rObj$x, model = "logit",
                                        w = "ind", dist = "Mammen")))
  timeM.MB <- system.time((MB <- spec.glm_mul.test(rObj, Kern = Kern,
                                                   wmat = wmat)))

  tms <- c(timeChi.tn[3],
           timeM.MB[3], timeM.MB[3] / timeChi.tn[3],
           timeM.SS[3], timeM.SS[3] / timeChi.tn[3])
  names(tms) <- c("Time_Chi2", "Time_MB", "Rel_MB", "Time_SS", "Rel_SS")

  p.Chi2 <- (c(obj.Chi2$p.value <= levls)) * 1
  names(p.Chi2) <- c("Chi2_0.10", "Chi2_0.05", "Chi2_0.01")
  p.MB <- (MB$p.value <= levls) * 1
  names(p.MB) <- c("MB_0.10", "MB_0.05", "MB_0.01")
  p.SS <- (SS$pvks <= levls) * 1
  names(p.SS) <- c("SS_0.10", "SS_0.05", "SS_0.01")

  c(p.Chi2, p.MB, p.SS, tms)
}

#===============================================================================

# Purpose: Run one Monte Carlo replication for the mean-independence baseline.
# Input: `j` selects a dataset from `datl`, `wmat` stores bootstrap weights,
# and `Kern` selects the kernel.
# Output: A named numeric vector of rejection indicators and timing measures.
MCfun.type.MI <- function(j = NULL, datl, wmat, Kern = "Gauss", h.fun = NULL) {
  dat <- datl[[j]]
  U <- dat$Y
  Z <- as.matrix(dat$Z)

  time.Chi <- system.time((obj.Chi2 <- MI_Spec.Chi(U, Z, Kern = Kern)))
  timeM.MB <- system.time((MB <- mindep2.boot(U, Z, B = B, Kern = Kern,
                                              wmat = wmat)))

  tms <- c(time.Chi[3], timeM.MB[3], timeM.MB[3] / time.Chi[3])
  names(tms) <- c("Time_Chi2", "Time_MB", "Rel_MB")

  p.Chi2 <- (c(obj.Chi2$p.value <= levls)) * 1
  names(p.Chi2) <- c("Chi2_0.10", "Chi2_0.05", "Chi2_0.01")
  p.MB <- (MB$p.value <= levls) * 1
  names(p.MB) <- c("MB_0.10", "MB_0.05", "MB_0.01")

  c(p.Chi2, p.MB, tms)
}

#===============================================================================

# Purpose: Compare alternative moment-basis dimensions for the MI extension.
# Input: `j` selects a dataset from `datl` and `wmat` stores bootstrap weights.
# Output: A named numeric vector of rejection indicators across tests.
MCfun4.MI <- function(j = NULL, datl, wmat) {
  dat <- datl[[j]]
  U <- dat[, 1]
  Z <- as.matrix(dat[, -1])
  U <- (U - mean(U)) / sd(U)

  h.fun1 <- function(Z) exp(Z)
  h.fun2 <- function(Z) 4 * sqrt(3) * exp(-Z^2 / 2)

  V.fun1 <- function(U, Z) cbind(h.fun1(Z), U - h.fun1(Z))
  V.fun2 <- function(U, Z) cbind(h.fun2(Z), U - h.fun2(Z))
  V.fun1a <- function(U, Z) cbind(h.fun1(Z), U - h.fun1(Z), h.fun2(Z))
  V.fun2a <- function(U, Z) cbind(h.fun2(Z), U - h.fun2(Z), h.fun1(Z))
  V.fun1b <- function(U, Z) cbind(h.fun1(Z), U - h.fun1(Z), h.fun2(Z),
                                  2.0 * scale(poly(Z, 2)))
  V.fun2b <- function(U, Z) cbind(h.fun2(Z), U - h.fun2(Z), h.fun1(Z),
                                  2.0 * scale(poly(Z, 2)))
  V.fun1c <- function(U, Z) cbind(h.fun1(Z), U - h.fun1(Z), h.fun2(Z),
                                  2.0 * scale(poly(Z, 7)))
  V.fun2c <- function(U, Z) cbind(h.fun2(Z), U - h.fun2(Z), h.fun1(Z),
                                  2.0 * scale(poly(Z, 7)))

  mdtChi1a <- MI_Spec.Chi(U, Z, V.fun = V.fun1a, df = NULL)
  mdtChi2a <- MI_Spec.Chi(U, Z, V.fun = V.fun2a, df = NULL)
  mdtChi1b <- MI_Spec.Chi(U, Z, V.fun = V.fun1b, df = NULL)
  mdtChi2b <- MI_Spec.Chi(U, Z, V.fun = V.fun2b, df = NULL)
  mdtChi1c <- MI_Spec.Chi(U, Z, V.fun = V.fun1c, df = NULL)
  mdtChi2c <- MI_Spec.Chi(U, Z, V.fun = V.fun2c, df = NULL)

  Boot.Gauss <- mindep2.boot(U, Z, B = B, Kern = "Gauss", wmat = wmat)
  Boot.MDD <- mindep2.boot(U, Z, B = B, Kern = "Euclid", wmat = wmat)
  Boot.Esc6 <- mindep2.boot(U, Z, B = B, Kern = "Esc6", wmat = wmat)

  pChi1 <- (c(mdtChi1a$p.value <= levls)) * 1
  names(pChi1) <- c("Chi1_10", "Chi1_05", "Chi1_01")
  pChi1a <- (c(mdtChi1a$p.value <= levls)) * 1
  names(pChi1a) <- c("Chi1a_10", "Chi1a_05", "Chi1a_01")
  pChi1b <- (c(mdtChi1b$p.value <= levls)) * 1
  names(pChi1b) <- c("Chi1b_10", "Chi1b_05", "Chi1b_01")
  pChi1c <- (c(mdtChi1c$p.value <= levls)) * 1
  names(pChi1c) <- c("Chi1c_10", "Chi1c_05", "Chi1c_01")
  pChi2 <- (c(mdtChi2a$p.value <= levls)) * 1
  names(pChi2) <- c("Chi2_10", "Chi2_05", "Chi2_01")
  pChi2a <- (c(mdtChi2a$p.value <= levls)) * 1
  names(pChi2a) <- c("Chi2a_10", "Chi2a_05", "Chi2a_01")
  pChi2b <- (c(mdtChi2b$p.value <= levls)) * 1
  names(pChi2b) <- c("Chi2b_10", "Chi2b_05", "Chi2b_01")
  pChi2c <- (c(mdtChi2c$p.value <= levls)) * 1
  names(pChi2c) <- c("Chi2c_10", "Chi2c_05", "Chi2c_01")

  btGauss <- (Boot.Gauss$p.value <= levls) * 1
  names(btGauss) <- c("btGauss_10", "btGauss_05", "btGauss_01")
  btMDD <- (Boot.MDD$p.value <= levls) * 1
  names(btMDD) <- c("btMDD_10", "btMDD_05", "btMDD_01")
  btEsc6 <- (Boot.Esc6$p.value <= levls) * 1
  names(btEsc6) <- c("btEsc6_10", "btEsc6_05", "btEsc6_01")

  c(pChi1, pChi1a, pChi1b, pChi1c,
    pChi2, pChi2a, pChi2b, pChi2c,
    btGauss, btMDD, btEsc6)
}

#===============================================================================

# Purpose: Compare different eigenvalue-threshold rules for the MI test.
# Input: `j` selects a dataset from `datl`; `wmat` is accepted for interface
# consistency with other Monte Carlo helpers.
# Output: A named numeric vector of rejection indicators across tuning rules.
MCfun5.MI <- function(j = NULL, datl, wmat) {
  dat <- datl[[j]]
  U <- dat[, 1]
  Z <- as.matrix(dat[, -1])
  U <- (U - mean(U)) / sd(U)
  h.fun <- function(Z) exp(Z)
  V.fun <- function(U, Z) cbind(h.fun(Z), U - h.fun(Z))

  cn.fun_1 <- function(lam.vec, n) which(lam.vec >= lam.vec[1] * n^(-2 / 5))
  cn.fun_2 <- function(lam.vec, n) which(lam.vec >= lam.vec[1] * n^(-1 / 3))
  cn.fun_3 <- function(lam.vec, n) which(lam.vec >= lam.vec[1] * n^(-1 / 4))
  cn.fun_4 <- function(lam.vec, n) which(lam.vec >= lam.vec[1] * n^(-1 / 6))

  mdtChi1 <- MI_Spec.Chi(U, Z, V.fun = V.fun, cn.fun = cn.fun_1)
  mdtChi2 <- MI_Spec.Chi(U, Z, V.fun = V.fun, cn.fun = cn.fun_2)
  mdtChi3 <- MI_Spec.Chi(U, Z, V.fun = V.fun, cn.fun = cn.fun_3)
  mdtChi4 <- MI_Spec.Chi(U, Z, V.fun = V.fun, cn.fun = cn.fun_4)

  pChi1 <- (c(mdtChi1$p.value <= levls)) * 1
  names(pChi1) <- c("Chi1_10", "Chi1_05", "Chi1_01")
  pChi2 <- (c(mdtChi2$p.value <= levls)) * 1
  names(pChi2) <- c("Chi2_10", "Chi2_05", "Chi2_01")
  pChi3 <- (c(mdtChi3$p.value <= levls)) * 1
  names(pChi3) <- c("Chi3_10", "Chi3_05", "Chi3_01")
  pChi4 <- (c(mdtChi4$p.value <= levls)) * 1
  names(pChi4) <- c("Chi4_10", "Chi4_05", "Chi4_01")

  c(pChi1, pChi2, pChi3, pChi4)
}

#===============================================================================

# Purpose: Compare different eigenvalue-threshold rules for the joint-null MI test.
# Input: `j` selects a dataset from `datl`; `wmat` is accepted for interface
# consistency with other Monte Carlo helpers.
# Output: A named numeric vector of rejection indicators across tuning rules.
MCfun5star.MI <- function(j = NULL, datl, wmat) {
  dat <- datl[[j]]
  U <- dat[, 1]
  Z <- as.matrix(dat[, -1])

  h.fun <- function(Z) exp(Z)
  V.fun <- function(U, Z) cbind(h.fun(Z), U - h.fun(Z))

  cn.fun_1 <- function(lam.vec, n) which(lam.vec >= lam.vec[1] * n^(-2 / 5))
  cn.fun_2 <- function(lam.vec, n) which(lam.vec >= lam.vec[1] * n^(-1 / 3))
  cn.fun_3 <- function(lam.vec, n) which(lam.vec >= lam.vec[1] * n^(-1 / 4))
  cn.fun_4 <- function(lam.vec, n) which(lam.vec >= lam.vec[1] * n^(-1 / 6))

  mdtChi1 <- MIndep.Chi.star(U, Z, V.fun = V.fun, cn.fun = cn.fun_1)
  mdtChi2 <- MIndep.Chi.star(U, Z, V.fun = V.fun, cn.fun = cn.fun_2)
  mdtChi3 <- MIndep.Chi.star(U, Z, V.fun = V.fun, cn.fun = cn.fun_3)
  mdtChi4 <- MIndep.Chi.star(U, Z, V.fun = V.fun, cn.fun = cn.fun_4)

  pChi1 <- (c(mdtChi1$p.value <= levls)) * 1
  names(pChi1) <- c("Chi1_10", "Chi1_05", "Chi1_01")
  pChi2 <- (c(mdtChi2$p.value <= levls)) * 1
  names(pChi2) <- c("Chi2_10", "Chi2_05", "Chi2_01")
  pChi3 <- (c(mdtChi3$p.value <= levls)) * 1
  names(pChi3) <- c("Chi3_10", "Chi3_05", "Chi3_01")
  pChi4 <- (c(mdtChi4$p.value <= levls)) * 1
  names(pChi4) <- c("Chi4_10", "Chi4_05", "Chi4_01")

  c(pChi1, pChi2, pChi3, pChi4)
}

#===============================================================================

# Purpose: Compare a broader set of eigenvalue-selection rules for the MI test.
# Input: `j` selects a dataset from `datl`; `wmat` is accepted for interface
# consistency with other Monte Carlo helpers.
# Output: A named numeric vector of rejection indicators across tuning rules.
MCfun6.MI <- function(j = NULL, datl, wmat) {
  dat <- datl[[j]]
  U <- dat[, 1]
  Z <- as.matrix(dat[, -1])
  U <- (U - mean(U)) / sd(U)

  h.fun1 <- function(Z) exp(Z)
  h.fun2 <- function(Z) 4 * sqrt(3) * exp(-Z^2 / 2)
  V.fun <- function(U, Z) cbind(h.fun1(Z), U - h.fun1(Z), h.fun2(Z),
                                2.0 * scale(poly(Z, 7)))

  cn.fun_1 <- function(lam.vec, n) which(lam.vec >= lam.vec[1] * n^(-2 / 5))
  cn.fun_2 <- function(lam.vec, n) which(lam.vec >= lam.vec[1] * n^(-1 / 3))
  cn.fun_3 <- function(lam.vec, n) which(lam.vec >= lam.vec[1] * n^(-1 / 4))
  cn.fun_4 <- function(lam.vec, n) which(lam.vec >= lam.vec[1] * n^(-1 / 6))
  cn.fun_5 <- function(lam.vec, n) {
    if (length(lam.vec) <= 2) {
      stop("Need more than 2 eigen-values for the ratio-based estimator")
    }
    pv <- length(lam.vec)
    rat.vec <- lam.vec[-1] / lam.vec[-pv]
    1:which.min(rat.vec)
  }
  cn.fun_6 <- function(lam.vec, n) {
    pv <- length(lam.vec)
    f.vec <- lam.vec^2 / sum(lam.vec^2)
    Ep <- -(1 / log(pv)) * sum(f.vec * log(f.vec))
    ep.fun <- function(k) {
      Ep.k <- -(1 / log(pv)) * sum(f.vec[1:k] * log(f.vec[1:k]))
      Ep.k / Ep
    }
    ep.fun <- Vectorize(ep.fun)
    1:min(which(ep.fun(1:pv) >= 0.7))
  }
  cn.fun_7 <- function(lam.vec, n) {
    pv <- length(lam.vec)
    f.vec <- lam.vec^2 / sum(lam.vec^2)
    Ep <- -(1 / log(pv)) * sum(f.vec * log(f.vec))
    ep.fun <- function(k) {
      Ep.k <- -(1 / log(pv)) * sum(f.vec[1:k] * log(f.vec[1:k]))
      Ep.k / Ep
    }
    ep.fun <- Vectorize(ep.fun)
    1:min(which(ep.fun(1:pv) >= 0.9))
  }
  cn.fun_8 <- function(lam.vec, n) {
    f.vec <- lam.vec^2 / sum(lam.vec^2)
    which(f.vec >= 0.05)
  }
  cn.fun_9 <- function(lam.vec, n) {
    f.vec <- lam.vec^2 / sum(lam.vec^2)
    which(f.vec >= 0.10)
  }
  cn.fun_10 <- function(lam.vec, n) {
    f.vec <- lam.vec^2 / sum(lam.vec^2)
    1:min(which(cumsum(f.vec) >= 0.7))
  }
  cn.fun_11 <- function(lam.vec, n) {
    f.vec <- lam.vec^2 / sum(lam.vec^2)
    1:min(which(cumsum(f.vec) >= 0.9))
  }

  mdtChi1 <- MI_Spec.Chi(U, Z, V.fun = V.fun, df = NULL, cn.fun = cn.fun_1)
  mdtChi2 <- MI_Spec.Chi(U, Z, V.fun = V.fun, df = NULL, cn.fun = cn.fun_2)
  mdtChi3 <- MI_Spec.Chi(U, Z, V.fun = V.fun, df = NULL, cn.fun = cn.fun_3)
  mdtChi4 <- MI_Spec.Chi(U, Z, V.fun = V.fun, df = NULL, cn.fun = cn.fun_4)
  mdtChi5 <- MI_Spec.Chi(U, Z, V.fun = V.fun, df = NULL, cn.fun = cn.fun_5)
  mdtChi6 <- MI_Spec.Chi(U, Z, V.fun = V.fun, df = NULL, cn.fun = cn.fun_6)
  mdtChi7 <- MI_Spec.Chi(U, Z, V.fun = V.fun, df = NULL, cn.fun = cn.fun_7)
  mdtChi8 <- MI_Spec.Chi(U, Z, V.fun = V.fun, df = NULL, cn.fun = cn.fun_8)
  mdtChi9 <- MI_Spec.Chi(U, Z, V.fun = V.fun, df = NULL, cn.fun = cn.fun_9)
  mdtChi10 <- MI_Spec.Chi(U, Z, V.fun = V.fun, df = NULL, cn.fun = cn.fun_10)
  mdtChi11 <- MI_Spec.Chi(U, Z, V.fun = V.fun, df = NULL, cn.fun = cn.fun_11)

  pChi1 <- (c(mdtChi1$p.value <= levls)) * 1
  names(pChi1) <- c("Chi1_10", "Chi1_05", "Chi1_01")
  pChi2 <- (c(mdtChi2$p.value <= levls)) * 1
  names(pChi2) <- c("Chi2_10", "Chi2_05", "Chi2_01")
  pChi3 <- (c(mdtChi3$p.value <= levls)) * 1
  names(pChi3) <- c("Chi3_10", "Chi3_05", "Chi3_01")
  pChi4 <- (c(mdtChi4$p.value <= levls)) * 1
  names(pChi4) <- c("Chi4_10", "Chi4_05", "Chi4_01")
  pChi5 <- (c(mdtChi5$p.value <= levls)) * 1
  names(pChi5) <- c("Chi5_10", "Chi5_05", "Chi5_01")
  pChi6 <- (c(mdtChi6$p.value <= levls)) * 1
  names(pChi6) <- c("Chi6_10", "Chi6_05", "Chi6_01")
  pChi7 <- (c(mdtChi7$p.value <= levls)) * 1
  names(pChi7) <- c("Chi7_10", "Chi7_05", "Chi7_01")
  pChi8 <- (c(mdtChi8$p.value <= levls)) * 1
  names(pChi8) <- c("Chi8_10", "Chi8_05", "Chi8_01")
  pChi9 <- (c(mdtChi9$p.value <= levls)) * 1
  names(pChi9) <- c("Chi9_10", "Chi9_05", "Chi9_01")
  pChi10 <- (c(mdtChi10$p.value <= levls)) * 1
  names(pChi10) <- c("Chi10_10", "Chi10_05", "Chi10_01")
  pChi11 <- (c(mdtChi11$p.value <= levls)) * 1
  names(pChi11) <- c("Chi11_10", "Chi11_05", "Chi11_01")

  c(pChi1, pChi2, pChi3, pChi4, pChi5, pChi6,
    pChi7, pChi8, pChi9, pChi10, pChi11)
}

#===============================================================================

# Purpose: Format a numeric vector as one LaTeX table row.
# Input: `x` is the vector to print and `n.dec` is the displayed precision.
# Output: Printed text written to the active sink/console.
print.fn <- function(x, n.dec = 3) {
  cat(paste(format(x, nsmall = n.dec), collapse = " & "),
      paste("\\", "\\", sep = ""), "\n")
}

#===============================================================================

# Purpose: Print paired size or power summaries for two kernel configurations.
# Input: `MCOBJ1` and `MCOBJ2` are Monte Carlo result lists, `id` selects
# columns to display, and `Kernels` labels the two configurations.
# Output: Printed LaTeX-style table rows written to the active sink/console.
print.size.type <- function(MCOBJ1, MCOBJ2, id,
                            Kernels = c("Gauss", "Stute", "Euclid")) {
  cat("\n")
  res <- c()
  for (l in 1:length(MCOBJ1)) {
    tmp <- rbind(
      c(nvec[l], Kernels[1], round(apply(MCOBJ1[[l]], 1, mean), 3)[id]),
      c(nvec[l], Kernels[2], round(apply(MCOBJ2[[l]], 1, mean), 3)[id])
    )
    res <- rbind(res, tmp)
  }
  apply(res, 1, print.fn)
}

#===============================================================================

# Purpose: Print timing summaries for two kernel configurations.
# Input: `MCOBJ1` and `MCOBJ2` are Monte Carlo result lists, `id1` selects
# elapsed-time columns, `id2` selects relative-time columns, and `Kernels`
# labels the two configurations.
# Output: Printed LaTeX-style table rows written to the active sink/console.
print.time.type <- function(MCOBJ1, MCOBJ2, MCOBJ3, id1, id2,
                            Kernels = c("Gauss", "Euclid")) {
  cat("\n")
  res <- c()
  for (l in 1:length(MCOBJ1)) {
    tmp <- rbind(
      c(nvec[l], Kernels[1], round(apply(MCOBJ1[[l]], 1, mean), 3)[id1],
        round(apply(MCOBJ1[[l]], 1, median), 3)[id2]),
      c(nvec[l], Kernels[1], round(apply(MCOBJ1[[l]], 1, sd), 3)[id1],
        round(apply(MCOBJ1[[l]], 1, IQR), 3)[id2]),
      c(nvec[l], Kernels[2], round(apply(MCOBJ2[[l]], 1, mean), 3)[id1],
        round(apply(MCOBJ2[[l]], 1, median), 3)[id2]),
      c(nvec[l], Kernels[2], round(apply(MCOBJ2[[l]], 1, sd), 3)[id1],
        round(apply(MCOBJ2[[l]], 1, IQR), 3)[id2])
    )
    res <- rbind(res, tmp)
  }
  apply(res, 1, print.fn, n.dec = 3)
}

#===============================================================================

# Purpose: Print a generic power table across gamma values and nominal levels.
# Input: `MCOBJ` is a Monte Carlo result list, `id.10`, `id.05`, and `id.01`
# select level-specific columns, and `vec` supplies the gamma grid.
# Output: Printed LaTeX-style table rows written to the active sink/console.
print.tab <- function(MCOBJ, id.10, id.05, id.01, vec) {
  cat("\n")
  res <- c()
  for (l in 1:length(MCOBJ)) {
    mm <- matrix(" ", 3, 2)
    mm[2, 1] <- vec[l]
    mm[, 2] <- c(10, 5, 1)
    vec.gam <- round(apply(MCOBJ[[l]], 1, mean), 3)
    res.gam <- cbind(mm, rbind(vec.gam[id.10], vec.gam[id.05], vec.gam[id.01]))
    res <- rbind(res, res.gam)
  }
  apply(res, 1, print.fn)
}

#===============================================================================

# Purpose: Plot and save linear-model power curves at 10%, 5%, and 1% levels.
# Input: `MCOBJ` is the Monte Carlo result list, `id` selects columns to plot,
# and `filename` is the output-file prefix without the nominal-level suffix.
# Output: Three PDF files saved to disk.
plot.pow <- function(MCOBJ, id, filename = NULL) {
  mat <- matrix(NA, length(MCOBJ), length(id) + 1)
  for (l in 1:length(MCOBJ)) {
    mat[l, ] <- c(gamvec[l], round(apply(MCOBJ[[l]], 1, mean), 3)[id])
  }
  mat <- as.data.frame(mat)
  names(mat) <- c("gamma",
                  "Chi2_10", "MB_10", "WB_10",
                  "Chi2_05", "MB_05", "WB_05",
                  "Chi2_01", "MB_01", "WB_01")

  group_10 <- group_05 <- group_01 <- c()
  n.test <- length(id) / 3
  n.g <- nrow(mat)
  for (l in 1:n.test) {
    group_10 <- c(group_10, rep(names(mat)[-1][1:n.test][l], n.g))
    group_05 <- c(group_05, rep(names(mat)[-1][n.test + (1:n.test)][l], n.g))
    group_01 <- c(group_01, rep(names(mat)[-1][2 * n.test + (1:n.test)][l], n.g))
  }

  df_10 <- data.frame(gam = rep(mat$gamma, n.test),
                      Pow = c(mat$Chi2_10, mat$MB_10, mat$WB_10),
                      group = group_10, group_col = group_10,
                      group_line = group_10)
  df_05 <- data.frame(gam = rep(mat$gamma, n.test),
                      Pow = c(mat$Chi2_05, mat$MB_05, mat$WB_05),
                      group = group_05, group_col = group_05,
                      group_line = group_05)
  df_01 <- data.frame(gam = rep(mat$gamma, n.test),
                      Pow = c(mat$Chi2_01, mat$MB_01, mat$WB_01),
                      group = group_01, group_col = group_01,
                      group_line = group_01)

  ppt.Pow_10 <- ggplot(data = df_10) +
    aes(x = gam, y = Pow, colour = group_10) +
    theme_gray() +
    xlab(latex2exp::TeX("$gamma$")) +
    ylab("") +
    scale_colour_manual(name = "Labels",
                        values = c("Chi2_10" = "black", "MB_10" = "blue",
                                   "WB_10" = "red"),
                        labels = c("Chi2_10" = latex2exp::TeX("$chi^2$"),
                                   "MB_10" = "MB", "WB_10" = "WB")) +
    scale_linetype_manual(name = "Labels",
                          values = c("Chi2_10" = "solid", "MB_10" = 42,
                                     "WB_10" = 44),
                          labels = c("Chi2_10" = latex2exp::TeX("$chi^2$"),
                                     "MB_10" = "MB", "WB_10" = "WB")) +
    scale_shape_manual(name = "Labels",
                       values = c("Chi2_10" = 1, "MB_10" = 3, "WB_10" = 4),
                       labels = c("Chi2_10" = latex2exp::TeX("$chi^2$"),
                                  "MB_10" = "MB", "WB_10" = "WB")) +
    theme(legend.title = element_blank()) +
    theme(axis.text = element_text(size = 40),
          axis.title = element_text(size = 40, face = "bold")) +
    theme(legend.text = element_text(colour = "black", size = 40)) +
    theme(legend.position = c(0.75, 0.4), legend.key.size = unit(2, "cm")) +
    ylim(low = -0.1, high = 1.1) +
    geom_line(aes(linetype = group_10), linewidth = 1.0) +
    geom_point(aes(shape = group_10), size = 4) +
    geom_hline(yintercept = 0.1, colour = "brown", size = 0.25)
  ppt.Pow_10
  ggsave(paste(filename, "_10.pdf", sep = ""), width = 30, height = 30,
         unit = "cm")

  ppt.Pow_05 <- ggplot(data = df_05) +
    aes(x = gam, y = Pow, colour = group_05) +
    theme_gray() +
    xlab(latex2exp::TeX("$gamma$")) +
    ylab("") +
    scale_colour_manual(name = "Labels",
                        values = c("Chi2_05" = "black", "MB_05" = "blue",
                                   "WB_05" = "red"),
                        labels = c("Chi2_05" = latex2exp::TeX("$chi^2$"),
                                   "MB_05" = "MB", "WB_05" = "WB")) +
    scale_linetype_manual(name = "Labels",
                          values = c("Chi2_05" = "solid", "MB_05" = 42,
                                     "WB_05" = 44),
                          labels = c("Chi2_05" = latex2exp::TeX("$chi^2$"),
                                     "MB_05" = "MB", "WB_05" = "WB")) +
    scale_shape_manual(name = "Labels",
                       values = c("Chi2_05" = 1, "MB_05" = 3, "WB_05" = 4),
                       labels = c("Chi2_05" = latex2exp::TeX("$chi^2$"),
                                  "MB_05" = "MB", "WB_05" = "WB")) +
    theme(legend.title = element_blank()) +
    theme(axis.text = element_text(size = 40),
          axis.title = element_text(size = 40, face = "bold")) +
    theme(legend.text = element_text(colour = "black", size = 15)) +
    theme(legend.position = "none") +
    ylim(low = -0.1, high = 1.1) +
    geom_line(aes(linetype = group_05), linewidth = 1.0) +
    geom_point(aes(shape = group_05), size = 4) +
    geom_hline(yintercept = 0.05, colour = "brown", size = 0.25)
  ppt.Pow_05
  ggsave(paste(filename, "_05.pdf", sep = ""), width = 30, height = 30,
         unit = "cm")

  ppt.Pow_01 <- ggplot(data = df_01) +
    aes(x = gam, y = Pow, colour = group_01) +
    theme_gray() +
    xlab(latex2exp::TeX("$gamma$")) +
    ylab("") +
    scale_colour_manual(name = "Labels",
                        values = c("Chi2_01" = "black", "MB_01" = "blue",
                                   "WB_01" = "red"),
                        labels = c("Chi2_01" = latex2exp::TeX("$chi^2$"),
                                   "MB_01" = "MB", "WB_01" = "WB")) +
    scale_linetype_manual(name = "Labels",
                          values = c("Chi2_01" = "solid", "MB_01" = 42,
                                     "WB_01" = 44),
                          labels = c("Chi2_01" = latex2exp::TeX("$chi^2$"),
                                     "MB_01" = "MB", "WB_01" = "WB")) +
    scale_shape_manual(name = "Labels",
                       values = c("Chi2_01" = 1, "MB_01" = 3, "WB_01" = 4),
                       labels = c("Chi2_01" = latex2exp::TeX("$chi^2$"),
                                  "MB_01" = "MB", "WB_01" = "WB")) +
    theme(legend.title = element_blank()) +
    theme(axis.text = element_text(size = 40),
          axis.title = element_text(size = 40, face = "bold")) +
    theme(legend.text = element_text(colour = "black", size = 15)) +
    theme(legend.position = "none") +
    ylim(low = -0.1, high = 1.1) +
    geom_line(aes(linetype = group_01), linewidth = 1.0) +
    geom_point(aes(shape = group_01), size = 4) +
    geom_hline(yintercept = 0.01, colour = "brown", size = 0.25)
  ppt.Pow_01
  ggsave(paste(filename, "_01.pdf", sep = ""), width = 30, height = 30,
         unit = "cm")
}

#===============================================================================

# Purpose: Plot and save nonlinear-model power curves at 10%, 5%, and 1% levels.
# Input: `MCOBJ` is the Monte Carlo result list, `id` selects columns to plot,
# and `filename` is the output-file prefix without the nominal-level suffix.
# Output: Three PDF files saved to disk.
plot.pow.NLM <- function(MCOBJ, id, filename = NULL) {
  mat <- matrix(NA, length(MCOBJ), length(id) + 1)
  for (l in 1:length(MCOBJ)) {
    mat[l, ] <- c(gamvec[l], round(apply(MCOBJ[[l]], 1, mean), 3)[id])
  }
  mat <- as.data.frame(mat)
  names(mat) <- c("gamma",
                  "Chi2_10", "MB_10", "SS_10",
                  "Chi2_05", "MB_05", "SS_05",
                  "Chi2_01", "MB_01", "SS_01")

  group_10 <- group_05 <- group_01 <- c()
  n.test <- length(id) / 3
  n.g <- nrow(mat)
  for (l in 1:n.test) {
    group_10 <- c(group_10, rep(names(mat)[-1][1:n.test][l], n.g))
    group_05 <- c(group_05, rep(names(mat)[-1][n.test + (1:n.test)][l], n.g))
    group_01 <- c(group_01, rep(names(mat)[-1][2 * n.test + (1:n.test)][l], n.g))
  }

  df_10 <- data.frame(gam = rep(mat$gamma, n.test),
                      Pow = c(mat$Chi2_10, mat$MB_10, mat$SS_10),
                      group = group_10, group_col = group_10,
                      group_line = group_10)
  df_05 <- data.frame(gam = rep(mat$gamma, n.test),
                      Pow = c(mat$Chi2_05, mat$MB_05, mat$SS_05),
                      group = group_05, group_col = group_05,
                      group_line = group_05)
  df_01 <- data.frame(gam = rep(mat$gamma, n.test),
                      Pow = c(mat$Chi2_01, mat$MB_01, mat$SS_01),
                      group = group_01, group_col = group_01,
                      group_line = group_01)

  ppt.Pow_10 <- ggplot(data = df_10) +
    aes(x = gam, y = Pow, colour = group_10) +
    theme_gray() +
    xlab(latex2exp::TeX("$gamma$")) +
    ylab("") +
    scale_colour_manual(name = "Labels",
                        values = c("Chi2_10" = "black", "MB_10" = "blue",
                                   "SS_10" = "red"),
                        labels = c("Chi2_10" = latex2exp::TeX("$chi^2$"),
                                   "MB_10" = "MB", "SS_10" = "SS")) +
    scale_linetype_manual(name = "Labels",
                          values = c("Chi2_10" = "solid", "MB_10" = 42,
                                     "SS_10" = 44),
                          labels = c("Chi2_10" = latex2exp::TeX("$chi^2$"),
                                     "MB_10" = "MB", "SS_10" = "SS")) +
    scale_shape_manual(name = "Labels",
                       values = c("Chi2_10" = 1, "MB_10" = 3, "SS_10" = 4),
                       labels = c("Chi2_10" = latex2exp::TeX("$chi^2$"),
                                  "MB_10" = "MB", "SS_10" = "SS")) +
    theme(legend.title = element_blank()) +
    theme(axis.text = element_text(size = 40),
          axis.title = element_text(size = 40, face = "bold")) +
    theme(legend.text = element_text(colour = "black", size = 40)) +
    theme(legend.position = c(0.75, 0.4), legend.key.size = unit(2, "cm")) +
    ylim(low = -0.1, high = 1.1) +
    geom_line(aes(linetype = group_10), linewidth = 1.0) +
    geom_point(aes(shape = group_10), size = 4) +
    geom_hline(yintercept = 0.1, colour = "brown", size = 0.25)
  ppt.Pow_10
  ggsave(paste(filename, "_10.pdf", sep = ""), width = 30, height = 30,
         unit = "cm")

  ppt.Pow_05 <- ggplot(data = df_05) +
    aes(x = gam, y = Pow, colour = group_05) +
    theme_gray() +
    xlab(latex2exp::TeX("$gamma$")) +
    ylab("") +
    scale_colour_manual(name = "Labels",
                        values = c("Chi2_05" = "black", "MB_05" = "blue",
                                   "SS_05" = "red"),
                        labels = c("Chi2_05" = latex2exp::TeX("$chi^2$"),
                                   "MB_05" = "MB", "SS_05" = "SS")) +
    scale_linetype_manual(name = "Labels",
                          values = c("Chi2_05" = "solid", "MB_05" = 42,
                                     "SS_05" = 44),
                          labels = c("Chi2_05" = latex2exp::TeX("$chi^2$"),
                                     "MB_05" = "MB", "SS_05" = "SS")) +
    scale_shape_manual(name = "Labels",
                       values = c("Chi2_05" = 1, "MB_05" = 3, "SS_05" = 4),
                       labels = c("Chi2_05" = latex2exp::TeX("$chi^2$"),
                                  "MB_05" = "MB", "SS_05" = "SS")) +
    theme(legend.title = element_blank()) +
    theme(axis.text = element_text(size = 40),
          axis.title = element_text(size = 40, face = "bold")) +
    theme(legend.text = element_text(colour = "black", size = 15)) +
    theme(legend.position = "none") +
    ylim(low = -0.1, high = 1.1) +
    geom_line(aes(linetype = group_05), linewidth = 1.0) +
    geom_point(aes(shape = group_05), size = 4) +
    geom_hline(yintercept = 0.05, colour = "brown", size = 0.25)
  ppt.Pow_05
  ggsave(paste(filename, "_05.pdf", sep = ""), width = 30, height = 30,
         unit = "cm")

  ppt.Pow_01 <- ggplot(data = df_01) +
    aes(x = gam, y = Pow, colour = group_01) +
    theme_gray() +
    xlab(latex2exp::TeX("$gamma$")) +
    ylab("") +
    scale_colour_manual(name = "Labels",
                        values = c("Chi2_01" = "black", "MB_01" = "blue",
                                   "SS_01" = "red"),
                        labels = c("Chi2_01" = latex2exp::TeX("$chi^2$"),
                                   "MB_01" = "MB", "SS_01" = "SS")) +
    scale_linetype_manual(name = "Labels",
                          values = c("Chi2_01" = "solid", "MB_01" = 42,
                                     "SS_01" = 44),
                          labels = c("Chi2_01" = latex2exp::TeX("$chi^2$"),
                                     "MB_01" = "MB", "SS_01" = "SS")) +
    scale_shape_manual(name = "Labels",
                       values = c("Chi2_01" = 1, "MB_01" = 3, "SS_01" = 4),
                       labels = c("Chi2_01" = latex2exp::TeX("$chi^2$"),
                                  "MB_01" = "MB", "SS_01" = "SS")) +
    theme(legend.title = element_blank()) +
    theme(axis.text = element_text(size = 40),
          axis.title = element_text(size = 40, face = "bold")) +
    theme(legend.text = element_text(colour = "black", size = 15)) +
    theme(legend.position = "none") +
    ylim(low = -0.1, high = 1.1) +
    geom_line(aes(linetype = group_01), linewidth = 1.0) +
    geom_point(aes(shape = group_01), size = 4) +
    geom_hline(yintercept = 0.01, colour = "brown", size = 0.25)
  ppt.Pow_01
  ggsave(paste(filename, "_01.pdf", sep = ""), width = 30, height = 30,
         unit = "cm")
}

#===============================================================================

# Purpose: Plot and save mean-independence power curves at 10%, 5%, and 1% levels.
# Input: `MCOBJ` is the Monte Carlo result list, `id` selects columns to plot,
# and `filename` is the output-file prefix without the nominal-level suffix.
# Output: Three PDF files saved to disk.
plot.pow2 <- function(MCOBJ, id, filename = NULL) {
  mat <- matrix(NA, length(MCOBJ), length(id) + 1)
  for (l in 1:length(MCOBJ)) {
    mat[l, ] <- c(gamvec[l], round(apply(MCOBJ[[l]], 1, mean), 3)[id])
  }
  mat <- as.data.frame(mat)
  names(mat) <- c("gamma",
                  "Chi2_10", "MB_10",
                  "Chi2_05", "MB_05",
                  "Chi2_01", "MB_01")

  group_10 <- group_05 <- group_01 <- c()
  n.test <- length(id) / 3
  n.g <- nrow(mat)
  for (l in 1:n.test) {
    group_10 <- c(group_10, rep(names(mat)[-1][1:n.test][l], n.g))
    group_05 <- c(group_05, rep(names(mat)[-1][n.test + (1:n.test)][l], n.g))
    group_01 <- c(group_01, rep(names(mat)[-1][2 * n.test + (1:n.test)][l], n.g))
  }

  df_10 <- data.frame(gam = rep(mat$gamma, n.test),
                      Pow = c(mat$Chi2_10, mat$MB_10),
                      group = group_10, group_col = group_10,
                      group_line = group_10)
  df_05 <- data.frame(gam = rep(mat$gamma, n.test),
                      Pow = c(mat$Chi2_05, mat$MB_05),
                      group = group_05, group_col = group_05,
                      group_line = group_05)
  df_01 <- data.frame(gam = rep(mat$gamma, n.test),
                      Pow = c(mat$Chi2_01, mat$MB_01),
                      group = group_01, group_col = group_01,
                      group_line = group_01)

  ppt.Pow_10 <- ggplot(data = df_10) +
    aes(x = gam, y = Pow, colour = group_10) +
    theme_gray() +
    xlab(latex2exp::TeX("$gamma$")) +
    ylab("") +
    scale_colour_manual(name = "Labels",
                        values = c("Chi2_10" = "black", "MB_10" = "blue"),
                        labels = c("Chi2_10" = latex2exp::TeX("$chi^2$"),
                                   "MB_10" = "MB")) +
    scale_linetype_manual(name = "Labels",
                          values = c("Chi2_10" = "solid", "MB_10" = 42),
                          labels = c("Chi2_10" = latex2exp::TeX("$chi^2$"),
                                     "MB_10" = "MB")) +
    scale_shape_manual(name = "Labels",
                       values = c("Chi2_10" = 1, "MB_10" = 3),
                       labels = c("Chi2_10" = latex2exp::TeX("$chi^2$"),
                                  "MB_10" = "MB")) +
    theme(legend.title = element_blank()) +
    theme(axis.text = element_text(size = 40),
          axis.title = element_text(size = 40, face = "bold")) +
    theme(legend.text = element_text(colour = "black", size = 40)) +
    theme(legend.position = c(0.75, 0.4), legend.key.size = unit(2, "cm")) +
    ylim(low = -0.1, high = 1.1) +
    geom_line(aes(linetype = group_10), linewidth = 1.0) +
    geom_point(aes(shape = group_10), size = 4) +
    geom_hline(yintercept = 0.1, colour = "brown", size = 0.25)
  ppt.Pow_10
  ggsave(paste(filename, "_10.pdf", sep = ""), width = 30, height = 30,
         unit = "cm")

  ppt.Pow_05 <- ggplot(data = df_05) +
    aes(x = gam, y = Pow, colour = group_05) +
    theme_gray() +
    xlab(latex2exp::TeX("$gamma$")) +
    ylab("") +
    scale_colour_manual(name = "Labels",
                        values = c("Chi2_05" = "black", "MB_05" = "blue"),
                        labels = c("Chi2_05" = latex2exp::TeX("$chi^2$"),
                                   "MB_05" = "MB")) +
    scale_linetype_manual(name = "Labels",
                          values = c("Chi2_05" = "solid", "MB_05" = 42),
                          labels = c("Chi2_05" = latex2exp::TeX("$chi^2$"),
                                     "MB_05" = "MB")) +
    scale_shape_manual(name = "Labels",
                       values = c("Chi2_05" = 1, "MB_05" = 3),
                       labels = c("Chi2_05" = latex2exp::TeX("$chi^2$"),
                                  "MB_05" = "MB")) +
    theme(legend.title = element_blank()) +
    theme(axis.text = element_text(size = 40),
          axis.title = element_text(size = 40, face = "bold")) +
    theme(legend.text = element_text(colour = "black", size = 15)) +
    theme(legend.position = "none") +
    ylim(low = -0.1, high = 1.1) +
    geom_line(aes(linetype = group_05), linewidth = 1.0) +
    geom_point(aes(shape = group_05), size = 4) +
    geom_hline(yintercept = 0.05, colour = "brown", size = 0.25)
  ppt.Pow_05
  ggsave(paste(filename, "_05.pdf", sep = ""), width = 30, height = 30,
         unit = "cm")

  ppt.Pow_01 <- ggplot(data = df_01) +
    aes(x = gam, y = Pow, colour = group_01) +
    theme_gray() +
    xlab(latex2exp::TeX("$gamma$")) +
    ylab("") +
    scale_colour_manual(name = "Labels",
                        values = c("Chi2_01" = "black", "MB_01" = "blue"),
                        labels = c("Chi2_01" = latex2exp::TeX("$chi^2$"),
                                   "MB_01" = "MB")) +
    scale_linetype_manual(name = "Labels",
                          values = c("Chi2_01" = "solid", "MB_01" = 42),
                          labels = c("Chi2_01" = latex2exp::TeX("$chi^2$"),
                                     "MB_01" = "MB")) +
    scale_shape_manual(name = "Labels",
                       values = c("Chi2_01" = 1, "MB_01" = 3),
                       labels = c("Chi2_01" = latex2exp::TeX("$chi^2$"),
                                  "MB_01" = "MB")) +
    theme(legend.title = element_blank()) +
    theme(axis.text = element_text(size = 40),
          axis.title = element_text(size = 40, face = "bold")) +
    theme(legend.text = element_text(colour = "black", size = 15)) +
    theme(legend.position = "none") +
    ylim(low = -0.1, high = 1.1) +
    geom_line(aes(linetype = group_01), linewidth = 1.0) +
    geom_point(aes(shape = group_01), size = 4) +
    geom_hline(yintercept = 0.01, colour = "brown", size = 0.25)
  ppt.Pow_01
  ggsave(paste(filename, "_01.pdf", sep = ""), width = 30, height = 30,
         unit = "cm")
}

#===============================================================================

# Purpose: Compute the product sinc kernel used for the uniform spectral measure.
# Input: `Z` is the conditioning-variable matrix.
# Output: A kernel matrix evaluated pairwise across rows of `Z`.
Kern.fun_muUnif <- function(Z) {
  Zdiff.ARRAY <- diffZ(as.matrix(Z))
  n <- dim(Zdiff.ARRAY)[1]
  Omg <- matrix(0, n, n)
  ID <- Zdiff.ARRAY[, , 1] == 0
  Omg <- sin(Zdiff.ARRAY[, , 1]) / Zdiff.ARRAY[, , 1]
  Omg[ID] <- 1
  for (k in 2:dim(Zdiff.ARRAY)[3]) {
    ID <- Zdiff.ARRAY[, , k] == 0
    Om <- sin(Zdiff.ARRAY[, , k]) / Zdiff.ARRAY[, , k]
    Om[ID] <- 1
    Omg <- Omg * Om
  }
  Omg
}

#===============================================================================

# Purpose: Compute the product triangular spectral kernel.
# Input: `Z` is the conditioning-variable matrix.
# Output: A kernel matrix evaluated pairwise across rows of `Z`.
Kern.fun_muTri <- function(Z) {
  Zdiff.ARRAY <- diffZ(as.matrix(Z))
  n <- dim(Zdiff.ARRAY)[1]
  Omg <- matrix(0, n, n)
  ID <- Zdiff.ARRAY[, , 1] == 0
  Omg <- -2 * (cos(Zdiff.ARRAY[, , 1]) - 1) / (Zdiff.ARRAY[, , 1]^2)
  Omg[ID] <- 1
  for (k in 2:dim(Zdiff.ARRAY)[3]) {
    ID <- Zdiff.ARRAY[, , k] == 0
    Om <- -2 * (cos(Zdiff.ARRAY[, , k]) - 1) / (Zdiff.ARRAY[, , k]^2)
    Om[ID] <- 1
    Omg <- Omg * Om
  }
  Omg
}

#===============================================================================

# Purpose: Compute the negative Euclidean-distance kernel with exponent `alpha`.
# Input: `Z` is the conditioning-variable matrix and `alpha` is the exponent.
# Output: A kernel matrix based on pairwise Euclidean distances.
Kern.fun_Euclid.a <- function(Z, alpha = 1.0) {
  -as.matrix(dist(Z))^alpha
}

#===============================================================================

# Purpose: Compute a product kernel using a chosen univariate density.
# Input: `Z` is the conditioning-variable matrix and `CDF` selects the density.
# Output: A kernel matrix evaluated pairwise across rows of `Z`.
Kern.fun_ProdCDF <- function(Z, CDF = "Logistic") {
  if (CDF == "Logistic") {
    CDFun <- function(z) dlogis(z)
  } else if (CDF == "Cauchy") {
    CDFun <- function(z) dcauchy(z)
  }
  Zdiff.ARRAY <- diffZ(as.matrix(Z))
  Omg <- CDFun(Zdiff.ARRAY[, , 1])
  for (k in 2:dim(Zdiff.ARRAY)[3]) {
    Omg <- Omg * CDFun(Zdiff.ARRAY[, , k])
  }
  Omg
}

#===============================================================================

# Purpose: Build a 3D array of all pairwise row differences in `Z`.
# Input: `Z` is a numeric vector or matrix of conditioning variables.
# Output: An `n x n x p` array of pairwise differences.
diffZ <- function(Z) {
  Z <- as.matrix(Z)
  n <- nrow(Z)
  pz <- ncol(Z)
  Zdiff.ARRAY <- array(0, c(n, n, pz))
  for (i in 2:n) {
    for (j in 1:(i - 1)) {
      Zdiff.ARRAY[i, j, ] <- Z[i, ] - Z[j, ]
      Zdiff.ARRAY[j, i, ] <- -Zdiff.ARRAY[i, j, ]
    }
  }
  Zdiff.ARRAY
}

#===============================================================================

# Purpose: Dispatch to the kernel matrix used by the chi-squared procedures.
# Input: `Z` is the conditioning-variable matrix, `Kern` names the kernel,
# and `alf` is the exponent for the Euclidean-alpha kernel.
# Output: A kernel matrix evaluated pairwise across rows of `Z`.
Kern.fun2 <- function(Z, Kern = "Gauss", alf = 1.0) {
  if (Kern == "Unif") {
    Ker <- Kern.fun_muUnif(Z)
  } else if (Kern == "muTri") {
    Ker <- Kern.fun_muTri(Z)
  } else if (Kern == "Euclid.alpha") {
    Ker <- Kern.fun_Euclid.a(Z, alpha = alf)
  } else if (Kern == "Logistic") {
    Ker <- Kern.fun_ProdCDF(Z, CDF = "Logistic")
  } else if (Kern == "Cauchy") {
    Ker <- Kern.fun_ProdCDF(Z, CDF = "Cauchy")
  } else {
    Ker <- Kern.fun(Z, Kern = Kern)
  }
  Ker
}

#===============================================================================

# Purpose: Compute the multiplier bootstrap for mean-independence comparisons.
# Input: `U` is the scalar outcome, `V` is the conditioning-variable matrix,
# `B` is the number of bootstrap draws, `Kern` selects the kernel, and `wmat`
# optionally supplies multiplier weights.
# Output: A list with the test statistic and bootstrap p-value.
mindep2.boot <- function(U, V, B = 199, Kern = "Gauss", wmat = NULL, cl = NULL,
                         cluster = NULL) {
  U <- U - mean(U)
  n <- length(U)
  Ker <- Kern.fun(V, Kern = Kern)
  diag(Ker) <- 0.0
  DU <- tcrossprod(c(U))
  diag(DU) <- 0.0

  K.C <- Ker + sum(c(Ker)) / ((n - 1) * (n - 2))
  D.C <- DU + sum(c(DU)) / ((n - 1) * (n - 2))

  for (i in 1:n) {
    ci <- sum(Ker[i, ]) / (n - 2)
    K.C[i, ] <- K.C[i, ] - ci
    K.C[, i] <- K.C[, i] - ci

    di <- sum(DU[i, ]) / (n - 2)
    D.C[i, ] <- D.C[i, ] - di
    D.C[, i] <- D.C[, i] - di
  }
  mdotP <- K.C * D.C
  diag(mdotP) <- 0.0

  Tn0 <- n * sum(mdotP) / (n * (n - 3))

  if (is.null(wmat)) {
    wmat <- wmat.mammen(n, B = B, seed = 0, cluster = cluster)
  } else {
    B <- ncol(wmat)
  }

  fn <- function(j) {
    n * (t(wmat[, j]) %*% mdotP %*% wmat[, j]) / (n * (n - 3))
  }
  if (is.null(cl)) {
    Tns <- sapply(1:B, fn)
  } else {
    Tns <- pbapply::pbsapply(1:B, fn, cl = cl)
  }

  ans <- list()
  ans$statistic <- Tn0
  ans$p.value <- (1 + sum(Tns > ans$statistic)) / (1 + B)
  ans
}

#===============================================================================

# Purpose: Compute the multiplier-bootstrap ICM specification test for IV models.
# Input: `rObj` is an `ivreg` fit, `wmat` optionally supplies multiplier weights,
# `B` is the number of bootstrap draws, and `Kern` selects the kernel.
# Output: A list with the test statistic and bootstrap p-value.
speclm_mul.test <- function(rObj, wmat = NULL, B = 999, Kern = "Gauss") {
  n <- length(rObj$y)
  if (is.null(wmat)) {
    wmat <- wmat.mammen(n, B = B, seed = 0)
  } else {
    B <- ncol(wmat)
  }

  Zp <- rObj$x$instruments
  if (!all(Zp[, 2] == rObj$x$regressors[, 2])) {
    Zp[, 2] <- lm(rObj$x$regressors[, 2] ~ poly(Zp[, 2], 3))$fitted.values
  }

  Ker <- Kern.fun2(Zp, Kern = Kern) / n
  diag(Ker) <- 0.0
  Ker.p <- (Zp %*% solve(crossprod(Zp)) %*% t(Zp))
  Ker.p <- diag(n) - Ker.p
  Ker.p <- t(Ker.p) %*% Ker %*% Ker.p

  Rn.fun <- function(b = NULL) {
    if (!is.null(b)) {
      tmp <- c(wmat[, b] * rObj$residuals)
      return(c(t(tmp) %*% Ker.p %*% tmp))
    }
    c(t(rObj$residuals) %*% Ker.p %*% rObj$residuals)
  }

  Tn0 <- Rn.fun(b = NULL)
  Tns <- sapply(1:B, Rn.fun)

  ans <- list()
  ans$statistic <- Tn0
  ans$p.value <- (1 + sum(Tns > ans$statistic)) / (1 + B)
  ans
}

#===============================================================================

# Purpose: Compute the multiplier-bootstrap ICM specification test for GLMs.
# Input: `rObj` is a fitted `glm`, `wmat` optionally supplies multiplier weights,
# `B` is the number of bootstrap draws, and `Kern` selects the kernel.
# Output: A list with the test statistic and bootstrap p-value.
spec.glm_mul.test <- function(rObj, wmat = NULL, B = 999, Kern = "Gauss") {
  n <- length(rObj$y)
  U <- rObj$y - rObj$fitted.values
  if (is.null(wmat)) {
    wmat <- wmat.mammen(n, B = B, seed = 0)
  } else {
    B <- ncol(wmat)
  }

  infl.obj <- glm_influence_blocks(mod = rObj)
  Zp <- infl.obj$G_X_theta

  Ker <- Kern.fun2(Zp, Kern = Kern) / n
  diag(Ker) <- 0.0
  Ker.p <- (Zp %*% solve(crossprod(Zp)) %*% t(Zp))
  Ker.p <- diag(n) - Ker.p
  Ker.p <- t(Ker.p) %*% Ker %*% Ker.p

  Rn.fun <- function(b = NULL) {
    if (!is.null(b)) {
      tmp <- c(wmat[, b] * U)
      return(c(t(tmp) %*% Ker.p %*% tmp))
    }
    c(t(U) %*% Ker.p %*% U)
  }

  Tn0 <- Rn.fun(b = NULL)
  Tns <- sapply(1:B, Rn.fun)

  ans <- list()
  ans$statistic <- Tn0
  ans$p.value <- (1 + sum(Tns > ans$statistic)) / (1 + B)
  ans
}

#===============================================================================

# Purpose: Build score, Fisher-information, and influence-function blocks for GLMs.
# Input: `mod` is a fitted `glm` object.
# Output: A list containing the model matrix, response, derivative matrix, score
# matrix, Fisher information, its inverse, and observation-level influences.
glm_influence_blocks <- function(mod) {
  if (!inherits(mod, "glm")) {
    stop("mod must be a glm() fit")
  }

  mf <- tryCatch(model.frame(mod), error = function(e) NULL)
  X <- model.matrix(mod)
  n <- nrow(X)

  y <- if (!is.null(mod$y)) {
    mod$y
  } else {
    if (is.null(mf)) {
      stop("Cannot find response; refit with y=TRUE or keep model frame.")
    }
    model.response(mf)
  }

  fam <- mod$family
  mu <- mod$fitted.values
  eta <- mod$linear.predictors
  wts <- if (!is.null(mod$prior.weights)) mod$prior.weights else rep(1, length(mu))
  phi <- summary(mod)$dispersion

  Vmu <- fam$variance(mu)
  dmu_deta <- fam$mu.eta(eta)
  G_X_theta <- X * dmu_deta

  scale_i <- wts * (y - mu) * dmu_deta / (phi * Vmu)
  score_i <- X * scale_i

  W_i <- wts * (dmu_deta^2) / (phi * Vmu)
  WX <- X * W_i
  fisher <- crossprod(X, WX) / n
  fisher_inv <- tryCatch(solve(fisher), error = function(e) MASS::ginv(fisher))
  IF_mat <- score_i %*% fisher_inv

  list(
    X = X,
    y = y,
    G_X_theta = G_X_theta,
    score_i = score_i,
    fisher = fisher,
    fisher_inv = fisher_inv,
    influence_mat = IF_mat
  )
}

#===============================================================================
