MATLAB="/Applications/MATLAB_R2018b.app"
Arch=maci64
ENTRYPOINT=mexFunction
MAPFILE=$ENTRYPOINT'.map'
PREFDIR="/Users/Selorm/Library/Application Support/MathWorks/MATLAB/R2018b"
OPTSFILE_NAME="./setEnv.sh"
. $OPTSFILE_NAME
COMPILER=$CC
. $OPTSFILE_NAME
echo "# Make settings for goldsscoord2" > goldsscoord2_mex.mki
echo "CC=$CC" >> goldsscoord2_mex.mki
echo "CFLAGS=$CFLAGS" >> goldsscoord2_mex.mki
echo "CLIBS=$CLIBS" >> goldsscoord2_mex.mki
echo "COPTIMFLAGS=$COPTIMFLAGS" >> goldsscoord2_mex.mki
echo "CDEBUGFLAGS=$CDEBUGFLAGS" >> goldsscoord2_mex.mki
echo "CXX=$CXX" >> goldsscoord2_mex.mki
echo "CXXFLAGS=$CXXFLAGS" >> goldsscoord2_mex.mki
echo "CXXLIBS=$CXXLIBS" >> goldsscoord2_mex.mki
echo "CXXOPTIMFLAGS=$CXXOPTIMFLAGS" >> goldsscoord2_mex.mki
echo "CXXDEBUGFLAGS=$CXXDEBUGFLAGS" >> goldsscoord2_mex.mki
echo "LDFLAGS=$LDFLAGS" >> goldsscoord2_mex.mki
echo "LDOPTIMFLAGS=$LDOPTIMFLAGS" >> goldsscoord2_mex.mki
echo "LDDEBUGFLAGS=$LDDEBUGFLAGS" >> goldsscoord2_mex.mki
echo "Arch=$Arch" >> goldsscoord2_mex.mki
echo "LD=$LD" >> goldsscoord2_mex.mki
echo OMPFLAGS= >> goldsscoord2_mex.mki
echo OMPLINKFLAGS= >> goldsscoord2_mex.mki
echo "EMC_COMPILER=clang" >> goldsscoord2_mex.mki
echo "EMC_CONFIG=optim" >> goldsscoord2_mex.mki
"/Applications/MATLAB_R2018b.app/bin/maci64/gmake" -j 1 -B -f goldsscoord2_mex.mk
