function betas = CCRls2(Y,Xv,n,p)
%% Note: this function takes vectorised inputs. 
% Vectorisation is column major.
tol = 1e-06; 
Y = Y(1:n); %extract actual data
np = (n*p); % total number of elements in Xv and covariates
Xm = Xv(1:np); %extract total number of elements in covariates

X = zeros(n,p); %convert design vector into design matrix
for i=1:n
   for j=1:p
      X(i,j) = Xm((j-1)*n +i);
   end
end

bet_vec = zeros(1,p); % vector to store parameters, excludes intercept
betas = zeros(1,(p+1));
kp = 0.1; % fraction of total number of observations as partition size
slc = floor(kp*n); %maximum size of a local covariate cluster.
if (slc > p)
    error('use this function for p >> 0.1n');
end
lcls = ceil((1:p)./slc); %partition covarites into clusters
nlcls = max(lcls); % number of partitions

%% Initialise parameters
bet0 = 0; %initialise intercept
X0 = ones(n,2); % coef0 = zeros(1,2)';
for j=1:p
   X0(:,2) = X(:,j); 
   coef0 = X0\Y;
   bet_vec(j) = coef0(2) ;
end

val0 = 10^10+0.1; val1=0; l=0; dev = val0;
coefs = zeros(1,slc)'; 
ngIDLS=false(1,(p-slc));
IDls = false(1,slc);

while (dev>tol)
    if (l>0)
      val0 = val1;
      bet_vec(IDls)=coefs(2:(end-1));
      bet0 = coefs(1);
      bet_vec(ngIDLS) =  bet_vec(ngIDLS) * coefs(end);
    end
    
     l = l+1; IND = l - (ceil(l/nlcls)-1)*nlcls;
     IDls = lcls ==IND; % nIDls = length(IDls);
     ngIDLS = lcls ~=IND;
     XB = X(:,ngIDLS)*bet_vec(ngIDLS)';
     Xl = X(:,IDls);
     XX = [ones(n,1) Xl XB] ; %make room for intercept term
     coefs = XX\Y;
     val1=sum((Y-XX*coefs).^2);
     
     if (l>1)
        dev = (val0-val1)/(1+abs(val0)); 
     else
        dev=1; 
     end
     % print progress
     if(mod(l,100)==0)
     sprintf('iter = %.0f fval = %f and dev = %f',l,val1,dev)
     end
end
betas(1) = bet0;
for j=1:p
betas(j+1) =  bet_vec(j);    
end

