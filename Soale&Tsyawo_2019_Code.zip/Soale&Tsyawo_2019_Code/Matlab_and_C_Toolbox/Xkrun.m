function [clus,deltas,RSS] = Xkrun(coefs,Y,X,Xc,k)
% input X,Xk,p,k

[n,~]=size(X);[~,lXc] = size(Xc);
Xk = ones(n,(k+lXc+1)); Xk(:,(2:lXc+1)) = Xc;
rng(1); % For reproducibility
[clus,~] = kmeans(coefs,k); % coefs of length p
for j = 1:k
    Xk(:,(lXc+1+j)) = sum(X(:,clus==j),2); %sum rows of columns in same cluster
end
deltas = Xk\Y;
RSS = double(sum((Y-Xk*deltas).^2));
end
