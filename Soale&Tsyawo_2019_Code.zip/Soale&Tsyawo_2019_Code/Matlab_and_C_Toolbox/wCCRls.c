/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 * File: CCRls2.c
 *
 * MATLAB Coder version            : 4.1
 * C/C++ source code generated on  : 23-Nov-2018 14:05:49
 */

/* Include Files */
#include <math.h>
#include "CCRls2.h"
#include "CCRls2_emxutil.h"
#include "CCRls2_emxAPI.h"
#include "mldivide.h"
#include "ceil.h"
#include <stdio.h>

// a wrapper function with an amenable input to call in R
void wCCRls(double *Y, double *Xv, double *n, double *p, double *betas){
    
    emxArray_real_T *YY, *XXv, *bbetas;
    
    YY = emxCreateWrapper_real_T(Y, (int)n, 1);
    XXv = emxCreateWrapper_real_T(Xv, (int) (n*p), 1);
    bbetas = emxCreateWrapper_real_T(betas, (int) (p+1), 1);
    
    return CCRls2(YY, const XXv, double n, double p, bbetas);
}


/* Function Definitions */

/*
 * Note: this function takes vectorised inputs.
 *  Vectorisation is column major.
 * Arguments    : emxArray_real_T *Y
 *                const emxArray_real_T *Xv
 *                double n
 *                double p
 *                emxArray_real_T *betas
 * Return Type  : void
 */
void CCRls2(emxArray_real_T *Y, const emxArray_real_T *Xv, double n, double p,
            emxArray_real_T *betas)
{
  emxArray_real_T *X;
  int i0;
  int i1;
  int i2;
  int i;
  int b_n;
  emxArray_real_T *lcls;
  int slc;
  int i3;
  double nlcls;
  int k;
  emxArray_real_T *X0;
  emxArray_real_T *bet_vec;
  emxArray_real_T *coefs;
  double val0;
  double val1;
  double dv0[2];
  double l;
  double dev;
  emxArray_boolean_T *ngIDLS;
  emxArray_boolean_T *IDls;
  emxArray_real_T *XX;
  emxArray_real_T *r0;
  emxArray_int32_T *r1;
  emxArray_int32_T *r2;
  emxArray_int32_T *r3;
  cell_wrap_0 reshapes[3];
  emxArray_real_T *y;
  emxArray_char_T *charStr;
  emxArray_int32_T *a_tmp;
  emxArray_real_T *b_X;
  emxArray_real_T *b_bet_vec;
  int inner;
  boolean_T empty_non_axis_sizes;
  signed char input_sizes_idx_1;
  boolean_T guard1 = false;
  unsigned int a_idx_0;
  emxInit_real_T(&X, 2);
  i0 = Y->size[0];
  if (1.0 > n) {
    Y->size[0] = 0;
  } else {
    Y->size[0] = (int)n;
  }

  emxEnsureCapacity_real_T(Y, i0);

  /* extract actual data */
  /*  total number of elements in Xv and covariates */
  /* extract total number of elements in covariates */
  /* convert design vector into design matrix */
  i0 = (int)n;
  i1 = X->size[0] * X->size[1];
  X->size[0] = i0;
  i2 = (int)p;
  X->size[1] = i2;
  emxEnsureCapacity_real_T(X, i1);
  for (i = 0; i < i0; i++) {
    for (b_n = 0; b_n < i2; b_n++) {
      X->data[i + X->size[0] * b_n] = Xv->data[(int)(((1.0 + (double)b_n) - 1.0)
        * n + (1.0 + (double)i)) - 1];
    }
  }

  /*  vector to store parameters, excludes intercept */
  i1 = betas->size[0] * betas->size[1];
  betas->size[0] = 1;
  i = (int)(p + 1.0);
  betas->size[1] = i;
  emxEnsureCapacity_real_T(betas, i1);
  for (i1 = 0; i1 < i; i1++) {
    betas->data[i1] = 0.0;
  }

  emxInit_real_T(&lcls, 2);

  /*  fraction of total number of observations as partition size */
  slc = (int)floor(0.1 * n);

  /* maximum size of a local covariate cluster. */
  if (p < 1.0) {
    lcls->size[0] = 1;
    lcls->size[1] = 0;
  } else {
    i1 = lcls->size[0] * lcls->size[1];
    lcls->size[0] = 1;
    i = (int)floor(p - 1.0);
    lcls->size[1] = i + 1;
    emxEnsureCapacity_real_T(lcls, i1);
    for (i1 = 0; i1 <= i; i1++) {
      lcls->data[i1] = 1.0 + (double)i1;
    }
  }

  i1 = lcls->size[0] * lcls->size[1];
  i3 = lcls->size[0] * lcls->size[1];
  lcls->size[0] = 1;
  emxEnsureCapacity_real_T(lcls, i3);
  i = i1 - 1;
  for (i1 = 0; i1 <= i; i1++) {
    lcls->data[i1] /= (double)slc;
  }

  b_ceil(lcls);

  /* partition covarites into clusters */
  b_n = lcls->size[1];
  if (lcls->size[1] <= 2) {
    if (lcls->size[1] == 1) {
      nlcls = lcls->data[0];
    } else if (lcls->data[0] < lcls->data[1]) {
      nlcls = lcls->data[1];
    } else {
      nlcls = lcls->data[0];
    }
  } else {
    nlcls = lcls->data[0];
    for (k = 2; k <= b_n; k++) {
      if (nlcls < lcls->data[k - 1]) {
        nlcls = lcls->data[k - 1];
      }
    }
  }

  emxInit_real_T(&X0, 2);

  /*  number of partitions */
  /*  Initialise parameters */
  betas->data[0] = 0.0;

  /* initialise intercept */
  i1 = X0->size[0] * X0->size[1];
  X0->size[0] = i0;
  X0->size[1] = 2;
  emxEnsureCapacity_real_T(X0, i1);
  i = i0 << 1;
  for (i1 = 0; i1 < i; i1++) {
    X0->data[i1] = 1.0;
  }

  emxInit_real_T(&bet_vec, 2);

  /*  coef0 = zeros(1,2)'; */
  i1 = bet_vec->size[0] * bet_vec->size[1];
  bet_vec->size[0] = 1;
  bet_vec->size[1] = i2;
  emxEnsureCapacity_real_T(bet_vec, i1);
  for (b_n = 0; b_n < i2; b_n++) {
    i = X->size[0] - 1;
    for (i1 = 0; i1 <= i; i1++) {
      X0->data[i1 + X0->size[0]] = X->data[i1 + X->size[0] * b_n];
    }

    mldivide(X0, Y, dv0);
    bet_vec->data[b_n] = dv0[1];
  }

  emxFree_real_T(&X0);
  emxInit_real_T(&coefs, 1);
  val0 = 1.00000000001E+10;
  val1 = 0.0;
  l = 0.0;
  dev = 1.00000000001E+10;
  i1 = coefs->size[0];
  coefs->size[0] = slc;
  emxEnsureCapacity_real_T(coefs, i1);
  for (i1 = 0; i1 < slc; i1++) {
    coefs->data[i1] = 0.0;
  }

  emxInit_boolean_T(&ngIDLS, 2);
  i1 = ngIDLS->size[0] * ngIDLS->size[1];
  ngIDLS->size[0] = 1;
  i = (int)(p - (double)slc);
  ngIDLS->size[1] = i;
  emxEnsureCapacity_boolean_T(ngIDLS, i1);
  for (i1 = 0; i1 < i; i1++) {
    ngIDLS->data[i1] = false;
  }

  emxInit_boolean_T(&IDls, 2);
  i1 = IDls->size[0] * IDls->size[1];
  IDls->size[0] = 1;
  IDls->size[1] = slc;
  emxEnsureCapacity_boolean_T(IDls, i1);
  for (i1 = 0; i1 < slc; i1++) {
    IDls->data[i1] = false;
  }

  emxInit_real_T(&XX, 2);
  emxInit_real_T(&r0, 2);
  emxInit_int32_T(&r1, 2);
  emxInit_int32_T(&r2, 2);
  emxInit_int32_T(&r3, 2);
  emxInitMatrix_cell_wrap_0(reshapes);
  emxInit_real_T(&y, 1);
  emxInit_char_T(&charStr, 2);
  emxInit_int32_T(&a_tmp, 1);
  emxInit_real_T(&b_X, 2);
  emxInit_real_T(&b_bet_vec, 1);
  while (dev > 1.0E-6) {
    if (l > 0.0) {
      val0 = val1;
      if (2.0 > (double)coefs->size[0] - 1.0) {
        i1 = 1;
      } else {
        i1 = 2;
      }

      slc = IDls->size[1];
      b_n = -1;
      for (i = 0; i < slc; i++) {
        if (IDls->data[i]) {
          bet_vec->data[i] = coefs->data[i1 + b_n];
          b_n++;
        }
      }

      betas->data[0] = coefs->data[0];
      slc = ngIDLS->size[1] - 1;
      b_n = 0;
      for (i = 0; i <= slc; i++) {
        if (ngIDLS->data[i]) {
          b_n++;
        }
      }

      i1 = r3->size[0] * r3->size[1];
      r3->size[0] = 1;
      r3->size[1] = b_n;
      emxEnsureCapacity_int32_T(r3, i1);
      b_n = 0;
      for (i = 0; i <= slc; i++) {
        if (ngIDLS->data[i]) {
          r3->data[b_n] = i + 1;
          b_n++;
        }
      }

      i1 = r0->size[0] * r0->size[1];
      r0->size[0] = 1;
      r0->size[1] = r3->size[1];
      emxEnsureCapacity_real_T(r0, i1);
      val1 = coefs->data[coefs->size[0] - 1];
      i = r3->size[0] * r3->size[1];
      for (i1 = 0; i1 < i; i1++) {
        r0->data[i1] = bet_vec->data[r3->data[i1] - 1] * val1;
      }

      slc = ngIDLS->size[1];
      b_n = 0;
      for (i = 0; i < slc; i++) {
        if (ngIDLS->data[i]) {
          bet_vec->data[i] = r0->data[b_n];
          b_n++;
        }
      }
    }

    l++;
    val1 = l - (ceil(l / nlcls) - 1.0) * nlcls;
    i1 = IDls->size[0] * IDls->size[1];
    IDls->size[0] = 1;
    IDls->size[1] = lcls->size[1];
    emxEnsureCapacity_boolean_T(IDls, i1);
    i = lcls->size[0] * lcls->size[1];
    for (i1 = 0; i1 < i; i1++) {
      IDls->data[i1] = (lcls->data[i1] == val1);
    }

    /*  nIDls = length(IDls); */
    i1 = ngIDLS->size[0] * ngIDLS->size[1];
    ngIDLS->size[0] = 1;
    ngIDLS->size[1] = lcls->size[1];
    emxEnsureCapacity_boolean_T(ngIDLS, i1);
    i = lcls->size[0] * lcls->size[1];
    for (i1 = 0; i1 < i; i1++) {
      ngIDLS->data[i1] = (lcls->data[i1] != val1);
    }

    slc = ngIDLS->size[1] - 1;
    b_n = 0;
    for (i = 0; i <= slc; i++) {
      if (ngIDLS->data[i]) {
        b_n++;
      }
    }

    i1 = r1->size[0] * r1->size[1];
    r1->size[0] = 1;
    r1->size[1] = b_n;
    emxEnsureCapacity_int32_T(r1, i1);
    b_n = 0;
    for (i = 0; i <= slc; i++) {
      if (ngIDLS->data[i]) {
        r1->data[b_n] = i + 1;
        b_n++;
      }
    }

    i1 = a_tmp->size[0];
    a_tmp->size[0] = r1->size[1];
    emxEnsureCapacity_int32_T(a_tmp, i1);
    i = r1->size[1];
    for (i1 = 0; i1 < i; i1++) {
      a_tmp->data[i1] = r1->data[i1];
    }

    if (a_tmp->size[0] == 1) {
      i = X->size[0];
      i1 = b_X->size[0] * b_X->size[1];
      b_X->size[0] = i;
      b_X->size[1] = a_tmp->size[0];
      emxEnsureCapacity_real_T(b_X, i1);
      b_n = a_tmp->size[0];
      for (i1 = 0; i1 < b_n; i1++) {
        for (i3 = 0; i3 < i; i3++) {
          b_X->data[i3 + b_X->size[0] * i1] = X->data[i3 + X->size[0] *
            (a_tmp->data[i1] - 1)];
        }
      }

      i1 = b_bet_vec->size[0];
      b_bet_vec->size[0] = a_tmp->size[0];
      emxEnsureCapacity_real_T(b_bet_vec, i1);
      i = a_tmp->size[0];
      for (i1 = 0; i1 < i; i1++) {
        b_bet_vec->data[i1] = bet_vec->data[a_tmp->data[i1] - 1];
      }

      i1 = coefs->size[0];
      coefs->size[0] = b_X->size[0];
      emxEnsureCapacity_real_T(coefs, i1);
      i = b_X->size[0];
      for (i1 = 0; i1 < i; i1++) {
        coefs->data[i1] = 0.0;
        b_n = b_X->size[1];
        for (i3 = 0; i3 < b_n; i3++) {
          coefs->data[i1] += b_X->data[i1 + b_X->size[0] * i3] * b_bet_vec->
            data[i3];
        }
      }
    } else {
      i1 = X->size[0];
      inner = a_tmp->size[0];
      i3 = X->size[0];
      b_n = coefs->size[0];
      coefs->size[0] = i3;
      emxEnsureCapacity_real_T(coefs, b_n);
      for (i = 0; i < i1; i++) {
        coefs->data[i] = 0.0;
      }

      for (k = 0; k < inner; k++) {
        slc = k * i1;
        for (i = 0; i < i1; i++) {
          i3 = X->size[0];
          b_n = slc + i;
          coefs->data[i] += bet_vec->data[a_tmp->data[k] - 1] * X->data[b_n % i3
            + X->size[0] * (a_tmp->data[b_n / i3] - 1)];
        }
      }
    }

    slc = IDls->size[1] - 1;
    b_n = 0;
    for (i = 0; i <= slc; i++) {
      if (IDls->data[i]) {
        b_n++;
      }
    }

    i1 = r2->size[0] * r2->size[1];
    r2->size[0] = 1;
    r2->size[1] = b_n;
    emxEnsureCapacity_int32_T(r2, i1);
    b_n = 0;
    for (i = 0; i <= slc; i++) {
      if (IDls->data[i]) {
        r2->data[b_n] = i + 1;
        b_n++;
      }
    }

    if (i0 != 0) {
      slc = i0;
    } else {
      i1 = X->size[0];
      i3 = a_tmp->size[0];
      a_tmp->size[0] = r2->size[1];
      emxEnsureCapacity_int32_T(a_tmp, i3);
      i = r2->size[1];
      for (i3 = 0; i3 < i; i3++) {
        a_tmp->data[i3] = r2->data[i3];
      }

      if ((i1 != 0) && (a_tmp->size[0] != 0)) {
        slc = X->size[0];
      } else if (coefs->size[0] != 0) {
        slc = coefs->size[0];
      } else {
        slc = 0;
        i1 = X->size[0];
        if (i1 > 0) {
          slc = X->size[0];
        }
      }
    }

    empty_non_axis_sizes = (slc == 0);
    if (empty_non_axis_sizes || (i0 != 0)) {
      input_sizes_idx_1 = 1;
    } else {
      input_sizes_idx_1 = 0;
    }

    i1 = reshapes[0].f1->size[0] * reshapes[0].f1->size[1];
    reshapes[0].f1->size[0] = slc;
    reshapes[0].f1->size[1] = input_sizes_idx_1;
    emxEnsureCapacity_real_T(reshapes[0].f1, i1);
    i = slc * input_sizes_idx_1;
    for (i1 = 0; i1 < i; i1++) {
      reshapes[0].f1->data[i1] = 1.0;
    }

    guard1 = false;
    if (empty_non_axis_sizes) {
      guard1 = true;
    } else {
      i1 = X->size[0];
      i3 = a_tmp->size[0];
      a_tmp->size[0] = r2->size[1];
      emxEnsureCapacity_int32_T(a_tmp, i3);
      i = r2->size[1];
      for (i3 = 0; i3 < i; i3++) {
        a_tmp->data[i3] = r2->data[i3];
      }

      if ((i1 != 0) && (a_tmp->size[0] != 0)) {
        guard1 = true;
      } else {
        inner = 0;
      }
    }

    if (guard1) {
      i1 = a_tmp->size[0];
      a_tmp->size[0] = r2->size[1];
      emxEnsureCapacity_int32_T(a_tmp, i1);
      i = r2->size[1];
      for (i1 = 0; i1 < i; i1++) {
        a_tmp->data[i1] = r2->data[i1];
      }

      inner = a_tmp->size[0];
    }

    if (empty_non_axis_sizes || (coefs->size[0] != 0)) {
      input_sizes_idx_1 = 1;
    } else {
      input_sizes_idx_1 = 0;
    }

    i = X->size[0];
    i1 = b_X->size[0] * b_X->size[1];
    b_X->size[0] = i;
    b_X->size[1] = r2->size[1];
    emxEnsureCapacity_real_T(b_X, i1);
    b_n = r2->size[1];
    for (i1 = 0; i1 < b_n; i1++) {
      for (i3 = 0; i3 < i; i3++) {
        b_X->data[i3 + b_X->size[0] * i1] = X->data[i3 + X->size[0] * (r2->
          data[i1] - 1)];
      }
    }

    i1 = XX->size[0] * XX->size[1];
    XX->size[0] = reshapes[0].f1->size[0];
    XX->size[1] = (reshapes[0].f1->size[1] + inner) + input_sizes_idx_1;
    emxEnsureCapacity_real_T(XX, i1);
    i = reshapes[0].f1->size[1];
    for (i1 = 0; i1 < i; i1++) {
      b_n = reshapes[0].f1->size[0];
      for (i3 = 0; i3 < b_n; i3++) {
        XX->data[i3 + XX->size[0] * i1] = reshapes[0].f1->data[i3 + reshapes[0].
          f1->size[0] * i1];
      }
    }

    for (i1 = 0; i1 < inner; i1++) {
      for (i3 = 0; i3 < slc; i3++) {
        XX->data[i3 + XX->size[0] * (i1 + reshapes[0].f1->size[1])] = b_X->
          data[i3 + slc * i1];
      }
    }

    i = input_sizes_idx_1;
    for (i1 = 0; i1 < i; i1++) {
      for (i3 = 0; i3 < slc; i3++) {
        XX->data[i3 + XX->size[0] * (reshapes[0].f1->size[1] + inner)] =
          coefs->data[i3];
      }
    }

    /* make room for intercept term */
    i1 = coefs->size[0];
    coefs->size[0] = Y->size[0];
    emxEnsureCapacity_real_T(coefs, i1);
    i = Y->size[0];
    for (i1 = 0; i1 < i; i1++) {
      coefs->data[i1] = Y->data[i1];
    }

    b_mldivide(XX, coefs);
    if ((XX->size[1] == 1) || (coefs->size[0] == 1)) {
      i1 = b_bet_vec->size[0];
      b_bet_vec->size[0] = XX->size[0];
      emxEnsureCapacity_real_T(b_bet_vec, i1);
      i = XX->size[0];
      for (i1 = 0; i1 < i; i1++) {
        b_bet_vec->data[i1] = 0.0;
        b_n = XX->size[1];
        for (i3 = 0; i3 < b_n; i3++) {
          b_bet_vec->data[i1] += XX->data[i1 + XX->size[0] * i3] * coefs->
            data[i3];
        }
      }
    } else {
      b_n = XX->size[0];
      inner = XX->size[1];
      i1 = b_bet_vec->size[0];
      b_bet_vec->size[0] = XX->size[0];
      emxEnsureCapacity_real_T(b_bet_vec, i1);
      for (i = 0; i < b_n; i++) {
        b_bet_vec->data[i] = 0.0;
      }

      for (k = 0; k < inner; k++) {
        slc = k * b_n;
        for (i = 0; i < b_n; i++) {
          b_bet_vec->data[i] += coefs->data[k] * XX->data[slc + i];
        }
      }
    }

    i1 = b_bet_vec->size[0];
    b_bet_vec->size[0] = Y->size[0];
    emxEnsureCapacity_real_T(b_bet_vec, i1);
    i = Y->size[0];
    for (i1 = 0; i1 < i; i1++) {
      b_bet_vec->data[i1] = Y->data[i1] - b_bet_vec->data[i1];
    }

    a_idx_0 = (unsigned int)b_bet_vec->size[0];
    i1 = y->size[0];
    y->size[0] = (int)a_idx_0;
    emxEnsureCapacity_real_T(y, i1);
    a_idx_0 = (unsigned int)b_bet_vec->size[0];
    b_n = (int)a_idx_0;
    for (k = 0; k < b_n; k++) {
      y->data[k] = b_bet_vec->data[k] * b_bet_vec->data[k];
    }

    b_n = y->size[0];
    if (y->size[0] == 0) {
      val1 = 0.0;
    } else {
      val1 = y->data[0];
      for (k = 2; k <= b_n; k++) {
        val1 += y->data[k - 1];
      }
    }

    if (l > 1.0) {
      dev = (val0 - val1) / (1.0 + fabs(val0));
    } else {
      dev = 1.0;
    }

    /*  print progress */
    if (fmod(l, 100.0) == 0.0) {
      b_n = (int)snprintf(NULL, 0, "iter = %.0f fval = %f and dev = %f", l, val1,
                          dev) + 1;
      i1 = charStr->size[0] * charStr->size[1];
      charStr->size[0] = 1;
      charStr->size[1] = b_n;
      emxEnsureCapacity_char_T(charStr, i1);
      snprintf(&charStr->data[0], (size_t)b_n,
               "iter = %.0f fval = %f and dev = %f", l, val1, dev);
    }
  }

  emxFree_real_T(&b_bet_vec);
  emxFree_real_T(&b_X);
  emxFree_int32_T(&a_tmp);
  emxFree_char_T(&charStr);
  emxFree_real_T(&y);
  emxFreeMatrix_cell_wrap_0(reshapes);
  emxFree_int32_T(&r3);
  emxFree_int32_T(&r2);
  emxFree_int32_T(&r1);
  emxFree_real_T(&r0);
  emxFree_real_T(&XX);
  emxFree_boolean_T(&IDls);
  emxFree_boolean_T(&ngIDLS);
  emxFree_real_T(&coefs);
  emxFree_real_T(&lcls);
  emxFree_real_T(&X);
  for (b_n = 0; b_n < i2; b_n++) {
    betas->data[b_n + 1] = bet_vec->data[b_n];
  }

  emxFree_real_T(&bet_vec);
}

/*
 * File trailer for CCRls2.c
 *
 * [EOF]
 */
