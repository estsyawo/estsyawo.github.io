#=========================================================================================>
# Functions

#-------------------------------------------------->
# Function for initialising parameter/covariate clusters
# Arguments: 
# X - design matrix, Y - dependent variable, k - number of clusters
# method - method for assigning clusters: "kmeans", "fkmeans" are supported
# return - clus - vector of cluster assignments of covariates

iniclus<- function(X,Y=NULL,k,method="kmeans"){ 
  set.seed(1)
  if(method=="kmeans"){
    clus=stats::kmeans(t(X),centers=k)$cluster
  }else if(method=="fkmeans"){
    zX<- matrix(NA,dim(X)[1],dim(X)[2])
    for (j in 1:dim(X)[2]) {
      zX[,j]<- lm(Y~X[,j])$fitted.values
    }
    clus=kmeans(t(zX),centers=k)$cluster
  }else{stop("method not supported")}
  clus
}


#=========================================================================================>

#=========================================================================================>
# Function for parameter/covariate clustering regression
# Arguments:
# X - design matrix, Y - dependent variable, k - number of clusters
# method - method for initial assignment of clusters: "kmeans", "fkmeans" are supported
# crit - the criterion "AIC" or "BIC" to be computed
# return - clus - vector of cluster assignments of covariates

cluspar<- function(X,Y,k,method="kmeans",crit="BIC"){
  #Preliminaries
  nrX <- nrow(X) #number of rows of X
  ncX <- ncol(X) #number of columns of X
  if(method=="kmeans"){
  clus <- iniclus(X=X,k=k,method=method)  
  }else if(method=="fkmeans"){
    clus <- iniclus(X=X,Y=Y,k=k,method=method)  
  }else{
    stop("method not supported")
  }
  uniClus <- unique(clus)
  
  X1 <- matrix(NA,nrX,k)
  for(j in uniClus) X1[,j] <- apply(as.matrix(X[,(which(clus == j))]),1,sum)
  model1 <- lm(Y~X1)
  SSEo<-sum(model1$residuals^2)
  lmc1 <- (k-1)*ncX #number of single-shift permutations
  
  #create matrix of one-shift permutation clusterings
  iter=0; optSSE=0 #initialise counter and optimal SSE
  while(optSSE<SSEo){
    iter=iter+1;  
    if(iter>1){SSEo<- optSSE; clus<- clus1[optcl,]}
    
    clus1 <- matrix(rep(clus,lmc1) ,ncol=ncX,byrow=T) 
    for(j in 1:ncX) clus1[c(((k-1)*(j-1)+1):(j*(k-1))),j] <- setdiff(uniClus,clus[j])
    
    #-------------------------------------------------->
    vSSE<-rep(NA,lmc1) # a vector of length lmc1 to store sum of squared errors
    for (i in 1:lmc1){
      for(h in uniClus) X1[,h] <- apply(as.matrix(X[,(which(clus1[i,] == h))]),1,sum)
      vSSE[i]=sum((lm(Y~X1)$residuals)^2)
    }
    #-------------------------------------------------->
    optcl<- which.min(vSSE) #optimal model at this node
    optSSE<- vSSE[optcl]
    
    print(optSSE)
    
  }
  if(crit=="AIC"){
    critval=2*SSEo + 2*k
  }else if(crit=="BIC"){
      critval=2*SSEo + (log(nrX)*k)
  }else{
      stop("Criterion type not recognised.")
    }
  list(clus=clus,SSE=SSEo,critval=critval,iter=iter)
}


## monte carlo data
mcdata <- function(beta, s, n, p,model="lm"){
  set.seed(s)
  x1 <- rnorm(n*p/2,sd=1.2)
  set.seed(s)
  x2 <- rlogis(n*p/2,scale=1.2)
  xx <- c(x1,x2)
  x <- matrix(xx,ncol=p,byrow=F)
  
  ## response Y
  set.seed(100+s)
  yt<- sqrt(2) + x%*%beta + rnorm(n)
  if(model%in%c("logit","probit")){
    set.seed(200+s)
    Y=rep(0,n); Y[scale(yt)>0]=1
  }else{
    Y=yt
  }
  return(list(Y = Y, X = x))
}
#-------------------------------------------------->
# This function is called to cross-validate a cluspar1 model


ifn <- function(i){
  j <- ceiling(i/(k-1))
  clus[j] = setdiff(uniClus,clus[j])[i-((j-1)*(k-1))]
  return(clus)
}

#=========================================================================================>
# Function for parameter/covariate clustering regression
# Arguments:
# X - design matrix, Y - dependent variable, k - number of clusters
# method - method for initial assignment of clusters: "kmeans", "fkmeans" are supported
# return - clus - vector of cluster assignments of covariates

cluspar2<- function(X,Y,k,model="lm",method="corpars",pars.o=NULL,...){
  #Preliminaries
  nrX <- nrow(X) #number of rows of X
  ncX <- ncol(X) #number of columns of X
  
  if(is.null(pars.o)){
    clus <- iniclus1(X=X,Y=Y,k=k,method=method,model=model,...)
  }else{
    clus<-iniclus1(X,Y=NULL,k,method="corpars",model=model,pars.o=pars.o,...)
  }
  uniClus <- unique(clus)
  X1 <- matrix(NA,nrX,k)
  for(j in uniClus) X1[,j] <- apply(as.matrix(X[,(which(clus == j))]),1,sum)
  model1 <-ch.model(Y,X1,model = model,...)# lm(Y~X1)
  fval_o<- -logLik(model1)#sum(model1$residuals^2)
  lmc1 <- (k-1)*ncX #number of single-shift permutations
  dmod<- c(0)       # index 
  
  
  #create matrix of one-shift permutation clusterings
  iter=0; optfval=0 #initialise counter and optimal fval
  while(optfval<fval_o){
    iter=iter+1;  
    IDj<- rep(NA,ncX) # index
    if(iter>1){fval_o<- optfval;
    if(!j%in%dmod){clus[opj] = setdiff(uniClus,clus[opj])[optcl-((opj-1)*(k-1))]}
    }
    
    # clus<- clus1[optcl,]
    # clus1 <- matrix(rep(clus,lmc1) ,ncol=ncX,byrow=T) 
    # for(j in 1:ncX){ 
    #   
    #   if(!j%in%dmod){
    #     clus1[c(((k-1)*(j-1)+1):(j*(k-1))),j] <- setdiff(uniClus,clus[j])  
    #   }else{
    #     clus1[c(((k-1)*(j-1)+1):(j*(k-1))),j] <- clus[j]
    #     IDj[c(((k-1)*(j-1)+1):(j*(k-1)))]<- 1 #index rows in clus1 not to run
    #   }
    # }
    # nrI<- which(IDj==1)
    #-------------------------------------------------->
    vfun<- function(i){
      j <- ceiling(i/(k-1))
      if(!j%in%dmod){
      klus=clus
      klus[j] = setdiff(uniClus,clus[j])[i-((j-1)*(k-1))]
      for(h in uniClus) X1[,h] <- apply(as.matrix(X[,(which(klus == h))]),1,sum)
      model1 <-ch.model(Y,X1,model = model,...)
      val<- -logLik(model1)
      }else{
      val=Inf # skip strictly dominated models
      }
      return(val)
    }
    
    # if(lmc1<20000){
    #   vfval<- sapply(1:lmc1, vfun)
    # }else{
    #   vfval<- unlist(bayesdistreg::parLply(1:lmc1,fn=vfun,type = "FORK"))
    # }
    vfval<- sapply(1:lmc1, vfun)
    
    #-------------------------------------------------->
    optcl<- which.min(vfval) #optimal model at this node
    opj <- ceiling(optcl/(k-1))
    
    optfval<- vfval[optcl]
    dmod<- c(dmod,optcl)
    
  }
  
  AIC= 2*(fval_o + (k+1))
  BIC= 2*fval_o + (log(nrX)*(k+1))
  
  list(clus=clus,fval=fval_o,AIC=AIC,BIC=BIC,iter=iter)
}



#-------------------------------------------------->


cv.model<- function(clus,Y,X,model,cost=NULL,K=10,...){
  nrX = nrow(X)
  uniClus<- unique(clus)
  X1 <- matrix(NA,nrX,length(uniClus))
  for(j in uniClus) X1[,j] <- apply(as.matrix(X[,(which(clus == j))]),1,sum)
  model1 <-ch.model(Y,X1,model = model,...)
  if(!is.null(cost)){
    set.seed(14)
    zg=boot::cv.glm(data = data.frame(Y,X),glmfit = model1,cost = cost,K=K)
  }else{
    set.seed(14)
    zg=boot::cv.glm(data = data.frame(Y,X),glmfit = model1,K=K)
  }
  zg$delta[2]
}

#-------------------------------------------------->

## Search for the k that minimizes the criterion
cluspark <- function(ko,X,Y,crit="BIC",model="lm",method="corpars",cost=NULL,K=10,...){
  k = ko
  clob<-cluspar1(X,Y,ko,model=model,method = method,...)
  clus1 = clob$clus
  p = length(clus1)
    if(crit!="CV"){
    idcrit=which(names(clob)==crit)#identify the criterion
    crit1 =clob[[idcrit]]  
    }else if(crit=="CV"){
      crit1 = cv.model(clus=clus1,Y,X,model=model,cost=cost,K=K,...)
    }else{
      stop(cat("Criterion",crit,"is not supported. Use BIC, AIC, or CV"))
    }
  crito = Inf
  cluso = c(0)
  while(crito > crit1 & k < (p-1)){
    k = k + 1
    crito = crit1
    cluso = clus1
   clob= cluspar1(X,Y,k,model=model,method = method,...)
   clus1 = clob$clus
   if(crit!="CV"){
     idcrit=which(names(clob)==crit)#identify the criterion
     crit1 =clob[[idcrit]]  
   }else if(crit=="CV"){
     crit1 = cv.model(clus=clus1,Y,X,model=model,cost=cost,K=K,...)
   }
  }
  
  return(list(k=(k-1),clus=cluso, crit = crito))
}



#-------------------------------------------------->

estimates <- function(ko,X,Y,crit="BIC",model,method,cost=NULL,K=10,...){
  nrX <- dim(X)[1]
  clob <- cluspark(ko,X,Y,crit = crit,model=model,method = method,cost=cost,K=K,...)
  clus <- clob$clus
  crit <- clob$crit
  k=clob$k
  uniClus<- unique(clus)
  X1 <- matrix(NA,nrX,length(uniClus))
  for(j in uniClus) X1[,j] <- apply(as.matrix(X[,(which(clus == j))]),1,sum)
  model1 <-ch.model(Y,X1,model = model,...)# lm(Y~X1)
  deltas <- coef(model1)
  fval_o = -logLik(model1)
  return(list(param=deltas,clus=clus, crit = crit,k=k,fval=fval_o,modobj= model1))
}

# fnbl<- function(q) {cluspar1(lgdat$X,lgdat$Y,k=q,model = "logit")}
# (X,Y,k,model="lm",method="corpars",...)
cluscov<- function(interval,X,Y,crit="BIC",model="lm",tol=1,method="corpars",cost=NULL,K=10,...){
  nrX <- dim(X)[1]
  # provide corpars vector of pars
  pars.o=iniclus1(X=X,Y=Y,k=min(interval),method="corpars",model=model,pars=TRUE,...)$pars
  # cluspar1(X=X,Y=Y,k=min(interval),model="lm",method="corpars",pars.o=NULL,...)
  fnbl<- function(q) {cluspar1(X,Y,k=q,model = model,method=method,pars.o=pars.o,...)}
  clob<- goldopt(fn=fnbl,interval = interval,tol = tol)
  clus<- clob$fobj$clus
  crit <- clob$crit
  k=clob$k
  uniClus<- unique(clus)
  X1 <- matrix(NA,nrX,length(uniClus))
  for(j in uniClus) X1[,j] <- apply(as.matrix(X[,(which(clus == j))]),1,sum)
  model1 <-ch.model(Y,X1,model = model,...)# lm(Y~X1)
  deltas <- coef(model1)
  fval_o = -logLik(model1)
  return(list(param=deltas,clus=clus, crit = crit,k=k,fval=fval_o,modobj= model1))
}

cluscov2<- function(interval,X,Y,crit="BIC",model="lm",tol=1,method="corpars",cost=NULL,K=10,...){
  nrX <- dim(X)[1]
  # provide corpars vector of pars
  pars.o=iniclus1(X=X,Y=Y,k=min(interval),method="corpars",model=model,pars=TRUE,...)$pars
  # cluspar1(X=X,Y=Y,k=min(interval),model="lm",method="corpars",pars.o=NULL,...)
  fnbl<- function(q) {cluspar2(X,Y,k=q,model = model,method=method,pars.o=pars.o,...)}
  clob<- goldopt(fn=fnbl,interval = interval,tol = tol)
  clus<- clob$fobj$clus
  crit <- clob$crit
  k=clob$k
  uniClus<- unique(clus)
  X1 <- matrix(NA,nrX,length(uniClus))
  for(j in uniClus) X1[,j] <- apply(as.matrix(X[,(which(clus == j))]),1,sum)
  model1 <-ch.model(Y,X1,model = model,...)# lm(Y~X1)
  deltas <- coef(model1)
  fval_o = -logLik(model1)
  return(list(param=deltas,clus=clus, crit = crit,k=k,fval=fval_o,modobj= model1))
}

#===================================================================================>
# fn - function to be minimised
# interval - plausible lower and upper bounds on input
# tol - tolerance in the input at convergence

# Golden Search Algorithm for the outer loop ()
goldopt<- function(fn,interval,tol=1){
  a=min(interval); b = max(interval); key=0
  xvals<- c(0); xvals[1]<- a; xvals[2]<- b
  fvals<- c(0)
  faobj<-fn(a); fa = faobj$BIC; fbobj<-fn(b); fb = fbobj$BIC; 
  fvals[1]<- fa; fvals[2]<- fb
  cnt=2; # set counter to 2 for function evaluations
  phi<- (1+sqrt(5))/2
  
  c = ceiling(b - (b-a)/phi); d = floor(a + (b-a)/phi); 
  if(any(xvals==c)){
    c=xvals[which(xvals==c)]; fc=fvals[which(xvals==c)]
    warning("Function object may not correspond to optimal number of clusters")
    key=1
  }else{
    cnt=cnt+1
    fcobj<- fn(c); fc=fcobj$BIC  
  }
  if(any(xvals==d)){
    d=xvals[which(xvals==d)]; fd=fvals[which(xvals==d)]; 
    warning("Function object may not correspond to optimal number of clusters")
    key=1
  }else{
    cnt=cnt+1
    fdobj<- fn(d); fd=fdobj$BIC  
  }
  
  
  l = 1; # set counter for iterations
  cat("iter = ",l,"\n");arreter = 0
  while(abs(c-d)>tol & arreter==0){# while c d
    if(fc<fd){
      b=d; fb=fd; fbobj=fdobj
      d=c;fd=fc; fdobj=fcobj
      c = ceiling(b-(b-a)/phi); 
      if(any(xvals==c)){
        c=xvals[which(xvals==c)]; fc=fvals[which(xvals==c)]
        warning("Function object may not correspond to optimal number of clusters")
        key=1
      }else{
        cnt=cnt+1
        fcobj<- fn(c); fc=fcobj$BIC  
      }
      
    }else if(fc>fd){
      a=c; fa = fc; faobj=fcobj;
      c=d; fc=fd; fcobj = fdobj
      d = floor(a + (b-a)/phi); 
      if(any(xvals==d)){
        d=xvals[which(xvals==d)]; fd=fvals[which(xvals==d)]
        warning("Function object may not correspond to optimal number of clusters")
        key=1
      }else{
        cnt=cnt+1
        fdobj<- fn(d); fd=fdobj$BIC  
      }
    }else{
      arreter=1
    }
    l=l+1; cat("iter = ",l,"\n")
  }
  
  optx=ifelse(fc>fd,d,c); 
  if(fc>fd){
    fobj=fdobj
  }else{
    fobj=fcobj
  }
  res=list(k=optx,crit=min(fd,fc),iter=l,iterfn=cnt,fobj=fobj,key=key)
  return(res)
}


