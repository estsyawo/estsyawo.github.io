/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * CCRls_initialize.h
 *
 * Code generation for function 'CCRls_initialize'
 *
 */

#ifndef CCRLS_INITIALIZE_H
#define CCRLS_INITIALIZE_H

/* Include files */
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "tmwtypes.h"
#include "mex.h"
#include "emlrt.h"
#include "rtwtypes.h"
#include "CCRls_types.h"

/* Function Declarations */
extern void CCRls_initialize(void);

#endif

/* End of code generation (CCRls_initialize.h) */
