/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * CCRl_clus_initialize.c
 *
 * Code generation for function 'CCRl_clus_initialize'
 *
 */

/* Include files */
#include "rt_nonfinite.h"
#include "CCRl_clus.h"
#include "CCRl_clus_initialize.h"
#include "eml_rand_mt19937ar_stateful.h"
#include "_coder_CCRl_clus_mex.h"
#include "CCRl_clus_data.h"

/* Function Declarations */
static void CCRl_clus_once(void);

/* Function Definitions */
static void CCRl_clus_once(void)
{
  c_eml_rand_mt19937ar_stateful_i();
}

void CCRl_clus_initialize(void)
{
  mexFunctionCreateRootTLS();
  emlrtClearAllocCountR2012b(emlrtRootTLSGlobal, false, 0U, 0);
  emlrtEnterRtStackR2012b(emlrtRootTLSGlobal);
  emlrtLicenseCheckR2012b(emlrtRootTLSGlobal, "Statistics_Toolbox", 2);
  if (emlrtFirstTimeR2012b(emlrtRootTLSGlobal)) {
    CCRl_clus_once();
  }
}

/* End of code generation (CCRl_clus_initialize.c) */
