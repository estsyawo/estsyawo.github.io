/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * CCRls2_terminate.c
 *
 * Code generation for function 'CCRls2_terminate'
 *
 */

/* Include files */
#include "rt_nonfinite.h"
#include "CCRls2.h"
#include "CCRls2_terminate.h"
#include "_coder_CCRls2_mex.h"
#include "CCRls2_data.h"

/* Function Definitions */
void CCRls2_atexit(void)
{
  mexFunctionCreateRootTLS();
  emlrtEnterRtStackR2012b(emlrtRootTLSGlobal);
  emlrtProfilerUnregisterMEXFcn(CCRls2_complete_name, isMexOutdated);
  emlrtLeaveRtStackR2012b(emlrtRootTLSGlobal);
  emlrtDestroyRootTLS(&emlrtRootTLSGlobal);
}

void CCRls2_terminate(void)
{
  emlrtLeaveRtStackR2012b(emlrtRootTLSGlobal);
  emlrtDestroyRootTLS(&emlrtRootTLSGlobal);
}

/* End of code generation (CCRls2_terminate.c) */
