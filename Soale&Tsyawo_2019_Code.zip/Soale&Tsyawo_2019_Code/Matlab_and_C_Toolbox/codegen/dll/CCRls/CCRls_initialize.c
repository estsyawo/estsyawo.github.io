/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 * File: CCRls_initialize.c
 *
 * MATLAB Coder version            : 4.1
 * C/C++ source code generated on  : 22-Nov-2018 23:51:16
 */

/* Include Files */
#include "CCRls.h"
#include "CCRls_initialize.h"

/* Function Definitions */

/*
 * Arguments    : void
 * Return Type  : void
 */
void CCRls_initialize(void)
{
}

/*
 * File trailer for CCRls_initialize.c
 *
 * [EOF]
 */
