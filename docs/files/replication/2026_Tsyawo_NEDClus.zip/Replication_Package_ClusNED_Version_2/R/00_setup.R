#=====================================================
# Simulation setup library
# Purpose:
#   Prepare the shared simulation environment used by the manuscript-facing Monte
#   Carlo scripts in R/. This includes package loading, discovery of the
#   simulation root, compilation of the C++ helpers, output-directory helpers,
#   and lightweight parallel-cluster utilities.
# Inputs:
#   None when sourced.
# Outputs:
#   Functions and objects in the current R session, including sim_root and the
#   compiled Rcpp exports from src/cluster_gini.cpp and src/rank_correlation.cpp.
# Side effects:
#   Installs missing R packages, compiles C++ files, creates output/ on demand,
#   and prints setup progress.
#=====================================================

# Downstream note:
#   Every live simulation runner sources this file before launching either
#   Monte Carlo arm.

needed <- c("Rcpp", "pbapply", "sandwich")
to_install <- needed[!(needed %in% rownames(installed.packages()))]
if (length(to_install) > 0) install.packages(to_install, repos = "https://cloud.r-project.org")

library(Rcpp)
library(pbapply)
library(sandwich)

#=====================================================
# Parallel helpers
#=====================================================

# Purpose:
#   Choose the default worker count for simulation runs.
# Inputs:
#   None.
# Outputs:
#   Integer scalar: either 1L or about 75% of detected cores.
# Side effects:
#   None.
default_sim_cl <- function() {
  cores <- parallel::detectCores()
  if (is.na(cores) || cores < 1L) return(1L)
  max(1L, ceiling(cores * 0.75))
}

# Purpose:
#   Create the default PSOCK cluster, unless the recommended worker count is 1.
# Inputs:
#   None.
# Outputs:
#   Either integer 1L or a parallel cluster object.
# Side effects:
#   May launch parallel workers.
make_default_sim_cluster <- function() {
  n_workers <- default_sim_cl()
  if (n_workers <= 1L) return(1L)
  parallel::makeCluster(n_workers)
}

# Purpose:
#   Provide a compact human-readable label for a cluster setting.
# Inputs:
#   cl : either integer 1L or a parallel cluster object.
# Outputs:
#   Character scalar used in console progress messages.
# Side effects:
#   None.
sim_cl_label <- function(cl) {
  if (inherits(cl, "cluster")) return(sprintf("PSOCK(%d)", length(cl)))
  as.character(cl)
}

# Purpose:
#   Prepare a PSOCK cluster so worker sessions have the same packages, compiled
#   C++ exports, and R-level helper functions as the calling session.
# Inputs:
#   cl : either integer 1L or a parallel cluster object.
#   exports : character vector naming R objects that workers need.
# Outputs:
#   Invisible NULL.
# Side effects:
#   Loads packages and sources C++ on worker processes; exports selected R
#   objects to workers.
prepare_sim_cluster <- function(cl, exports) {
  if (!inherits(cl, "cluster")) return(invisible(NULL))
  parallel::clusterExport(cl, "sim_root", envir = .GlobalEnv)
  parallel::clusterEvalQ(cl, {
    library(Rcpp)
    library(pbapply)
    library(sandwich)
    if (!exists(".sim_cpp_loaded", envir = .GlobalEnv, inherits = FALSE)) {
      Rcpp::sourceCpp(file.path(sim_root, "src", "cluster_gini.cpp"))
      Rcpp::sourceCpp(file.path(sim_root, "src", "rank_correlation.cpp"))
      assign(".sim_cpp_loaded", TRUE, envir = .GlobalEnv)
    }
    NULL
  })
  rcpp_exports <- c(
    "cluster_gini_stat_cpp",
    "ustat_naive_cpp",
    "leave_one_out_projections_cpp",
    "kendall_u2_projection_cpp",
    "spearman_u3_projection_cpp"
  )
  parallel::clusterExport(cl, setdiff(exports, rcpp_exports), envir = .GlobalEnv)
  invisible(NULL)
}

#=====================================================
# Summary helpers
#=====================================================

# Purpose:
#   Compute two-sided rejection frequencies at the 1%, 5%, and 10% levels from
#   a vector of Monte Carlo t-statistics.
# Inputs:
#   tstat : numeric vector.
# Outputs:
#   Named numeric vector with entries reject_1pct, reject_5pct, reject_10pct.
# Side effects:
#   None.
summarise_t_rejections <- function(tstat) {
  c(
    reject_1pct = mean(abs(tstat) > qnorm(0.995), na.rm = TRUE),
    reject_5pct = mean(abs(tstat) > qnorm(0.975), na.rm = TRUE),
    reject_10pct = mean(abs(tstat) > qnorm(0.95), na.rm = TRUE)
  )
}

# Purpose:
#   Compute the unscaled Monte Carlo median absolute deviation.
# Inputs:
#   x : numeric vector.
# Outputs:
#   Numeric scalar.
# Side effects:
#   None.
monte_carlo_mad <- function(x) {
  stats::mad(x, center = stats::median(x, na.rm = TRUE), constant = 1, na.rm = TRUE)
}

#=====================================================
# Output helpers
#=====================================================

# Purpose:
#   Create and return the canonical simulation output directory.
# Inputs:
#   None.
# Outputs:
#   Character scalar giving the absolute path to output/.
# Side effects:
#   Creates the directory if it does not already exist.
sim_output_dir <- function() {
  out_dir <- file.path(sim_root, "output")
  if (!dir.exists(out_dir)) dir.create(out_dir, recursive = TRUE)
  out_dir
}

# Purpose:
#   Write a one-row Monte Carlo summary CSV when an output prefix is supplied.
# Inputs:
#   output_prefix : character scalar or NULL.
#   results : retained for interface symmetry; not written directly here.
#   summary : named vector or list coercible to a one-row data frame.
# Outputs:
#   Invisible list naming the written summary file, or NULL if output_prefix is NULL.
# Side effects:
#   Writes a CSV file and prints its path.
write_sim_outputs <- function(output_prefix, results, summary) {
  if (is.null(output_prefix)) return(invisible(NULL))

  out_dir <- sim_output_dir()
  summary_file <- file.path(out_dir, paste0(output_prefix, "_summary.csv"))

  write.csv(data.frame(t(summary), check.names = FALSE), summary_file, row.names = FALSE)

  message("Wrote simulation summary:")
  message("  ", summary_file)

  invisible(list(summary = summary_file))
}

# Purpose:
#   Write a manuscript-facing simulation table or summary-grid CSV.
# Inputs:
#   output_prefix : character scalar or NULL.
#   table : data frame to be written.
# Outputs:
#   Invisible list naming the written table file, or NULL if output_prefix is NULL.
# Side effects:
#   Writes a CSV file and prints its path.
write_sim_table <- function(output_prefix, table) {
  if (is.null(output_prefix)) return(invisible(NULL))

  out_dir <- sim_output_dir()
  table_file <- file.path(out_dir, paste0(output_prefix, ".csv"))
  write.csv(table, table_file, row.names = FALSE)

  message("Wrote simulation table:")
  message("  ", table_file)

  invisible(list(table = table_file))
}

#=====================================================
# Root discovery and C++ compilation
#=====================================================

sim_root <- tryCatch(
  dirname(dirname(rstudioapi::getActiveDocumentContext()$path)),
  error = function(e) NULL
)
if (is.null(sim_root) || !dir.exists(file.path(sim_root, "src"))) {
  sim_root <- normalizePath(file.path(getwd(), ".."), mustWork = FALSE)
  if (!dir.exists(file.path(sim_root, "src"))) {
    sim_root <- normalizePath(file.path(getwd(), "..", ".."), mustWork = FALSE)
  }
  if (!dir.exists(file.path(sim_root, "src"))) sim_root <- getwd()
}

message("Compiling src/cluster_gini.cpp ...")
sourceCpp(file.path(sim_root, "src", "cluster_gini.cpp"))

message("Compiling src/rank_correlation.cpp ...")
sourceCpp(file.path(sim_root, "src", "rank_correlation.cpp"))

message("Setup complete.")
