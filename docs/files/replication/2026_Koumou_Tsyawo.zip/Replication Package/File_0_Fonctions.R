#=======================================================================================>
# Purpose:
#   Estimate the average treatment effect on the treated (ATT) with the paper's
#   DiD estimator under several time-series specifications.
# Inputs:
#   Y1, Y0: Numeric outcome series for treated and untreated units.
#   var.time: Time index aligned with Y1 and Y0.
#   time.treat: Treatment period(s); those observations are excluded from estimation.
#   t.X: Model specification ("Level", "Diff", "Lag", "MA", or "Trend").
#   se.type: Standard-error estimator ("NW" or "HC").
#   transf: Optional transformation applied elementwise to Y1 and Y0.
#   weight: Optional weights used in weighted ATT regressions.
#   q: MA order used when t.X == "MA".
# Output:
#   A list with the ATT estimate, standard error, test statistics, diagnostics,
#   fitted model object, and covariance matrix.
ATT.fun<-function(Y1,Y0,var.time,time.treat,t.X="Level",se.type="NW"
                  ,transf=NULL,weight=NULL,q=0){
  
  if(!is.null(transf)){Y1=transf(Y1); Y0=transf(Y0)}
  
  id.post = which(var.time>max(time.treat))
  id.pre = which(var.time<min(time.treat))
  ids = c(id.post,id.pre)
  
  
  
  if(t.X=="Level"){
    X10 = Y1-Y0
    t.dum<- var.time>max(time.treat)*1
    
    if(is.null(weight)){
      reg.Obj=lm(X10[ids] ~ t.dum[ids], x=T,y=T)
    }else{
      reg.Obj=lm(I(X10[ids]*weight) ~ I(t.dum[ids]*weight), x=T,y=T)
    }
    #diagnostics:
    # Dickey-Fuller Test of non-stationarity
    ADF.test=adf.test(na.omit(X10[ids]))
    #Kwiatkowski-Phillips-Schmidt-Shin (KPSS) for level or trend stationarity
    KPSS.test=kpss.test(na.omit(X10[ids]),null="Trend")
    # Durbin-Watson test for two-sided autoccorrelation
    DW.test=dwtest(reg.Obj,alternative = "two.sided")
    
    est.ATT=reg.Obj$coefficients[2] 
    if(se.type=="NW"){
      mat.vcov = vcovHAC(reg.Obj)
      se.ATT=sqrt(c(mat.vcov[2,2]))
    }else if(se.type=="HC"){
      mat.vcov = vcovHC(reg.Obj)
      se.ATT=sqrt(c(mat.vcov[2,2]))
    }
    
  }else if(t.X=="Diff"){
    X10.post<- diff((Y1-Y0)[id.post])
    X10.pre<- diff((Y1-Y0)[id.pre])
    X10 = c(X10.post,X10.pre)
    t.dum<- rep(0,length(X10))
    t.dum[1:length(X10.post)]<- 1
    
    if(is.null(weight)){
      reg.Obj=lm(X10 ~ t.dum, x=T,y=T)
    }else{
      reg.Obj=lm(I(X10*weight) ~ I(t.dum*weight), x=T,y=T)
    }
    ids = 1:length(t.dum)
    #diagnostics:
    # Dickey-Fuller Test of non-stationarity
    ADF.test=adf.test(na.omit(X10[ids]))
    #Kwiatkowski-Phillips-Schmidt-Shin (KPSS) for level or trend stationarity
    KPSS.test=kpss.test(na.omit(X10[ids]),null="Trend")
    # Durbin-Watson test for two-sided autoccorrelation
    DW.test=dwtest(reg.Obj,alternative = "two.sided")
    
    est.ATT=reg.Obj$coefficients[2] 
    if(se.type=="NW"){
      mat.vcov = vcovHAC(reg.Obj)
      se.ATT=sqrt(c(mat.vcov[2,2]))
    }else if(se.type=="HC"){
      mat.vcov = vcovHC(reg.Obj)
      se.ATT=sqrt(c(mat.vcov[2,2]))
    }
    
  }else if(t.X=="Lag"){
    X10 = Y1-Y0
    T.post = length(id.post); T.pre = length(id.pre)
    t.dum<- var.time>max(time.treat)*1
    idz = c(id.post[-T.post],id.pre[-T.pre])
    ids = c(id.post[-1],id.pre[-1])
    
    if(is.null(weight)){
      reg.Obj=lm(X10[ids] ~ t.dum[ids] + X10[idz], x=T,y=T)
    }else{
      reg.Obj=lm(I(X10[ids]*weight) ~ I(t.dum[ids]*weight) + I(X10[idz]*weight), x=T,y=T)
    }
    
    #diagnostics:
    # Dickey-Fuller Test of non-stationarity
    ADF.test=adf.test(na.omit(reg.Obj$residuals))
    #Kwiatkowski-Phillips-Schmidt-Shin (KPSS) for level or trend stationarity
    KPSS.test=kpss.test(na.omit(reg.Obj$residuals),null="Trend")
    # Durbin-Watson test for two-sided autoccorrelation
    DW.test=dwtest(reg.Obj,alternative = "two.sided")
    
    est.ATT=reg.Obj$coefficients[2] 
    if(se.type=="NW"){
      mat.vcov = vcovHAC(reg.Obj)
      se.ATT=sqrt(c(mat.vcov[2,2]))
    }else if(se.type=="HC"){
      mat.vcov = vcovHC(reg.Obj)
      se.ATT=sqrt(c(mat.vcov[2,2]))
    }
    
  }else if(t.X=="MA"){
    
    X10 = Y1-Y0
    t.dum<- var.time>max(time.treat)*1
    
    if(is.null(weight)){
      reg.Obj=estimate_maq_robust(X10[ids], t.dum[ids], q = q, method = c("ML","REML"))
    }else{
      reg.Obj=estimate_maq_robust(I(X10[ids]*weight), I(t.dum[ids]*weight), q = q, method = c("ML","REML"))
    }
    
    #diagnostics:
    # Dickey-Fuller Test of non-stationarity
    ADF.test=adf.test(na.omit(reg.Obj$fit$residuals))
    #Kwiatkowski-Phillips-Schmidt-Shin (KPSS) for level or trend stationarity
    KPSS.test=kpss.test(na.omit(reg.Obj$fit$residuals),null="Trend")
    # Ljung-Box test for two-sided autoccorrelation
    m <- min(10, floor(length(na.omit(reg.Obj$fit$residuals)) / 5))  # rule-of-thumb lag choice
    
    DW.test=list()
    DW.test[[1]]<- "The Ljung-Box applies in this case instead."
    DW.test[[2]]<- Box.test(resid(reg.Obj$fit,type="normalized"),lag=m,type = "Ljung-Box",fitdf=1)
    
    est.ATT=reg.Obj$fit$coefficients[2] 
    se.ATT=reg.Obj$se_robust[2]
    mat.vcov=reg.Obj$vcov_robust
    
  }else if(t.X=="Trend"){
    X10 = Y1-Y0
    t.dum<- var.time>max(time.treat)*1
    
    n = length(ids)
    trnd = var.time
    trnd[var.time<0] = var.time[var.time<0] + abs(min(var.time)) + 1
    trnd[var.time>0] = var.time[var.time>0] + abs(min(var.time))
    trnd = trnd/n #scaling time trend by n
    
    
    if(is.null(weight)){
      reg.Obj=lm(X10[ids] ~ t.dum[ids] + trnd[ids], x=T,y=T)
    }else{
      reg.Obj=lm(I(X10[ids]*weight) ~ I(t.dum[ids]*weight) + I(trnd[ids]*weight), x=T,y=T)
    }
    
    #diagnostics:
    # Dickey-Fuller Test of non-stationarity
    ADF.test=adf.test(na.omit(X10[ids]))
    #Kwiatkowski-Phillips-Schmidt-Shin (KPSS) for level or trend stationarity
    KPSS.test=kpss.test(na.omit(X10[ids]),null="Trend")
    # Durbin-Watson test for two-sided autoccorrelation
    DW.test=dwtest(reg.Obj,alternative = "two.sided")
    
    est.ATT=reg.Obj$coefficients[2] 
    if(se.type=="NW"){
      mat.vcov = vcovHAC(reg.Obj)
      se.ATT=sqrt(c(mat.vcov[2,2]))
    }else if(se.type=="HC"){
      mat.vcov = vcovHC(reg.Obj)
      se.ATT=sqrt(c(mat.vcov[2,2]))
    }
  }
  
  
  pval.ATT = 2*pnorm(-abs(est.ATT/se.ATT))
  
  list(est.ATT=est.ATT, se.ATT=se.ATT, t.stat=est.ATT/se.ATT,
       pval.ATT=pval.ATT, ADF.test=ADF.test, KPSS.test=KPSS.test,
       DW.test=DW.test,reg.Obj=reg.Obj,mat.vcov=mat.vcov)
}
#=======================================================================================>

#=======================================================================================>
# Purpose:
#   Estimate the ATT using the synthetic-control benchmark without an intercept,
#   which reduces to a post-treatment mean comparison in this two-unit setting.
# Inputs:
#   Y1, Y0: Numeric outcome series for treated and untreated units.
#   var.time: Time index aligned with Y1 and Y0.
#   time.treat: Treatment period(s); those observations are excluded from estimation.
#   t.X: Model specification ("Level", "Diff", "Lag", "MA", or "Trend").
#   se.type: Standard-error estimator ("NW" or "HC").
#   transf: Optional transformation applied elementwise to Y1 and Y0.
# Output:
#   A list with the ATT estimate, standard error, test statistics, diagnostics,
#   and fitted regression object.
SC.fun<- function(Y1,Y0,var.time,time.treat,t.X="Level",se.type="NW",transf=NULL){
  
  if(!is.null(transf)){Y1=transf(Y1); Y0=transf(Y0)}
  
  ids = which(var.time>max(time.treat))
  X10 = Y1-Y0
  
  if(t.X %in% c("Level","MA")){
    reg.Obj=lm(X10[ids] ~ 1, x=T,y=T)
    #diagnostics:
    # Dickey-Fuller Test of non-stationarity
    ADF.test=adf.test(na.omit(X10[ids]))
    #Kwiatkowski-Phillips-Schmidt-Shin (KPSS) for level or trend stationarity
    KPSS.test=kpss.test(na.omit(X10[ids]),null="Trend")
    # Durbin-Watson test for two-sided autoccorrelation
    DW.test=dwtest(reg.Obj,alternative = "two.sided")
  }else if(t.X=="Diff"){
    X10 = diff(X10[ids])
    reg.Obj = lm(X10 ~ 1, x=T,y=T)
    #diagnostics:
    # Dickey-Fuller Test of non-stationarity
    ADF.test=adf.test(na.omit(X10))
    #Kwiatkowski-Phillips-Schmidt-Shin (KPSS) for level or trend stationarity
    KPSS.test=kpss.test(na.omit(X10),null="Trend")
    # Durbin-Watson test for two-sided autoccorrelation
    DW.test=dwtest(reg.Obj,alternative = "two.sided")
  }else if(t.X=="Lag"){
    T.post = length(ids)
    
    idz = c(ids[-T.post])
    ids = c(ids[-1])
    reg.Obj=lm(X10[ids] ~ X10[idz], x=T,y=T)
    #diagnostics:
    # Dickey-Fuller Test of non-stationarity
    ADF.test=adf.test(na.omit(reg.Obj$residuals))
    #Kwiatkowski-Phillips-Schmidt-Shin (KPSS) for level or trend stationarity
    KPSS.test=kpss.test(na.omit(reg.Obj$residuals),null="Trend")
    # Durbin-Watson test for two-sided autoccorrelation
    DW.test=dwtest(reg.Obj,alternative = "two.sided")
  }else if(t.X=="Trend"){
    n = length(ids)
    trnd = var.time/n #scaling time trend by n
    reg.Obj=lm(X10[ids] ~ trnd[ids], x=T,y=T)
    #diagnostics:
    # Dickey-Fuller Test of non-stationarity
    ADF.test=adf.test(na.omit(X10[ids]))
    #Kwiatkowski-Phillips-Schmidt-Shin (KPSS) for level or trend stationarity
    KPSS.test=kpss.test(na.omit(X10[ids]),null="Trend")
    # Durbin-Watson test for two-sided autoccorrelation
    DW.test=dwtest(reg.Obj,alternative = "two.sided")
  }
  
  est.ATT=reg.Obj$coefficients[1] 
  if(se.type=="NW"){
    se.ATT=sqrt(c(vcovHAC(reg.Obj)[1,1]))
  }else if(se.type=="HC"){
    se.ATT=sqrt(c(vcovHC(reg.Obj)[1,1]))
  }
  t.stat=est.ATT/se.ATT
  pval.ATT = 2*pnorm(-abs(t.stat))
  
  list(est.ATT=est.ATT, se.ATT=se.ATT, t.stat=t.stat,
       pval.ATT=pval.ATT, ADF.test=ADF.test, KPSS.test=KPSS.test,
       DW.test=DW.test,reg.Obj=reg.Obj)
  
}
#=======================================================================================>

#=======================================================================================>
# Purpose:
#   Estimate the ATT with the before-after benchmark, using the treated unit's
#   own pre-treatment history as the control path.
# Inputs:
#   Y1: Numeric outcome series for the treated unit.
#   var.time: Time index aligned with Y1.
#   time.treat: Treatment period(s); those observations are excluded from estimation.
#   t.X: Model specification ("Level", "Diff", "Lag", "MA", or "Trend").
#   se.type: Standard-error estimator ("NW" or "HC").
#   transf: Optional transformation applied elementwise to Y1.
# Output:
#   A list with the ATT estimate, standard error, test statistics, diagnostics,
#   and fitted regression object.
BA.fun<- function(Y1,var.time,time.treat,t.X="Level",se.type="NW",transf=NULL){
  
  if(!is.null(transf)){Y1=transf(Y1)}
  
  id.post = which(var.time>max(time.treat))
  id.pre = which(var.time<min(time.treat))
  ids = c(id.post,id.pre)
  
  if(t.X %in% c("Level","MA")){
    t.dum<- var.time>max(time.treat)*1
    reg.Obj=lm(Y1[ids] ~ t.dum[ids], x=T,y=T)
    #diagnostics:
    # Dickey-Fuller Test of non-stationarity
    ADF.test=adf.test(na.omit(Y1[ids]))
    #Kwiatkowski-Phillips-Schmidt-Shin (KPSS) for level or trend stationarity
    KPSS.test=kpss.test(na.omit(Y1[ids]),null="Trend")
    # Durbin-Watson test for two-sided autoccorrelation
    DW.test=dwtest(reg.Obj,alternative = "two.sided")
  }else if(t.X=="Diff"){
    Y1.post<- diff(Y1[id.post])
    Y1.pre<- diff(Y1[id.pre])
    Y1 = c(Y1.post,Y1.pre)
    t.dum<- rep(0,length(Y1))
    t.dum[1:length(Y1.post)]<- 1
    reg.Obj=lm(Y1 ~ t.dum, x=T,y=T)
    ids = 1:length(t.dum)
    #diagnostics:
    # Dickey-Fuller Test of non-stationarity
    ADF.test=adf.test(na.omit(Y1[ids]))
    #Kwiatkowski-Phillips-Schmidt-Shin (KPSS) for level or trend stationarity
    KPSS.test=kpss.test(na.omit(Y1[ids]),null="Trend")
    # Durbin-Watson test for two-sided autoccorrelation
    DW.test=dwtest(reg.Obj,alternative = "two.sided")
  }else if(t.X=="Lag"){
    T.post = length(id.post); T.pre = length(id.pre)
    t.dum<- var.time>max(time.treat)*1
    idz = c(id.post[-T.post],id.pre[-T.pre])
    ids = c(id.post[-1],id.pre[-1])
    reg.Obj=lm(Y1[ids] ~ t.dum[ids] + Y1[idz], x=T,y=T)
    #diagnostics:
    # Dickey-Fuller Test of non-stationarity
    ADF.test=adf.test(na.omit(reg.Obj$residuals))
    #Kwiatkowski-Phillips-Schmidt-Shin (KPSS) for level or trend stationarity
    KPSS.test=kpss.test(na.omit(reg.Obj$residuals),null="Trend")
    # Durbin-Watson test for two-sided autoccorrelation
    DW.test=dwtest(reg.Obj,alternative = "two.sided")
  }else if(t.X=="Trend"){
    t.dum<- var.time>max(time.treat)*1
    
    n = length(ids)
    trnd = var.time
    trnd[var.time<0] = var.time[var.time<0] + abs(min(var.time)) + 1
    trnd[var.time>0] = var.time[var.time>0] + abs(min(var.time))
    trnd = trnd/n #scaling time trend by n
    
    reg.Obj=lm(Y1[ids] ~ t.dum[ids] + trnd[ids], x=T,y=T)
    #diagnostics:
    # Dickey-Fuller Test of non-stationarity
    ADF.test=adf.test(na.omit(Y1[ids]))
    #Kwiatkowski-Phillips-Schmidt-Shin (KPSS) for level or trend stationarity
    KPSS.test=kpss.test(na.omit(Y1[ids]),null="Trend")
    # Durbin-Watson test for two-sided autoccorrelation
    DW.test=dwtest(reg.Obj,alternative = "two.sided")
  }
  
  est.ATT=reg.Obj$coefficients[2] 
  if(se.type=="NW"){
    se.ATT=sqrt(c(vcovHAC(reg.Obj)[2,2]))
  }else if(se.type=="HC"){
    se.ATT=sqrt(c(vcovHC(reg.Obj)[2,2]))
  }
  t.stat=est.ATT/se.ATT
  pval.ATT = 2*pnorm(-abs(t.stat))
  
  list(est.ATT=est.ATT, se.ATT=se.ATT, t.stat=t.stat,
       pval.ATT=pval.ATT, ADF.test=ADF.test, KPSS.test=KPSS.test,
       DW.test=DW.test,reg.Obj=reg.Obj)
  
}
#=======================================================================================>


#===============================================================================
# Purpose:
#   Compute an HC0-style robust covariance matrix for an `nlme::gls` fit with a
#   correlation structure.
# Inputs:
#   fit: A `gls` model object.
# Output:
#   A robust covariance matrix for the GLS coefficient estimates.
vcovHC_gls <- function(fit) {
  stopifnot(inherits(fit, "gls"))
  X <- model.matrix(formula(fit), data = fit$data)
  e <- resid(fit, type = "response")
  
  # Correlation matrix from nlme (single group assumed)
  R <- corMatrix(fit$modelStruct$corStruct)
  if (is.list(R)) R <- R[[1L]]
  # If you used variance weights in gls(..., weights=...), you'd need to fold them in here.
  
  sig2 <- fit$sigma^2
  V <- sig2 * R
  
  # Solve V %*% z = y without explicitly inverting
  cholV <- chol(V)
  V_inv_y <- function(y) backsolve(cholV, forwardsolve(t(cholV), y))
  
  # Bread: (X' V^{-1} X)^{-1}
  XVinv <- apply(X, 2, V_inv_y)         # columns: V^{-1} x_j
  H <- crossprod(X, XVinv)              # X' V^{-1} X
  bread <- solve(H)
  
  # Meat: sum_t (x_t x_t' * (V^{-1} e)_t^2)
  u_star <- V_inv_y(e)                  # V^{-1} e (vector length T)
  ZX <- X * as.numeric(u_star)          # rowwise multiply by u_star
  meat <- crossprod(ZX)                 # X' diag(u_star^2) X
  
  # Sandwich
  vcov_rob <- bread %*% meat %*% bread
  vcov_rob
}
#-------------------------------------------------------------------------------
# Purpose:
#   Fit the MA(q) version of the ATT regression and attach robust inference.
# Inputs:
#   X: Outcome-difference series to regress.
#   post: Post-treatment indicator aligned with X.
#   q: Moving-average order.
#   method: GLS estimation method passed to `gls`.
# Output:
#   A list containing the fitted GLS model, coefficients, robust covariance
#   matrix, robust standard errors, and coefficient test output.
estimate_maq_robust <- function(X, post, q = 0, method = c("ML","REML")) {
  method <- match.arg(method)
  stopifnot(length(X) == length(post))
  dat <- data.frame(X = as.numeric(X), post = as.numeric(post))
  
  fit <- gls(X ~ post, data = dat, method = method,
             correlation = corARMA(p = 0, q = q), na.action = na.omit)
  
  Vrob <- vcovHC_gls(fit)
  se   <- sqrt(diag(Vrob))
  ct   <- coeftest(fit, vcov. = Vrob)   # robust tests (lmtest)
  
  list(fit = fit, coef = coef(fit), vcov_robust = Vrob, se_robust = se,
       coeftest_robust = ct)
}
#-------------------------------------------------------------------------------
# Purpose:
#   Compute the observation-level influence contributions for OLS slope estimates.
# Inputs:
#   lmreg: An `lm` regression object.
# Output:
#   A matrix whose rows are influence contributions for each observation.
influence_matrix_beta <- function(lmreg) {
  # Extract the design matrix X and residuals u
  X <- model.matrix(lmreg)
  u <- residuals(lmreg)
  
  # Calculate (X'X)^-1
  # Using solve(qr(X)) or chol2inv is more numerically stable than solve(t(X) %*% X)
  xtx_inv <- chol2inv(qr.R(lmreg$qr))
  
  # The influence terms are (u_i * x_i) %*% (X'X)^-1
  # We first scale the rows of X by the residuals
  # Then post-multiply by the inverse of the gram matrix
  M <- (X * u) %*% xtx_inv
  
  return(M)
}

# --- Verification ---
# lm_obj <- lm(mpg ~ wt + hp, data = mtcars)
# M <- influence_matrix_beta(lm_obj)
# V_robust_manual <- crossprod(M)
# 
# # Compare with sandwich package HC0
# # all.equal(V_robust_manual, sandwich::vcovHC(lm_obj, type = "HC0"))
#===============================================================================


#===============================================================================
# Purpose:
#   Run one Monte Carlo replication and collect bias and rejection indicators for
#   the DiD, SC, and BA estimators.
# Inputs:
#   l: Replication index.
#   datlist: List of simulated datasets.
#   ATT: True treatment effect used to compute bias.
#   t.X: Model specification passed to the estimators.
#   se.type: Standard-error estimator.
#   weight: Optional weights passed to `ATT.fun`.
#   q: MA order used when t.X == "MA".
# Output:
#   A named numeric vector with estimator bias and rejection indicators.
MC_Sim_Fun<- function(l,datlist,ATT,t.X="Level",se.type="NW",weight=NULL,q=1){
  donnees=datlist[[l]] #extract data
  
  #Compute proposed ATT
  DiD.Obj = ATT.fun(Y1=donnees$Y1,Y0=donnees$Y0,var.time = donnees$var.time,
          time.treat=0,t.X=t.X,se.type=se.type,transf=NULL,weight=weight,q=q)
  bias.ATT = DiD.Obj$est.ATT-mean(ATT) #bias in ATT
  Rej.ATT = 1*(DiD.Obj$pval.ATT<= c(0.01,0.05,0.1)) #for size control
  res.ATT=c(bias.ATT,Rej.ATT); names(res.ATT)<- c("Bias.DiD","DiD.Rej.01","DiD.Rej.05","DiD.Rej.10")
  
  #Compute Synthetic Control convex weights without intercept
  SC.Obj = SC.fun(Y1=donnees$Y1,Y0=donnees$Y0,var.time = donnees$var.time,
          time.treat = 0, t.X=t.X,se.type=se.type,transf=NULL)
  bias.SC = SC.Obj$est.ATT-mean(ATT) #bias in ATT
  Rej.SC = 1*(SC.Obj$pval.ATT<= c(0.01,0.05,0.1)) #for size control
  res.SC=c(bias.SC,Rej.SC); names(res.SC)<- c("Bias.SC","SC.Rej.01","SC.Rej.05","SC.Rej.10")
  
  #Before-After (BA) estimator
  BA.Obj = BA.fun(Y1=donnees$Y1,var.time = donnees$var.time,
         time.treat=0,t.X=t.X,se.type=se.type,transf=NULL)
  
  bias.BA = BA.Obj$est.ATT-mean(ATT) #bias in ATT
  Rej.BA = 1*(BA.Obj$pval.ATT<= c(0.01,0.05,0.1)) #for size control
  res.BA=c(bias.BA,Rej.BA); names(res.BA)<- c("Bias.BA","BA.Rej.01","BA.Rej.05","BA.Rej.10")
  
  #Concatenate results
  res=c(res.ATT,res.SC,res.BA)
  #return results
  res
}
#===============================================================================


#===============================================================================
# Purpose:
#   Run one Monte Carlo replication for the identification-test exercises and
#   record rejection indicators for direct and placebo-style pre-tests.
# Inputs:
#   l: Replication index.
#   datlist: List of simulated datasets.
#   ATT: True treatment effect.
#   t.X: Model specification passed to the estimators.
#   se.type: Standard-error estimator.
#   q: MA order used when t.X == "MA".
# Output:
#   A numeric vector of rejection indicators for all reported tests.
MC_Sim_idt<- function(l,datlist,ATT,t.X="Level",se.type="NW",q=0){
  donnees=datlist[[l]] #extract data
  
  #Compute power based on identification tests
  DiD.Obj = ATT.fun(Y1=donnees$Y1,Y0=donnees$Y0,var.time = donnees$var.time,
                    time.treat=0,t.X=t.X,se.type=se.type,transf=NULL,q=q)
  id.DiD = 1*(DiD.Obj$pval.ATT<= c(0.01,0.05,0.1)) #for size control
  
  #Compute Synthetic Control convex weights without intercept
  SC.Obj = SC.fun(Y1=donnees$Y1,Y0=donnees$Y0,var.time = donnees$var.time,
                  time.treat = 0, t.X=t.X,se.type=se.type,transf=NULL)
  id.SC = 1*(SC.Obj$pval.ATT<= c(0.01,0.05,0.1)) #for size control
  
  #Before-After (BA) estimator
  BA.Obj = BA.fun(Y1=donnees$Y1,var.time = donnees$var.time,
                  time.treat=0,t.X=t.X,se.type=se.type,transf=NULL)
  id.BA = 1*(BA.Obj$pval.ATT<= c(0.01,0.05,0.1)) #for size control
  
  #Compute power based on pre- tests
  id.pre = which(donnees$var.time<0)
  pt0<- donnees$var.time[ceiling(0.5*length(id.pre))]
  
  pt.DiD.Obj = ATT.fun(Y1=donnees$Y1[id.pre],Y0=donnees$Y0[id.pre],
                       var.time = donnees$var.time[id.pre],
                    time.treat=pt0,t.X=t.X,se.type=se.type,transf=NULL,q=q)
  pt.DiD = 1*(pt.DiD.Obj$pval.ATT<= c(0.01,0.05,0.1)) #for size control
  
  #Compute Synthetic Control convex weights without intercept
  pt.SC.Obj = SC.fun(Y1=donnees$Y1[id.pre],Y0=donnees$Y0[id.pre],
                     var.time = donnees$var.time[id.pre],
                  time.treat = pt0, t.X=t.X,se.type=se.type,transf=NULL)
  pt.SC = 1*(pt.SC.Obj$pval.ATT<= c(0.01,0.05,0.1)) #for size control
  
  #Before-After (BA) estimator
  pt.BA.Obj = BA.fun(Y1=donnees$Y1[id.pre],var.time = donnees$var.time[id.pre],
                  time.treat=pt0,t.X=t.X,se.type=se.type,transf=NULL)
  pt.BA = 1*(pt.BA.Obj$pval.ATT<= c(0.01,0.05,0.1)) #for size control
  
  #Concatenate results
  res=c(id.DiD,id.SC,id.BA,pt.DiD,pt.SC,pt.BA)
  #return results
  res
}
#===============================================================================


#===============================================================================
# Purpose:
#   Compute the root mean squared error of a numeric vector.
# Inputs:
#   X: Numeric vector.
# Output:
#   A single numeric RMSE value.
RMSE.f<- function(X) sqrt(mean(c(X)^2)) 
#===============================================================================


#===============================================================================
# Purpose:
#   Return the package output directory, creating it if needed.
# Inputs:
#   None.
# Output:
#   A character path to the `output/` folder under the working directory.
get_output_dir <- function() {
  out.dir <- file.path(getwd(), "output")
  if (!dir.exists(out.dir)) {
    dir.create(out.dir, recursive = TRUE)
  }
  out.dir
}
#===============================================================================


#===============================================================================
# Purpose:
#   Build a path inside the package output directory.
# Inputs:
#   filename: Output filename relative to `output/`.
# Output:
#   A character path pointing to the output file location.
output_path <- function(filename) {
  file.path(get_output_dir(), filename)
}
#===============================================================================


#===============================================================================
# Purpose:
#   Summarize Monte Carlo results into MB, MAD, RMSE, and rejection-rate blocks.
# Inputs:
#   MC_Res: Matrix of replication-level simulation results.
# Output:
#   A rounded numeric vector arranged for downstream reporting tables.
summary.ATT<- function(MC_Res){
  c1=c(1,5,9)
  MB = apply(MC_Res[c1,],1,mean); names(MB)<- c("DiD.MB","SC.MB","BA.MB")
  MAD = apply(abs(MC_Res[c1,]),1,median); names(MAD)<- c("DiD.MAD","SC.MAD","BA.MAD")
  RMSE = apply(MC_Res[c1,],1,RMSE.f); names(RMSE)<- c("DiD.RMSE","SC.RMSE","BA.RMSE")
  res=c(MB,MAD,RMSE,apply(MC_Res[-c1,],1,mean))
  #arrange results for reporting in LaTeX
  round(res,3)[c(1:9,10+(0:2)*3,11+(0:2)*3,12+(0:2)*3)]
}
#=======================================================================================>


#=======================================================================================>
# Purpose:
#   Aggregate simulation results across sample sizes and write the formatted table
#   of summary statistics to disk.
# Inputs:
#   MC_Res.list: List of Monte Carlo result matrices, one per sample size.
#   out.file: Output filename for the summary table.
#   n.vec: Sample sizes corresponding to the result list.
# Output:
#   A matrix combining sample sizes with summarized simulation statistics.
extract.res<- function(MC_Res.list,out.file,n.vec){
  res.all=NULL
  for (l in 1:length(MC_Res.list)) {
    res.all = rbind(res.all,summary.ATT(MC_Res.list[[l]]))
  }
  sink(output_path(out.file))
  cat("\n")
  cat("MB, MAD, RMSE: \n")
  cat("\n")
  apply(cbind(rep(" ",length(n.vec)),n.vec,res.all[,1:9]),1,print.fn)
  cat("\n")
  cat("Rejection Rates: \n")
  cat("\n")
  apply(cbind(rep(" ",length(n.vec)),n.vec,res.all[,10:18]),1,print.fn)
  sink()
  cbind(n.vec,res.all)
}
#=======================================================================================>


#=======================================================================================>
# Purpose:
#   Aggregate Monte Carlo power results across treatment-effect values.
# Inputs:
#   MC_Res.list: List of Monte Carlo result matrices, one per gamma value.
#   g.vec: Treatment-effect grid used in the simulations.
# Output:
#   A data frame with gamma and rejection frequencies for each estimator.
extract.pow<- function(MC_Res.list,g.vec){
  res.all=NULL
  for (l in 1:length(MC_Res.list)) {
    res.all = rbind(res.all,summary.ATT(MC_Res.list[[l]]))
  }
  res<- data.frame(g.vec,res.all[,10:18])
  names(res)<- c("gamma","DiD_01","SC_01","BA_01","DiD_05","SC_05","BA_05",
                 "DiD_10","SC_10","BA_10")
  res
}
#=======================================================================================>


#=======================================================================================>
# Purpose:
#   Run the baseline Monte Carlo design over a vector of sample sizes and save
#   the resulting summary table.
# Inputs:
#   out.file: Output filename for the summary table.
#   n.vec: Sample sizes to simulate.
#   R: Number of Monte Carlo replications.
#   ATT: Treatment effect used in data generation.
#   error.type, alph, phi, eta, nu.suff, lam.vec: Data-generating-process controls.
#   t.X, se.type, weight, q: Estimator specification controls.
#   cl: Parallel worker count passed to `pbsapply`.
# Output:
#   A matrix of summarized Monte Carlo results by sample size.
MC_DGP<- function(out.file,n.vec,R,ATT,error.type,alph,phi,eta,
                  t.X,se.type,nu.suff=F,lam.vec=NULL,weight=NULL,q=1,cl){
  #------------------------------>
  
  #------------------------------>
  # Simulate data and compute results
  MC_Res.list = list()
  for (l in 1:length(n.vec)) {
    #--------------->
    # generate data list
    if(is.null(lam.vec)){
      nT=nTau=n.vec[l]
    }else{
      n=2*n.vec[l]; nT = ceiling(lam.vec[l]*n); nTau = n-nT
    }
    
    donnees.liste = lapply(1:R,dat.gen,nT=nT,nTau=nTau,
                           ATT=ATT,error.type=error.type,
                         alph=alph,phi=phi,eta=eta,nu.suff=nu.suff)
    
    #test
    # MC_Sim_Fun(l=1,datlist=donnees.liste,ATT=ATT,t.X=t.X,se.type=se.type)
    # MC_Sim_Fun(l=1,datlist=donnees.liste,ATT,t.X=t.X,se.type="NW",weight=T,q=q)
    #--------------->
    
    MC_Res.list[[l]] = pbsapply(1:R, FUN=MC_Sim_Fun,cl=cl,datlist=donnees.liste,
                                ATT=ATT,t.X=t.X,se.type=se.type,weight=weight,q=q)
  }#end for (l in 1:length(n.vec))
  #------------------------------>
  
  #------------------------------>
  
  res.sim<- extract.res(MC_Res.list=MC_Res.list,out.file=out.file,n.vec=n.vec)
  res.sim
}
#=======================================================================================>


#=======================================================================================>
# Purpose:
#   Run the heterogeneous-treatment Monte Carlo design over a vector of sample
#   sizes and save the resulting summary table.
# Inputs:
#   out.file: Output filename for the summary table.
#   n.vec: Sample sizes to simulate.
#   R: Number of Monte Carlo replications.
#   error.type, alph, phi, eta, nu.suff: Data-generating-process controls.
#   t.X, se.type, q: Estimator specification controls.
#   cl: Parallel worker count passed to `pbsapply`.
# Output:
#   A matrix of summarized Monte Carlo results by sample size.
MC_DGPb<- function(out.file,n.vec,R,error.type,alph,phi,eta,
                  t.X,se.type,nu.suff=F,q=0,cl){
  #------------------------------>
  
  #------------------------------>
  # Simulate data and compute results
  MC_Res.list = list()
  for (l in 1:length(n.vec)) {
    #--------------->
    # generate data list
    ATT = sin(1:n.vec[l])/pi
    
    donnees.liste = lapply(1:R,dat.gen,nT=n.vec[l],nTau=n.vec[l],ATT=ATT,error.type=error.type,
                           alph=alph,phi=phi,eta=eta,nu.suff=nu.suff)
    
    #test
    # MC_Sim_Fun(l=1,datlist=donnees.liste,ATT=ATT,t.X=t.X,se.type=se.type)
    #--------------->
    
    MC_Res.list[[l]] = pbsapply(1:R, FUN=MC_Sim_Fun,cl=cl,datlist=donnees.liste,
                                ATT=ATT,t.X=t.X,se.type=se.type,q=q)
  }#end for (l in 1:length(n.vec))
  #------------------------------>
  
  #------------------------------>
  
  res.sim<- extract.res(MC_Res.list=MC_Res.list,out.file=out.file,n.vec=n.vec)
  res.sim
}
#=======================================================================================>


#=======================================================================================>
# Purpose:
#   Run the power-curve Monte Carlo design over a grid of treatment-effect values
#   and save the corresponding figures.
# Inputs:
#   out.file: Output filename stem for generated figures.
#   n: Sample size used in each replication.
#   g.vec: Grid of treatment-effect perturbations.
#   R: Number of Monte Carlo replications.
#   ATT: Baseline treatment effect.
#   error.type, alph, phi, eta, nu.suff: Data-generating-process controls.
#   t.X, se.type, q: Estimator specification controls.
#   cl: Parallel worker count passed to `pbsapply`.
# Output:
#   A data frame of rejection frequencies by treatment-effect value.
MC_DGP.pow<- function(out.file,n,g.vec,R,ATT,error.type,alph,phi,eta,
                  t.X,se.type,nu.suff=F,q=0,cl){
  #------------------------------>
  
  #------------------------------>
  # Simulate data and compute results
  MC_Res.list = list()
  for (l in 1:length(g.vec)) {
    #--------------->
    # generate data list
    
    donnees.liste = lapply(1:R,dat.gen,nT=n,nTau=n,ATT=(ATT+g.vec[l]),error.type=error.type,
                           alph=alph,phi=phi,eta=eta,nu.suff=nu.suff)
    
    #test
    # MC_Sim_Fun(l=1,datlist=donnees.liste,ATT=ATT,t.X=t.X,se.type=se.type)
    #--------------->
    
    MC_Res.list[[l]] = pbsapply(1:R, FUN=MC_Sim_Fun,cl=cl,datlist=donnees.liste,
                                ATT=ATT,t.X=t.X,se.type=se.type,q=q)
  }#end for (l in 1:length(g.vec))
  #------------------------------>
  
  #------------------------------>
  
  res.sim<- extract.pow(MC_Res.list=MC_Res.list,g.vec=g.vec)

  #------------------------------>
  
  #------------------------------>
  Label.tests = c("DiD_10"="DiD","SC_10"="SC","BA_10"="BA")
  x.lab = "ATT"
  y.lab = " "
  
  col.val_10 = c("DiD_10"="black","SC_10"="red","BA_10"="blue")
  line.val_10 = c("DiD_10"="solid","SC_10"=22,"BA_10"=42)
  shape.val_10 = c("DiD_10"=1,"SC_10"=2,"BA_10"=3)
  
  col.val_05 = c("DiD_05"="black","SC_05"="red","BA_05"="blue")
  line.val_05 = c("DiD_05"="solid","SC_05"=22,"BA_05"=42)
  shape.val_05 = c("DiD_05"=1,"SC_05"=2,"BA_05"=3)
  
  
  col.val_01 = c("DiD_01"="black","SC_01"="red","BA_01"="blue")
  line.val_01 = c("DiD_01"="solid","SC_01"=22,"BA_01"=42)
  shape.val_01 = c("DiD_01"=1,"SC_01"=2,"BA_01"=3)
  
  col.val=list();col.val[[1]]=col.val_10;col.val[[2]]=col.val_05;col.val[[3]]=col.val_01
  line.val=list();line.val[[1]]=line.val_10;line.val[[2]]=line.val_05;line.val[[3]]=line.val_01
  shape.val=list();shape.val[[1]]=shape.val_10;shape.val[[2]]=shape.val_05;shape.val[[3]]=shape.val_01
  
  plot.pow(filename=out.file,pow.mat=res.sim,
           Label.tests,x.lab,y.lab,col.val,line.val,shape.val)
  return(res.sim)
}
#=======================================================================================>


#=======================================================================================>
# Purpose:
#   Run the identification-test Monte Carlo design over a grid of departures from
#   the null and save the corresponding power figures.
# Inputs:
#   test.DGP: Identifier for the alternative DGP used in the test exercise.
#   out.file: Output filename stem for generated figures.
#   n: Sample size used in each replication.
#   h.vec: Grid of departure parameters.
#   R: Number of Monte Carlo replications.
#   ATT: Baseline treatment effect.
#   error.type, alph, phi: Data-generating-process controls.
#   t.X, se.type, q: Estimator specification controls.
#   cl: Parallel worker count passed to `pbsapply`.
# Output:
#   A data frame of rejection frequencies by departure parameter.
MC_idtest.pow<- function(test.DGP,out.file,n,h.vec,R,ATT=0.0,error.type,alph,phi,
                      t.X,se.type,q=0,cl){
  #------------------------------>
  
  #------------------------------>
  # Simulate data and compute results
  MC_Res.list = list()
  for (l in 1:length(h.vec)) {
    #--------------->
    # generate data list
    #dat.gen_test(seed=0,nT,nTau,ATT=0.0,error.type="MDS",alph,phi=NULL,h,test.DGP)
    donnees.liste = lapply(1:R,dat.gen_test,nT=n,nTau=n,ATT=ATT,error.type=error.type,
                           alph=alph,phi=phi,h=h.vec[l],test.DGP=test.DGP)
    
    #test
    # MC_Sim_Fun(l=1,datlist=donnees.liste,ATT=ATT,t.X=t.X,se.type=se.type)
    #--------------->
    
    MC_Res.list[[l]] = pbsapply(1:R, FUN=MC_Sim_idt,cl=cl,datlist=donnees.liste,
                                ATT=ATT,t.X=t.X,se.type=se.type,q=q)
  }#end for (l in 1:length(h.vec))
  #------------------------------>
  
  
  #------------------------------>
  
  res.all=NULL
  for (l in 1:length(MC_Res.list)) {
    res.all = rbind(res.all,apply(MC_Res.list[[l]],1,mean))
  }
  res.sim<- data.frame(h.vec,res.all)
  names(res.sim)<- c("h.vec","id.DiD_01","id.DiD_05","id.DiD_10",
                     "id.SC_01","id.SC_05","id.SC_10",
                     "id.BA_01","id.BA_05","id.BA_10",
                     "pt.DiD_01","pt.DiD_05","pt.DiD_10",
                     "pt.SC_01","pt.SC_05","pt.SC_10",
                     "pt.BA_01","pt.BA_05","pt.BA_10")
  n.test = (ncol(res.sim)-1)/3
  id.01 = (0:(n.test-1))*3 +2
  pow.mat=res.sim[,c(1,id.01,id.01+1,id.01+2)] #rearrange columns for plotting
  #------------------------------>

  #------------------------------>
  Label.tests = c("id.DiD_10"="id.DiD","id.SC_10"="id.SC","id.BA_10"="id.BA",
                  "pt.DiD_10"="pt.DiD","pt.SC_10"="pt.SC","pt.BA_10"="pt.BA")
  x.lab = "h"
  y.lab = " "
  
  col.val_10 = c("id.DiD_10"="black","id.SC_10"="red","id.BA_10"="blue",
                 "pt.DiD_10"="darkorchid","pt.SC_10"="goldenrod4","pt.BA_10"="darkgreen")
  line.val_10 = c("id.DiD_10"="solid","id.SC_10"=22,"id.BA_10"=42,
                  "pt.DiD_10"=11,"pt.SC_10"=15,"pt.BA_10"=19)
  shape.val_10 = c("id.DiD_10"=1,"id.SC_10"=2,"id.BA_10"=3,
                   "pt.DiD_10"=4,"pt.SC_10"=5,"pt.BA_10"=6)
  
  col.val_05 = c("id.DiD_05"="black","id.SC_05"="red","id.BA_05"="blue",
                 "pt.DiD_05"="darkorchid","pt.SC_05"="goldenrod4","pt.BA_05"="darkgreen")
  line.val_05 = c("id.DiD_05"="solid","id.SC_05"=22,"id.BA_05"=42,
                  "pt.DiD_05"=11,"pt.SC_05"=15,"pt.BA_05"=19)
  shape.val_05 = c("id.DiD_05"=1,"id.SC_05"=2,"id.BA_05"=3,
                   "pt.DiD_05"=4,"pt.SC_05"=5,"pt.BA_05"=6)
  
  
  col.val_01 = c("id.DiD_01"="black","id.SC_01"="red","id.BA_01"="blue",
                 "pt.DiD_01"="darkorchid","pt.SC_01"="goldenrod4","pt.BA_01"="darkgreen")
  line.val_01 = c("id.DiD_01"="solid","id.SC_01"=22,"id.BA_01"=42,
                  "pt.DiD_01"=11,"pt.SC_01"=15,"pt.BA_01"=19)
  shape.val_01 = c("id.DiD_01"=1,"id.SC_01"=2,"id.BA_01"=3,
                   "pt.DiD_01"=4,"pt.SC_01"=5,"pt.BA_01"=6)
  
  
  col.val=list();col.val[[1]]=col.val_10;col.val[[2]]=col.val_05;col.val[[3]]=col.val_01
  line.val=list();line.val[[1]]=line.val_10;line.val[[2]]=line.val_05;line.val[[3]]=line.val_01
  shape.val=list();shape.val[[1]]=shape.val_10;shape.val[[2]]=shape.val_05;shape.val[[3]]=shape.val_01
  
  plot.pow(filename=out.file,pow.mat=pow.mat,
           Label.tests,x.lab,y.lab,col.val,line.val,shape.val)
  return(pow.mat)
}
#=======================================================================================>


#===============================================================================
# Purpose:
#   Plot and optionally save power curves at the 10%, 5%, and 1% levels.
# Inputs:
#   filename: Optional output filename stem; if NULL, plots are not saved.
#   pow.mat: Data frame or matrix of power values with the first column as the x-axis.
#   Label.tests: Named labels for legend entries.
#   x.lab, y.lab: Axis labels.
#   col.val, line.val, shape.val: Per-significance-level plotting aesthetics.
# Output:
#   Side effect only: generates plots and saves them when `filename` is provided.
plot.pow<- function(filename=NULL,pow.mat,Label.tests,
                    x.lab,y.lab,col.val,line.val,shape.val){
   
  pow.mat<- as.data.frame(pow.mat)
  gamvec<- pow.mat[,1]
  
  #------------------------------------------------>
  group_10<- group_05<- group_01<- c()
  n.test = (ncol(pow.mat)-1)/3 #number of estimators/tests to compare
  n.g = nrow(pow.mat) #number of sample sizes (or gamma) considered
  id.01 = (1:n.test)+1 #recall first column of pow.mat is gamma
  id.05 = ((n.test+1):(2*n.test)) + 1
  id.10 = ((2*n.test+1):(3*n.test)) + 1
  
  for(l in 1:n.test){
    group_01<- c(group_01,rep(names(pow.mat)[-1][1:n.test][l],n.g))
    group_05<- c(group_05,rep(names(pow.mat)[-1][n.test+(1:n.test)][l],n.g))
    group_10<- c(group_10,rep(names(pow.mat)[-1][2*n.test+(1:n.test)][l],n.g))
  }
  #------------------------------------------------->
  df_10<-data.frame(gam = rep(pow.mat[,1],n.test), 
                    Pow = unlist(pow.mat[,id.10]),
                    group=group_10, group_col = group_10,group_line =group_10)
  #----------------->
  df_05<-data.frame(gam = rep(pow.mat[,1],n.test), 
                    Pow = unlist(pow.mat[,id.05]),
                    group=group_05, group_col = group_05,group_line =group_05)
  #----------------->
  df_01<-data.frame(gam = rep(pow.mat[,1],n.test), 
                    Pow = unlist(pow.mat[,id.01]),
                    group=group_01, group_col = group_01,group_line =group_01)
  #------------------------------------------------>
  ppt.Pow_10<- ggplot(data=df_10)+
    aes(x=gam,y=Pow,colour=group_10)+
    theme_gray()+
    xlab(x.lab)+
    ylab(y.lab)+
    scale_colour_manual(name="Labels", values=col.val[[1]],
                        labels=Label.tests)+
    scale_linetype_manual(name="Labels", values=line.val[[1]],
                          labels=Label.tests)+
    scale_shape_manual(name="Labels", values=shape.val[[1]],
                       labels=Label.tests)+
    theme(legend.title=element_blank())+
    theme(axis.text=element_text(size=40),axis.title=element_text(size=40,face="bold"))+
    theme(legend.text = element_text(colour="black", size=40))+
    theme(legend.position = c(0.75,0.4),legend.key.size = unit(2, 'cm'))+
    ylim(low=-0.1,high=1.1)+
    geom_line(aes(linetype = group_10),size=1.0)+
    geom_point(aes(shape=group_10),size=4)+
    geom_hline(yintercept = 0.1,colour = "brown",size=0.25)
  ppt.Pow_10
  if(!is.null(filename)){
    ggsave(output_path(paste(filename,"_10.png",sep = "")),width=30,height=30,unit="cm")  
  }
  #------------------------------------------------>
  ppt.Pow_05<- ggplot(data=df_05)+
    aes(x=gam,y=Pow,colour=group_05)+
    theme_gray()+
    xlab(x.lab)+
    ylab(y.lab)+
    scale_colour_manual(name="Labels", values=col.val[[2]],
                        labels=Label.tests)+
    scale_linetype_manual(name="Labels", values=line.val[[2]],
                          labels=Label.tests)+
    scale_shape_manual(name="Labels", values=shape.val[[2]],
                       labels=Label.tests)+
    theme(legend.title=element_blank())+
    theme(axis.text=element_text(size=40),axis.title=element_text(size=40,face="bold"))+
    theme(legend.text = element_text(colour="black", size=15))+
    theme(legend.position = "none")+
    ylim(low=-0.1,high=1.1)+
    geom_line(aes(linetype = group_05),size=1.0)+
    geom_point(aes(shape=group_05),size=4)+
    geom_hline(yintercept = 0.05,colour = "brown",size=0.25)
  ppt.Pow_05
  if(!is.null(filename)){
    ggsave(output_path(paste(filename,"_05.png",sep = "")),width=30,height=30,unit="cm")  
  }
  #------------------------------------------------>
  ppt.Pow_01<- ggplot(data=df_01)+
    aes(x=gam,y=Pow,colour=group_01)+
    theme_gray()+
    xlab(x.lab)+
    ylab(y.lab)+
    scale_colour_manual(name="Labels", values=col.val[[3]],
                        labels=Label.tests)+
    scale_linetype_manual(name="Labels", values=line.val[[3]],
                          labels=Label.tests)+
    scale_shape_manual(name="Labels", values=shape.val[[3]],
                       labels=Label.tests)+
    theme(legend.title=element_blank())+
    theme(axis.text=element_text(size=40),axis.title=element_text(size=40,face="bold"))+
    theme(legend.text = element_text(colour="black", size=15))+
    theme(legend.position = "none")+
    ylim(low=-0.1,high=1.1)+
    geom_line(aes(linetype = group_01),size=1.0)+
    geom_point(aes(shape=group_01),size=4)+
    geom_hline(yintercept = 0.01,colour = "brown",size=0.25)
  ppt.Pow_01
  if(!is.null(filename)){
    ggsave(output_path(paste(filename,"_01.png",sep = "")),width=30,height=30,unit="cm")  
  }
  #------------------------------------------------>
}
#===============================================================================


#=======================================================================================>
# Purpose:
#   Assemble the empirical results table from objects created in the empirical
#   scripts and optionally write a LaTeX-style text version to disk.
# Inputs:
#   LaTeX: Logical flag; when TRUE, writes the formatted table to `outfile`.
#   outfile: Output filename used when `LaTeX` is TRUE.
# Output:
#   A data frame containing the empirical results table.
res.fun<- function(LaTeX=FALSE,outfile="out.file.txt"){
  
  suffix.namen<- c("1990.1992","1990","1991","1992")
  res<- data.frame(matrix(" ",8,9))
  rownames(res)<- c("ATT","Ste.ATT","p-val","lag.Y","Ste.lag.Y","ADF","KPSS","DW")
  colnames(res)<- c(suffix.namen," ",suffix.namen)
  n.sn<- length(suffix.namen)
  
  for (j in 1:n.sn) {
    obj_log = get(paste("log_lag_",suffix.namen[j],sep = ""))
    obj_lev = get(paste("lag_",suffix.namen[j],sep = ""))
    
    res[1,j] = round(obj_log$est.ATT,3)
    res[1,(j+1+n.sn)] = round(obj_lev$est.ATT,3)
    
    res[2,j] = round(obj_log$se.ATT,3)
    res[2,(j+1+n.sn)] = round(obj_lev$se.ATT,3)
    
    res[3,j] = round(obj_log$pval.ATT,3)
    res[3,(j+1+n.sn)] = round(obj_lev$pval.ATT,3)
    
    res[4,j] = round(obj_log$reg.Obj$coefficients[3],3)
    res[4,(j+1+n.sn)] = round(obj_lev$reg.Obj$coefficients[3],3)
    
    res[5,j] = round(sqrt(obj_log$mat.vcov[3,3]),3)
    res[5,(j+1+n.sn)] = round(sqrt(obj_lev$mat.vcov[3,3]),3)
    
    res[6,j] = round(obj_log$ADF.test$p.value,3)
    res[6,(j+1+n.sn)] = round(obj_lev$ADF.test$p.value,3)
    
    res[7,j] = round(obj_log$KPSS.test$p.value,3)
    res[7,(j+1+n.sn)] = round(obj_lev$KPSS.test$p.value,3)
    
    res[8,j] = round(obj_log$DW.test$p.value,3)
    res[8,(j+1+n.sn)] = round(obj_lev$DW.test$p.value,3)
    
  }
  

  if(!LaTeX){
    cat("\n");print(res);cat("\n")
  }else{
    sink(output_path(outfile))
    cat("\n");apply(cbind(rownames(res),res),1,print.fn,nsmall=3);cat("\n")
    sink()
  }
  res
}
#=====================================================================================>

#=====================================================================================>
# Purpose:
#   Print one row of a LaTeX-style table with a fixed number of decimals.
# Inputs:
#   x: Vector or row to print.
#   nsmall: Minimum number of digits after the decimal point.
# Output:
#   Side effect only: prints a formatted table row to the active output stream.
print.fn<-function(x,nsmall=3) cat(paste(format(x,nsmall=nsmall),collapse=" &"),paste("\\","\\",sep=""),"\n")
#=====================================================================================>


#=======================================================================================>
# Purpose:
#   Generate one simulated dataset for the main Monte Carlo exercises.
# Inputs:
#   seed: Random seed for the replication.
#   nT, nTau: Numbers of post- and pre-treatment periods.
#   ATT: Scalar or vector treatment effect applied after treatment.
#   error.type: DGP family ("MDS", "White.Noise", "MA", "GARCH", "AR",
#     "Unit.Root", or "Trend").
#   alph: Length-2 vector of unit intercepts.
#   phi: Optional deterministic time-effect function.
#   eta: Optional parameter controlling deviations from parallel trends.
#   nu.suff: Logical flag controlling whether deviations are one-sided.
# Output:
#   A data frame with columns `Y1`, `Y0`, and `var.time`.
dat.gen<- function(seed=0,nT,nTau,ATT=0.0,error.type="MDS",alph,phi=NULL,eta=NULL,nu.suff=F){

  #------------------------------------>
  #create the time variable
  var.time = c(-(nTau:1),0,1:nT) #in ascending order from -nTau to nT
  id.post = which(var.time>0)
  n = nT+nTau+1 #a period for the period of treatment

  #------------------------------------>
  # set seed
  set.seed(seed)

  #------------------------------------>
  #compute eta.vec
  if(error.type=="MDS"){
    #generate errors of untreated potential outcome
    eps.0<- (rchisq(n=(n+1),df=1)-1)/sqrt(2)
    eps.1<- rt(n=(n+1),df=nT)/sqrt(nT/(nT-2))

    e.0<- eps.0[2:(n+1)]*eps.0[1:n] #an extra error for lagging
    e.1<- eps.1[2:(n+1)]*eps.1[1:n] #an extra error for lagging

    e.1<- (e.0 + e.1)/sqrt(2) #cross-sectional dependence
  }else if(error.type=="White.Noise"){
    eps.0<- (rchisq(n=(n+2),df=1)-1)/sqrt(2)
    eps.1<- rt(n=(n+2),df=nT)/sqrt(nT/(nT-2))

    e.0<- (eps.0[1:n] + eps.0[2:(n+1)]*eps.0[3:(n+2)])/sqrt(2) #an extra error for lagging
    e.1<- (eps.1[1:n] + eps.1[2:(n+1)]*eps.1[3:(n+2)])/sqrt(2) #an extra error for lagging

    e.1<- (e.0 + e.1)/sqrt(2) #cross-sectional dependence
  }else if(error.type=="MA"){ #with white noise

    eps.0<- (rchisq(n=(n+3),df=1)-1)/sqrt(2)
    eps.1<- rt(n=(n+3),df=nT)/sqrt(nT/(nT-2))

    eps.0<- (eps.0[1:(n+1)] + eps.0[2:(n+2)]*eps.0[3:(n+3)])/sqrt(2) #an extra error for lagging
    eps.1<- (eps.1[1:(n+1)] + eps.1[2:(n+2)]*eps.1[3:(n+3)])/sqrt(2) #an extra error for lagging


    b<- 0.25
    e.0<- eps.0[1:n] + b*eps.0[2:(n+1)]  #MA(1)
    e.1<- eps.1[1:n] + b*eps.1[2:(n+1)]  #MA(1)

    e.1<- (e.0 + e.1)/sqrt(2) #cross-sectional dependence
  }else if(error.type=="GARCH"){
    eps.0<- (rchisq(n=(n+1),df=1)-1)/sqrt(2)
    eps.1<- rt(n=(n+1),df=nT)/sqrt(nT/(nT-2))

    sig2.0=sig2.1=e.0=e.1=rep(0,(n+1))
    for (t in 2:(n+1)) {

      sig2.0[t] = 0.4 + 0.3*(e.0[t-1])^2 + 0.3*sig2.0[t-1]
      e.0[t] = sqrt(sig2.0[t])*eps.0[t]

      sig2.1[t] = 0.4 + 0.3*(e.1[t-1])^2 + 0.3*sig2.1[t-1]
      e.1[t] = sqrt(sig2.1[t])*eps.1[t]
    }#end for t
    e.1<- (e.0 + e.1)/sqrt(2) #cross-sectional dependence
    e.1=e.1[-1]; e.0=e.0[-1] #remove initial value
  }else if(error.type %in% c("AR","Unit.Root")){
    if(error.type=="AR"){b1=0.5}else if(error.type=="Unit.Root"){b1=1.0}

    eps.0<- (rchisq(n=(n+3),df=1)-1)/sqrt(2)
    eps.1<- rt(n=(n+3),df=nT)/sqrt(nT/(nT-2))

    eps.0<- (eps.0[1:(n+1)] + eps.0[2:(n+2)]*eps.0[3:(n+3)])/sqrt(2) #an extra error for lagging
    eps.1<- (eps.1[1:(n+1)] + eps.1[2:(n+2)]*eps.1[3:(n+3)])/sqrt(2) #an extra error for lagging

    Y0=Y1=y0.1=rep(0,(n+1))
    for (t in 2:(n+1)) { #t indexes zero as well so count to n+1
      Y0[t] = alph[1] + b1*Y0[t-1] + eps.0[t]
      y0.1[t] = alph[2] + b1*y0.1[t-1] + eps.0[t]/sqrt(2)
      if(length(ATT)>1){ #if heterogeneous treatment effects
        if(var.time[t-1]>0){
          ATTt = ATT[var.time[t-1]]*(var.time[t-1]>0) #effect post-treatment
        }else{
          ATTt = 0.0 #no effect pre-treatment
        }
      }else{
        if(var.time[t-1]>0){
          ATTt = ATT #effect post-treatment
        }else{
          ATTt = 0.0 #no effect pre-treatment
        }
      }
      
      
      Y1[t] = ATTt + y0.1[t] + b1*(Y1[t-1]-y0.1[t-1]) + eps.1[t]/sqrt(2)
    }#end for t
    Y0=Y0[-1]; Y1=Y1[-1] #remove initial value
  }
  
  # else{
  #   stop("error type not recognised. \n")
  # }

  if(!(error.type %in% c("AR","Unit.Root"))){
    #------------------------------------>
    #compute eta.vec
    if(is.null(eta)){
      nu.vec = 0.0
    }else{
      if(!nu.suff){
        nu.vec = rnorm(n=n,mean = 0.5*sign(var.time)*1/c(nTau:1,Inf,(1:nT))^eta,sd=1)
      }else{
        nu.vec = rnorm(n=n,mean = 0.5*1/c(nTau:1,Inf,(1:nT))^eta,sd=1)
      }
    }
    #------------------------------------>
    #compute phi
    if(is.null(phi)){
      vec.phi = 0.0
    }else{
      vec.phi = phi(var.time)
    }
    
    if(error.type=="Trend"){
      #generate errors MDS of untreated potential outcome
      eps.0<- (rchisq(n=(n+1),df=1)-1)/sqrt(2)
      eps.1<- rt(n=(n+1),df=nT)/sqrt(nT/(nT-2))
      
      e.0<- eps.0[2:(n+1)]*eps.0[1:n] #an extra error for lagging
      e.1<- eps.1[2:(n+1)]*eps.1[1:n] #an extra error for lagging
      
      e.1<- (e.0 + e.1)/sqrt(2) #cross-sectional dependence
      
      #generate deterministic trend
      nu.vec = var.time
      nu.vec[var.time<0] = var.time[var.time<0] + abs(min(var.time)) + 1
      nu.vec[var.time>0] = var.time[var.time>0] + abs(min(var.time))
    }

    #generate untreated potential outcomes with MDS errors
    y0.0 = alph[1] + vec.phi + e.0
    y0.1 = alph[2] + vec.phi + e.1 + nu.vec

    #Generate observed outcomes
    Y0 = y0.0 #the untreated potential outcome of the untreated group is observed
    Y1 = y0.1; Y1[id.post] = Y1[id.post] + ATT #no-anticipation assumption imposed before treatment
    }# if(!(error.type %in% c("AR","Unit.Root")))

  data.frame(Y1,Y0,var.time)
}
#=======================================================================================>


#=======================================================================================>
# Purpose:
#   Generate one simulated dataset for the identification-test Monte Carlo
#   exercises under the selected alternative design.
# Inputs:
#   seed: Random seed for the replication.
#   nT, nTau: Numbers of post- and pre-treatment periods.
#   ATT: Scalar treatment effect applied after treatment.
#   error.type: DGP family used for the shocks and dynamics.
#   alph: Length-2 vector of unit intercepts.
#   phi: Optional deterministic time-effect function.
#   h: Departure parameter governing the identification-test alternative.
#   test.DGP: Identifier selecting which alternative design to generate.
# Output:
#   A data frame with columns `Y1`, `Y0`, and `var.time`.
dat.gen_test<- function(seed=0,nT,nTau,ATT=0.0,error.type="MDS",alph,phi=NULL,h,test.DGP=1){
  
  #------------------------------------>
  #create the time variable
  var.time = c(-(nTau:1),0,1:nT) #in ascending order from -nTau to nT
  id.post = which(var.time>0)
  n = nT+nTau+1 #a period for the period of treatment
  
  #------------------------------------>
  # set seed
  set.seed(seed)
  
  #------------------------------------>
  #compute eta.vec
  if(error.type=="MDS"){
    #generate errors of untreated potential outcome
    eps.0<- (rchisq(n=(n+1),df=1)-1)/sqrt(2)
    eps.1<- rt(n=(n+1),df=nT)/sqrt(nT/(nT-2))
    
    e.0<- eps.0[2:(n+1)]*eps.0[1:n] #an extra error for lagging
    e.1<- eps.1[2:(n+1)]*eps.1[1:n] #an extra error for lagging
    
    e.1<- (e.0 + e.1)/sqrt(2) #cross-sectional dependence
  }else if(error.type=="White.Noise"){
    eps.0<- (rchisq(n=(n+2),df=1)-1)/sqrt(2)
    eps.1<- rt(n=(n+2),df=nT)/sqrt(nT/(nT-2))
    
    e.0<- (eps.0[1:n] + eps.0[2:(n+1)]*eps.0[3:(n+2)])/sqrt(2) #an extra error for lagging
    e.1<- (eps.1[1:n] + eps.1[2:(n+1)]*eps.1[3:(n+2)])/sqrt(2) #an extra error for lagging
    
    e.1<- (e.0 + e.1)/sqrt(2) #cross-sectional dependence
  }else if(error.type=="MA"){ #with white noise
    
    eps.0<- (rchisq(n=(n+3),df=1)-1)/sqrt(2)
    eps.1<- rt(n=(n+3),df=nT)/sqrt(nT/(nT-2))
    
    eps.0<- (eps.0[1:(n+1)] + eps.0[2:(n+2)]*eps.0[3:(n+3)])/sqrt(2) #an extra error for lagging
    eps.1<- (eps.1[1:(n+1)] + eps.1[2:(n+2)]*eps.1[3:(n+3)])/sqrt(2) #an extra error for lagging
    
    
    b<- 0.25
    e.0<- eps.0[1:n] + b*eps.0[2:(n+1)]  #MA(1)
    e.1<- eps.1[1:n] + b*eps.1[2:(n+1)]  #MA(1)
    
    e.1<- (e.0 + e.1)/sqrt(2) #cross-sectional dependence
  }else if(error.type=="GARCH"){
    eps.0<- (rchisq(n=(n+1),df=1)-1)/sqrt(2)
    eps.1<- rt(n=(n+1),df=nT)/sqrt(nT/(nT-2))
    
    sig2.0=sig2.1=e.0=e.1=rep(0,(n+1))
    for (t in 2:(n+1)) {
      
      sig2.0[t] = 0.4 + 0.3*(e.0[t-1])^2 + 0.3*sig2.0[t-1]
      e.0[t] = sqrt(sig2.0[t])*eps.0[t]
      
      sig2.1[t] = 0.4 + 0.3*(e.1[t-1])^2 + 0.3*sig2.1[t-1]
      e.1[t] = sqrt(sig2.1[t])*eps.1[t]
    }#end for t
    e.1<- (e.0 + e.1)/sqrt(2) #cross-sectional dependence
    e.1=e.1[-1]; e.0=e.0[-1] #remove initial value
  }else if(error.type %in% c("AR","Unit.Root")){
    if(error.type=="AR"){b1=0.5}else if(error.type=="Unit.Root"){b1=1.0}
    
    eps.0<- (rchisq(n=(n+3),df=1)-1)/sqrt(2)
    eps.1<- rt(n=(n+3),df=nT)/sqrt(nT/(nT-2))
    
    eps.0<- (eps.0[1:(n+1)] + eps.0[2:(n+2)]*eps.0[3:(n+3)])/sqrt(2) #an extra error for lagging
    eps.1<- (eps.1[1:(n+1)] + eps.1[2:(n+2)]*eps.1[3:(n+3)])/sqrt(2) #an extra error for lagging
    
    #eps.1<- (eps.0 + eps.1)/sqrt(2) #cross-sectional dependence
    
    Y0=Y1=y0.1=rep(0,(n+1))
    for (t in 2:(n+1)) {
      Y0[t] = alph[1] + b1*Y0[t-1] + eps.0[t]
      y0.1[t] = alph[2] + b1*y0.1[t-1] + eps.0[t]/sqrt(2)
      #Y1[t] = (alph[2]-alph[1]) + ATT*(var.time[t-1]>0) + Y0[t] + b1*(Y1[t-1]-Y0[t-1]) + eps.1[t]
      Y1[t] = ATT*(var.time[t-1]>0) + y0.1[t] + b1*(Y1[t-1]-y0.1[t-1]) + eps.1[t]/sqrt(2)
    }#end for t
    Y0=Y0[-1]; Y1=Y1[-1] #remove initial value
  }else{
    stop("error type not recognised. \n")
  }
  
  if(!(error.type %in% c("AR","Unit.Root"))){
    #------------------------------------>
    #compute eta.vec
      
    if(test.DGP==1){
        m.vec = 2.5*h*( abs(var.time) )^(-1/4)
        m.vec[is.na(m.vec) | is.infinite(m.vec)] = 0
        nu.vec = rnorm(n=n,mean = m.vec,sd=1)
        nu.vec[id.post]=0.0
      }else if(test.DGP==2){
        m.vec = 2.5*h*( abs(var.time) )^(-1/4)
        m.vec[is.na(m.vec) | is.infinite(m.vec)] = 0
        nu.vec = rnorm(n=n,mean = m.vec,sd=1)
        nu.vec[-id.post]=0.0
      }else if(test.DGP==3){
        #mean = 0.5*1/c(nTau:1,Inf,(1:nT))^eta
        #m.vec = 0.5*( abs( var.time-ceiling(h*nT) ) )^(-1/4)
        m.vec = 2.5*(1-h*(1-sign(var.time)))*( abs(var.time) )^(-1/4)
        m.vec[is.na(m.vec) | is.infinite(m.vec)] = 0
        nu.vec = rnorm(n=n,mean = m.vec,sd=1)
        #nu.vec[id.post]=0.0
      }
    #------------------------------------>
    #compute phi
    if(is.null(phi)){
      vec.phi = 0.0
    }else{
      vec.phi = phi(var.time)
    }
    
    #generate untreated potential outcomes with MDS errors
    y0.0 = alph[1] + vec.phi + e.0
    y0.1 = alph[2] + vec.phi + e.1 + nu.vec
    
    #Generate observed outcomes
    Y0 = y0.0 #the untreated potential outcome of the untreated group is observed
    Y1 = y0.1; Y1[id.post] = Y1[id.post] + ATT #no-anticipation assumption imposed before treatment
  }# if(!(error.type %in% c("AR","Unit.Root")))
  
  data.frame(Y1,Y0,var.time)
}
#=======================================================================================>
