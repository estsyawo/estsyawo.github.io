#=========================================================================================>
# Functions

#-------------------------------------------------->
# Function for initialising parameter/covariate clusters
# Arguments: 
# X - design matrix, Y - dependent variable, k - number of clusters
# method - method for assigning clusters: "kmeans", "fkmeans","cormeans", "corpars" 
# are supported
# return - clus - vector of cluster assignments of covariates

iniclus1<- function(X,Y=NULL,k,method="corpars",model="lm",pars.o=NULL,pars=FALSE,...){ 
  set.seed(1)
  if(method=="kmeans"){
    clus=stats::kmeans(t(X),centers=k)$cluster
  }else if(method=="fkmeans"){
    zX<- matrix(NA,dim(X)[1],dim(X)[2])
    for (j in 1:dim(X)[2]) {
      zX[,j]<-ch.model(Y,X1,model = model,...)$fitted.values
    }
    clus=kmeans(t(zX),centers=k)$cluster
  }else if(method=="cormeans"){
    clus=kmeans(cor(X,Y),centers=k)$cluster
  }else if(method=="corpars"){
    if(is.null(pars.o)){zX<- rep(NA,dim(X)[2])
    for (j in 1:dim(X)[2]) {
      zX[j]<-coef(ch.model(Y,X[,j],model = model,...))[2]
    }
    clus=kmeans(zX,centers=k)$cluster
    }else{
      zX=pars.o
      clus=kmeans(zX,centers=k)$cluster
    }
  }else{stop("method not supported")}
  if(!pars){
    return(clus)
  }else{
    return(list(clus=clus,pars=zX))
  }
  
}


#=========================================================================================>

#=========================================================================================>
# Function for parameter/covariate clustering regression
# Arguments:
# X - design matrix, Y - dependent variable, k - number of clusters
# method - method for initial assignment of clusters: "kmeans", "fkmeans" are supported
# return - clus - vector of cluster assignments of covariates

cluspar1<- function(X,Y,k,model="lm",method="corpars",pars.o=NULL,...){
  #Preliminaries
  nrX <- nrow(X) #number of rows of X
  ncX <- ncol(X) #number of columns of X
  
  if(is.null(pars.o)){
  clus <- iniclus1(X=X,Y=Y,k=k,method=method,model=model,...)
  }else{
    clus<-iniclus1(X,Y=NULL,k,method="corpars",model=model,pars.o=pars.o,...)
  }
  uniClus <- unique(clus)
  X1 <- matrix(NA,nrX,k)
  for(j in uniClus) X1[,j] <- apply(as.matrix(X[,(which(clus == j))]),1,sum)
  model1 <-ch.model(Y,X1,model = model,...)# lm(Y~X1)
  fval_o<- -logLik(model1)#sum(model1$residuals^2)
  lmc1 <- (k-1)*ncX #number of single-shift permutations
  dmod<- c(0)       # index 
  
  
  #create matrix of one-shift permutation clusterings
  iter=0; optfval=0 #initialise counter and optimal fval
  while(optfval<fval_o){
    iter=iter+1;  
    IDj<- rep(NA,ncX) # index
    if(iter>1){fval_o<- optfval; clus<- clus1[optcl,]}
    
    clus1 <- matrix(rep(clus,lmc1) ,ncol=ncX,byrow=T) 
    for(j in 1:ncX){ 
      
      if(!j%in%dmod){
        clus1[c(((k-1)*(j-1)+1):(j*(k-1))),j] <- setdiff(uniClus,clus[j])  
      }else{
        clus1[c(((k-1)*(j-1)+1):(j*(k-1))),j] <- clus[j]
        IDj[c(((k-1)*(j-1)+1):(j*(k-1)))]<- 1 #index rows in clus1 not to run
      }
      }
    nrI<- which(IDj==1)
    #-------------------------------------------------->
    vfun<- function(i){
      if(!i%in%nrI){
      for(h in uniClus) X1[,h] <- apply(as.matrix(X[,(which(clus1[i,] == h))]),1,sum)
      model1 <-ch.model(Y,X1,model = model,...)# lm(Y~X1)
      val<- -logLik(model1)
      #val=sum((lm(Y~X1)$residuals)^2)
      }else{
        val=Inf # skip strictly dominated models
      }
      val
    }
    
    # if(lmc1<20000){
    #   vfval<- sapply(1:lmc1, vfun)
    # }else{
    #   vfval<- unlist(bayesdistreg::parLply(1:lmc1,fn=vfun,type = "FORK"))
    # }
    vfval<- sapply(1:lmc1, vfun)
    
    #-------------------------------------------------->
    optcl<- which.min(vfval) #optimal model at this node
    optfval<- vfval[optcl]
    dmod<- c(dmod,optcl)
    
  }
  
  AIC= 2*(fval_o + (k+1))
  BIC= 2*fval_o + (log(nrX)*(k+1))
  
  list(clus=clus,fval=fval_o,AIC=AIC,BIC=BIC,iter=iter)
}



#-------------------------------------------------->
# Monte Carlo Simulation function for optimal k
# Argument: s - seed
MCfun<- function(s,ko=3,beta,crit,model="lm",method="corpars",cost=NULL,...){
  dat<- mcdata(beta=beta,s=s,n=2000,p=20,model=model)
  estob<- estimates(ko,dat$X,dat$Y,crit=crit,model=model,method=method,cost=cost,...)[-6]
  # Extract quantities of interest, exclude the model object
  return(estob)
}

#-------------------------------------------------->
# Monte Carlo Simulation function with a fixed k
# Argument: s - seed
MCfun_fk<- function(s,k,beta,model="lm",method="corpars",...){
  dat<- mcdata(beta=beta,s=s,n=2000,p=20,model=model)
  clob<- cluspar1(dat$X,dat$Y,k=k,model = model,method=method,...)
  nrX = nrow(dat$X)
  # Extract quantities of interest
  clus <- clob$clus
  AIC <- clob$AIC; BIC<- clob$BIC; iter=clob$iter; fval<- clob$fval
  uniClus<- unique(clus)
  X1 <- matrix(NA,nrX,length(uniClus))
  for(j in uniClus) X1[,j] <- apply(as.matrix(dat$X[,(which(clus == j))]),1,sum)
  model1 <-ch.model(Y,X1,model = model,...)
  deltas <- coef(model1)
  
  return(list(param=deltas,clus=clus, AIC = AIC,BIC=BIC,fval=fval,iter=iter))
  return(clob)
}

#=========================================================================================>
# Model function
# This function takes input of model type and executes the right model
# lm, glm, and quantreg functions are implemented

ch.model<- function(Y,X,model="lm",...){
  if(model=="lm"){
    mobj<- stats::glm(Y~.,family = gaussian(link = "identity"),data = data.frame(Y,X),...)
  }else if(model=="logit"){
    mobj<- stats::glm(Y~.,family = binomial(link = "logit"),data = data.frame(Y,X),...)
  }else if(model=="quantreg"){
    mobj<- quantreg::rq(Y~.,data = data.frame(Y,X),...)
  }else if(model=="probit"){
    mobj<- stats::glm(Y~.,family = binomial(link = "probit"),data = data.frame(Y,X),...)
  }else if(model=="gammainverse"){
    mobj<- stats::glm(Y~.,family = Gamma(link = "inverse"),data = data.frame(Y,X),...)
  }else if(model=="gammaidentity"){
    mobj<- stats::glm(Y~.,family = Gamma(link = "identity"),data = data.frame(Y,X),...)
  }else if(model=="gammalog"){
    mobj<- stats::glm(Y~.,family = Gamma(link = "log"),data = data.frame(Y,X),...)
  }else if(model=="poissonlog"){
    mobj<- stats::glm(Y~.,family = poisson(link = "log"),data = data.frame(Y,X),...)
  }else if(model=="poissonidentity"){
    mobj<- stats::glm(Y~.,family = poisson(link = "identity"),data = data.frame(Y,X),...)
  }else if(model=="poissonsqrt"){
    mobj<- stats::glm(Y~.,family = poisson(link = "sqrt"),data = data.frame(Y,X),...)
  }else if(model=="negbin"){
    mobj<- MASS::glm.nb(Y~.,data = data.frame(Y,X),...)
  }
  return(mobj)
}

#=========================================================================================>
# Construct a design matrix
# datf - the entire data frame of balanced panel with NT rows of unit-time observations
# Y - dependent variable in the data frame datf
# X - the covariate(s) generating spillovers
# Wi - other unit-varying (can be time-invariant) control variables
# W - global variables. these are only time varying but are common to all units. eg. GDP
# for individual/state-level data. Note that W has to be a vector of length T so cannot be 
# in the data frame datf
# panvar - the panel variable eg. unique person/firm identifiers
# tvar - time variable, eg. years
# factors - a vector of characters of factors in the data
# scaling - a logical indicating whether non-discrete covariates should be scaled by their standard deviations
# unicons - a logical indicating whether to include unit-specific constant term

# output- Y - vector of dependent variables 
# output- X - a block matrix of spillover matrix (TN x N^2)

netdat<- function(datf,Y,X,Wi,W=NULL,panvar,tvar,factors,scaling=TRUE,unicons=TRUE){
  if(any(is.na(data.frame(datf[panvar],datf[tvar])))){stop("NA in panel or time variables unallowed")}
  dat<- datf[order(datf[panvar],datf[tvar]),] #sort data into a panel by units and time
  Nd = nrow(unique(datf[panvar])) # extract number of units
  Td = nrow(unique(datf[tvar])) # extract the number of time periods
  fmat<- dat[factors]
  # check if panel is balanced
  if(dim(dat)[1]!=(Nd*Td)){stop("Unbalanced panel")}
  Xj = matrix(unlist(dat[X]),ncol = Nd) # the covariate(s) generating spillovers or externalities
  # write code to scale continuous covariates and store scales.
  if(scaling){
    fn<- function(x) {sd(na.omit(x))*sqrt(length(which(!is.na(x)))/length(x))}
    vX<- apply(Xj,2,fn); 
    if(any(vX<(10^-6))){cat("some units lack variation in x. consider removing them.")}
    if(unicons){
      Xm = kronecker(diag(1,Nd),cbind(1,(Xj/vX)))
    }else{
      Xm = kronecker(diag(1,Nd),(Xj/vX))
    } # a (TdxNd) x (Nd^2) block matrix
  }else{
    if(unicons){
      Xm = kronecker(diag(1,Nd),cbind(1,Xj))
    }else{
      Xm = kronecker(diag(1,Nd),Xj)
    } # a (TdxNd) x (Nd^2) block matrix
  }
  
  if(all(dim(Xm)!=c((Td*Nd),(Nd^2)))){stop("Network data creation failed.")}
  
  if(scaling){
    vWm = apply(dat[Wi],2,fn); 
    if(any(vWm<(10^-6))){cat("some units lack variation in covariates. consider removing them.")}
    Wm = dat[Wi]/vWm  
  }else{
    Wm = dat[Wi]
  }
  
  Ym = unlist(dat[Y]); zY=rep(1,length(Ym)); zY[!is.na(Ym)]<- Ym[!is.na(Ym)]
  fmod<- apply(fmat, 2, as.factor) #convert the columns of fmat into factors
  Wf=model.matrix(zY~.,data.frame(zY,fmod))[,-1] # remove the constant term
  # combine terms
  #datDM<-data.frame(Ym,Xm,Wm,Wf); names(datDM)[1]<- "Y"
  if(scaling){
    res=list(Y=Ym,X=Xm,Wm=Wm,Wf=Wf,sdX=vX,sdWm=vWm)
  }else{
    res=list(Y=Ym,X=Xm,Wm=Wm,Wf=Wf)
  }
  return(res)
}

#=============================================================================================>
# Function: dcluspar
# a deterministic clustering device of vector elements into k clusters
# arguments: 	k - number of clusters
# 		vec - the vector of real valued elements
# output	clus - integer assignment of corresponding elements in vec in up to k clusters
dcluspar<- function(k,vec){
  svec=sort(vec)
  dsvec=diff(svec)
  idub = which(rank(-dsvec)<k)
  idlb = 1+idub
  lb=svec[idlb]
  ub=svec[idub]
  lb = c(min(vec),lb); ub = c(ub,max(vec))
  clus = rep(1,length(vec))
  for (j in 1:k) {
    clus[which(vec>=lb[j] & vec<=ub[j])]=j
  }
  clus
}



