#================================================================================>

# Gerstner-Tsyawo 2022
# PISA Panel analysis 
# Updated: 7/19/2022
# Author: Emmanuel Selorm Tsyawo & Clara-Christina Gerstner

# ================================================================>

# Load packages
library(xtable)
library(car)
library(spatialreg)
library(sphet)
library(splm)
library(ggplot2)
library(rworldmap)
library(RColorBrewer)

# Set working directory path to source file (all files should be located in the same folder)
setwd(dirname(rstudioapi::getActiveDocumentContext()$path)) 

# Load Functions
source('SARARGMM.R')
source('Spatial_functions.R')
source('Gerstner_Tsyawo_2022_ConstructW')

# ================================================================>

# Load data
Dat_Final <- read.csv("Gerstner_Tsyawo_2022_Data.csv")

#####################################################################
# Replicate Table 2.1 Summary statistics
#####################################################################

### Summary statistics ###
summarystat <- function(X){
  Output <- matrix(0, nrow = ncol(X), ncol = 4)
  colnames(Output) <- c("Mean", "SD", "Min", "Max")
  rownames(Output) <- names(X)
  for(i in 1:ncol(X)){
    Output[i,1] <- round(mean(X[,i], na.rm=TRUE),3)
    Output[i,2] <- round(sd(X[,i], na.rm=TRUE),3)
    Output[i,3] <- round(min(X[,i], na.rm=TRUE),3)
    Output[i,4] <- round(max(X[,i], na.rm=TRUE),3)
  }
  Output
}

SumVar <- c("READ","MATH","SCIENCE","AUTONOMY",
            "assessm","textbooks","content","course",
            "BUDGET","TEACHER",
            "ACCOUNT","PRIVATE",
            "SHORTMYES","SHORTMNO",
            "GDP","OECD")

PISA_Sum <- summarystat(Dat_Final[SumVar])
PISA_Sum

table(Dat_Final$INCOME)

print(xtable(PISA_Sum,digits=3))

#####################################################################
# Replicate Table 4.1 OLS Results by Subject
#####################################################################

### Specification 1: Reading ###

OLSmodel = lm(READ ~ AUTONOMY+PRIVATE+ACCOUNT+
                SHORTMNO+SHORTMYES+
                I(GDP/1000)+OECD+
                as.factor(INCOME)+as.factor(TIME), 
                data = Dat_Final)

sm = summary(OLSmodel)
sm

# Cluster robust SE
OLSmodel$STEclass = sqrt(diag(sandwich::vcovCL(OLSmodel, cluster = Dat_Final$CNT)))

# P-value
tval1 = sm$coefficients[,1]/OLSmodel$STEclass
pval1 = pnorm(-abs(tval1))*2
tval1

### Specification 2: Math ###

OLSmodel2 = lm(MATH ~ AUTONOMY+PRIVATE+ACCOUNT+
                SHORTMNO+SHORTMYES+
                I(GDP/1000)+OECD+
                as.factor(INCOME)+as.factor(TIME), 
              data = Dat_Final)

sm2 = summary(OLSmodel2)
sm2

# Cluster robust SE
OLSmodel2$STEclass = sqrt(diag(sandwich::vcovCL(OLSmodel2, cluster = Dat_Final$CNT)))

# P-value
tval2 = sm2$coefficients[,1]/OLSmodel2$STEclass
pval2 = pnorm(-abs(tval2))*2
tval2

### Specification 3: Science ###

OLSmodel3 = lm(SCIENCE ~ AUTONOMY+PRIVATE+ACCOUNT+
                SHORTMNO+SHORTMYES+
                I(GDP/1000)+OECD+
                as.factor(INCOME)+as.factor(TIME), 
              data = Dat_Final)

sm3 = summary(OLSmodel3)
sm3

# Cluster robust SE
OLSmodel3$STEclass = sqrt(diag(sandwich::vcovCL(OLSmodel3, cluster = Dat_Final$CNT)))

# P-value
tval3 = sm3$coefficients[,1]/OLSmodel3$STEclass
pval3 = pnorm(-abs(tval3))*2
tval3

#####################################################################
# Replicate Table 4.2 Results by Subject
#####################################################################

### Specification 1: Reading ###

# Dependent variable
Y = Dat_Final$READ

# Independent variables
X <- model.matrix(~ AUTONOMY+PRIVATE+ACCOUNT+
                    SHORTMNO+SHORTMYES+
                    I(GDP/1000)+OECD+
                    as.factor(INCOME)+as.factor(TIME),
                    data = Dat_Final)

# Create weight matrix
WSM1 = list()
WSM1[[1]]=as.matrix(W1)

# Obtain SAR starting values 
startersar1 <- Start_values(X,Y,WSM1, mod="SAR")
SVsar1 <- startersar1$SV
namensar1 <- startersar1$name

## Run GMM Model ##
rgobj1=rgSARGMM(theta0=SVsar1,Y=Y,X=X[,-c(1)],W=WSM1, cluster = Dat_Final$CNT) 

# Output
out1 = round(Spatial_output(rgobj1, namensar1, WSM1, mod="SAR"),3)
out1

# Inference statistics
rgobj1$Jstat
rgobj1$pvalJ
rgobj1$df
rgobj1$R2

# ================================================================>

### Specification 2: Math ###

# Dependent variable
Y = Dat_Final$MATH

# Independent variables
X <- model.matrix(~ AUTONOMY+PRIVATE+ACCOUNT+
                    SHORTMNO+SHORTMYES+
                    I(GDP/1000)+OECD+
                    as.factor(INCOME)+as.factor(TIME),
                    data = Dat_Final)

# Weight matrix
WSM1 = list()
WSM1[[1]]=as.matrix(W1)

# Obtain SAR starting values 
startersar2 <- Start_values(X,Y,WSM1, mod="SAR")
SVsar2 <- startersar2$SV
namensar2 <- startersar2$name

## Run GMM Model ##
rgobj2=rgSARGMM(theta0=SVsar2,Y=Y,X=X[,-1],W=WSM1, cluster = Dat_Final$CNT) 

# Output
out2 = round(Spatial_output(rgobj2, namensar2, WSM1, mod="SAR"),3)
out2

# Inference statistics
rgobj2$Jstat
rgobj2$pvalJ
rgobj2$df
rgobj2$R2

# ================================================================>

### Specification 3: Science ###

# Dependent variable
Y = Dat_Final$SCIENCE

# Independent variables
X <- model.matrix(~ AUTONOMY+PRIVATE+ACCOUNT+
                    SHORTMNO+SHORTMYES+
                    I(GDP/1000)+OECD+
                    as.factor(INCOME)+as.factor(TIME),
                    data = Dat_Final)

# Weight matrix
WSM1 = list()
WSM1[[1]]=as.matrix(W1)

# Obtain SAR starting values 
startersar3 <- Start_values(X,Y,WSM1, mod="SAR")
SVsar3 <- startersar3$SV
namensar3 <- startersar3$name

## Run GMM Model ##
rgobj3=rgSARGMM(theta0=SVsar3,Y=Y,X=X[,-1],W=WSM1, cluster = Dat_Final$CNT) 

# Output
out3 = round(Spatial_output(rgobj3, namensar3, WSM1, mod="SAR"),3)
out3

# Inference statistics
rgobj3$Jstat
rgobj3$pvalJ
rgobj3$df
rgobj3$R2

# ================================================================>

# Print output
print(xtable(matrix(c("Autonomy", out1[2,1], out2[2,1],out3[2,1],
         "",paste("(",out1[2,2],")"),paste("(",out2[2,2],")"),paste("(",out3[2,2],")"),
         "rho", out1[1,1],out2[1,1],out3[1,1],
         "",paste("(",out1[1,2],")"),paste("(",out2[1,2],")"),paste("(",out3[1,2],")")),
            ncol=4, byrow = T), digits=3),include.rownames=FALSE)

print(xtable(matrix(c("J-statistic",round(rgobj1$Jstat,2),round(rgobj2$Jstat,2),round(rgobj3$Jstat,2),
       "df",rgobj1$df,rgobj3$df,rgobj2$df,
       "p-value",round(rgobj1$pvalJ,2),round(rgobj2$pvalJ,2),round(rgobj3$pvalJ,2),
       "R",round(rgobj1$R2,2),round(rgobj2$R2,2),round(rgobj3$R2,2)),
       ncol=4, byrow = T), digits=2),include.rownames=FALSE)

#####################################################################
# Replicate Table 4.3 Results by Subdomains
#####################################################################

# Dependent variable
Y = Dat_Final$READ

# Independent variables
X2 <- model.matrix(~ assessm+PRIVATE+ACCOUNT+
                     SHORTMNO+SHORTMYES+
                     I(GDP/1000)+OECD+
                     as.factor(INCOME)+
                     as.factor(TIME), data = Dat_Final)

X3 <- model.matrix(~ textbooks+PRIVATE+ACCOUNT+
                     SHORTMNO+SHORTMYES+
                     I(GDP/1000)+OECD+
                     as.factor(INCOME)+
                     as.factor(TIME), data = Dat_Final)

X4 <- model.matrix(~ content+PRIVATE+ACCOUNT+
                     SHORTMNO+SHORTMYES+
                     I(GDP/1000)+OECD+
                     as.factor(INCOME)+
                     as.factor(TIME), data = Dat_Final)

X5 <- model.matrix(~ course+PRIVATE+ACCOUNT+
                     SHORTMNO+SHORTMYES+
                     I(GDP/1000)+OECD+
                     as.factor(INCOME)+
                     as.factor(TIME), data = Dat_Final)

X6 <- model.matrix(~ TEACHER+PRIVATE+ACCOUNT+
                     SHORTMNO+SHORTMYES+
                     I(GDP/1000)+OECD+
                     as.factor(INCOME)+
                     as.factor(TIME), data = Dat_Final)

X7 <- model.matrix(~ BUDGET+PRIVATE+ACCOUNT+
                     SHORTMNO+SHORTMYES+
                     I(GDP/1000)+OECD+
                     as.factor(INCOME)+
                     as.factor(TIME), data = Dat_Final)

# Weight matrix
WSM1 = list()
WSM1[[1]]=as.matrix(W1)

# Obtain SAR starting values 
startersar1b <- Start_values(X2,Y,WSM1, mod="SAR")
SVsar1b <- startersar1b$SV
namensar1b <- startersar1b$name

startersar1c <- Start_values(X3,Y,WSM1, mod="SAR")
SVsar1c <- startersar1c$SV
namensar1c <- startersar1c$name

startersar1d <- Start_values(X4,Y,WSM1, mod="SAR")
SVsar1d <- startersar1d$SV
namensar1d <- startersar1d$name

startersar1e <- Start_values(X5,Y,WSM1, mod="SAR")
SVsar1e <- startersar1e$SV
namensar1e <- startersar1e$name

startersar1f <- Start_values(X6,Y,WSM1, mod="SAR")
SVsar1f <- startersar1f$SV
namensar1f <- startersar1f$name

startersar1g <- Start_values(X7,Y,WSM1, mod="SAR")
SVsar1g <- startersar1g$SV
namensar1g <- startersar1g$name

# ================================================================>

### Specification 1: Assessments ### 
rgobj1b=rgSARGMM(theta0=SVsar1b,Y=Y,X=X2[,-1],W=WSM1, cluster = Dat_Final$CNT) 

# Output
out1b = round(Spatial_output(rgobj1b, namensar1b, WSM1, mod="SAR"),3)

# Inference statistics
rgobj1b$Jstat
rgobj1b$pvalJ
rgobj1b$df
rgobj1b$R2

# ================================================================>

### Specification 2: Textbooks ### 
rgobj1c=rgSARGMM(theta0=SVsar1c,Y=Y,X=X3[,-1],W=WSM1, cluster = Dat_Final$CNT) 

# Output
out1c = round(Spatial_output(rgobj1c, namensar1c, WSM1, mod="SAR"),3)

# Inference statistics
rgobj1c$Jstat
rgobj1c$pvalJ
rgobj1c$df
rgobj1c$R2

# ================================================================>

### Specification 3: Course content ### 
rgobj1d=rgSARGMM(theta0=SVsar1d,Y=Y,X=X4[,-1],W=WSM1, cluster = Dat_Final$CNT) 

# Output
out1d = round(Spatial_output(rgobj1d, namensar1d, WSM1, mod="SAR"),3)

# Inference statistics
rgobj1d$Jstat
rgobj1d$pvalJ
rgobj1d$df
rgobj1d$R2

# ================================================================>

### Specification 4: Course choices ### 
rgobj1e=rgSARGMM(theta0=SVsar1e,Y=Y,X=X5[,-1],W=WSM1, cluster = Dat_Final$CNT) 

# Output
out1e = round(Spatial_output(rgobj1e, namensar1e, WSM1, mod="SAR"),3)

# Inference statistics
rgobj1e$Jstat
rgobj1e$pvalJ
rgobj1e$df
rgobj1e$R2

# ================================================================>

### Specification 5: Personnel autonomy ### 
rgobj1f=rgSARGMM(theta0=SVsar1f,Y=Y,X=X6[,-1],W=WSM1, cluster = Dat_Final$CNT) 

# Output
out1f = round(Spatial_output(rgobj1f, namensar1f, WSM1, mod="SAR"),3)

# Inference statistics
rgobj1f$Jstat
rgobj1f$pvalJ
rgobj1f$df
rgobj1f$R2

# ================================================================>

###  Specification 6: Budget autonomy ### 
rgobj1g=rgSARGMM(theta0=SVsar1g,Y=Y,X=X7[,-1],W=WSM1, cluster = Dat_Final$CNT) 

# Output
out1g = round(Spatial_output(rgobj1g, namensar1g, WSM1, mod="SAR"),3)

# Inference statistics
rgobj1g$Jstat
rgobj1g$pvalJ
rgobj1g$df
rgobj1g$R2

# ================================================================>

# Print output
print(xtable(matrix(c("Autonomy", out1b[2,1], out1c[2,1],out1d[2,1],out1e[2,1],out1f[2,1],out1g[2,1],
                      "",paste("(",out1b[2,2],")"),paste("(",out1c[2,2],")"),
                      paste("(",out1d[2,2],")"),paste("(",out1e[2,2],")"),
                      paste("(",out1f[2,2],")"),paste("(",out1g[2,2],")"),
                      "rho", out1b[1,1],out1c[1,1],out1d[1,1],out1e[1,1],out1f[1,1],out1g[1,1],
                      "",paste("(",out1b[1,2],")"),paste("(",out1c[1,2],")"),
                      paste("(",out1d[1,2],")"),paste("(",out1e[1,2],")"),
                    paste("(",out1f[1,2],")"),paste("(",out1g[1,2],")")),
                    ncol=7, byrow = T), digits=3),include.rownames=FALSE)

print(xtable(matrix(c("J-statistic",round(rgobj1b$Jstat,2),round(rgobj1c$Jstat,2),
                      round(rgobj1d$Jstat,2),round(rgobj1e$Jstat,2),
                      round(rgobj1f$Jstat,2),round(rgobj1g$Jstat,2),
                      "df",rgobj1b$df,rgobj1c$df,rgobj1d$df,rgobj1e$df,rgobj1f$df,rgobj1g$df,
                      "p-value",round(rgobj1b$pvalJ,2),round(rgobj1c$pvalJ,2),
                      round(rgobj1d$pvalJ,2),round(rgobj1e$pvalJ,2),
                    round(rgobj1f$pvalJ,2),round(rgobj1g$pvalJ,2),
                    "R",round(rgobj1b$R2,2),round(rgobj1c$R2,2),round(rgobj1d$R2,2),
                    round(rgobj1e$R2,2),round(rgobj1f$R2,2),round(rgobj1g$R2,2)),
                    ncol=7, byrow = T), digits=2),include.rownames=FALSE)

#####################################################################
# Replicate Table 4.4 Robustness Checks
#####################################################################

### Specification 1: Without ISR and SWE ###

# Dependent variable
Y = Dat_Final[!Dat_Final$CNT==c("SWE","ISR"),]$READ

# Independent variables
X <- model.matrix(~ AUTONOMY+ACCOUNT+PRIVATE+
                    SHORTMNO+SHORTMYES+
                    I(GDP/1000)+OECD+
                    as.factor(INCOME)+as.factor(TIME),
                    data = Dat_Final[!Dat_Final$CNT==c("SWE","ISR"),])

 # Create weight matrix
WSM1d = list()
WSM1d[[1]]=as.matrix(W1d)

# Obtain SAR starting values 
startersar1h <- Start_values(X,Y,WSM1d, mod="SAR")
SVsar1h <- startersar1h$SV
namensar1h <- startersar1h$name

## Run GMM Model ##
rgobj1h=rgSARGMM(theta0=SVsar1h,Y=Y,X=X[,-c(1)],W=WSM1d, cluster=Dat_Final[!Dat_Final$CNT==c("SWE","ISR"),]$CNT) 

# Output
out1h = round(Spatial_output(rgobj1h, namensar1h, WSM1d, mod="SAR"),3)
out1h

# Inference statistics
rgobj1h$Jstat
rgobj1h$pvalJ
rgobj1h$df
rgobj1h$R2

# ================================================================>

### Specification 2: OECD only ###

# Dependent variable
Y = Dat_Final[Dat_Final$OECD==1,]$READ

# Independent variables
X <- model.matrix(~ AUTONOMY+PRIVATE+ACCOUNT+
                    SHORTMNO+SHORTMYES+
                    I(GDP/1000)+
                    as.factor(INCOME)+as.factor(TIME),
                  data = Dat_Final[Dat_Final$OECD==1,])

# Create weight matrix
WSM1c = list()
WSM1c[[1]]=as.matrix(W1c)

# Obtain SAR starting values 
startersar1i <- Start_values(X,Y,WSM1c, mod="SAR")
SVsar1i <- startersar1i$SV
namensar1i <- startersar1i$name

## Run GMM Model ##
rgobj1i=rgSARGMM(theta0=SVsar1i,Y=Y,X=X[,-c(1)],W=WSM1c) 

# Output
out1i = round(Spatial_output(rgobj1i, namensar1i, WSM1c, mod="SAR"),3)
out1i

# Inference statistics
rgobj1i$Jstat
rgobj1i$pvalJ
rgobj1i$df
rgobj1i$R2

# ================================================================>

### Specification 3: Europe only ###

# Dependent variable
Y = Dat_Final[Dat_Final$Continent=='Europe',]$READ

# Independent variables
X <- model.matrix(~ AUTONOMY+PRIVATE+ACCOUNT+
                    SHORTMNO+SHORTMYES+
                    I(GDP/1000)+
                    as.factor(INCOME)+as.factor(TIME),
                  data = Dat_Final[Dat_Final$Continent=='Europe',])

# Create weight matrix
WSM1b = list()
WSM1b[[1]]=as.matrix(W1b)

# Obtain SAR starting values 
startersar1j <- Start_values(X,Y,WSM1b, mod="SAR")
SVsar1j <- startersar1j$SV
namensar1j <- startersar1j$name

## Run GMM Model ##
rgobj1j=rgSARGMM(theta0=SVsar1j,Y=Y,X=X[,-c(1)],W=WSM1b) 

# Output
out1j = round(Spatial_output(rgobj1j, namensar1j, WSM1b, mod="SAR"),3)
out1j

# Inference statistics
rgobj1j$Jstat
rgobj1j$pvalJ
rgobj1j$df
rgobj1j$R2

# ================================================================>

### Specification 4: Country-fixed effects ###

# Dependent variable
Y = Dat_Final$READ

# Independent variables
X <- model.matrix(~ AUTONOMY+PRIVATE+ACCOUNT+
                    SHORTMNO+SHORTMYES+
                    I(GDP/1000)+OECD+as.factor(CNT)+
                    as.factor(INCOME)+as.factor(TIME),
                    data = Dat_Final)

# Create weight matrix
WSM1 = list()
WSM1[[1]]=as.matrix(W1)

# Obtain SAR starting values 
startersar1k <- Start_values(X,Y,WSM1, mod="SAR")
SVsar1k <- startersar1k$SV
namensar1k <- startersar1k$name

## Run GMM Model ##
rgobj1k=rgSARGMM(theta0=SVsar1k,Y=Y,X=X[,-c(1)],W=WSM1) 

# Output
out1k = round(Spatial_output(rgobj1k, namensar1k, WSM1, mod="SAR"),3)
out1k

# Inference statistics
rgobj1k$Jstat
rgobj1k$pvalJ
rgobj1k$df
rgobj1k$R2

# ================================================================>

# Print output
print(xtable(matrix(c("Autonomy", out1h[2,1], out1i[2,1],out1j[2,1],out1k[2,1],
                      "",paste("(",out1h[2,2],")"),paste("(",out1i[2,2],")"),
                      paste("(",out1j[2,2],")"),paste("(",out1k[2,2],")"),
                      "rho", out1h[1,1],out1i[1,1],out1j[1,1],out1k[1,1],
                      "",paste("(",out1h[1,2],")"),paste("(",out1i[1,2],")"),
                      paste("(",out1j[1,2],")"),paste("(",out1k[1,2],")")),
                    ncol=5, byrow = T), digits=3),include.rownames=FALSE)

print(xtable(matrix(c("J-statistic",round(rgobj1h$Jstat,2),round(rgobj1i$Jstat,2),
                      round(rgobj1j$Jstat,2),round(rgobj1k$Jstat,2),
                      "df",rgobj1h$df,rgobj1i$df,rgobj1j$df,rgobj1k$df,
                      "p-value",round(rgobj1h$pvalJ,2),round(rgobj1i$pvalJ,2),
                      round(rgobj1j$pvalJ,2),round(rgobj1k$pvalJ,2),
                      "R",round(rgobj1h$R2,2),round(rgobj1i$R2,2),
                      round(rgobj1j$R2,2),round(rgobj1k$R2,2)),
                    ncol=5, byrow = T), digits=2),include.rownames=FALSE)

#####################################################################
# Replicate Table 4.1 Partial effects for Subjects
#####################################################################

### Specification 1: Reading ###

Sum_measures1 <- Sum_spatial(b=rgobj1$coefs[3], rho=rgobj1$coefs[1], WSM1)
length(Sum_measures1)

varsm1 <- rgobj1$VC[c(1,3),c(1,3)]
theta1 <- c(rgobj1$coefs[1], rgobj1$coefs[3])

nsim=10000; set.seed(101)
simpar1<- mvtnorm::rmvnorm(n=1.5*nsim,mean = theta1, sigma = varsm1)
simpar1 = simpar1[which(abs(simpar1[,1])<1),][1:nsim,]
dim(simpar1)

sum_mat1<- matrix(NA,nsim,length(Sum_measures1))
dim(sum_mat1)

for (i in 1:nsim) {
  sum_mat1[i,] = Sum_spatial(b=simpar1[i,c(-1)], rho=simpar1[i,1], WSM1)
}

Sum_sd1 <- apply(sum_mat1, 2, sd)
Sum_t1 <- Sum_measures1/Sum_sd1
Sum_combined1 <- cbind(Sum_measures1, Sum_sd1, Sum_t1)

par1 = round(Sum_combined1,3)
par1

par1d = quantile(sum_mat1[,1],prob=c(0.025,0.5,0.975))
par1b = quantile(sum_mat1[,2],prob=c(0.025,0.5,0.975))
par1c = quantile(sum_mat1[,3],prob=c(0.025,0.5,0.975))

ci1b = paste("[",round(par1b[1],1),";",round(par1b[3],1),"]")
ci1c = paste("[",round(par1c[1],1),";",round(par1c[3],1),"]")
ci1d = paste("[",round(par1d[1],1),";",round(par1d[3],1),"]")

# ================================================================>

### Specification 2: Math ###

Sum_measures2 <- Sum_spatial(b=rgobj2$coefs[3], rho=rgobj2$coefs[1], WSM1)
length(Sum_measures2)

varsm2 <- rgobj2$VC[c(1,3),c(1,3)]
theta2 <- c(rgobj2$coefs[1], rgobj2$coefs[3])
ncol(varsm2)==length(theta2)

nsim=10000; set.seed(101)
simpar2<- mvtnorm::rmvnorm(n=1.5*nsim,mean = theta2, sigma = varsm2)
simpar2 = simpar2[which(abs(simpar2[,1])<1),][1:nsim,]
dim(simpar2)

sum_mat2<- matrix(NA,nsim,length(Sum_measures2))
dim(sum_mat2)

for (i in 1:nsim) {
  sum_mat2[i,] = Sum_spatial(b=simpar2[i,-1], rho=simpar2[i,1], WSM1)
}

Sum_sd2 <- apply(sum_mat2, 2, sd)
Sum_t2 <- Sum_measures2/Sum_sd2
Sum_combined2 <- cbind(Sum_measures2, Sum_sd2, Sum_t2)

par2 = round(Sum_combined2,3)
par2

par2d = quantile(sum_mat2[,1],prob=c(0.025,0.5,0.975))
par2b = quantile(sum_mat2[,2],prob=c(0.025,0.5,0.975))
par2c = quantile(sum_mat2[,3],prob=c(0.025,0.5,0.975))

ci2b = paste("[",round(par2b[1],1),";",round(par2b[3],1),"]")
ci2c = paste("[",round(par2c[1],1),";",round(par2c[3],1),"]")
ci2d = paste("[",round(par2d[1],1),";",round(par2d[3],1),"]")

# ================================================================>

### Specification 3: Science ###

Sum_measures3 <- Sum_spatial(b=rgobj3$coefs[3], rho=rgobj3$coefs[1], WSM1)
length(Sum_measures3)

varsm3 <- rgobj3$VC[c(1,3),c(1,3)]
theta3 <- c(rgobj3$coefs[1], rgobj3$coefs[3])
ncol(varsm3)==length(theta3)

nsim=10000; set.seed(101)
simpar3<- mvtnorm::rmvnorm(n=1.5*nsim,mean = theta3, sigma = varsm3)
simpar3 = simpar3[which(abs(simpar3[,1])<1),][1:nsim,]
dim(simpar3)

sum_mat3<- matrix(NA,nsim,length(Sum_measures3))
dim(sum_mat3)

for (i in 1:nsim) {
  sum_mat3[i,] = Sum_spatial(b=simpar3[i,-1], rho=simpar3[i,1], WSM1)
}

Sum_sd3 <- apply(sum_mat3, 2, sd)
Sum_t3 <- Sum_measures3/Sum_sd3
Sum_combined3 <- cbind(Sum_measures3, Sum_sd3, Sum_t3)

par3 = round(Sum_combined3,3)
par3

par3b = quantile(sum_mat3[,2],prob=c(0.025,0.5,0.975))
par3c = quantile(sum_mat3[,3],prob=c(0.025,0.5,0.975))
par3d = quantile(sum_mat3[,1],prob=c(0.025,0.5,0.975))

ci3b = paste("[",round(par3b[1],1),";",round(par3b[3],1),"]")
ci3c = paste("[",round(par3c[1],1),";",round(par3c[3],1),"]")
ci3d = paste("[",round(par3d[1],1),";",round(par3d[3],1),"]")

# ================================================================>

# Print Output
R1=c(par1[2,1],ci1b,par1[3,1],ci1c,par1[1,1],ci1d)
R2=c(par2[2,1],ci2b,par2[3,1],ci2c,par2[1,1],ci2d)
R3=c(par3[2,1],ci3b,par3[3,1],ci3c,par3[1,1],ci3d)

# Add all results
Rall = cbind(R1,R2,R3)
colnames(Rall) = c("Est","Est","Est")
rownames(Rall) = c("Local","","Spillover","","Total","")
Rall

print(xtable(Rall,digits=3),row.names=F)

#####################################################################
# Replicate Table 4.2 Partial Effects for Subdomains
#####################################################################

### Specification 1: Assessments ### 

Sum_measures4 <- Sum_spatial(b=rgobj1b$coefs[3], rho=rgobj1b$coefs[1], WSM1)
length(Sum_measures4)

varsm4 <- rgobj1b$VC[c(1,3),c(1,3)]
theta4 <- c(rgobj1b$coefs[1], rgobj1b$coefs[3])
ncol(varsm4)==length(theta4)

nsim=10000; set.seed(101)
simpar4<- mvtnorm::rmvnorm(n=1.5*nsim,mean = theta4, sigma = varsm4)
simpar4 = simpar4[which(abs(simpar4[,1])<1),][1:nsim,]
dim(simpar4)

sum_mat4<- matrix(NA,nsim,length(Sum_measures4))
dim(sum_mat4)

for (i in 1:nsim) {
  sum_mat4[i,] = Sum_spatial(b=simpar4[i,c(-1)], rho=simpar4[i,1], WSM1)
}

Sum_sd4 <- apply(sum_mat4, 2, sd)
Sum_t4 <- Sum_measures4/Sum_sd4
Sum_combined4 <- cbind(Sum_measures4, Sum_sd4, Sum_t4)

par4 = round(Sum_combined4,3)
par4

par4b = quantile(sum_mat4[,2],prob=c(0.025,0.5,0.975))
par4c = quantile(sum_mat4[,3],prob=c(0.025,0.5,0.975))
par4d = quantile(sum_mat4[,1],prob=c(0.025,0.5,0.975))

ci4b = paste("[",round(par4b[1],1),";",round(par4b[3],1),"]")
ci4c = paste("[",round(par4c[1],1),";",round(par4c[3],1),"]")
ci4d = paste("[",round(par4d[1],1),";",round(par4d[3],1),"]")

# ================================================================>

### Specification 2: Textbooks ### 

Sum_measures5 <- Sum_spatial(b=rgobj1c$coefs[3], rho=rgobj1c$coefs[1], WSM1)
length(Sum_measures5)

varsm5 <- rgobj1c$VC[c(1,3),c(1,3)]
theta5 <- c(rgobj1c$coefs[1], rgobj1c$coefs[3])
ncol(varsm5)==length(theta5)

nsim=10000; set.seed(101)
simpar5<- mvtnorm::rmvnorm(n=1.5*nsim,mean = theta5, sigma = varsm5)
simpar5 = simpar5[which(abs(simpar5[,1])<1),][1:nsim,]
dim(simpar5)

sum_mat5<- matrix(NA,nsim,length(Sum_measures5))
dim(sum_mat5)

for (i in 1:nsim) {
  sum_mat5[i,] = Sum_spatial(b=simpar5[i,c(-1)], rho=simpar5[i,1], WSM1)
}

Sum_sd5 <- apply(sum_mat5, 2, sd)
Sum_t5 <- Sum_measures5/Sum_sd5
Sum_combined5 <- cbind(Sum_measures5, Sum_sd5, Sum_t5)

par5 = round(Sum_combined5,3)
par5

par5b = quantile(sum_mat5[,2],prob=c(0.025,0.5,0.975))
par5c = quantile(sum_mat5[,3],prob=c(0.025,0.5,0.975))
par5d = quantile(sum_mat5[,1],prob=c(0.025,0.5,0.975))

ci5b = paste("[",round(par5b[1],1),";",round(par5b[3],1),"]")
ci5c = paste("[",round(par5c[1],1),";",round(par5c[3],1),"]")
ci5d = paste("[",round(par5d[1],1),";",round(par5d[3],1),"]")

# ================================================================>

### Specification 3: Course content ### 

Sum_measures6 <- Sum_spatial(b=rgobj1d$coefs[3], rho=rgobj1d$coefs[1], WSM1)
length(Sum_measures6)

varsm6 <- rgobj1d$VC[c(1,3),c(1,3)]
theta6 <- c(rgobj1d$coefs[1], rgobj1d$coefs[3])
ncol(varsm6)==length(theta6)

nsim=10000; set.seed(101)
simpar6<- mvtnorm::rmvnorm(n=1.5*nsim,mean = theta6, sigma = varsm6)
simpar6 = simpar6[which(abs(simpar6[,1])<1),][1:nsim,]
dim(simpar6)

sum_mat6<- matrix(NA,nsim,length(Sum_measures6))
dim(sum_mat6)

for (i in 1:nsim) {
  sum_mat6[i,] = Sum_spatial(b=simpar6[i,c(-1)], rho=simpar6[i,1], WSM1)
}

Sum_sd6 <- apply(sum_mat6, 2, sd)
Sum_t6 <- Sum_measures6/Sum_sd6
Sum_combined6 <- cbind(Sum_measures6, Sum_sd6, Sum_t6)

par6 = round(Sum_combined6,3)
par6

par6b = quantile(sum_mat6[,2],prob=c(0.025,0.5,0.975))
par6c = quantile(sum_mat6[,3],prob=c(0.025,0.5,0.975))
par6d = quantile(sum_mat6[,1],prob=c(0.025,0.5,0.975))

ci6b = paste("[",round(par6b[1],1),";",round(par6b[3],1),"]")
ci6c = paste("[",round(par6c[1],1),";",round(par6c[3],1),"]")
ci6d = paste("[",round(par6d[1],1),";",round(par6d[3],1),"]")

# ================================================================>

### Specification 4: Course choice ### 

Sum_measures7 <- Sum_spatial(b=rgobj1e$coefs[3], rho=rgobj1e$coefs[1], WSM1)
length(Sum_measures7)

varsm7 <- rgobj1e$VC[c(1,3),c(1,3)]
theta7 <- c(rgobj1e$coefs[1], rgobj1e$coefs[3])
ncol(varsm7)==length(theta7)

nsim=10000; set.seed(101)
simpar7<- mvtnorm::rmvnorm(n=1.5*nsim,mean = theta7, sigma = varsm7)
simpar7 = simpar7[which(abs(simpar7[,1])<1),][1:nsim,]
dim(simpar7)

sum_mat7<- matrix(NA,nsim,length(Sum_measures7))
dim(sum_mat7)

for (i in 1:nsim) {
  sum_mat7[i,] = Sum_spatial(b=simpar7[i,c(-1)], rho=simpar7[i,1], WSM1)
}

Sum_sd7 <- apply(sum_mat7, 2, sd)
Sum_t7 <- Sum_measures7/Sum_sd7
Sum_combined7 <- cbind(Sum_measures7, Sum_sd7, Sum_t7)

par7 = round(Sum_combined7,3)
par7

par7b = quantile(sum_mat7[,2],prob=c(0.025,0.5,0.975))
par7c = quantile(sum_mat7[,3],prob=c(0.025,0.5,0.975))
par7d = quantile(sum_mat7[,1],prob=c(0.025,0.5,0.975))

ci7b = paste("[",round(par7b[1],1),";",round(par7b[3],1),"]")
ci7c = paste("[",round(par7c[1],1),";",round(par7c[3],1),"]")
ci7d = paste("[",round(par7d[1],1),";",round(par7d[3],1),"]")

# ================================================================>

### Specification 5: Personnel autonomy ### 

Sum_measures8 <- Sum_spatial(b=rgobj1f$coefs[3], rho=rgobj1f$coefs[1], WSM1)
length(Sum_measures8)

varsm8 <- rgobj1f$VC[c(1,3),c(1,3)]
theta8 <- c(rgobj1f$coefs[1], rgobj1f$coefs[3])
ncol(varsm8)==length(theta8)

nsim=10000; set.seed(101)
simpar8<- mvtnorm::rmvnorm(n=1.5*nsim,mean = theta8, sigma = varsm8)
simpar8 = simpar8[which(abs(simpar8[,1])<1),][1:nsim,]
dim(simpar8)

sum_mat8<- matrix(NA,nsim,length(Sum_measures8))
dim(sum_mat8)

for (i in 1:nsim) {
  sum_mat8[i,] = Sum_spatial(b=simpar8[i,c(-1)], rho=simpar8[i,1], WSM1)
}

Sum_sd8 <- apply(sum_mat8, 2, sd)
Sum_t8 <- Sum_measures8/Sum_sd8
Sum_combined8 <- cbind(Sum_measures8, Sum_sd8, Sum_t8)

par8 = round(Sum_combined8,3)
par8

par8b = quantile(sum_mat8[,2],prob=c(0.025,0.5,0.975))
par8c = quantile(sum_mat8[,3],prob=c(0.025,0.5,0.975))
par8d = quantile(sum_mat8[,1],prob=c(0.025,0.5,0.975))

ci8b = paste("[",round(par8b[1],1),";",round(par8b[3],1),"]")
ci8c = paste("[",round(par8c[1],1),";",round(par8c[3],1),"]")
ci8d = paste("[",round(par8d[1],1),";",round(par8d[3],1),"]")

# ================================================================>

### Specification 6: Budget autonomy ### 

Sum_measures9 <- Sum_spatial(b=rgobj1g$coefs[3], rho=rgobj1g$coefs[1], WSM1)
length(Sum_measures9)

varsm9 <- rgobj1g$VC[c(1,3),c(1,3)]
theta9 <- c(rgobj1g$coefs[1], rgobj1g$coefs[3])
ncol(varsm9)==length(theta9)

nsim=10000; set.seed(101)
simpar9<- mvtnorm::rmvnorm(n=1.5*nsim,mean = theta9, sigma = varsm9)
simpar9 = simpar9[which(abs(simpar9[,1])<1),][1:nsim,]
dim(simpar9)

sum_mat9<- matrix(NA,nsim,length(Sum_measures9))
dim(sum_mat9)

for (i in 1:nsim) {
  sum_mat9[i,] = Sum_spatial(b=simpar9[i,c(-1)], rho=simpar9[i,1], WSM1)
}

Sum_sd9 <- apply(sum_mat9, 2, sd)
Sum_t9 <- Sum_measures9/Sum_sd9
Sum_combined9 <- cbind(Sum_measures9, Sum_sd9, Sum_t9)

par9 = round(Sum_combined9,3)
par9

par9b = quantile(sum_mat9[,2],prob=c(0.025,0.5,0.975))
par9c = quantile(sum_mat9[,3],prob=c(0.025,0.5,0.975))
par9d = quantile(sum_mat9[,1],prob=c(0.025,0.5,0.975))

ci9b = paste("[",round(par9b[1],1),";",round(par9b[3],1),"]")
ci9c = paste("[",round(par9c[1],1),";",round(par9c[3],1),"]")
ci9d = paste("[",round(par9d[1],1),";",round(par9d[3],1),"]")

# ================================================================>

# Print Output
R4=c(par4[2,1],ci4b,par4[3,1],ci4c,par4[1,1],ci4d)
R5=c(par5[2,1],ci5b,par5[3,1],ci5c,par5[1,1],ci5d)
R6=c(par6[2,1],ci6b,par6[3,1],ci6c,par6[1,1],ci6d)
R7=c(par7[2,1],ci7b,par7[3,1],ci7c,par7[1,1],ci7d)
R8=c(par8[2,1],ci8b,par8[3,1],ci8c,par8[1,1],ci8d)
R9=c(par9[2,1],ci9b,par9[3,1],ci9c,par9[1,1],ci9d)

# Add all results
Rall2 = cbind(R4,R5,R6,R7,R8,R9)
colnames(Rall2) = c("Est","Est","Est","Est","Est","Est")
rownames(Rall2) = c("Local","","Spillover","","Total","")

print(xtable(Rall2,digits=3),row.names=F)

#####################################################################
# Replicate Table 4.3 Partial effects for Robustness checks
#####################################################################

### Specification 1: Without ISR and SWE ###

Sum_measures10 <- Sum_spatial(b=rgobj1h$coefs[3], rho=rgobj1h$coefs[1], WSM1d)
length(Sum_measures10)

varsm10 <- rgobj1h$VC[c(1,3),c(1,3)]
theta10 <- c(rgobj1h$coefs[1], rgobj1h$coefs[3])

nsim=10000; set.seed(101)
simpar10<- mvtnorm::rmvnorm(n=1.5*nsim,mean = theta10, sigma = varsm10)
simpar10 = simpar10[which(abs(simpar10[,1])<1),][1:nsim,]
dim(simpar10)

sum_mat10<- matrix(NA,nsim,length(Sum_measures10))
dim(sum_mat10)

for (i in 1:nsim) {
  sum_mat10[i,] = Sum_spatial(b=simpar10[i,c(-1)], rho=simpar10[i,1], WSM1d)
}

Sum_sd10 <- apply(sum_mat10, 2, sd)
Sum_t10 <- Sum_measures10/Sum_sd10
Sum_combined10 <- cbind(Sum_measures10, Sum_sd10, Sum_t10)

par10 = round(Sum_combined10,3)
par10

par10d = quantile(sum_mat10[,1],prob=c(0.025,0.5,0.975))
par10b = quantile(sum_mat10[,2],prob=c(0.025,0.5,0.975))
par10c = quantile(sum_mat10[,3],prob=c(0.025,0.5,0.975))

ci10b = paste("[",round(par10b[1],1),";",round(par10b[3],1),"]")
ci10c = paste("[",round(par10c[1],1),";",round(par10c[3],1),"]")
ci10d = paste("[",round(par10d[1],1),";",round(par10d[3],1),"]")

# ================================================================>

### Specification 2: OECD only ###

Sum_measures11 <- Sum_spatial(b=rgobj1i$coefs[3], rho=rgobj1i$coefs[1], WSM1c)
length(Sum_measures11)

varsm11 <- rgobj1i$VC[c(1,3),c(1,3)]
theta11 <- c(rgobj1i$coefs[1], rgobj1i$coefs[3])

nsim=10000; set.seed(101)
simpar11<- mvtnorm::rmvnorm(n=1.5*nsim,mean = theta11, sigma = varsm11)
simpar11 = simpar11[which(abs(simpar11[,1])<1),][1:nsim,]
dim(simpar11)

sum_mat11<- matrix(NA,nsim,length(Sum_measures11))
dim(sum_mat11)

for (i in 1:nsim) {
  sum_mat11[i,] = Sum_spatial(b=simpar11[i,c(-1)], rho=simpar11[i,1], WSM1c)
}

Sum_sd11 <- apply(sum_mat11, 2, sd)
Sum_t11 <- Sum_measures11/Sum_sd11
Sum_combined11 <- cbind(Sum_measures11, Sum_sd11, Sum_t11)

par11 = round(Sum_combined11,3)
par11

par11d = quantile(sum_mat11[,1],prob=c(0.025,0.5,0.975))
par11b = quantile(sum_mat11[,2],prob=c(0.025,0.5,0.975))
par11c = quantile(sum_mat11[,3],prob=c(0.025,0.5,0.975))

ci11b = paste("[",round(par11b[1],1),";",round(par11b[3],1),"]")
ci11c = paste("[",round(par11c[1],1),";",round(par11c[3],1),"]")
ci11d = paste("[",round(par11d[1],1),";",round(par11d[3],1),"]")

# ================================================================>

### Specification 3: Europe only ###

Sum_measures12 <- Sum_spatial(b=rgobj1j$coefs[3], rho=rgobj1j$coefs[1], WSM1b)
length(Sum_measures12)

varsm12 <- rgobj1j$VC[c(1,3),c(1,3)]
theta12 <- c(rgobj1j$coefs[1], rgobj1j$coefs[3])

nsim=10000; set.seed(101)
simpar12<- mvtnorm::rmvnorm(n=1.5*nsim,mean = theta12, sigma = varsm12)
simpar12 = simpar12[which(abs(simpar12[,1])<1),][1:nsim,]
dim(simpar12)

sum_mat12<- matrix(NA,nsim,length(Sum_measures12))
dim(sum_mat12)

for (i in 1:nsim) {
  sum_mat12[i,] = Sum_spatial(b=simpar12[i,c(-1)], rho=simpar12[i,1], WSM1b)
}

Sum_sd12 <- apply(sum_mat12, 2, sd)
Sum_t12 <- Sum_measures12/Sum_sd12
Sum_combined12 <- cbind(Sum_measures12, Sum_sd12, Sum_t12)

par12 = round(Sum_combined12,3)
par12

par12d = quantile(sum_mat12[,1],prob=c(0.025,0.5,0.975))
par12b = quantile(sum_mat12[,2],prob=c(0.025,0.5,0.975))
par12c = quantile(sum_mat12[,3],prob=c(0.025,0.5,0.975))

ci12b = paste("[",round(par12b[1],1),";",round(par12b[3],1),"]")
ci12c = paste("[",round(par12c[1],1),";",round(par12c[3],1),"]")
ci12d = paste("[",round(par12d[1],1),";",round(par12d[3],1),"]")

# ================================================================>

### Specification 4: Country fixed ###

Sum_measures13 <- Sum_spatial(b=rgobj1k$coefs[3], rho=rgobj1k$coefs[1], WSM1)
length(Sum_measures13)

varsm13 <- rgobj1k$VC[c(1,3),c(1,3)]
theta13 <- c(rgobj1k$coefs[1], rgobj1h$coefs[3])

nsim=10000; set.seed(101)
simpar13<- mvtnorm::rmvnorm(n=1.5*nsim,mean = theta13, sigma = varsm13)
simpar13 = simpar13[which(abs(simpar13[,1])<1),][1:nsim,]
dim(simpar13)

sum_mat13<- matrix(NA,nsim,length(Sum_measures13))
dim(sum_mat13)

for (i in 1:nsim) {
  sum_mat13[i,] = Sum_spatial(b=simpar13[i,c(-1)], rho=simpar13[i,1], WSM1)
}

Sum_sd13 <- apply(sum_mat13, 2, sd)
Sum_t13 <- Sum_measures13/Sum_sd13
Sum_combined13 <- cbind(Sum_measures13, Sum_sd13, Sum_t13)

par13 = round(Sum_combined13,3)
par13

par13d = quantile(sum_mat13[,1],prob=c(0.025,0.5,0.975))
par13b = quantile(sum_mat13[,2],prob=c(0.025,0.5,0.975))
par13c = quantile(sum_mat13[,3],prob=c(0.025,0.5,0.975))

ci13b = paste("[",round(par13b[1],1),";",round(par13b[3],1),"]")
ci13c = paste("[",round(par13c[1],1),";",round(par13c[3],1),"]")
ci13d = paste("[",round(par13d[1],1),";",round(par13d[3],1),"]")

# ================================================================>

# Print Output
R1=c(par10[2,1],ci10b,par10[3,1],ci10c,par10[1,1],ci10d)
R2=c(par11[2,1],ci11b,par11[3,1],ci11c,par11[1,1],ci11d)
R3=c(par12[2,1],ci12b,par12[3,1],ci12c,par12[1,1],ci12d)
R4=c(par13[2,1],ci13b,par13[3,1],ci13c,par13[1,1],ci13d)

# Add all results
Rall3 = cbind(R1,R2,R3,R4)
colnames(Rall3) = c("Est","Est","Est","Est")
rownames(Rall3) = c("Local","","Spillover","","Total","")
Rall3

print(xtable(Rall3,digits=3),row.names=F)