/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * randsample.c
 *
 * Code generation for function 'randsample'
 *
 */

/* Include files */
#include "mwmathutil.h"
#include "rt_nonfinite.h"
#include "CCRl_clus.h"
#include "randsample.h"
#include "CCRl_clus_emxutil.h"
#include "rand.h"
#include "CCRl_clus_data.h"

/* Function Definitions */
void randsample(real_T varargin_1, real_T varargin_2, emxArray_real_T *y)
{
  real_T n;
  int32_T k_tmp;
  int32_T j;
  emxArray_boolean_T *selected;
  emxArray_real_T *rp;
  emxArray_int32_T *idx;
  int32_T nsel;
  int32_T b_n;
  real_T r;
  emxArray_int32_T *iwork;
  int32_T i2;
  int32_T k;
  int32_T pEnd;
  int32_T p;
  int32_T q;
  int32_T qEnd;
  int32_T kEnd;
  emlrtHeapReferenceStackEnterFcnR2012b(emlrtRootTLSGlobal);
  n = muDoubleScalarFloor(varargin_1);
  k_tmp = (int32_T)muDoubleScalarFloor(varargin_2);
  j = y->size[0];
  y->size[0] = k_tmp;
  emxEnsureCapacity_real_T(y, j);
  if ((k_tmp << 2) > n) {
    emxInit_real_T(&rp, 2, true);
    emxInit_int32_T(&idx, 2, true);
    b_rand(n, rp);
    b_n = rp->size[1] + 1;
    j = idx->size[0] * idx->size[1];
    idx->size[0] = 1;
    idx->size[1] = rp->size[1];
    emxEnsureCapacity_int32_T(idx, j);
    nsel = rp->size[1];
    for (j = 0; j < nsel; j++) {
      idx->data[j] = 0;
    }

    if (rp->size[1] != 0) {
      emxInit_int32_T(&iwork, 1, true);
      j = iwork->size[0];
      iwork->size[0] = rp->size[1];
      emxEnsureCapacity_int32_T(iwork, j);
      j = rp->size[1] - 1;
      for (k = 1; k <= j; k += 2) {
        if ((rp->data[k - 1] <= rp->data[k]) || muDoubleScalarIsNaN(rp->data[k]))
        {
          idx->data[k - 1] = k;
          idx->data[k] = k + 1;
        } else {
          idx->data[k - 1] = k + 1;
          idx->data[k] = k;
        }
      }

      if ((rp->size[1] & 1) != 0) {
        idx->data[rp->size[1] - 1] = rp->size[1];
      }

      nsel = 2;
      while (nsel < b_n - 1) {
        i2 = nsel << 1;
        j = 1;
        for (pEnd = 1 + nsel; pEnd < b_n; pEnd = qEnd + nsel) {
          p = j;
          q = pEnd - 1;
          qEnd = j + i2;
          if (qEnd > b_n) {
            qEnd = b_n;
          }

          k = 0;
          kEnd = qEnd - j;
          while (k + 1 <= kEnd) {
            if ((rp->data[idx->data[p - 1] - 1] <= rp->data[idx->data[q] - 1]) ||
                muDoubleScalarIsNaN(rp->data[idx->data[q] - 1])) {
              iwork->data[k] = idx->data[p - 1];
              p++;
              if (p == pEnd) {
                while (q + 1 < qEnd) {
                  k++;
                  iwork->data[k] = idx->data[q];
                  q++;
                }
              }
            } else {
              iwork->data[k] = idx->data[q];
              q++;
              if (q + 1 == qEnd) {
                while (p < pEnd) {
                  k++;
                  iwork->data[k] = idx->data[p - 1];
                  p++;
                }
              }
            }

            k++;
          }

          for (k = 0; k < kEnd; k++) {
            idx->data[(j + k) - 1] = iwork->data[k];
          }

          j = qEnd;
        }

        nsel = i2;
      }

      emxFree_int32_T(&iwork);
    }

    nsel = rp->size[0];
    i2 = rp->size[1];
    j = rp->size[0] * rp->size[1];
    rp->size[0] = 1;
    rp->size[1] = i2;
    emxEnsureCapacity_real_T(rp, j);
    nsel *= i2;
    for (j = 0; j < nsel; j++) {
      rp->data[j] = idx->data[j];
    }

    emxFree_int32_T(&idx);
    for (j = 0; j < k_tmp; j++) {
      y->data[j] = (int32_T)rp->data[j];
    }

    emxFree_real_T(&rp);
  } else {
    emxInit_boolean_T(&selected, 2, true);
    j = selected->size[0] * selected->size[1];
    selected->size[0] = 1;
    nsel = (int32_T)n;
    selected->size[1] = nsel;
    emxEnsureCapacity_boolean_T(selected, j);
    for (j = 0; j < nsel; j++) {
      selected->data[j] = false;
    }

    nsel = 0;
    while (nsel < k_tmp) {
      r = c_rand();
      r = muDoubleScalarFloor(r * n);
      if (!selected->data[(int32_T)(1.0 + r) - 1]) {
        selected->data[(int32_T)(1.0 + r) - 1] = true;
        nsel++;
        y->data[nsel - 1] = 1.0 + r;
      }
    }

    emxFree_boolean_T(&selected);
  }

  emlrtHeapReferenceStackLeaveFcnR2012b(emlrtRootTLSGlobal);
}

/* End of code generation (randsample.c) */
