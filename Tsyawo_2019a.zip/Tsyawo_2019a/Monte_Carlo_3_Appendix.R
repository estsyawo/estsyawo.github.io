#==========================================================================================>
# Author: Emmanuel S. Tsyawo
# Purpose: Simulate data for Tsyawo 2019b
# Date: March 28, 2019
# Last Update: July 19, 2019
#----------------------
# Set working directory to source file
rm(list = ls())
setwd(dirname(rstudioapi::getActiveDocumentContext()$path)) 
#set directory to source file
list.files() #see files in directory
source("Functions.R")
library(bayesprdopt)
library(pracma)
library(BB)
#==========================================================================================>
# Note: The data should be sorted first by individual identifiers (numbered 1:N)
# and then by time (1:T). See gen_dd() for example of generated code.
#=====================================================================================>
# Simulations with weight polynomial approximation of the weight function
# Note: Good starting values are crucial
#========================================================================================>
Ndd = 10; Tpdd = 6
#gdat_dds<- function(N,Tp,seed,fun=fn4,sder)
dat_dd=gdat_dds(N=Ndd,Tp=Tpdd,fun=fn2S,seed=2,sder=.1);
#dat_dd=gdat_dds(N=Ndd,Tp=Tpdd,seed=20,sder=.1);

polyexp_s(1.2,2.3,3) # takes polynomial expansion
k=2; lp=k*(k+3)/2; 
#k=3; lp=k*(k+3)/2; 

#order of parameter vector: pars - first nt are delta, nt+1 is rho, nt+2 is alpha, and nt+3 is beta
startp = rep(0.0,(lp+3)) #; (startp = c(runif(lp,-.5,.5),0.8,-0.2,0.6))

ncd_lmSs(pars=startp,Y=dat_dd$Y,X=dat_dd$X,Tid=dat_dd$tpID,Pid = dat_dd$psID,
         fun=polyexp_s,k=k,utid = c(2:Tpdd))

system.time((Ob_dd = optim(par = startp,fn=ncd_lmSs,Y=dat_dd$Y,X=dat_dd$X,
               Tid=dat_dd$tpID,Pid = dat_dd$psID,fun=polyexp_s,k=k,utid = c(2:Tpdd),method = "BFGS"))
)
Ob_dd
Ob_dd$par[-c(1:lp)] #parameters of interest
# true parameter values are: [0.5,0.0,0.5]
startp = Ob_dd$par #for fast convergence
#========================================================================================>
# Set parameters
dSize<- c(5,10,30,50); # N,T of data to consider
nSim = 1000; # Number of simulations
#startp = rep(0.6,3) # starting vector for optim

# function to be used for simulations
simfun<- function(N,Tp,seed)
{
  dat_dd=gdat_dds(N=N,Tp=Tp,fun=fn2S,seed=seed,sder=.1) #generate data
  Ob_dd = optim(par = startp,fn=ncd_lmSs,Y=dat_dd$Y,X=dat_dd$X,
                Tid=dat_dd$tpID,Pid = dat_dd$psID,fun=polyexp_s,k=k,
                utid = c(2:Tp)) #,method = "BFGS"
  Ob_dd$par[-c(1:lp)]-c(0.5,0.0,0.5) #return bias
}
#example:
simfun(N=10,Tp=11,seed = 200)


# Monte Carlo simulations
simBias<- list() #list to store results
ldSize<- length(dSize)

for (n in 4:ldSize) {
  for (t in 3:ldSize) {
    id = (n-1)*ldSize + t
    cat("n = ",dSize[n],", t = ",dSize[t],", id = ",id,", \n")
    fn = function(seed) simfun(N=dSize[n],Tp=(dSize[t]+1),seed = seed)
    simBias[[id]]=bayesprdopt::parsply(X=(1:nSim),fn=fn,type = "FORK",nc=3)
    #simBias[[id]]=sapply(X=(1:nSim),FUN = fn)
  }
}




#========================================================================================>
# Functions for analyses:
# mean, median absolute deviation, root mean squared error
MAD<- function(y) median(abs(y))
RMSE<- function(y) sqrt(mean(y^2))

# Table for mean bias
rmatalf<-rmatrho<-rmatbet<- matrix(NA,4,12)

for (n in 1:ldSize) {
  for (t in 1:ldSize) {
    id = (n-1)*ldSize + t
    cat("n = ",dSize[n],", t = ",dSize[t],", id = ",id,", \n")
    vMB=apply(simBias[[id]],1,mean)
    rmatalf[n,t]=vMB[1]; rmatrho[n,t]=vMB[2]; 
    vMAD=apply(simBias[[id]],1,MAD)
    rmatalf[n,ldSize+t]=vMAD[1];rmatrho[n,ldSize+t]=vMAD[2]
    vRMSE<- apply(simBias[[id]],1,RMSE)
    rmatalf[n,2*ldSize+t]=vRMSE[1];rmatrho[n,2*ldSize+t]=vRMSE[2]
  }
}

# Print out matrices for tex tables

apply(rmatalf, 1, function(x)paste(round(x,3),collapse = " & "))
apply(rmatrho, 1, function(x)paste(round(x,3),collapse = " & "))
