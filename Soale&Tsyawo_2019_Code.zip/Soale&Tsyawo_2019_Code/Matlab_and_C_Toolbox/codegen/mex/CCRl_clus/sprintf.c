/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * sprintf.c
 *
 * Code generation for function 'sprintf'
 *
 */

/* Include files */
#include "rt_nonfinite.h"
#include "CCRl_clus.h"
#include "sprintf.h"
#include "CCRl_clus_emxutil.h"
#include "CCRl_clus_data.h"

/* Function Definitions */
void b_sprintf(uint64_T varargin_1, real_T varargin_2, real_T varargin_3)
{
  emxArray_char_T *charStr;
  int32_T nbytes;
  int32_T i9;
  emlrtHeapReferenceStackEnterFcnR2012b(emlrtRootTLSGlobal);
  emxInit_char_T(&charStr, 2, true);
  nbytes = (int32_T)emlrtMexSnprintf(NULL, 0,
    "iter = %llu fval = %0.5f and dev = %0.5f", varargin_1, varargin_2,
    varargin_3) + 1;
  i9 = charStr->size[0] * charStr->size[1];
  charStr->size[0] = 1;
  charStr->size[1] = nbytes;
  emxEnsureCapacity_char_T(charStr, i9);
  emlrtMexSnprintf(&charStr->data[0], (size_t)nbytes,
                   "iter = %llu fval = %0.5f and dev = %0.5f", varargin_1,
                   varargin_2, varargin_3);
  emxFree_char_T(&charStr);
  emlrtHeapReferenceStackLeaveFcnR2012b(emlrtRootTLSGlobal);
}

/* End of code generation (sprintf.c) */
