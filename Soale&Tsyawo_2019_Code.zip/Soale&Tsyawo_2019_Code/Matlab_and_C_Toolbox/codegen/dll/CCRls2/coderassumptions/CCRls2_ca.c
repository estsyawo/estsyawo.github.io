/*
 * File: CCRls2_ca.c
 *
 * Abstract: Tests assumptions in the generated code.
 */

#include "CCRls2_ca.h"

CA_HWImpl_TestResults CA_CCRls2_HWRes;
CA_PWS_TestResults CA_CCRls2_PWSRes;
const CA_HWImpl CA_CCRls2_ExpHW = {
  8,                                   /* BitPerChar */
  16,                                  /* BitPerShort */
  32,                                  /* BitPerInt */
  64,                                  /* BitPerLong */
  64,                                  /* BitPerLongLong */
  32,                                  /* BitPerFloat */
  64,                                  /* BitPerDouble */
  64,                                  /* BitPerPointer */
  64,                                  /* BitPerSizeT */
  64,                                  /* BitPerPtrDiffT */
  CA_LITTLE_ENDIAN,                    /* Endianess */
  CA_ZERO,                             /* IntDivRoundTo */
  1,                                   /* ShiftRightIntArith */
  1,                                   /* LongLongMode */
  0,                                   /* PortableWordSizes */
  "Generic->MATLAB Host Computer",     /* HWDeviceType */
  0,                                   /* MemoryAtStartup */
  0,                                   /* DenormalFlushToZero */
  0                                    /* DenormalAsZero */
};

CA_HWImpl CA_CCRls2_ActHW;
void CCRls2_caRunTests(void)
{
  /* verify hardware implementation */
  caVerifyPortableWordSizes(&CA_CCRls2_ActHW, &CA_CCRls2_ExpHW,
    &CA_CCRls2_PWSRes);
  caVerifyHWImpl(&CA_CCRls2_ActHW, &CA_CCRls2_ExpHW, &CA_CCRls2_HWRes);
}
