#=====================================================
# Clustered Monte Carlo library
# Purpose:
#   Provide the clustered-sampling simulation arm used in CLT_U_Stats.tex,
#   Section Sect:Simulations. The design is calibrated to the Park-Shin county
#   income application, with centred order-2 Gini mean-difference and centred
#   order-3 third L-moment statistics.
# Inputs:
#   None when sourced.
# Outputs:
#   Reusable simulation, summary, and table-writing functions.
# Side effects:
#   None when sourced; functions may write files and print progress when called.
#=====================================================

# Manuscript-facing note:
#   The public grid runner in this file feeds the clustered Monte Carlo table
#   reported in `Sect:Sim_Cluster`.

#=====================================================
# Empirical calibration inputs
#=====================================================

default_park_shin_pi_path <- function() {
  file.path(sim_root, "data", "park_shin_PI.txt")
}

load_park_shin_state_sizes <- function(path = default_park_shin_pi_path()) {
  raw <- read.table(path, header = FALSE)
  county_fips <- raw[[1L]]
  state_fips <- county_fips %/% 1000L
  as.integer(table(state_fips))
}

load_park_shin_income_quantiles <- function(path = default_park_shin_pi_path(), year = 2017L) {
  raw <- read.table(path, header = FALSE)
  names(raw) <- c("county_fips", as.character(1970:2017))
  y <- raw[[as.character(year)]]
  sort(y[is.finite(y) & y > 0])
}

#=====================================================
# Distribution and target helpers
#=====================================================

empirical_quantile_type1 <- function(sorted_values, u) {
  u <- pmin(pmax(u, .Machine$double.eps), 1 - .Machine$double.eps)
  sorted_values[pmax(1L, ceiling(u * length(sorted_values)))]
}

empirical_gmd_target <- function(sorted_values) {
  n <- length(sorted_values)
  if (n < 2L) stop("Need at least two empirical outcome values.")
  rank <- seq_len(n)
  2 * sum((2 * rank - n - 1) * sorted_values) / n^2
}

empirical_l3_target <- function(sorted_values) {
  n <- length(sorted_values)
  if (n < 3L) stop("Need at least three empirical outcome values.")
  rank <- seq_len(n)
  p_max <- (rank / n)^3 - ((rank - 1) / n)^3
  p_min <- ((n - rank + 1) / n)^3 - ((n - rank) / n)^3
  p_median <- (6 * (rank - 1) * (n - rank) + 3 * (n - 1) + 1) / n^3
  sum((p_max + p_min - 2 * p_median) * sorted_values) / 3
}

#=====================================================
# Cluster-size construction
#=====================================================

bounded_largest_remainder <- function(weights, total, cap, min_size = 1L) {
  G <- length(weights)
  if (G * min_size > total) stop("Too many clusters for the target sample size.")
  if (G * cap < total) stop("Cluster-size cap is too small for the target sample size.")

  sizes <- rep(min_size, G)
  remaining <- total - sum(sizes)
  if (remaining == 0L) return(sizes)

  weights <- pmax(as.numeric(weights), .Machine$double.eps)
  quota <- remaining * weights / sum(weights)
  add <- pmin(floor(quota), cap - min_size)
  sizes <- sizes + add
  remaining <- total - sum(sizes)

  if (remaining > 0L) {
    remainder <- quota - floor(quota)
    open <- which(sizes < cap)
    ord <- open[order(remainder[open], decreasing = TRUE)]
    while (remaining > 0L) {
      if (length(ord) == 0L) stop("Unable to allocate remaining units under the cap.")
      take <- ord[seq_len(min(remaining, length(ord)))]
      sizes[take] <- sizes[take] + 1L
      remaining <- total - sum(sizes)
      ord <- ord[sizes[ord] < cap]
    }
  }

  sizes
}

make_cluster_sizes <- function(n_target, beta = 0.25, cap_multiplier = 4, empirical_sizes = NULL) {
  if (beta <= 0 || beta >= 0.5) stop("beta must lie in (0, 1/2).")
  if (is.null(empirical_sizes)) empirical_sizes <- load_park_shin_state_sizes()

  G_n <- min(n_target, max(2L, ceiling(n_target^(1 - beta))))
  u <- (seq_len(G_n) - 0.5) / G_n
  q_shape <- as.numeric(stats::quantile(empirical_sizes, probs = u, type = 1, names = FALSE))
  q_shape <- q_shape / mean(q_shape)

  cap <- max(2L, ceiling(cap_multiplier * n_target^beta))
  sizes <- bounded_largest_remainder(q_shape, total = n_target, cap = cap, min_size = 1L)
  sizes[order(q_shape, decreasing = TRUE)]
}

cluster_n_target_for_G <- function(G_target, beta = 0.25) {
  if (beta <= 0 || beta >= 0.5) stop("beta must lie in (0, 1/2).")
  if (G_target < 2L) stop("G_target must be at least 2.")

  lower <- max(1L, floor((G_target - 1L)^(1 / (1 - beta))) + 1L)
  upper <- max(lower, floor(G_target^(1 / (1 - beta))))
  candidates <- lower:upper
  hit <- candidates[ceiling(candidates^(1 - beta)) == G_target]
  if (length(hit) == 0L) stop("No integer n_target yields the requested G_target.")
  hit[1L]
}

#=====================================================
# Data-generation layer
#=====================================================

simulate_W <- function(cluster_sizes, rho, outcome_quantiles) {
  G <- length(cluster_sizes)
  n <- sum(cluster_sizes)
  cluster_id <- rep(seq_len(G) - 1L, cluster_sizes)
  Z <- rnorm(G)
  eps <- rnorm(n)
  latent <- sqrt(rho) * Z[cluster_id + 1L] + sqrt(1 - rho) * eps
  W <- empirical_quantile_type1(outcome_quantiles, pnorm(latent))
  list(W = W, cluster_id = cluster_id)
}

generate_clustered_gini_replicates <- function(n_target, n_reps, rho = 0.5, sigma = NULL, seed = 1, outcome_quantiles = NULL, beta = 0.25, cap_multiplier = 4) {
  set.seed(seed)
  if (is.null(outcome_quantiles)) outcome_quantiles <- load_park_shin_income_quantiles()
  theta <- empirical_gmd_target(outcome_quantiles)
  l3_target <- empirical_l3_target(outcome_quantiles)
  sizes <- make_cluster_sizes(n_target, beta = beta, cap_multiplier = cap_multiplier)
  replicate(n_reps, {
    dat <- simulate_W(sizes, rho, outcome_quantiles)
    list(W = dat$W, cluster_id = dat$cluster_id, theta = theta, l3_target = l3_target)
  }, simplify = FALSE)
}

#=====================================================
# One-replication evaluators
#=====================================================

clustered_gini_one_replication <- function(rep_data) {
  n <- length(rep_data$W)
  res <- cluster_gini_stat_cpp(rep_data$W, rep_data$cluster_id, rep_data$theta)
  mean_diff <- abs(mean(res$loo_avg) - res$U_phi_n)
  mean_tol <- 1e-6 * max(1, abs(res$U_phi_n), abs(mean(res$loo_avg)))
  if (!is.finite(mean_diff) || mean_diff > mean_tol) {
    stop(sprintf(
      "The leave-one-out vector does not average to the U-statistic: diff=%g, tol=%g.",
      mean_diff, mean_tol
    ))
  }
  projection <- res$loo_avg - res$U_phi_n
  se_rob <- sqrt(res$hat_sigma2 / n)
  se_iid <- sqrt(4 * mean(projection^2) / n)
  tstat_rob <- res$U_phi_n / se_rob
  tstat_iid <- res$U_phi_n / se_iid
  c(
    U = res$U_phi_n,
    hat_sigma2_rob = res$hat_sigma2,
    se_rob = se_rob,
    se_iid = se_iid,
    tstat_rob = tstat_rob,
    tstat_iid = tstat_iid,
    n = n
  )
}

clustered_l3_projection <- function(W, cluster_id) {
  keep <- is.finite(W)
  W <- W[keep]
  cluster_id <- cluster_id[keep]
  n <- length(W)
  if (n < 4L) stop("Need at least four observations for the third L-moment.")

  ord <- order(W)
  W_sorted <- W[ord]
  rank <- seq_len(n)
  choose2 <- function(x) x * (x - 1) / 2
  total_triples <- choose(n, 3)

  theta_weight <- (
    choose2(rank - 1) -
      2 * (rank - 1) * (n - rank) +
      choose2(n - rank)
  ) / (3 * total_triples)
  l3_hat <- sum(theta_weight * W_sorted)

  prefix <- c(0, cumsum(W_sorted))
  prefix_weighted <- c(0, cumsum(rank * W_sorted))
  total_W <- prefix[n + 1L]
  total_weighted <- prefix_weighted[n + 1L]

  below <- rank - 1
  above <- n - rank
  below_sum <- prefix[rank]
  above_sum <- total_W - prefix[rank + 1L]
  below_weighted_sum <- prefix_weighted[rank]
  above_weighted_sum <- total_weighted - prefix_weighted[rank + 1L]

  lower_high <- below_weighted_sum - below_sum
  lower_low <- below * below_sum - below_weighted_sum
  both_below <- choose2(below) * W_sorted - 2 * lower_high + lower_low

  upper_high <- above_weighted_sum - (rank + 1) * above_sum
  upper_low <- n * above_sum - above_weighted_sum
  both_above <- choose2(above) * W_sorted + upper_high - 2 * upper_low

  one_each <- below * above_sum + above * below_sum - 2 * W_sorted * below * above
  loo_sum_sorted <- (both_below + both_above + one_each) / 3
  loo_avg_sorted <- loo_sum_sorted / choose(n - 1L, 2L)
  loo_avg <- numeric(n)
  loo_avg[ord] <- loo_avg_sorted
  mean_diff <- abs(mean(loo_avg) - l3_hat)
  mean_tol <- 1e-6 * max(1, abs(l3_hat), abs(mean(loo_avg)))
  if (!is.finite(mean_diff) || mean_diff > mean_tol) {
    stop(sprintf(
      "The third L-moment leave-one-out vector does not average to the U-statistic: diff=%g, tol=%g.",
      mean_diff, mean_tol
    ))
  }

  projection <- loo_avg - l3_hat
  cluster_sum <- tapply(3 * projection, cluster_id, sum)
  hat_sigma2_rob <- sum(cluster_sum^2) / n
  hat_sigma2_iid <- 9 * mean(projection^2)
  list(
    l3 = l3_hat,
    loo_avg = loo_avg,
    projection = projection,
    hat_sigma2_rob = hat_sigma2_rob,
    hat_sigma2_iid = hat_sigma2_iid
  )
}

clustered_l3_one_replication <- function(rep_data) {
  n <- length(rep_data$W)
  res <- clustered_l3_projection(rep_data$W, rep_data$cluster_id)
  se_rob <- sqrt(res$hat_sigma2_rob / n)
  se_iid <- sqrt(res$hat_sigma2_iid / n)
  tstat_rob <- (res$l3 - rep_data$l3_target) / se_rob
  tstat_iid <- (res$l3 - rep_data$l3_target) / se_iid
  c(
    L3 = res$l3,
    l3_target = rep_data$l3_target,
    hat_sigma2_rob = res$hat_sigma2_rob,
    hat_sigma2_iid = res$hat_sigma2_iid,
    se_rob = se_rob,
    se_iid = se_iid,
    tstat_rob = tstat_rob,
    tstat_iid = tstat_iid,
    n = n
  )
}

clustered_gini_l3_one_replication <- function(rep_data) {
  gmd <- clustered_gini_one_replication(rep_data)
  l3 <- clustered_l3_one_replication(rep_data)
  c(
    gmd_U = unname(gmd["U"]),
    gmd_se_rob = unname(gmd["se_rob"]),
    gmd_se_iid = unname(gmd["se_iid"]),
    gmd_tstat_rob = unname(gmd["tstat_rob"]),
    gmd_tstat_iid = unname(gmd["tstat_iid"]),
    l3_U = unname(l3["L3"]),
    l3_target = unname(l3["l3_target"]),
    l3_se_rob = unname(l3["se_rob"]),
    l3_se_iid = unname(l3["se_iid"]),
    l3_tstat_rob = unname(l3["tstat_rob"]),
    l3_tstat_iid = unname(l3["tstat_iid"]),
    n = unname(gmd["n"])
  )
}

#=====================================================
# Monte Carlo summaries
#=====================================================

summarise_clustered_gini_l3_results <- function(out) {
  gmd_rejections_rob <- summarise_t_rejections(out$gmd_tstat_rob)
  names(gmd_rejections_rob) <- paste0("gmd_rob_", names(gmd_rejections_rob))
  gmd_rejections_iid <- summarise_t_rejections(out$gmd_tstat_iid)
  names(gmd_rejections_iid) <- paste0("gmd_iid_", names(gmd_rejections_iid))
  l3_rejections_rob <- summarise_t_rejections(out$l3_tstat_rob)
  names(l3_rejections_rob) <- paste0("l3_rob_", names(l3_rejections_rob))
  l3_rejections_iid <- summarise_t_rejections(out$l3_tstat_iid)
  names(l3_rejections_iid) <- paste0("l3_iid_", names(l3_rejections_iid))
  iqr_w <- unname(stats::quantile(load_park_shin_income_quantiles(), probs = 0.75, type = 1, names = FALSE) -
                    stats::quantile(load_park_shin_income_quantiles(), probs = 0.25, type = 1, names = FALSE))

  c(
    mean_gmd = mean(out$gmd_U),
    mc_sd_gmd = sd(out$gmd_U),
    mc_mad_gmd = monte_carlo_mad(out$gmd_U),
    mean_se_gmd_rob = mean(out$gmd_se_rob),
    se_sd_ratio_gmd_rob = mean(out$gmd_se_rob) / sd(out$gmd_U),
    mean_gmd_t_rob = mean(out$gmd_tstat_rob),
    sd_gmd_t_rob = sd(out$gmd_tstat_rob),
    gmd_rejections_rob,
    mean_se_gmd_iid = mean(out$gmd_se_iid),
    se_sd_ratio_gmd_iid = mean(out$gmd_se_iid) / sd(out$gmd_U),
    mean_gmd_t_iid = mean(out$gmd_tstat_iid),
    sd_gmd_t_iid = sd(out$gmd_tstat_iid),
    gmd_rejections_iid,
    target_l3 = mean(out$l3_target),
    mean_l3 = mean(out$l3_U),
    mc_sd_l3 = sd(out$l3_U),
    mc_mad_l3 = monte_carlo_mad(out$l3_U),
    mean_se_l3_rob = mean(out$l3_se_rob),
    se_sd_ratio_l3_rob = mean(out$l3_se_rob) / sd(out$l3_U),
    mean_l3_t_rob = mean(out$l3_tstat_rob),
    sd_l3_t_rob = sd(out$l3_tstat_rob),
    l3_rejections_rob,
    mean_se_l3_iid = mean(out$l3_se_iid),
    se_sd_ratio_l3_iid = mean(out$l3_se_iid) / sd(out$l3_U),
    mean_l3_t_iid = mean(out$l3_tstat_iid),
    sd_l3_t_iid = sd(out$l3_tstat_iid),
    l3_rejections_iid,
    population_iqr = iqr_w,
    mad_iqr_gmd = monte_carlo_mad(out$gmd_U) / iqr_w,
    mad_iqr_l3 = monte_carlo_mad(out$l3_U) / iqr_w
  )
}

#=====================================================
# Legacy order-2 benchmark runner
#=====================================================

# Workflow note:
#   `run_coverage_check()` is retained as a narrow order-2 benchmark. The
#   manuscript-facing clustered results are produced by
#   `run_clustered_gini_l3_check()` and `run_clustered_gini_l3_grid()` below.

run_coverage_check <- function(n_target, n_reps = 2000, rho = 0.5, sigma = NULL, seed = 1, cl = default_sim_cl(), replicates = NULL, output_prefix = NULL, outcome_quantiles = NULL, beta = 0.25, cap_multiplier = 4) {
  n_target <- force(n_target)
  n_reps <- force(n_reps)
  rho <- force(rho)
  sigma <- force(sigma)
  seed <- force(seed)
  output_prefix <- force(output_prefix)
  beta <- force(beta)
  cap_multiplier <- force(cap_multiplier)
  if (is.null(replicates)) {
    replicates <- generate_clustered_gini_replicates(n_target, n_reps, rho, sigma, seed, outcome_quantiles, beta, cap_multiplier)
  } else {
    n_reps <- length(replicates)
  }
  prepare_sim_cluster(
    cl,
    c("cluster_gini_stat_cpp", "clustered_gini_one_replication")
  )
  theta <- replicates[[1L]]$theta
  out <- t(pbapply::pbsapply(replicates, clustered_gini_one_replication, cl = cl))
  out <- as.data.frame(out)
  rejections_rob <- summarise_t_rejections(out$tstat_rob)
  rejections_iid <- summarise_t_rejections(out$tstat_iid)
  summary <- c(
    mean_U = mean(out$U),
    mc_sd = sd(out$U),
    mean_se_rob = mean(out$se_rob),
    mean_se_iid = mean(out$se_iid),
    mean_tstat_rob = mean(out$tstat_rob),
    sd_tstat_rob = sd(out$tstat_rob),
    mean_tstat_iid = mean(out$tstat_iid),
    sd_tstat_iid = sd(out$tstat_iid),
    rejections_rob,
    rejections_iid
  )
  cat(sprintf("n=%6d  rho=%.2f  reps=%d  cl=%s\n", n_target, rho, n_reps, sim_cl_label(cl)))
  cat(sprintf("  empirical target E[U]    = 0.00000  (kernel centred at theta = %.5f)\n", theta))
  cat(sprintf("  mean(U_phi_n)             = %.5f  (should be near 0 under the null)\n", summary["mean_U"]))
  cat(sprintf("  sd(U_phi_n)  (MC)         = %.5f\n", summary["mc_sd"]))
  cat(sprintf("  mean(SE robust / iid)     = %.5f / %.5f\n", summary["mean_se_rob"], summary["mean_se_iid"]))
  cat(sprintf("  robust rejection 1/5/10%%  = %.4f, %.4f, %.4f\n", rejections_rob["reject_1pct"], rejections_rob["reject_5pct"], rejections_rob["reject_10pct"]))
  cat(sprintf("  iid rejection 1/5/10%%     = %.4f, %.4f, %.4f\n", rejections_iid["reject_1pct"], rejections_iid["reject_5pct"], rejections_iid["reject_10pct"]))
  cat(sprintf("  mean(t robust / iid)      = %.4f / %.4f\n\n", summary["mean_tstat_rob"], summary["mean_tstat_iid"]))
  output_files <- write_sim_outputs(output_prefix, out, summary)
  invisible(list(results = out, replicates = replicates, summary = summary, output_files = output_files))
}

#=====================================================
# Manuscript-facing clustered runners
#=====================================================

# Workflow note:
#   `run_clustered_gini_l3_check()` evaluates one design point, while
#   `run_clustered_gini_l3_grid()` loops over the design grid used in the
#   manuscript table.

run_clustered_gini_l3_check <- function(n_target, n_reps = 2000, rho = 0.5, sigma = NULL, seed = 1, cl = default_sim_cl(), replicates = NULL, output_prefix = NULL, outcome_quantiles = NULL, beta = 0.25, cap_multiplier = 4) {
  n_target <- force(n_target)
  n_reps <- force(n_reps)
  rho <- force(rho)
  sigma <- force(sigma)
  seed <- force(seed)
  output_prefix <- force(output_prefix)
  beta <- force(beta)
  cap_multiplier <- force(cap_multiplier)
  if (is.null(replicates)) {
    replicates <- generate_clustered_gini_replicates(n_target, n_reps, rho, sigma, seed, outcome_quantiles, beta, cap_multiplier)
  } else {
    n_reps <- length(replicates)
  }

  prepare_sim_cluster(
    cl,
    c(
      "cluster_gini_stat_cpp",
      "clustered_gini_one_replication",
      "clustered_l3_projection",
      "clustered_l3_one_replication",
      "clustered_gini_l3_one_replication",
      "summarise_clustered_gini_l3_results",
      "summarise_t_rejections",
      "monte_carlo_mad",
      "load_park_shin_income_quantiles"
    )
  )

  theta <- replicates[[1L]]$theta
  l3_target <- replicates[[1L]]$l3_target
  cluster_sizes <- as.integer(table(replicates[[1L]]$cluster_id))
  out <- t(pbapply::pbsapply(replicates, clustered_gini_l3_one_replication, cl = cl))
  out <- as.data.frame(out)
  summary <- summarise_clustered_gini_l3_results(out)
  summary <- c(
    n = n_target,
    G = length(cluster_sizes),
    m_n = max(cluster_sizes),
    m_n_sq_over_n = max(cluster_sizes)^2 / n_target,
    beta = beta,
    cap_multiplier = cap_multiplier,
    rho = rho,
    n_reps = n_reps,
    theta_gmd = theta,
    theta_l3 = l3_target,
    summary
  )

  cat(sprintf("n=%6d  rho=%.2f  reps=%d  cl=%s\n", n_target, rho, n_reps, sim_cl_label(cl)))
  cat(sprintf("  GMD target E[U]           = 0.00000  (kernel centred at theta = %.5f)\n", theta))
  cat(sprintf("  GMD mean/MC sd/MC MAD     = %.5f / %.5f / %.5f\n",
              as.numeric(summary["mean_gmd"]), as.numeric(summary["mc_sd_gmd"]),
              as.numeric(summary["mc_mad_gmd"])))
  cat(sprintf("  GMD mean SE robust / iid  = %.5f / %.5f\n",
              as.numeric(summary["mean_se_gmd_rob"]), as.numeric(summary["mean_se_gmd_iid"])))
  cat(sprintf("  GMD SE/SD robust / iid    = %.5f / %.5f\n",
              as.numeric(summary["se_sd_ratio_gmd_rob"]), as.numeric(summary["se_sd_ratio_gmd_iid"])))
  cat(sprintf("  GMD rejection 5%% r/iid    = %.4f / %.4f\n",
              as.numeric(summary["gmd_rob_reject_5pct"]), as.numeric(summary["gmd_iid_reject_5pct"])))
  cat(sprintf("  L3 target                 = %.5f\n", l3_target))
  cat(sprintf("  L3 mean/MC sd/MC MAD      = %.5f / %.5f / %.5f\n",
              as.numeric(summary["mean_l3"]), as.numeric(summary["mc_sd_l3"]),
              as.numeric(summary["mc_mad_l3"])))
  cat(sprintf("  L3 mean SE robust / iid   = %.5f / %.5f\n",
              as.numeric(summary["mean_se_l3_rob"]), as.numeric(summary["mean_se_l3_iid"])))
  cat(sprintf("  L3 SE/SD robust / iid     = %.5f / %.5f\n",
              as.numeric(summary["se_sd_ratio_l3_rob"]), as.numeric(summary["se_sd_ratio_l3_iid"])))
  cat(sprintf("  L3 rejection 5%% r/iid     = %.4f / %.4f\n\n",
              as.numeric(summary["l3_rob_reject_5pct"]), as.numeric(summary["l3_iid_reject_5pct"])))

  output_files <- write_sim_outputs(output_prefix, out, summary)
  invisible(list(results = out, replicates = replicates, summary = summary, output_files = output_files))
}

run_clustered_gini_l3_grid <- function(Gs = c(200, 400, 600), ns = NULL, rhos = c(0, 0.25, 0.5), n_reps = 2000, seed = 1, cl = default_sim_cl(), output_prefix = NULL, outcome_quantiles = NULL, beta = 0.15, cap_multiplier = 4) {
  if (is.null(outcome_quantiles)) outcome_quantiles <- load_park_shin_income_quantiles()
  beta <- force(beta)
  cap_multiplier <- force(cap_multiplier)
  if (is.null(ns)) {
    ns <- vapply(Gs, cluster_n_target_for_G, numeric(1L), beta = beta)
  }
  rows <- list()
  idx <- 1L
  for (n_target in ns) {
    for (rho in rhos) {
      ans <- run_clustered_gini_l3_check(
        n_target = n_target,
        n_reps = n_reps,
        rho = rho,
        seed = seed + idx - 1L,
        cl = cl,
        output_prefix = NULL,
        outcome_quantiles = outcome_quantiles,
        beta = beta,
        cap_multiplier = cap_multiplier
      )
      rows[[idx]] <- as.data.frame(t(ans$summary), check.names = FALSE)
      idx <- idx + 1L
    }
  }
  out <- do.call(rbind, rows)
  row.names(out) <- NULL
  if (!is.null(output_prefix)) write_sim_table(paste0(output_prefix, "_summary_grid"), out)
  out
}

#=====================================================
# Manuscript table writer
#=====================================================

write_clustered_gini_l3_latex_table <- function(tab, path) {
  tab <- tab[order(tab$G, tab$rho), , drop = FALSE]
  con <- file(path, open = "wt")
  on.exit(close(con), add = TRUE)
  writeLines(c(
    "\\begin{tabular}{lrrrrrrrrrrr}",
    "\\toprule",
    "\\multicolumn{2}{c}{Design} & \\multicolumn{5}{c}{GMD} & \\multicolumn{5}{c}{Third L-moment} \\\\",
    "\\cmidrule(lr){1-2}\\cmidrule(lr){3-7}\\cmidrule(lr){8-12}",
    "$(G_n,m_n^2/n)$ & $\\rho$ & $\\frac{\\mathrm{MAD}}{\\mathrm{IQR}}$ & $\\frac{\\mathrm{SE}}{\\mathrm{SD}}_{\\mathrm{rob}}$ & 5\\%$_{\\mathrm{rob}}$ & $\\frac{\\mathrm{SE}}{\\mathrm{SD}}_{\\mathrm{iid}}$ & 5\\%$_{\\mathrm{iid}}$ & $\\frac{\\mathrm{MAD}}{\\mathrm{IQR}}$ & $\\frac{\\mathrm{SE}}{\\mathrm{SD}}_{\\mathrm{rob}}$ & 5\\%$_{\\mathrm{rob}}$ & $\\frac{\\mathrm{SE}}{\\mathrm{SD}}_{\\mathrm{iid}}$ & 5\\%$_{\\mathrm{iid}}$ \\\\",
    "\\midrule"
  ), con)
  last_G <- NA_integer_
  for (i in seq_len(nrow(tab))) {
    n_i <- as.integer(tab$n[i])
    G_i <- as.integer(tab$G[i])
    if (i > 1L && G_i != last_G) writeLines("\\midrule", con)
    design_label <- ""
    if (is.na(last_G) || G_i != last_G) {
      design_label <- sprintf("$(%d,%.3f)$", G_i, as.numeric(tab$m_n[i])^2 / n_i)
    }
    writeLines(sprintf(
      "%s & %.2f & %.3f & %.3f & %.3f & %.3f & %.3f & %.3f & %.3f & %.3f & %.3f & %.3f \\\\",
      design_label,
      as.numeric(tab$rho[i]),
      as.numeric(tab$mad_iqr_gmd[i]),
      as.numeric(tab$se_sd_ratio_gmd_rob[i]),
      as.numeric(tab$gmd_rob_reject_5pct[i]),
      as.numeric(tab$se_sd_ratio_gmd_iid[i]),
      as.numeric(tab$gmd_iid_reject_5pct[i]),
      as.numeric(tab$mad_iqr_l3[i]),
      as.numeric(tab$se_sd_ratio_l3_rob[i]),
      as.numeric(tab$l3_rob_reject_5pct[i]),
      as.numeric(tab$se_sd_ratio_l3_iid[i]),
      as.numeric(tab$l3_iid_reject_5pct[i])
    ), con)
    last_G <- G_i
  }
  writeLines(c("\\bottomrule", "\\end{tabular}"), con)
  invisible(path)
}

#=====================================================
# Direct smoke run
#=====================================================

if (sys.nframe() == 0) {
  run_clustered_gini_l3_grid(n_reps = 2000)
}
