/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 * File: mldivide.h
 *
 * MATLAB Coder version            : 4.1
 * C/C++ source code generated on  : 23-Nov-2018 17:24:14
 */

#ifndef MLDIVIDE_H
#define MLDIVIDE_H

/* Include Files */
#include <stddef.h>
#include <stdlib.h>
#include "rtwtypes.h"
#include "CCRls2_types.h"

/* Function Declarations */
#ifdef __cplusplus

extern "C" {

#endif

  extern void b_mldivide(const emxArray_real_T *A, emxArray_real_T *B);
  extern void mldivide(const emxArray_real_T *A, const emxArray_real_T *B,
                       double Y[2]);

#ifdef __cplusplus

}
#endif
#endif

/*
 * File trailer for mldivide.h
 *
 * [EOF]
 */
