/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * CCRls.c
 *
 * Code generation for function 'CCRls'
 *
 */

/* Include files */
#include "mwmathutil.h"
#include "rt_nonfinite.h"
#include "CCRls.h"
#include "CCRls_emxutil.h"
#include "mldivide.h"
#include "ceil.h"
#include "CCRls_data.h"
#include "blas.h"

/* Function Definitions */
void CCRls(const emxArray_real_T *Y, const emxArray_real_T *X, emxArray_real_T
           *betas)
{
  emxArray_real_T *lcls;
  int32_T n;
  int32_T slc;
  int32_T i0;
  int32_T i1;
  int32_T loop_ub;
  int32_T b_n;
  int32_T idx;
  real_T nlcls;
  int32_T input_sizes_idx_1;
  boolean_T exitg1;
  emxArray_real_T *X0;
  real_T bet0;
  emxArray_real_T *bet_vec;
  emxArray_real_T *coefs;
  real_T val0;
  real_T val1;
  real_T coef0[2];
  real_T l;
  real_T dev;
  emxArray_boolean_T *ngIDLS;
  emxArray_boolean_T *IDls;
  emxArray_real_T *XB;
  emxArray_real_T *XX;
  emxArray_real_T *r0;
  emxArray_int32_T *r1;
  emxArray_int32_T *r2;
  emxArray_int32_T *r3;
  cell_wrap_0 reshapes[3];
  emxArray_real_T *y;
  emxArray_char_T *charStr;
  emxArray_int32_T *a_tmp;
  emxArray_real_T *b_X;
  ptrdiff_t m_t;
  ptrdiff_t n_t;
  ptrdiff_t k_t;
  ptrdiff_t lda_t;
  ptrdiff_t ldb_t;
  ptrdiff_t ldc_t;
  char_T TRANSA;
  char_T TRANSB;
  boolean_T empty_non_axis_sizes;
  int8_T b_input_sizes_idx_1;
  boolean_T guard1 = false;
  uint32_T XB_idx_0;
  real_T d0;
  emlrtHeapReferenceStackEnterFcnR2012b(emlrtRootTLSGlobal);
  emxInit_real_T(&lcls, 2, true);
  n = X->size[0];

  /*  vector to store parameters, excludes intercept */
  /*  fraction of total number of observations as partition size */
  slc = (int32_T)muDoubleScalarFloor(0.1 * (real_T)X->size[0]);

  /* maximum size of a local covariate cluster. */
  if (X->size[1] < 1) {
    lcls->size[0] = 1;
    lcls->size[1] = 0;
  } else {
    i0 = X->size[1];
    i1 = lcls->size[0] * lcls->size[1];
    lcls->size[0] = 1;
    loop_ub = (int32_T)((real_T)i0 - 1.0);
    lcls->size[1] = loop_ub + 1;
    emxEnsureCapacity_real_T(lcls, i1);
    for (i0 = 0; i0 <= loop_ub; i0++) {
      lcls->data[i0] = 1.0 + (real_T)i0;
    }
  }

  i0 = lcls->size[0] * lcls->size[1];
  i1 = lcls->size[0] * lcls->size[1];
  lcls->size[0] = 1;
  emxEnsureCapacity_real_T(lcls, i1);
  loop_ub = i0 - 1;
  for (i0 = 0; i0 <= loop_ub; i0++) {
    lcls->data[i0] /= (real_T)slc;
  }

  b_ceil(lcls);

  /* partition covarites into clusters */
  b_n = lcls->size[1];
  if (lcls->size[1] <= 2) {
    if (lcls->size[1] == 1) {
      nlcls = lcls->data[0];
    } else if ((lcls->data[0] < lcls->data[1]) || (muDoubleScalarIsNaN
                (lcls->data[0]) && (!muDoubleScalarIsNaN(lcls->data[1])))) {
      nlcls = lcls->data[1];
    } else {
      nlcls = lcls->data[0];
    }
  } else {
    if (!muDoubleScalarIsNaN(lcls->data[0])) {
      idx = 1;
    } else {
      idx = 0;
      input_sizes_idx_1 = 2;
      exitg1 = false;
      while ((!exitg1) && (input_sizes_idx_1 <= lcls->size[1])) {
        if (!muDoubleScalarIsNaN(lcls->data[input_sizes_idx_1 - 1])) {
          idx = input_sizes_idx_1;
          exitg1 = true;
        } else {
          input_sizes_idx_1++;
        }
      }
    }

    if (idx == 0) {
      nlcls = lcls->data[0];
    } else {
      nlcls = lcls->data[idx - 1];
      i0 = idx + 1;
      for (input_sizes_idx_1 = i0; input_sizes_idx_1 <= b_n; input_sizes_idx_1++)
      {
        if (nlcls < lcls->data[input_sizes_idx_1 - 1]) {
          nlcls = lcls->data[input_sizes_idx_1 - 1];
        }
      }
    }
  }

  emxInit_real_T(&X0, 2, true);

  /*  number of partitions */
  /*  Initialise parameters */
  bet0 = 0.0;

  /* initialise intercept */
  i0 = X0->size[0] * X0->size[1];
  X0->size[0] = X->size[0];
  X0->size[1] = 2;
  emxEnsureCapacity_real_T(X0, i0);
  loop_ub = X->size[0] << 1;
  for (i0 = 0; i0 < loop_ub; i0++) {
    X0->data[i0] = 1.0;
  }

  emxInit_real_T(&bet_vec, 2, true);

  /*  coef0 = zeros(1,2)'; */
  i0 = X->size[1];
  i1 = bet_vec->size[0] * bet_vec->size[1];
  bet_vec->size[0] = 1;
  bet_vec->size[1] = X->size[1];
  emxEnsureCapacity_real_T(bet_vec, i1);
  for (idx = 0; idx < i0; idx++) {
    loop_ub = X->size[0] - 1;
    for (i1 = 0; i1 <= loop_ub; i1++) {
      X0->data[i1 + X0->size[0]] = X->data[i1 + X->size[0] * idx];
    }

    mldivide(X0, Y, coef0);
    bet_vec->data[idx] = coef0[1];
  }

  emxFree_real_T(&X0);
  emxInit_real_T(&coefs, 1, true);
  val0 = 1.00000000001E+10;
  val1 = 0.0;
  l = 0.0;
  dev = 1.00000000001E+10;
  i0 = coefs->size[0];
  coefs->size[0] = slc;
  emxEnsureCapacity_real_T(coefs, i0);
  for (i0 = 0; i0 < slc; i0++) {
    coefs->data[i0] = 0.0;
  }

  emxInit_boolean_T(&ngIDLS, 2, true);
  i0 = ngIDLS->size[0] * ngIDLS->size[1];
  ngIDLS->size[0] = 1;
  ngIDLS->size[1] = X->size[1] - slc;
  emxEnsureCapacity_boolean_T(ngIDLS, i0);
  loop_ub = X->size[1] - slc;
  for (i0 = 0; i0 < loop_ub; i0++) {
    ngIDLS->data[i0] = false;
  }

  emxInit_boolean_T(&IDls, 2, true);
  i0 = IDls->size[0] * IDls->size[1];
  IDls->size[0] = 1;
  IDls->size[1] = slc;
  emxEnsureCapacity_boolean_T(IDls, i0);
  for (i0 = 0; i0 < slc; i0++) {
    IDls->data[i0] = false;
  }

  emxInit_real_T(&XB, 1, true);
  emxInit_real_T(&XX, 2, true);
  emxInit_real_T(&r0, 2, true);
  emxInit_int32_T(&r1, 2, true);
  emxInit_int32_T(&r2, 2, true);
  emxInit_int32_T(&r3, 2, true);
  emxInitMatrix_cell_wrap_0(reshapes, true);
  emxInit_real_T(&y, 1, true);
  emxInit_char_T(&charStr, 2, true);
  emxInit_int32_T(&a_tmp, 1, true);
  emxInit_real_T(&b_X, 2, true);
  while (dev > 1.0E-6) {
    if (l > 0.0) {
      val0 = val1;
      if (2.0 > (real_T)coefs->size[0] - 1.0) {
        i0 = 1;
      } else {
        i0 = 2;
      }

      b_n = IDls->size[1];
      idx = -1;
      for (input_sizes_idx_1 = 0; input_sizes_idx_1 < b_n; input_sizes_idx_1++)
      {
        if (IDls->data[input_sizes_idx_1]) {
          bet_vec->data[input_sizes_idx_1] = coefs->data[i0 + idx];
          idx++;
        }
      }

      bet0 = coefs->data[0];
      b_n = ngIDLS->size[1] - 1;
      idx = 0;
      for (input_sizes_idx_1 = 0; input_sizes_idx_1 <= b_n; input_sizes_idx_1++)
      {
        if (ngIDLS->data[input_sizes_idx_1]) {
          idx++;
        }
      }

      i0 = r3->size[0] * r3->size[1];
      r3->size[0] = 1;
      r3->size[1] = idx;
      emxEnsureCapacity_int32_T(r3, i0);
      idx = 0;
      for (input_sizes_idx_1 = 0; input_sizes_idx_1 <= b_n; input_sizes_idx_1++)
      {
        if (ngIDLS->data[input_sizes_idx_1]) {
          r3->data[idx] = input_sizes_idx_1 + 1;
          idx++;
        }
      }

      i0 = r0->size[0] * r0->size[1];
      r0->size[0] = 1;
      r0->size[1] = r3->size[1];
      emxEnsureCapacity_real_T(r0, i0);
      val1 = coefs->data[coefs->size[0] - 1];
      loop_ub = r3->size[0] * r3->size[1];
      for (i0 = 0; i0 < loop_ub; i0++) {
        r0->data[i0] = bet_vec->data[r3->data[i0] - 1] * val1;
      }

      b_n = ngIDLS->size[1];
      idx = 0;
      for (input_sizes_idx_1 = 0; input_sizes_idx_1 < b_n; input_sizes_idx_1++)
      {
        if (ngIDLS->data[input_sizes_idx_1]) {
          bet_vec->data[input_sizes_idx_1] = r0->data[idx];
          idx++;
        }
      }
    }

    l++;
    val1 = l - (muDoubleScalarCeil(l / nlcls) - 1.0) * nlcls;
    i0 = IDls->size[0] * IDls->size[1];
    IDls->size[0] = 1;
    IDls->size[1] = lcls->size[1];
    emxEnsureCapacity_boolean_T(IDls, i0);
    loop_ub = lcls->size[0] * lcls->size[1];
    for (i0 = 0; i0 < loop_ub; i0++) {
      IDls->data[i0] = (lcls->data[i0] == val1);
    }

    /*  nIDls = length(IDls); */
    i0 = ngIDLS->size[0] * ngIDLS->size[1];
    ngIDLS->size[0] = 1;
    ngIDLS->size[1] = lcls->size[1];
    emxEnsureCapacity_boolean_T(ngIDLS, i0);
    loop_ub = lcls->size[0] * lcls->size[1];
    for (i0 = 0; i0 < loop_ub; i0++) {
      ngIDLS->data[i0] = (lcls->data[i0] != val1);
    }

    b_n = ngIDLS->size[1] - 1;
    idx = 0;
    for (input_sizes_idx_1 = 0; input_sizes_idx_1 <= b_n; input_sizes_idx_1++) {
      if (ngIDLS->data[input_sizes_idx_1]) {
        idx++;
      }
    }

    i0 = r1->size[0] * r1->size[1];
    r1->size[0] = 1;
    r1->size[1] = idx;
    emxEnsureCapacity_int32_T(r1, i0);
    idx = 0;
    for (input_sizes_idx_1 = 0; input_sizes_idx_1 <= b_n; input_sizes_idx_1++) {
      if (ngIDLS->data[input_sizes_idx_1]) {
        r1->data[idx] = input_sizes_idx_1 + 1;
        idx++;
      }
    }

    i0 = a_tmp->size[0];
    a_tmp->size[0] = r1->size[1];
    emxEnsureCapacity_int32_T(a_tmp, i0);
    loop_ub = r1->size[1];
    for (i0 = 0; i0 < loop_ub; i0++) {
      a_tmp->data[i0] = r1->data[i0];
    }

    loop_ub = X->size[0];
    i0 = XX->size[0] * XX->size[1];
    XX->size[0] = loop_ub;
    XX->size[1] = a_tmp->size[0];
    emxEnsureCapacity_real_T(XX, i0);
    idx = a_tmp->size[0];
    for (i0 = 0; i0 < idx; i0++) {
      for (i1 = 0; i1 < loop_ub; i1++) {
        XX->data[i1 + XX->size[0] * i0] = X->data[i1 + X->size[0] * (a_tmp->
          data[i0] - 1)];
      }
    }

    i0 = coefs->size[0];
    coefs->size[0] = a_tmp->size[0];
    emxEnsureCapacity_real_T(coefs, i0);
    loop_ub = a_tmp->size[0];
    for (i0 = 0; i0 < loop_ub; i0++) {
      coefs->data[i0] = bet_vec->data[a_tmp->data[i0] - 1];
    }

    if (a_tmp->size[0] == 1) {
      i0 = XB->size[0];
      XB->size[0] = XX->size[0];
      emxEnsureCapacity_real_T(XB, i0);
      loop_ub = XX->size[0];
      for (i0 = 0; i0 < loop_ub; i0++) {
        XB->data[i0] = 0.0;
        idx = XX->size[1];
        for (i1 = 0; i1 < idx; i1++) {
          XB->data[i0] += XX->data[i0 + XX->size[0] * i1] * coefs->data[i1];
        }
      }
    } else {
      i0 = X->size[0];
      if ((i0 == 0) || (a_tmp->size[0] == 0) || (a_tmp->size[0] == 0)) {
        loop_ub = X->size[0];
        i0 = XB->size[0];
        XB->size[0] = loop_ub;
        emxEnsureCapacity_real_T(XB, i0);
        for (i0 = 0; i0 < loop_ub; i0++) {
          XB->data[i0] = 0.0;
        }
      } else {
        val1 = 1.0;
        dev = 0.0;
        i0 = X->size[0];
        m_t = (ptrdiff_t)i0;
        n_t = (ptrdiff_t)1;
        k_t = (ptrdiff_t)a_tmp->size[0];
        i0 = X->size[0];
        lda_t = (ptrdiff_t)i0;
        ldb_t = (ptrdiff_t)a_tmp->size[0];
        i0 = X->size[0];
        ldc_t = (ptrdiff_t)i0;
        i0 = X->size[0];
        i1 = XB->size[0];
        XB->size[0] = i0;
        emxEnsureCapacity_real_T(XB, i1);
        TRANSA = 'N';
        TRANSB = 'N';
        dgemm(&TRANSA, &TRANSB, &m_t, &n_t, &k_t, &val1, &XX->data[0], &lda_t,
              &coefs->data[0], &ldb_t, &dev, &XB->data[0], &ldc_t);
      }
    }

    b_n = IDls->size[1] - 1;
    idx = 0;
    for (input_sizes_idx_1 = 0; input_sizes_idx_1 <= b_n; input_sizes_idx_1++) {
      if (IDls->data[input_sizes_idx_1]) {
        idx++;
      }
    }

    i0 = r2->size[0] * r2->size[1];
    r2->size[0] = 1;
    r2->size[1] = idx;
    emxEnsureCapacity_int32_T(r2, i0);
    idx = 0;
    for (input_sizes_idx_1 = 0; input_sizes_idx_1 <= b_n; input_sizes_idx_1++) {
      if (IDls->data[input_sizes_idx_1]) {
        r2->data[idx] = input_sizes_idx_1 + 1;
        idx++;
      }
    }

    if (n != 0) {
      b_n = n;
    } else {
      i0 = X->size[0];
      i1 = a_tmp->size[0];
      a_tmp->size[0] = r2->size[1];
      emxEnsureCapacity_int32_T(a_tmp, i1);
      loop_ub = r2->size[1];
      for (i1 = 0; i1 < loop_ub; i1++) {
        a_tmp->data[i1] = r2->data[i1];
      }

      if ((i0 != 0) && (a_tmp->size[0] != 0)) {
        b_n = X->size[0];
      } else if (XB->size[0] != 0) {
        b_n = XB->size[0];
      } else {
        b_n = 0;
        i0 = X->size[0];
        if (i0 > 0) {
          b_n = X->size[0];
        }
      }
    }

    empty_non_axis_sizes = (b_n == 0);
    if (empty_non_axis_sizes || (n != 0)) {
      b_input_sizes_idx_1 = 1;
    } else {
      b_input_sizes_idx_1 = 0;
    }

    i0 = reshapes[0].f1->size[0] * reshapes[0].f1->size[1];
    reshapes[0].f1->size[0] = b_n;
    reshapes[0].f1->size[1] = b_input_sizes_idx_1;
    emxEnsureCapacity_real_T(reshapes[0].f1, i0);
    loop_ub = b_n * b_input_sizes_idx_1;
    for (i0 = 0; i0 < loop_ub; i0++) {
      reshapes[0].f1->data[i0] = 1.0;
    }

    guard1 = false;
    if (empty_non_axis_sizes) {
      guard1 = true;
    } else {
      i0 = X->size[0];
      i1 = a_tmp->size[0];
      a_tmp->size[0] = r2->size[1];
      emxEnsureCapacity_int32_T(a_tmp, i1);
      loop_ub = r2->size[1];
      for (i1 = 0; i1 < loop_ub; i1++) {
        a_tmp->data[i1] = r2->data[i1];
      }

      if ((i0 != 0) && (a_tmp->size[0] != 0)) {
        guard1 = true;
      } else {
        input_sizes_idx_1 = 0;
      }
    }

    if (guard1) {
      i0 = a_tmp->size[0];
      a_tmp->size[0] = r2->size[1];
      emxEnsureCapacity_int32_T(a_tmp, i0);
      loop_ub = r2->size[1];
      for (i0 = 0; i0 < loop_ub; i0++) {
        a_tmp->data[i0] = r2->data[i0];
      }

      input_sizes_idx_1 = a_tmp->size[0];
    }

    if (empty_non_axis_sizes || (XB->size[0] != 0)) {
      b_input_sizes_idx_1 = 1;
    } else {
      b_input_sizes_idx_1 = 0;
    }

    loop_ub = X->size[0];
    i0 = b_X->size[0] * b_X->size[1];
    b_X->size[0] = loop_ub;
    b_X->size[1] = r2->size[1];
    emxEnsureCapacity_real_T(b_X, i0);
    idx = r2->size[1];
    for (i0 = 0; i0 < idx; i0++) {
      for (i1 = 0; i1 < loop_ub; i1++) {
        b_X->data[i1 + b_X->size[0] * i0] = X->data[i1 + X->size[0] * (r2->
          data[i0] - 1)];
      }
    }

    i0 = XX->size[0] * XX->size[1];
    XX->size[0] = reshapes[0].f1->size[0];
    XX->size[1] = (reshapes[0].f1->size[1] + input_sizes_idx_1) +
      b_input_sizes_idx_1;
    emxEnsureCapacity_real_T(XX, i0);
    loop_ub = reshapes[0].f1->size[1];
    for (i0 = 0; i0 < loop_ub; i0++) {
      idx = reshapes[0].f1->size[0];
      for (i1 = 0; i1 < idx; i1++) {
        XX->data[i1 + XX->size[0] * i0] = reshapes[0].f1->data[i1 + reshapes[0].
          f1->size[0] * i0];
      }
    }

    for (i0 = 0; i0 < input_sizes_idx_1; i0++) {
      for (i1 = 0; i1 < b_n; i1++) {
        XX->data[i1 + XX->size[0] * (i0 + reshapes[0].f1->size[1])] = b_X->
          data[i1 + b_n * i0];
      }
    }

    loop_ub = b_input_sizes_idx_1;
    for (i0 = 0; i0 < loop_ub; i0++) {
      for (i1 = 0; i1 < b_n; i1++) {
        XX->data[i1 + XX->size[0] * (reshapes[0].f1->size[1] + input_sizes_idx_1)]
          = XB->data[i1];
      }
    }

    /* make room for intercept term */
    i0 = coefs->size[0];
    coefs->size[0] = Y->size[0];
    emxEnsureCapacity_real_T(coefs, i0);
    loop_ub = Y->size[0];
    for (i0 = 0; i0 < loop_ub; i0++) {
      coefs->data[i0] = Y->data[i0];
    }

    b_mldivide(XX, coefs);
    if ((XX->size[1] == 1) || (coefs->size[0] == 1)) {
      i0 = XB->size[0];
      XB->size[0] = XX->size[0];
      emxEnsureCapacity_real_T(XB, i0);
      loop_ub = XX->size[0];
      for (i0 = 0; i0 < loop_ub; i0++) {
        XB->data[i0] = 0.0;
        idx = XX->size[1];
        for (i1 = 0; i1 < idx; i1++) {
          XB->data[i0] += XX->data[i0 + XX->size[0] * i1] * coefs->data[i1];
        }
      }
    } else if ((XX->size[0] == 0) || (XX->size[1] == 0) || (coefs->size[0] == 0))
    {
      i0 = XB->size[0];
      XB->size[0] = XX->size[0];
      emxEnsureCapacity_real_T(XB, i0);
      loop_ub = XX->size[0];
      for (i0 = 0; i0 < loop_ub; i0++) {
        XB->data[i0] = 0.0;
      }
    } else {
      val1 = 1.0;
      dev = 0.0;
      m_t = (ptrdiff_t)XX->size[0];
      n_t = (ptrdiff_t)1;
      k_t = (ptrdiff_t)XX->size[1];
      lda_t = (ptrdiff_t)XX->size[0];
      ldb_t = (ptrdiff_t)XX->size[1];
      ldc_t = (ptrdiff_t)XX->size[0];
      i0 = XB->size[0];
      XB->size[0] = XX->size[0];
      emxEnsureCapacity_real_T(XB, i0);
      TRANSA = 'N';
      TRANSB = 'N';
      dgemm(&TRANSA, &TRANSB, &m_t, &n_t, &k_t, &val1, &XX->data[0], &lda_t,
            &coefs->data[0], &ldb_t, &dev, &XB->data[0], &ldc_t);
    }

    i0 = XB->size[0];
    XB->size[0] = Y->size[0];
    emxEnsureCapacity_real_T(XB, i0);
    loop_ub = Y->size[0];
    for (i0 = 0; i0 < loop_ub; i0++) {
      XB->data[i0] = Y->data[i0] - XB->data[i0];
    }

    XB_idx_0 = (uint32_T)XB->size[0];
    i0 = y->size[0];
    y->size[0] = (int32_T)XB_idx_0;
    emxEnsureCapacity_real_T(y, i0);
    XB_idx_0 = (uint32_T)XB->size[0];
    idx = (int32_T)XB_idx_0;
    for (input_sizes_idx_1 = 0; input_sizes_idx_1 < idx; input_sizes_idx_1++) {
      y->data[input_sizes_idx_1] = XB->data[input_sizes_idx_1] * XB->
        data[input_sizes_idx_1];
    }

    idx = y->size[0];
    if (y->size[0] == 0) {
      val1 = 0.0;
    } else {
      val1 = y->data[0];
      for (input_sizes_idx_1 = 2; input_sizes_idx_1 <= idx; input_sizes_idx_1++)
      {
        val1 += y->data[input_sizes_idx_1 - 1];
      }
    }

    if (l > 1.0) {
      dev = (val0 - val1) / (1.0 + muDoubleScalarAbs(val0));
    } else {
      dev = 1.0;
    }

    /*  print progress */
    if (!muDoubleScalarIsInf(l)) {
      d0 = muDoubleScalarRem(l, 100.0);
    } else {
      d0 = rtNaN;
    }

    if (d0 == 0.0) {
      idx = (int32_T)emlrtMexSnprintf(NULL, 0,
        "iter = %.0f fval = %f and dev = %f", l, val1, dev) + 1;
      i0 = charStr->size[0] * charStr->size[1];
      charStr->size[0] = 1;
      charStr->size[1] = idx;
      emxEnsureCapacity_char_T(charStr, i0);
      emlrtMexSnprintf(&charStr->data[0], (size_t)idx,
                       "iter = %.0f fval = %f and dev = %f", l, val1, dev);
    }
  }

  emxFree_real_T(&b_X);
  emxFree_int32_T(&a_tmp);
  emxFree_char_T(&charStr);
  emxFree_real_T(&y);
  emxFreeMatrix_cell_wrap_0(reshapes);
  emxFree_int32_T(&r3);
  emxFree_int32_T(&r2);
  emxFree_int32_T(&r1);
  emxFree_real_T(&r0);
  emxFree_real_T(&XX);
  emxFree_real_T(&XB);
  emxFree_boolean_T(&IDls);
  emxFree_boolean_T(&ngIDLS);
  emxFree_real_T(&coefs);
  emxFree_real_T(&lcls);
  i0 = betas->size[0] * betas->size[1];
  betas->size[0] = 1;
  betas->size[1] = 1 + bet_vec->size[1];
  emxEnsureCapacity_real_T(betas, i0);
  betas->data[0] = bet0;
  loop_ub = bet_vec->size[1];
  for (i0 = 0; i0 < loop_ub; i0++) {
    betas->data[i0 + 1] = bet_vec->data[i0];
  }

  emxFree_real_T(&bet_vec);

  /* concatenate final parameter estimates */
  emlrtHeapReferenceStackLeaveFcnR2012b(emlrtRootTLSGlobal);
}

/* End of code generation (CCRls.c) */
