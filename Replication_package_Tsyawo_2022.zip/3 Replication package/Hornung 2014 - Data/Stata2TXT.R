#===================================================================================>
#This file saves the Stata dataset to txt format
setwd(dirname(rstudioapi::getActiveDocumentContext()$path)) #set working directory path to source file
library(foreign)
#===================================================================================>
list.files()
hornung_data_textiles<- read.dta("hornung-data-textiles.dta")
dim(hornung_data_textiles)
hornung_data_textiles[1,]
# save file into txt format
write.table(hornung_data_textiles, "hornung_data_textiles.txt", sep = " ",col.names = TRUE)
list.files()
#===================================================================================>