MATLAB="/usr/local/MATLAB/R2018b"
Arch=glnxa64
ENTRYPOINT=mexFunction
MAPFILE=$ENTRYPOINT'.map'
PREFDIR="/home/selorm/.matlab/R2018b"
OPTSFILE_NAME="./setEnv.sh"
. $OPTSFILE_NAME
COMPILER=$CC
. $OPTSFILE_NAME
echo "# Make settings for goldsscoord" > goldsscoord_mex.mki
echo "CC=$CC" >> goldsscoord_mex.mki
echo "CFLAGS=$CFLAGS" >> goldsscoord_mex.mki
echo "CLIBS=$CLIBS" >> goldsscoord_mex.mki
echo "COPTIMFLAGS=$COPTIMFLAGS" >> goldsscoord_mex.mki
echo "CDEBUGFLAGS=$CDEBUGFLAGS" >> goldsscoord_mex.mki
echo "CXX=$CXX" >> goldsscoord_mex.mki
echo "CXXFLAGS=$CXXFLAGS" >> goldsscoord_mex.mki
echo "CXXLIBS=$CXXLIBS" >> goldsscoord_mex.mki
echo "CXXOPTIMFLAGS=$CXXOPTIMFLAGS" >> goldsscoord_mex.mki
echo "CXXDEBUGFLAGS=$CXXDEBUGFLAGS" >> goldsscoord_mex.mki
echo "LDFLAGS=$LDFLAGS" >> goldsscoord_mex.mki
echo "LDOPTIMFLAGS=$LDOPTIMFLAGS" >> goldsscoord_mex.mki
echo "LDDEBUGFLAGS=$LDDEBUGFLAGS" >> goldsscoord_mex.mki
echo "Arch=$Arch" >> goldsscoord_mex.mki
echo "LD=$LD" >> goldsscoord_mex.mki
echo OMPFLAGS= >> goldsscoord_mex.mki
echo OMPLINKFLAGS= >> goldsscoord_mex.mki
echo "EMC_COMPILER=gcc" >> goldsscoord_mex.mki
echo "EMC_CONFIG=optim" >> goldsscoord_mex.mki
"/usr/local/MATLAB/R2018b/bin/glnxa64/gmake" -j 1 -B -f goldsscoord_mex.mk
