/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * goldsscoord_initialize.c
 *
 * Code generation for function 'goldsscoord_initialize'
 *
 */

/* Include files */
#include "rt_nonfinite.h"
#include "goldsscoord.h"
#include "goldsscoord_initialize.h"
#include "eml_rand_mt19937ar_stateful.h"
#include "_coder_goldsscoord_mex.h"
#include "goldsscoord_data.h"

/* Function Declarations */
static void goldsscoord_once(void);

/* Function Definitions */
static void goldsscoord_once(void)
{
  c_eml_rand_mt19937ar_stateful_i();
}

void goldsscoord_initialize(void)
{
  mexFunctionCreateRootTLS();
  emlrtClearAllocCountR2012b(emlrtRootTLSGlobal, false, 0U, 0);
  emlrtEnterRtStackR2012b(emlrtRootTLSGlobal);
  emlrtLicenseCheckR2012b(emlrtRootTLSGlobal, "Statistics_Toolbox", 2);
  if (emlrtFirstTimeR2012b(emlrtRootTLSGlobal)) {
    goldsscoord_once();
  }
}

/* End of code generation (goldsscoord_initialize.c) */
