/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 * File: round.c
 *
 * MATLAB Coder version            : 4.1
 * C/C++ source code generated on  : 22-Nov-2018 23:51:16
 */

/* Include Files */
#include <math.h>
#include "CCRls.h"
#include "round.h"

/* Function Declarations */
static double rt_roundd(double u);

/* Function Definitions */

/*
 * Arguments    : double u
 * Return Type  : double
 */
static double rt_roundd(double u)
{
  double y;
  if (fabs(u) < 4.503599627370496E+15) {
    if (u >= 0.5) {
      y = floor(u + 0.5);
    } else if (u > -0.5) {
      y = 0.0;
    } else {
      y = ceil(u - 0.5);
    }
  } else {
    y = u;
  }

  return y;
}

/*
 * Arguments    : emxArray_real_T *x
 * Return Type  : void
 */
void b_round(emxArray_real_T *x)
{
  int nx;
  int k;
  nx = x->size[1];
  for (k = 0; k < nx; k++) {
    x->data[k] = rt_roundd(x->data[k]);
  }
}

/*
 * File trailer for round.c
 *
 * [EOF]
 */
