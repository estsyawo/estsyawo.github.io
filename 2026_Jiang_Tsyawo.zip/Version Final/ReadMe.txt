--- ReadMe ---

Project: A Consistent ICM-based X2 Specification Test

All generated files are now written to the `output/` folder in the project root.
If the folder does not exist, the simulation scripts create it automatically.

**********************
Input Files in the Folder:

0) JT00_Main_File.R
Master script that runs all result-producing scripts in sequence. It also ensures
that the `output/` folder exists before execution.

1a) JT01_MCSim_LM.R
Simulation code for specification tests of linear models. It writes the LM text
tables and all `PCLM_*.pdf` figures to `output/`.

1b) JT01_MCSim_NLM.R
Simulation code for nonlinear/logit specification testing. It writes the
`PCNLM_*.pdf` figures to `output/`.

2) JT02_MCSim_MI.R
Simulation code for tests of mean independence. It writes the MI text tables and
all `PCMI_*.pdf` figures to `output/`.

3) JT03_MCSim_MI_ext.R
Additional mean-independence simulations. It writes the extension tables to
`output/`.

4) JT04_Power_Comparison.R
Bahadur-slope computations. It writes `Bahadur_slopes.txt` to `output/`.

5) JT05_Fonctions.R
Retained core helper functions that are actually used by the output-generating
scripts. Redundant helper functions not used by `JT01`-`JT04` were removed.

6) JT06_Fonctions_Sim.R
Data-generating processes used by the simulation scripts.

7) JT07_Fonctions_Bahadur.R
Auxiliary Bahadur-slope functions used by `JT04_Power_Comparison.R`.

**********************
Output Files in output/:

1) `PCLM_*.pdf`
Power-curve figures for the linear-model experiments.

2) `PCMI_*.pdf`
Power-curve figures for the mean-independence experiments.

3) `PCNLM_*.pdf`
Power-curve figures for the nonlinear/logit experiments.

4) `tab.size.*.txt`
Empirical size tables.

5) `tab.loc_pow.*.txt`
Local-power tables.

6) `tab.pow.*.txt`
Power tables for the MI extensions.

7) `tab.comp_time.*.txt`
Computation-time tables.

8) `Bahadur_slopes.txt`
Bahadur-slope summary written by `JT04_Power_Comparison.R`.

**********************
Function Documentation:

JT05_Fonctions.R

1) `specLM.Chi`
Purpose: pivotal chi-squared specification test for linear IV models.
Input: `ivreg` fit plus regressor and instrument matrices.
Output: list with statistic, p-value, degrees of freedom, and covariance objects.

2) `infl.fun.logit`
Purpose: influence-function building blocks for logit models.
Input: fitted logit `glm`.
Output: list with influence matrix and derivative matrix.

3) `spec.logit.Chi`
Purpose: pivotal chi-squared specification test for logit models.
Input: fitted logit `glm`.
Output: list with statistic, p-value, degrees of freedom, and covariance objects.

4) `MI_Spec.Chi`
Purpose: pivotal chi-squared test of mean independence.
Input: outcome vector `U` and conditioning variables `Z`.
Output: list with statistic, p-value, degrees of freedom, and covariance objects.

5) `MIndep.Chi.star`
Purpose: chi-squared test of the joint null `E[U|Z] = E[U] = 0`.
Input: outcome vector `U` and conditioning variables `Z`.
Output: list with statistic, p-value, degrees of freedom, and covariance objects.

6) `MCfun.type`
Purpose: one Monte Carlo replication for the linear-model comparison.
Input: one generated dataset and bootstrap weights.
Output: named vector of rejection indicators and timing measures.

7) `MC_glm.type`
Purpose: one Monte Carlo replication for the nonlinear/logit comparison.
Input: one generated dataset and bootstrap weights.
Output: named vector of rejection indicators and timing measures.

8) `MCfun.type.MI`
Purpose: one Monte Carlo replication for the baseline mean-independence comparison.
Input: one generated dataset and bootstrap weights.
Output: named vector of rejection indicators and timing measures.

9) `MCfun4.MI`
Purpose: MI extension comparing alternative moment-basis dimensions.
Input: one generated dataset and bootstrap weights.
Output: named vector of rejection indicators across tests.

10) `MCfun5.MI`
Purpose: MI extension comparing eigenvalue-threshold rules.
Input: one generated dataset.
Output: named vector of rejection indicators across tuning rules.

11) `MCfun5star.MI`
Purpose: joint-null MI extension comparing eigenvalue-threshold rules.
Input: one generated dataset.
Output: named vector of rejection indicators across tuning rules.

12) `MCfun6.MI`
Purpose: MI extension comparing a wider set of eigenvalue-selection rules.
Input: one generated dataset.
Output: named vector of rejection indicators across tuning rules.

13) `print.fn`
Purpose: print one LaTeX-style table row.
Input: numeric vector.
Output: formatted text row.

14) `print.size.type`
Purpose: print paired size/power summaries for two kernel settings.
Input: two Monte Carlo result lists and selected column indices.
Output: formatted text rows.

15) `print.time.type`
Purpose: print paired timing summaries for two kernel settings.
Input: two Monte Carlo result lists and selected time columns.
Output: formatted text rows.

16) `print.tab`
Purpose: print a generic power table over gamma values and nominal levels.
Input: Monte Carlo result list and column indices.
Output: formatted text rows.

17) `plot.pow`
Purpose: save LM power-curve figures.
Input: Monte Carlo result list, column indices, and filename prefix.
Output: three PDF figures.

18) `plot.pow.NLM`
Purpose: save nonlinear/logit power-curve figures.
Input: Monte Carlo result list, column indices, and filename prefix.
Output: three PDF figures.

19) `plot.pow2`
Purpose: save MI power-curve figures.
Input: Monte Carlo result list, column indices, and filename prefix.
Output: three PDF figures.

20) `Kern.fun_muUnif`
Purpose: uniform spectral kernel.
Input: conditioning-variable matrix `Z`.
Output: kernel matrix.

21) `Kern.fun_muTri`
Purpose: triangular spectral kernel.
Input: conditioning-variable matrix `Z`.
Output: kernel matrix.

22) `Kern.fun_Euclid.a`
Purpose: Euclidean-alpha kernel.
Input: conditioning-variable matrix `Z` and exponent `alpha`.
Output: kernel matrix.

23) `Kern.fun_ProdCDF`
Purpose: product kernel based on logistic or Cauchy densities.
Input: conditioning-variable matrix `Z`.
Output: kernel matrix.

24) `diffZ`
Purpose: pairwise row differences of `Z`.
Input: vector or matrix `Z`.
Output: `n x n x p` array of differences.

25) `Kern.fun2`
Purpose: kernel dispatcher used by the chi-squared procedures.
Input: conditioning-variable matrix `Z`, kernel name, and exponent.
Output: kernel matrix.

26) `mindep2.boot`
Purpose: multiplier bootstrap for mean-independence comparisons.
Input: outcome vector `U`, conditioning variables, and bootstrap settings.
Output: list with statistic and p-value.

27) `speclm_mul.test`
Purpose: multiplier-bootstrap ICM specification test for IV models.
Input: fitted `ivreg` object and bootstrap settings.
Output: list with statistic and p-value.

28) `spec.glm_mul.test`
Purpose: multiplier-bootstrap ICM specification test for GLMs.
Input: fitted `glm` object and bootstrap settings.
Output: list with statistic and p-value.

29) `glm_influence_blocks`
Purpose: GLM score, Fisher-information, and influence-function blocks.
Input: fitted `glm` object.
Output: list of matrices used by the GLM procedures.

JT06_Fonctions_Sim.R

1) `gdat1`
Purpose: exogenous LM size design.
Input: sample size `n`.
Output: list of simulated datasets.

2) `gdat2`
Purpose: endogenous quadratic-alternative design.
Input: sample size `n` and alternative strength `gam`.
Output: list of simulated datasets.

3) `gdat3`
Purpose: high-frequency alternative design.
Input: sample size `n` and alternative strength `gam`.
Output: list of simulated datasets.

4) `gdat4`
Purpose: chi-squared-targeted alternative design.
Input: sample size `n` and alternative strength `gam`.
Output: list of simulated datasets.

5) `gdatGLM`
Purpose: nonlinear/logit simulation design.
Input: sample size `n` and alternative strength `gam`.
Output: list of simulated datasets.

6) `gdat5`
Purpose: indicator-type MI alternative design.
Input: sample size `n` and alternative strength `gam`.
Output: list of simulated datasets.

JT07_Fonctions_Bahadur.R

1) `gdat.Bahadur2`
Purpose: generate one sample for the Bahadur-slope experiment.
Input: replication index and sample size `n`.
Output: data frame with `U`, `Z`, and `Eps`.

2) `GMDD.Bahadur`
Purpose: compute the GMDD Bahadur components.
Input: sample vectors and kernel matrix.
Output: numeric vector with GMDD numerator and leading eigenvalue term.

3) `Chi.Bahadur`
Purpose: compute the chi-squared Bahadur components for one basis choice.
Input: sample vectors, kernel matrix, and basis selector.
Output: list with local-drift vector and covariance matrix.

4) `MC.fn.Bahadur`
Purpose: run one Bahadur-slope Monte Carlo replication.
Input: sample index and list of generated samples.
Output: list of GMDD and chi-squared components used in `JT04`.
