/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * goldsscoord2.c
 *
 * Code generation for function 'goldsscoord2'
 *
 */

/* Include files */
#include "mwmathutil.h"
#include "rt_nonfinite.h"
#include "goldsscoord2.h"
#include "goldsscoord2_emxutil.h"
#include "sum.h"
#include "power.h"
#include "dot.h"
#include "kmeans.h"
#include "rng.h"
#include "mldivide.h"
#include "goldsscoord2_data.h"
#include "blas.h"
#include <stdio.h>

/* Function Declarations */
static void __anon_fcn(const emxArray_real_T *Y, const emxArray_real_T *X,
  real_T nC, emxArray_real_T *bets, const emxArray_real_T *Xdot, const
  emxArray_real_T *clus, real_T k, emxArray_real_T *varargout_2, real_T
  *varargout_3);

/* Function Definitions */
static void __anon_fcn(const emxArray_real_T *Y, const emxArray_real_T *X,
  real_T nC, emxArray_real_T *bets, const emxArray_real_T *Xdot, const
  emxArray_real_T *clus, real_T k, emxArray_real_T *varargout_2, real_T
  *varargout_3)
{
  emxArray_real_T *b_clus;
  int32_T i6;
  int32_T loop_ub;
  emxArray_real_T *b;
  int32_T p;
  real_T cnt;
  emxArray_real_T *err;
  real_T alpha1;
  real_T beta1;
  ptrdiff_t m_t;
  ptrdiff_t n_t;
  ptrdiff_t k_t;
  ptrdiff_t lda_t;
  emxArray_real_T *b_Y;
  int32_T nx;
  ptrdiff_t ldb_t;
  int32_T end;
  ptrdiff_t ldc_t;
  char_T TRANSA;
  char_T TRANSB;
  emxArray_real_T *clmns;
  int32_T lk;
  emxArray_int32_T *a_tmp;
  emxArray_boolean_T *id;
  emxArray_int32_T *r1;
  emxArray_int32_T *r2;
  emxArray_real_T *y;
  emxArray_real_T *a;
  int32_T exitg1;
  int32_T j;
  uint32_T err_idx_0;
  int32_T idx;
  boolean_T exitg2;
  emlrtHeapReferenceStackEnterFcnR2012b(emlrtRootTLSGlobal);
  emxInit_real_T(&b_clus, 2, true);
  i6 = b_clus->size[0] * b_clus->size[1];
  b_clus->size[0] = 1;
  b_clus->size[1] = clus->size[1];
  emxEnsureCapacity_real_T(b_clus, i6);
  loop_ub = clus->size[0] * clus->size[1];
  for (i6 = 0; i6 < loop_ub; i6++) {
    b_clus->data[i6] = clus->data[i6];
  }

  emxInit_real_T(&b, 1, true);

  /*  use coordinate descent to estimate linear regression */
  /*  and incorporate covariate clustering into k clusters. */
  /*  inputs: */
  /*  Y - vector of outcome variable */
  /*  X - matrix of p covariates, including 1's for intercept */
  /*  k - number of clusters */
  /*  nC - the first nC covariates in X are not to be clustered. nC=1 if only */
  /*  intercept is excluded from clustering. */
  /*  bets - vector of p betas */
  /*  Xdot - sum of squares of each column of X */
  /*  clus - clustering of X into k clusters */
  /*  */
  p = X->size[1];
  cnt = 0.0;

  /* counter */
  loop_ub = bets->size[1];
  i6 = b->size[0];
  b->size[0] = loop_ub;
  emxEnsureCapacity_real_T(b, i6);
  for (i6 = 0; i6 < loop_ub; i6++) {
    b->data[i6] = bets->data[i6];
  }

  emxInit_real_T(&err, 1, true);
  if ((X->size[1] == 1) || (b->size[0] == 1)) {
    i6 = err->size[0];
    err->size[0] = X->size[0];
    emxEnsureCapacity_real_T(err, i6);
    loop_ub = X->size[0];
    for (i6 = 0; i6 < loop_ub; i6++) {
      err->data[i6] = 0.0;
      nx = X->size[1];
      for (end = 0; end < nx; end++) {
        err->data[i6] += X->data[i6 + X->size[0] * end] * b->data[end];
      }
    }
  } else if ((X->size[0] == 0) || (X->size[1] == 0) || (b->size[0] == 0)) {
    i6 = err->size[0];
    err->size[0] = X->size[0];
    emxEnsureCapacity_real_T(err, i6);
    loop_ub = X->size[0];
    for (i6 = 0; i6 < loop_ub; i6++) {
      err->data[i6] = 0.0;
    }
  } else {
    alpha1 = 1.0;
    beta1 = 0.0;
    m_t = (ptrdiff_t)X->size[0];
    n_t = (ptrdiff_t)1;
    k_t = (ptrdiff_t)X->size[1];
    lda_t = (ptrdiff_t)X->size[0];
    ldb_t = (ptrdiff_t)X->size[1];
    ldc_t = (ptrdiff_t)X->size[0];
    i6 = err->size[0];
    err->size[0] = X->size[0];
    emxEnsureCapacity_real_T(err, i6);
    TRANSA = 'N';
    TRANSB = 'N';
    dgemm(&TRANSA, &TRANSB, &m_t, &n_t, &k_t, &alpha1, &X->data[0], &lda_t,
          &b->data[0], &ldb_t, &beta1, &err->data[0], &ldc_t);
  }

  emxInit_real_T(&b_Y, 1, true);
  i6 = b_Y->size[0];
  b_Y->size[0] = Y->size[0];
  emxEnsureCapacity_real_T(b_Y, i6);
  loop_ub = Y->size[0];
  for (i6 = 0; i6 < loop_ub; i6++) {
    b_Y->data[i6] = Y->data[i6] - err->data[i6];
  }

  power(b_Y, err);
  *varargout_3 = sum(err);

  /*  initial RSS0 */
  /*  Initial clustering */
  rng();

  /*  For reproducibility */
  if (nC + 1.0 > X->size[1]) {
    i6 = 0;
    end = 0;
  } else {
    i6 = (int32_T)(nC + 1.0) - 1;
    end = X->size[1];
  }

  nx = b_Y->size[0];
  loop_ub = end - i6;
  b_Y->size[0] = loop_ub;
  emxEnsureCapacity_real_T(b_Y, nx);
  for (end = 0; end < loop_ub; end++) {
    b_Y->data[end] = bets->data[i6 + end];
  }

  emxInit_real_T(&clmns, 1, true);
  kmeans(b_Y, k, varargout_2, clmns);

  /*  bets of length p */
  lk = varargout_2->size[0];
  if (nC + 1.0 > X->size[1]) {
    i6 = 0;
    end = 0;
  } else {
    i6 = (int32_T)(nC + 1.0) - 1;
    end = X->size[1];
  }

  emxInit_int32_T(&a_tmp, 1, true);
  nx = a_tmp->size[0];
  loop_ub = end - i6;
  a_tmp->size[0] = loop_ub;
  emxEnsureCapacity_int32_T(a_tmp, nx);
  for (end = 0; end < loop_ub; end++) {
    a_tmp->data[end] = i6 + end;
  }

  nx = a_tmp->size[0];
  for (i6 = 0; i6 < nx; i6++) {
    b_clus->data[a_tmp->data[i6]] = varargout_2->data[i6];
  }

  /*  to run in a while loop */
  emxInit_boolean_T(&id, 2, true);
  emxInit_int32_T(&r1, 2, true);
  emxInit_int32_T(&r2, 2, true);
  emxInit_real_T(&y, 2, true);
  emxInit_real_T(&a, 2, true);
  do {
    exitg1 = 0;
    cnt++;
    for (j = 0; j < p; j++) {
      if (p < 1) {
        y->size[0] = 1;
        y->size[1] = 0;
      } else {
        i6 = y->size[0] * y->size[1];
        y->size[0] = 1;
        y->size[1] = p;
        emxEnsureCapacity_real_T(y, i6);
        loop_ub = p - 1;
        for (i6 = 0; i6 <= loop_ub; i6++) {
          y->data[i6] = 1.0 + (real_T)i6;
        }
      }

      i6 = id->size[0] * id->size[1];
      id->size[0] = 1;
      id->size[1] = y->size[1];
      emxEnsureCapacity_boolean_T(id, i6);
      loop_ub = y->size[0] * y->size[1];
      for (i6 = 0; i6 < loop_ub; i6++) {
        id->data[i6] = (y->data[i6] != 1.0 + (real_T)j);
      }

      end = id->size[1] - 1;
      nx = 0;
      for (loop_ub = 0; loop_ub <= end; loop_ub++) {
        if (id->data[loop_ub]) {
          nx++;
        }
      }

      i6 = r1->size[0] * r1->size[1];
      r1->size[0] = 1;
      r1->size[1] = nx;
      emxEnsureCapacity_int32_T(r1, i6);
      nx = 0;
      for (loop_ub = 0; loop_ub <= end; loop_ub++) {
        if (id->data[loop_ub]) {
          r1->data[nx] = loop_ub + 1;
          nx++;
        }
      }

      i6 = a_tmp->size[0];
      a_tmp->size[0] = r1->size[1];
      emxEnsureCapacity_int32_T(a_tmp, i6);
      loop_ub = r1->size[1];
      for (i6 = 0; i6 < loop_ub; i6++) {
        a_tmp->data[i6] = r1->data[i6];
      }

      loop_ub = X->size[0];
      i6 = a->size[0] * a->size[1];
      a->size[0] = loop_ub;
      a->size[1] = a_tmp->size[0];
      emxEnsureCapacity_real_T(a, i6);
      nx = a_tmp->size[0];
      for (i6 = 0; i6 < nx; i6++) {
        for (end = 0; end < loop_ub; end++) {
          a->data[end + a->size[0] * i6] = X->data[end + X->size[0] *
            (a_tmp->data[i6] - 1)];
        }
      }

      i6 = b->size[0];
      b->size[0] = a_tmp->size[0];
      emxEnsureCapacity_real_T(b, i6);
      loop_ub = a_tmp->size[0];
      for (i6 = 0; i6 < loop_ub; i6++) {
        b->data[i6] = bets->data[a_tmp->data[i6] - 1];
      }

      if ((a_tmp->size[0] == 1) || (b->size[0] == 1)) {
        i6 = err->size[0];
        err->size[0] = a->size[0];
        emxEnsureCapacity_real_T(err, i6);
        loop_ub = a->size[0];
        for (i6 = 0; i6 < loop_ub; i6++) {
          err->data[i6] = 0.0;
          nx = a->size[1];
          for (end = 0; end < nx; end++) {
            err->data[i6] += a->data[i6 + a->size[0] * end] * b->data[end];
          }
        }
      } else {
        i6 = X->size[0];
        if ((i6 == 0) || (a_tmp->size[0] == 0) || (b->size[0] == 0)) {
          loop_ub = X->size[0];
          i6 = err->size[0];
          err->size[0] = loop_ub;
          emxEnsureCapacity_real_T(err, i6);
          for (i6 = 0; i6 < loop_ub; i6++) {
            err->data[i6] = 0.0;
          }
        } else {
          alpha1 = 1.0;
          beta1 = 0.0;
          i6 = X->size[0];
          m_t = (ptrdiff_t)i6;
          n_t = (ptrdiff_t)1;
          k_t = (ptrdiff_t)a_tmp->size[0];
          i6 = X->size[0];
          lda_t = (ptrdiff_t)i6;
          ldb_t = (ptrdiff_t)a_tmp->size[0];
          i6 = X->size[0];
          ldc_t = (ptrdiff_t)i6;
          i6 = X->size[0];
          end = err->size[0];
          err->size[0] = i6;
          emxEnsureCapacity_real_T(err, end);
          TRANSA = 'N';
          TRANSB = 'N';
          dgemm(&TRANSA, &TRANSB, &m_t, &n_t, &k_t, &alpha1, &a->data[0], &lda_t,
                &b->data[0], &ldb_t, &beta1, &err->data[0], &ldc_t);
        }
      }

      i6 = err->size[0];
      err->size[0] = Y->size[0];
      emxEnsureCapacity_real_T(err, i6);
      loop_ub = Y->size[0];
      for (i6 = 0; i6 < loop_ub; i6++) {
        err->data[i6] = Y->data[i6] - err->data[i6];
      }

      if (1.0 + (real_T)j > nC) {
        loop_ub = X->size[0];
        i6 = b_Y->size[0];
        b_Y->size[0] = loop_ub;
        emxEnsureCapacity_real_T(b_Y, i6);
        for (i6 = 0; i6 < loop_ub; i6++) {
          b_Y->data[i6] = X->data[i6 + X->size[0] * j];
        }

        alpha1 = dot(err, b_Y) / Xdot->data[j];

        /* identify current cluster assignment */
        i6 = err->size[0];
        err->size[0] = clmns->size[0];
        emxEnsureCapacity_real_T(err, i6);
        loop_ub = clmns->size[0];
        for (i6 = 0; i6 < loop_ub; i6++) {
          err->data[i6] = clmns->data[i6] - alpha1;
        }

        nx = err->size[0];
        err_idx_0 = (uint32_T)err->size[0];
        i6 = b->size[0];
        b->size[0] = (int32_T)err_idx_0;
        emxEnsureCapacity_real_T(b, i6);
        for (loop_ub = 0; loop_ub < nx; loop_ub++) {
          b->data[loop_ub] = muDoubleScalarAbs(err->data[loop_ub]);
        }

        nx = b->size[0];
        if (b->size[0] <= 2) {
          if (b->size[0] == 1) {
            idx = 1;
          } else if ((b->data[0] > b->data[1]) || (muDoubleScalarIsNaN(b->data[0])
                      && (!muDoubleScalarIsNaN(b->data[1])))) {
            idx = 2;
          } else {
            idx = 1;
          }
        } else {
          if (!muDoubleScalarIsNaN(b->data[0])) {
            idx = 1;
          } else {
            idx = 0;
            loop_ub = 2;
            exitg2 = false;
            while ((!exitg2) && (loop_ub <= b->size[0])) {
              if (!muDoubleScalarIsNaN(b->data[loop_ub - 1])) {
                idx = loop_ub;
                exitg2 = true;
              } else {
                loop_ub++;
              }
            }
          }

          if (idx == 0) {
            idx = 1;
          } else {
            beta1 = b->data[idx - 1];
            i6 = idx + 1;
            for (loop_ub = i6; loop_ub <= nx; loop_ub++) {
              if (beta1 > b->data[loop_ub - 1]) {
                beta1 = b->data[loop_ub - 1];
                idx = loop_ub;
              }
            }
          }
        }

        /*  identify nearest cluster centre */
        if (idx != b_clus->data[j]) {
          i6 = id->size[0] * id->size[1];
          id->size[0] = 1;
          id->size[1] = b_clus->size[1];
          emxEnsureCapacity_boolean_T(id, i6);
          loop_ub = b_clus->size[0] * b_clus->size[1];
          for (i6 = 0; i6 < loop_ub; i6++) {
            id->data[i6] = (b_clus->data[i6] == idx);
          }

          end = id->size[1] - 1;
          nx = 0;
          for (loop_ub = 0; loop_ub <= end; loop_ub++) {
            if (id->data[loop_ub]) {
              nx++;
            }
          }

          i6 = r2->size[0] * r2->size[1];
          r2->size[0] = 1;
          r2->size[1] = nx;
          emxEnsureCapacity_int32_T(r2, i6);
          nx = 0;
          for (loop_ub = 0; loop_ub <= end; loop_ub++) {
            if (id->data[loop_ub]) {
              r2->data[nx] = loop_ub + 1;
              nx++;
            }
          }

          i6 = y->size[0] * y->size[1];
          y->size[0] = 1;
          y->size[1] = 1 + r2->size[1];
          emxEnsureCapacity_real_T(y, i6);
          y->data[0] = alpha1;
          loop_ub = r2->size[1];
          for (i6 = 0; i6 < loop_ub; i6++) {
            y->data[i6 + 1] = bets->data[r2->data[i6] - 1];
          }

          nx = y->size[1];
          alpha1 = y->data[0];
          for (loop_ub = 2; loop_ub <= nx; loop_ub++) {
            alpha1 += y->data[loop_ub - 1];
          }

          bets->data[j] = alpha1 / (real_T)y->size[1];

          /* update clustered j */
          b_clus->data[j] = idx;

          /* update j's cluster */
        }
      } else {
        loop_ub = X->size[0];
        i6 = b_Y->size[0];
        b_Y->size[0] = loop_ub;
        emxEnsureCapacity_real_T(b_Y, i6);
        for (i6 = 0; i6 < loop_ub; i6++) {
          b_Y->data[i6] = X->data[i6 + X->size[0] * j];
        }

        bets->data[j] = dot(err, b_Y) / Xdot->data[j];

        /* update directly for non-clustered */
      }

      /* end if(j>nC) */
      if (*emlrtBreakCheckR2012bFlagVar != 0) {
        emlrtBreakCheckR2012b(emlrtRootTLSGlobal);
      }
    }

    /*  Compute RSS & check convergence */
    loop_ub = bets->size[1];
    i6 = b->size[0];
    b->size[0] = loop_ub;
    emxEnsureCapacity_real_T(b, i6);
    for (i6 = 0; i6 < loop_ub; i6++) {
      b->data[i6] = bets->data[i6];
    }

    if ((X->size[1] == 1) || (b->size[0] == 1)) {
      i6 = err->size[0];
      err->size[0] = X->size[0];
      emxEnsureCapacity_real_T(err, i6);
      loop_ub = X->size[0];
      for (i6 = 0; i6 < loop_ub; i6++) {
        err->data[i6] = 0.0;
        nx = X->size[1];
        for (end = 0; end < nx; end++) {
          err->data[i6] += X->data[i6 + X->size[0] * end] * b->data[end];
        }
      }
    } else if ((X->size[0] == 0) || (X->size[1] == 0) || (b->size[0] == 0)) {
      i6 = err->size[0];
      err->size[0] = X->size[0];
      emxEnsureCapacity_real_T(err, i6);
      loop_ub = X->size[0];
      for (i6 = 0; i6 < loop_ub; i6++) {
        err->data[i6] = 0.0;
      }
    } else {
      alpha1 = 1.0;
      beta1 = 0.0;
      m_t = (ptrdiff_t)X->size[0];
      n_t = (ptrdiff_t)1;
      k_t = (ptrdiff_t)X->size[1];
      lda_t = (ptrdiff_t)X->size[0];
      ldb_t = (ptrdiff_t)X->size[1];
      ldc_t = (ptrdiff_t)X->size[0];
      i6 = err->size[0];
      err->size[0] = X->size[0];
      emxEnsureCapacity_real_T(err, i6);
      TRANSA = 'N';
      TRANSB = 'N';
      dgemm(&TRANSA, &TRANSB, &m_t, &n_t, &k_t, &alpha1, &X->data[0], &lda_t,
            &b->data[0], &ldb_t, &beta1, &err->data[0], &ldc_t);
    }

    i6 = b_Y->size[0];
    b_Y->size[0] = Y->size[0];
    emxEnsureCapacity_real_T(b_Y, i6);
    loop_ub = Y->size[0];
    for (i6 = 0; i6 < loop_ub; i6++) {
      b_Y->data[i6] = Y->data[i6] - err->data[i6];
    }

    power(b_Y, err);
    alpha1 = sum(err);
    beta1 = (*varargout_3 - alpha1) / (1.0E-20 + muDoubleScalarAbs(*varargout_3));
    mexPrintf("\n Inner iter = %llu RSS = %0.5f and dev = %0.5f \n", (uint64_T)
              cnt, alpha1, beta1);
    if (beta1 <= 1.0E-10) {
      exitg1 = 1;
    } else {
      *varargout_3 = alpha1;

      /* update RSS */
      if (nC + 1.0 > p) {
        i6 = 0;
      } else {
        i6 = (int32_T)(nC + 1.0) - 1;
      }

      if (1 > lk) {
        loop_ub = 0;
      } else {
        loop_ub = lk;
      }

      end = a_tmp->size[0];
      a_tmp->size[0] = loop_ub;
      emxEnsureCapacity_int32_T(a_tmp, end);
      for (end = 0; end < loop_ub; end++) {
        a_tmp->data[end] = end;
      }

      nx = a_tmp->size[0];
      for (end = 0; end < nx; end++) {
        varargout_2->data[a_tmp->data[end]] = b_clus->data[i6 + end];
      }

      /*  update clusters */
      if (*emlrtBreakCheckR2012bFlagVar != 0) {
        emlrtBreakCheckR2012b(emlrtRootTLSGlobal);
      }
    }
  } while (exitg1 == 0);

  emxFree_real_T(&b_Y);
  emxFree_int32_T(&a_tmp);
  emxFree_real_T(&a);
  emxFree_real_T(&y);
  emxFree_real_T(&b);
  emxFree_int32_T(&r2);
  emxFree_int32_T(&r1);
  emxFree_real_T(&clmns);
  emxFree_real_T(&err);
  emxFree_boolean_T(&id);
  emxFree_real_T(&b_clus);

  /*  end while loop */
  emlrtHeapReferenceStackLeaveFcnR2012b(emlrtRootTLSGlobal);
}

void goldsscoord2(const emxArray_real_T *Y, const emxArray_real_T *X, real_T nC,
                  real_T a, real_T b, real_T *optk, emxArray_real_T *clus,
                  emxArray_real_T *bets, real_T *BIC)
{
  emxArray_real_T *Xdot;
  int32_T nd;
  int32_T i0;
  int32_T loop_ub;
  emxArray_real_T *X0;
  emxArray_real_T *clus_c;
  emxArray_real_T *b_X;
  int32_T j;
  emxArray_real_T *tunableEnvironment_f4;
  int32_T i1;
  real_T coef0[2];
  emxArray_real_T *bets_c;
  real_T fd;
  real_T c;
  real_T d;
  emxArray_real_T *r0;
  real_T fc;
  real_T cnt;
  emlrtHeapReferenceStackEnterFcnR2012b(emlrtRootTLSGlobal);
  emxInit_real_T(&Xdot, 2, true);

  /*  Golden Section Search for coordinate descent linear reg */
  nd = X->size[0];
  i0 = Xdot->size[0] * Xdot->size[1];
  Xdot->size[0] = 1;
  Xdot->size[1] = X->size[1];
  emxEnsureCapacity_real_T(Xdot, i0);
  loop_ub = X->size[1];
  for (i0 = 0; i0 < loop_ub; i0++) {
    Xdot->data[i0] = 0.0;
  }

  i0 = bets->size[0] * bets->size[1];
  bets->size[0] = 1;
  bets->size[1] = X->size[1];
  emxEnsureCapacity_real_T(bets, i0);
  loop_ub = X->size[1];
  for (i0 = 0; i0 < loop_ub; i0++) {
    bets->data[i0] = 0.0;
  }

  emxInit_real_T(&X0, 2, true);

  /* counter */
  /*  initialise parameters */
  i0 = X0->size[0] * X0->size[1];
  X0->size[0] = X->size[0];
  X0->size[1] = 2;
  emxEnsureCapacity_real_T(X0, i0);
  loop_ub = X->size[0] << 1;
  for (i0 = 0; i0 < loop_ub; i0++) {
    X0->data[i0] = 1.0;
  }

  /*  for the initialisation of coefficients */
  i0 = X->size[1];
  emxInit_real_T(&clus_c, 1, true);
  emxInit_real_T(&b_X, 1, true);
  for (j = 0; j <= i0 - 2; j++) {
    /* intercept initialised at zero */
    loop_ub = X->size[0] - 1;
    for (i1 = 0; i1 <= loop_ub; i1++) {
      X0->data[i1 + X0->size[0]] = X->data[i1 + X->size[0] * (j + 1)];
    }

    mldivide(X0, Y, coef0);
    bets->data[1 + j] = coef0[1];
    loop_ub = X->size[0];
    i1 = clus_c->size[0];
    clus_c->size[0] = loop_ub;
    emxEnsureCapacity_real_T(clus_c, i1);
    for (i1 = 0; i1 < loop_ub; i1++) {
      clus_c->data[i1] = X->data[i1 + X->size[0] * (j + 1)];
    }

    loop_ub = X->size[0];
    i1 = b_X->size[0];
    b_X->size[0] = loop_ub;
    emxEnsureCapacity_real_T(b_X, i1);
    for (i1 = 0; i1 < loop_ub; i1++) {
      b_X->data[i1] = X->data[i1 + X->size[0] * (j + 1)];
    }

    Xdot->data[1 + j] = dot(clus_c, b_X);

    /* sum of squared X[,j] */
    if (*emlrtBreakCheckR2012bFlagVar != 0) {
      emlrtBreakCheckR2012b(emlrtRootTLSGlobal);
    }
  }

  emxFree_real_T(&b_X);
  emxFree_real_T(&X0);
  emxInit_real_T(&tunableEnvironment_f4, 2, true);
  Xdot->data[0] = X->size[0];

  /* sum of squared X[,1] (intercept) */
  /*  begin golden section search optimisation for k */
  i0 = tunableEnvironment_f4->size[0] * tunableEnvironment_f4->size[1];
  tunableEnvironment_f4->size[0] = 1;
  tunableEnvironment_f4->size[1] = bets->size[1];
  emxEnsureCapacity_real_T(tunableEnvironment_f4, i0);
  loop_ub = bets->size[0] * bets->size[1];
  for (i0 = 0; i0 < loop_ub; i0++) {
    tunableEnvironment_f4->data[i0] = bets->data[i0];
  }

  emxInit_real_T(&bets_c, 2, true);

  /* define function in k */
  fd = (b - a) / 1.6180339887498949;
  c = muDoubleScalarCeil(b - fd);
  d = muDoubleScalarFloor(a + fd);
  i0 = bets_c->size[0] * bets_c->size[1];
  bets_c->size[0] = 1;
  bets_c->size[1] = bets->size[1];
  emxEnsureCapacity_real_T(bets_c, i0);
  loop_ub = bets->size[0] * bets->size[1];
  for (i0 = 0; i0 < loop_ub; i0++) {
    bets_c->data[i0] = bets->data[i0];
  }

  emxInit_real_T(&r0, 2, true);
  i0 = r0->size[0] * r0->size[1];
  r0->size[0] = 1;
  r0->size[1] = X->size[1];
  emxEnsureCapacity_real_T(r0, i0);
  loop_ub = X->size[1];
  for (i0 = 0; i0 < loop_ub; i0++) {
    r0->data[i0] = 0.0;
  }

  __anon_fcn(Y, X, nC, bets_c, Xdot, r0, c, clus_c, &fd);
  fc = (real_T)X->size[0] * muDoubleScalarLog(fd / (real_T)X->size[0]) + c *
    muDoubleScalarLog(X->size[0]);

  /* print */
  mexPrintf("\n Outer iter = %llu BIC = %0.5f \n", 1UL, fc);
  i0 = r0->size[0] * r0->size[1];
  r0->size[0] = 1;
  r0->size[1] = X->size[1];
  emxEnsureCapacity_real_T(r0, i0);
  loop_ub = X->size[1];
  for (i0 = 0; i0 < loop_ub; i0++) {
    r0->data[i0] = 0.0;
  }

  __anon_fcn(Y, X, nC, bets, Xdot, r0, d, clus, &fd);
  fd = (real_T)X->size[0] * muDoubleScalarLog(fd / (real_T)X->size[0]) + d *
    muDoubleScalarLog(X->size[0]);
  cnt = 2.0;

  /* print */
  mexPrintf("\n Outer iter = %llu BIC = %0.5f \n", 2UL, fd);

  /*     %% begin while loop */
  while (muDoubleScalarAbs(c - d) > 1.0) {
    if (fc < fd) {
      b = d;
    } else {
      a = c;
    }

    /*  end if */
    fd = (b - a) / 1.6180339887498949;
    c = muDoubleScalarCeil(b - fd);
    d = muDoubleScalarFloor(a + fd);
    i0 = bets_c->size[0] * bets_c->size[1];
    bets_c->size[0] = 1;
    bets_c->size[1] = tunableEnvironment_f4->size[1];
    emxEnsureCapacity_real_T(bets_c, i0);
    loop_ub = tunableEnvironment_f4->size[0] * tunableEnvironment_f4->size[1];
    for (i0 = 0; i0 < loop_ub; i0++) {
      bets_c->data[i0] = tunableEnvironment_f4->data[i0];
    }

    i0 = r0->size[0] * r0->size[1];
    r0->size[0] = 1;
    r0->size[1] = X->size[1];
    emxEnsureCapacity_real_T(r0, i0);
    loop_ub = X->size[1];
    for (i0 = 0; i0 < loop_ub; i0++) {
      r0->data[i0] = 0.0;
    }

    __anon_fcn(Y, X, nC, bets_c, Xdot, r0, c, clus_c, &fd);
    fc = (real_T)nd * muDoubleScalarLog(fd / (real_T)nd) + c * muDoubleScalarLog
      (nd);
    cnt++;

    /* print */
    mexPrintf("\n Outer iter = %llu BIC = %0.5f \n", (uint64_T)cnt, fc);
    i0 = bets->size[0] * bets->size[1];
    bets->size[0] = 1;
    bets->size[1] = tunableEnvironment_f4->size[1];
    emxEnsureCapacity_real_T(bets, i0);
    loop_ub = tunableEnvironment_f4->size[0] * tunableEnvironment_f4->size[1];
    for (i0 = 0; i0 < loop_ub; i0++) {
      bets->data[i0] = tunableEnvironment_f4->data[i0];
    }

    i0 = r0->size[0] * r0->size[1];
    r0->size[0] = 1;
    r0->size[1] = X->size[1];
    emxEnsureCapacity_real_T(r0, i0);
    loop_ub = X->size[1];
    for (i0 = 0; i0 < loop_ub; i0++) {
      r0->data[i0] = 0.0;
    }

    __anon_fcn(Y, X, nC, bets, Xdot, r0, d, clus, &fd);
    fd = (real_T)nd * muDoubleScalarLog(fd / (real_T)nd) + d * muDoubleScalarLog
      (nd);
    cnt++;

    /* print */
    mexPrintf("\n Outer iter = %llu BIC = %0.5f \n", (uint64_T)cnt, fd);
    if (*emlrtBreakCheckR2012bFlagVar != 0) {
      emlrtBreakCheckR2012b(emlrtRootTLSGlobal);
    }
  }

  emxFree_real_T(&r0);
  emxFree_real_T(&tunableEnvironment_f4);
  emxFree_real_T(&Xdot);

  /* end while loop */
  if (fc <= fd) {
    d = c;
    i0 = bets->size[0] * bets->size[1];
    bets->size[0] = 1;
    bets->size[1] = bets_c->size[1];
    emxEnsureCapacity_real_T(bets, i0);
    loop_ub = bets_c->size[0] * bets_c->size[1];
    for (i0 = 0; i0 < loop_ub; i0++) {
      bets->data[i0] = bets_c->data[i0];
    }

    fd = fc;
    i0 = clus->size[0];
    clus->size[0] = clus_c->size[0];
    emxEnsureCapacity_real_T(clus, i0);
    loop_ub = clus_c->size[0];
    for (i0 = 0; i0 < loop_ub; i0++) {
      clus->data[i0] = clus_c->data[i0];
    }
  }

  emxFree_real_T(&clus_c);
  emxFree_real_T(&bets_c);

  /*  end if */
  *optk = d;
  *BIC = fd;
  emlrtHeapReferenceStackLeaveFcnR2012b(emlrtRootTLSGlobal);
}

/* End of code generation (goldsscoord2.c) */
