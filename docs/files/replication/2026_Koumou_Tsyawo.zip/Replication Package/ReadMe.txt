---------------------------------------------ReadMe---------------------------------------------
Replication package for
"Difference-in-differences with as few as two cross-sectional units:
A new perspective to the democracy-growth debate"

This package reproduces the simulation, illustration, and empirical results reported in the
project. The master script is `File_0_Main.R`, and all generated files are written to the
`output/` subfolder.

------------------------------------------------------------------------------------------------


------------------------------------------Contents----------------------------------------------

. `File_0_Main.R`
  Master script for reproducing the full package output.

. `File_0_Fonctions.R`
  Shared functions used across the simulation and empirical scripts. The file now contains only
  functions used in the package, and each function is documented with its purpose, inputs, and
  output.

. `File_1_PT_Illus.R`
  Produces the parallel-trends illustration figures.

. `File_2a_Empirical.R`
  Produces the baseline empirical results.

. `File_2b_Empirical_More.R`
  Produces the extended empirical analysis and additional comparisons.

. `File_3a_Sim.R`
  Simulation results for homogeneous treatment effects.

. `File_3b_Sim.R`
  Simulation results for heterogeneous treatment effects.

. `File_3c_Sim.R`
  Power-curve simulations for estimator-based tests.

. `File_3d_Sim.R`
  Power-curve simulations for identification tests.

. `File_3e_Sim.R`
  Simulation results for designs with non-constant lambda.

. `Daten_2015_USD.txt`
  GDP per capita data for Benin and Togo.

. `Daten_2015_USD_More.txt`
  Expanded empirical dataset used in the additional empirical analysis.

. `Daten_world-gdp-per-capita.csv`
  World GDP per capita data used for manuscript calculations.

. `output/`
  Destination for all generated tables, figures, and text output.


------------------------------------------Generated Output--------------------------------------

All package output is written to `output/`. This includes:

. simulation tables beginning with `out_`
. power-curve figures beginning with `pow_`
. identification-test figures beginning with `test_`
. parallel-trends illustration figures beginning with `out_PT_Illus_`
. empirical figures and tables such as:
  `out_GDP_per_Capita.png`
  `out_logGDP_per_Capita.png`
  `out_2a_Empirical.txt`
  `out_2b_Empirical_More.txt`
  `tab.empirical.txt`

If `output/` does not already exist, `File_0_Main.R` creates it automatically.


------------------------------------------Requirements------------------------------------------

Run the package from RStudio or from an R session whose working directory is this folder.

The scripts use the following R packages:

. `rstudioapi`
. `tseries`
. `lmtest`
. `sandwich`
. `parallel`
. `pbapply`
. `nlme`
. `ggplot2`
. `dplyr`
. `latex2exp`


------------------------------------------How To Run--------------------------------------------

1. Open the replication package folder in RStudio, or set the working directory to this folder.

2. Make sure the required R packages are installed.

3. Run `File_0_Main.R`.

4. Retrieve all generated output from the `output/` subfolder.


------------------------------------------Execution Order---------------------------------------

`File_0_Main.R` executes the following scripts in sequence:

1. `File_1_PT_Illus.R`
2. `File_3a_Sim.R`
3. `File_3b_Sim.R`
4. `File_3c_Sim.R`
5. `File_3d_Sim.R`
6. `File_3e_Sim.R`
7. `File_2a_Empirical.R`
8. `File_2b_Empirical_More.R`


------------------------------------------Runtime Note------------------------------------------

The Monte Carlo scripts are computationally intensive. Approximate runtimes noted in
`File_0_Main.R` suggest:

. `File_3a_Sim.R`: about 50 minutes
. `File_3b_Sim.R`: about 49 minutes
. `File_3c_Sim.R`: about 1.17 hours
. `File_3d_Sim.R`: about 27 minutes
. `File_3e_Sim.R`: about 1.45 hours

Actual runtime will depend on the machine, available cores, and installed R environment.


------------------------------------------Additional Notes--------------------------------------

. Existing files in `output/` are included for convenience.

. Re-running `File_0_Main.R` reproduces the full set of outputs.

. The empirical and simulation scripts rely on `File_0_Fonctions.R` for shared estimation,
  simulation, formatting, and plotting utilities.
