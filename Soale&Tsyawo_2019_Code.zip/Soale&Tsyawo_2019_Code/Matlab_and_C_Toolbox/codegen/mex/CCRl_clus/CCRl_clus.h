/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * CCRl_clus.h
 *
 * Code generation for function 'CCRl_clus'
 *
 */

#ifndef CCRL_CLUS_H
#define CCRL_CLUS_H

/* Include files */
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "tmwtypes.h"
#include "mex.h"
#include "emlrt.h"
#include "rtwtypes.h"
#include "CCRl_clus_types.h"

/* Function Declarations */
extern void CCRl_clus(const emxArray_real_T *Y, const emxArray_real_T *X, const
                      emxArray_real_T *Xc, uint64_T frql, real_T kp, uint64_T
                      kmin, uint64_T kmax, boolean_T rpt, uint64_T *k,
                      emxArray_real_T *betas, emxArray_real_T *clus);
extern uint64_T eml_i64dplus(uint64_T x, real_T y);

#endif

/* End of code generation (CCRl_clus.h) */
