#=========================================================================================>
# Author: Emmanuel Selorm Tsyawo
# Project: Feasible IV Regression without Excluded Instruments
# Date began:   Sept 13, 2021
# Last Update:  Sept 13, 2021
# Place:        Rabat
#=========================================================================================>
# Load packages, clear memory,
#rm(list=ls())
library(MASS)
library(estrpac)#install from binary file estrpac_0.1.0.tgz or
# use devtools::install_github("estsyawo/estrpac")
library(pbapply)
library(AER)
setwd(dirname(rstudioapi::getActiveDocumentContext()$path)) #set working directory path to source file
list.files()
#=========================================================================================>
# Comments: Simulations to check the performance of the proposed Linear Completeness
# test on DGPs 0A, 3B, and 1B
#=========================================================================================>
# Set Parameters
R = 1000 # set number of simulations
a=b=1 #set parameters
B=499

#-------------------------------------------------------
# DGP OA
gdat_0A<- function(n,gam){
  datl=list()
  for (l in 1:R) {
    set.seed(l) #generate seed
    Z=rnorm(n)
    
    Sig = diag(2); Sig[1,2]=Sig[2,1]=0.5
    set.seed(l+10)
    EU=mvrnorm(n=n,mu=c(0,0),Sigma = Sig)
    #generate endogenous covariate
    D = 1/4 + Z + gam*Z^2+EU[,2]
    #generate outcome
    Y = a + D + Z + EU[,1]
    
    #save in a list
    datl[[l]]<- list(Y=Y,X=cbind(D,Z),Z=Z)
  }
  datl
}


#------------------------------------------------------------>
#DGP 3B
f.fun=function(Z,U,gam){1*((1+gam*Z+U)>0)}

gdat_3B<- function(n,gam){
  datl=list(); pz = 2
  for (l in 1:R) {
    set.seed(l) #generate seed
    Z=mvrnorm(n,rep(0,pz),exp(-as.matrix(dist(1:pz))))
    X = Z[,2]
    Sig = diag(2); Sig[1,2]=Sig[2,1]=0.8
    set.seed(l+10)
    EU=MASS::mvrnorm(n=n,mu=c(0,0),Sigma = Sig)
    #generate endogenous covariate
    
    D = f.fun(Z[,1],EU[,2],gam)
    #generate outcome
    Y = 1 + b*D + X + EU[,1]
    datl[[l]]<- list(Y=Y,X=cbind(D,X),Z=Z)
  }
  datl
}
#------------------------------------------------------------>
# DGP 1B
gdat_1B<- function(n,gam){
  datl=list()
  for (l in 1:R) {
    set.seed(l) #generate seed
    Z=mvrnorm(n,rep(0,2),exp(-as.matrix(dist(1:2))))
    
    Sig = diag(2); Sig[1,2]=Sig[2,1]=0.5
    set.seed(l+10)
    EU=mvrnorm(n=n,mu=c(0,0),Sigma = Sig)
    #generate endogenous covariate
    set.seed(2*l+10)
    
    D = sign(gam)*sqrt(abs(gam))*sin(Z[,1])*sin(Z[,2])/((1-exp(-2))/4) + EU[,2]
    #generate outcome
    
    Y = a + D + Z[,2] + EU[,1]
    
    #save in a list
    datl[[l]]<- list(Y=Y,X=cbind(D,Z[,2]),Z=Z)
  }
  datl
}

# size a, n = 250, gamma = 0.0
datl_0A=gdat_0A(n=250,gam = 0.0)
datl_3B=gdat_3B(n=250,gam = 0.0)
datl_1B=gdat_1B(n=250,gam = 0.0)

wmat.A = wmat.mammen(n=250,B=B,seed = 0)

MCfun0<- function(j=NULL,datl,wmat){
  dat = datl[[j]] #null operation for looping
  Y = dat$Y; X = as.matrix(dat$X)
  Z = as.matrix(dat$Z)
  
  #run K-Class regressions
  MMDObj=imlmreg2.fit(Y=X[,1],X=X[,2],Z=Z)
  pv.MMD=speclmb.test(reg.Obj = MMDObj,B=B,wmat = wmat)$p.value
  
  size_power.MMD = 1*(pv.MMD<=c(0.01,0.05,0.1))
  res=size_power.MMD
  names(res)=c("MMD_1%","MMD_5%","MMD_10%")
  res
}

MCfun1<- function(j=NULL,datl,wmat){
  dat = datl[[j]] #null operation for looping
  Y = dat$Y; X = as.matrix(dat$X)
  Z = as.matrix(dat$Z)
  
  #run K-Class regressions
  MMDObj=imlmreg2.fit(Y=X[,1],X=as.matrix(X[,2]),Z=Z)
  pv.MMD=speclmb.test(reg.Obj = MMDObj,B=B,wmat = wmat)$p.value
  pv.TSLS=c(summary(ivreg(Y~X|Z),diagnostics = TRUE)$diagnostics[1,4])
  
  size_power.MMD = 1*(pv.MMD<=c(0.01,0.05,0.1))
  size_power.TSLS = 1*(pv.TSLS<=c(0.01,0.05,0.1))
  res=c(size_power.MMD,size_power.TSLS)[c(1,4,2,5,3,6)]
  names(res)=c("MMD_1%","TSLS_1%","MMD_5%","TSLS_5%","MMD_10%","TSLS_10%")
  res
}

# 
#-------------------------------------------------------
# Design 1

# illustration

MCfun0(j=2,datl=datl_0A,wmat = wmat.A)
# MMD_1%  MMD_5% MMD_10% 
# 0       0       0
MCfun1(j=2,datl=datl_3B,wmat = wmat.A)
# MMD_1%  TSLS_1%   MMD_5%  TSLS_5%  MMD_10% TSLS_10% 
#   0        0        0        0        0        0
#
MCfun1(j=2,datl=datl_1B,wmat = wmat.A)

gamvec=seq(-1,1,0.2)
SizePow_0A=SizePow_3B=SizePow_1B=list()

for(g in 1:length(gamvec)){
  #------------------------------------>
  # DGP OA
  cat("g = ",g,"\n")
  dat0 = gdat_0A(n=250,gam = gamvec[g])
  SizePow_0A[[g]] = pbsapply(1:R, FUN=MCfun0,cl=5,datl=dat0,wmat = wmat.A)
  cat("gamma = ",gamvec[g],"\n")
  print(apply(SizePow_0A[[g]],1,mean))
  
  #------------------------------------>
  # DGP 3B
  cat("g = ",g,"\n")
  dat1 = gdat_3B(n=250,gam = gamvec[g])
  SizePow_3B[[g]] = pbsapply(1:R, FUN=MCfun1,cl=5,datl=dat1,wmat = wmat.A)
  cat("gamma = ",gamvec[g],"\n")
  print(apply(SizePow_3B[[g]],1,mean))
  
  #------------------------------------>
  # DGP 1B
  dat2 = gdat_1B(n=250,gam = gamvec[g])
  SizePow_1B[[g]] = pbsapply(1:R, FUN=MCfun1,cl=5,datl=dat2,wmat = wmat.A)
  print(apply(SizePow_1B[[g]],1,mean))
}

res.0A = apply(SizePow_0A[[1]],1,mean)
res.3B = apply(SizePow_3B[[1]],1,mean)
res.1B = apply(SizePow_1B[[1]],1,mean)

for (g in 2:length(gamvec)) {
  res.0A=rbind(res.0A,apply(SizePow_0A[[g]],1,mean))
  res.3B=rbind(res.3B,apply(SizePow_3B[[g]],1,mean))
  res.1B=rbind(res.1B,apply(SizePow_1B[[g]],1,mean))
}

rownames(res.0A)=paste(gamvec)

rownames(res.3B)=paste(gamvec)

rownames(res.1B)=paste(gamvec)

res.0A
res.3B
res.1B

#------------------------------------------------------------------------------------
# 1% Power Curve for Specification 0A
pdf("Fig_PowerCurve0A_01.pdf")
plot(gamvec,res.0A[,1],type = "l",col="blue",xlab = "",ylab = "",xaxt="n",yaxt="n",
     ylim = c(-0.01,1.01))
axis(side=1, at=gamvec , labels=paste(gamvec))
axis(side=2, at=seq(0,1,0.2) , labels=paste(seq(0,1,0.2)))
abline(h=0.01,lty=3)
dev.off()
#-----------------------------------
# 5% Power Curve for Specification 0A
pdf("Fig_PowerCurve0A_05.pdf")
plot(gamvec,res.0A[,2],type = "l",col="blue",xlab = "",ylab = "",xaxt="n",yaxt="n",
     ylim = c(-0.01,1.01))
axis(side=1, at=gamvec , labels=paste(gamvec))
axis(side=2, at=seq(0,1,0.2) , labels=paste(seq(0,1,0.2)))
abline(h=0.05,lty=3)
dev.off()
#-----------------------------------
# 10% Power Curve for Specification 0A
pdf("Fig_PowerCurve0A_10.pdf")
plot(gamvec,res.0A[,3],type = "l",col="blue",xlab = "",ylab = "",xaxt="n",yaxt="n",
     ylim = c(-0.01,1.01))
axis(side=1, at=gamvec , labels=paste(gamvec))
axis(side=2, at=seq(0,1,0.2) , labels=paste(seq(0,1,0.2)))
abline(h=0.10,lty=3)
dev.off()
#------------------------------------------------------------------------------------
# 1% Power Curve for Specification 3B
pdf("Fig_PowerCurve3B_01.pdf")
plot(gamvec,res.3B[,1],type = "l",col="blue",xlab = "",ylab = "",xaxt="n",yaxt="n",
     ylim = c(-0.01,1.01))
axis(side=1, at=gamvec , labels=paste(gamvec))
axis(side=2, at=seq(0,1,0.2) , labels=paste(seq(0,1,0.2)))
lines(gamvec,res.3B[,2],lty = 2,col="red")
abline(h=0.01,lty=3)
legend(0.6,0.95,c("MMD LC","IV FS"),lty = c(1,2),col = c("blue","red"))
dev.off()
#---------------------------------------------------------
# 5% Power Curve for Specification 3B
pdf("Fig_PowerCurve3B_05.pdf")
plot(gamvec,res.3B[,3],type = "l",col="blue",xlab = "",ylab = "",xaxt="n",yaxt="n",
     ylim = c(-0.01,1.01))
axis(side=1, at=gamvec , labels=paste(gamvec))
axis(side=2, at=seq(0,1,0.2) , labels=paste(seq(0,1,0.2)))
lines(gamvec,res.3B[,4],lty = 2,col="red")
abline(h=0.05,lty=3)
legend(0.6,0.95,c("MMD LC","IV FS"),lty = c(1,2),col = c("blue","red"))
dev.off()
#---------------------------------------------------------
# 10% Power Curve for Specification 3B
pdf("Fig_PowerCurve3B_10.pdf")
plot(gamvec,res.3B[,5],type = "l",col="blue",xlab = "",ylab = "",xaxt="n",yaxt="n",
     ylim = c(-0.01,1.01))
axis(side=1, at=gamvec , labels=paste(gamvec))
axis(side=2, at=seq(0,1,0.2) , labels=paste(seq(0,1,0.2)))
lines(gamvec,res.3B[,6],lty = 2,col="red")
abline(h=0.10,lty=3)
legend(0.6,0.95,c("MMD LC","IV FS"),lty = c(1,2),col = c("blue","red"))
dev.off()
#------------------------------------------------------------------------------------
# 1% Power Curve for Specification 1B
pdf("Fig_PowerCurve1B_01.pdf")
plot(gamvec,res.1B[,1],type = "l",col="blue",xlab = "",ylab = "",xaxt="n",yaxt="n",
     ylim = c(-0.01,1.01))
axis(side=1, at=gamvec , labels=paste(gamvec))
axis(side=2, at=seq(0,1,0.2) , labels=paste(seq(0,1,0.2)))
lines(gamvec,res.1B[,2],lty = 2,col="red")
abline(h=0.01,lty=3)
legend(0.6,0.75,c("MMD LC","IV FS"),lty = c(1,2),col = c("blue","red"))
dev.off()
#---------------------------------------------------------
# 5% Power Curve for Specification 1B
pdf("Fig_PowerCurve1B_05.pdf")
plot(gamvec,res.1B[,3],type = "l",col="blue",xlab = "",ylab = "",xaxt="n",yaxt="n",
     ylim = c(-0.01,1.01))
axis(side=1, at=gamvec , labels=paste(gamvec))
axis(side=2, at=seq(0,1,0.2) , labels=paste(seq(0,1,0.2)))
lines(gamvec,res.1B[,4],lty = 2,col="red")
abline(h=0.05,lty=3)
legend(0.6,0.90,c("MMD LC","IV FS"),lty = c(1,2),col = c("blue","red"))
dev.off()
#---------------------------------------------------------
# 10% Power Curve for Specification 1B
pdf("Fig_PowerCurve1B_10.pdf")
plot(gamvec,res.1B[,5],type = "l",col="blue",xlab = "",ylab = "",xaxt="n",yaxt="n",
     ylim = c(-0.01,1.01))
axis(side=1, at=gamvec , labels=paste(gamvec))
axis(side=2, at=seq(0,1,0.2) , labels=paste(seq(0,1,0.2)))
lines(gamvec,res.1B[,6],lty = 2,col="red")
abline(h=0.10,lty=3)
legend(0.5,0.90,c("MMD LC","IV FS"),lty = c(1,2),col = c("blue","red"))
dev.off()
#------------------------------------------------------------------------------------
#=========================================================================================>