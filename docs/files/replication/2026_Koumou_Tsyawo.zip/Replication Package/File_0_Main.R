#=========================================================================================>
# Authors: Gilles Koumou & Emmanuel Selorm Tsyawo
# Project: Difference-in-differences with as few as two cross-sectional units\\
#-- A new perspective to the democracy-growth debate
# Date begun: Sept. 13, 2022
# Date last updated:   April 19, 2026
# Place:        Tuscaloosa
# Purpose: Main file for executing all code
#=========================================================================================>
rm(list=ls()) # clear entire memory
setwd(dirname(rstudioapi::getActiveDocumentContext()$path)) #set working directory path to source file
if (!dir.exists("output")) {
  dir.create("output", recursive = TRUE)
}
#=========================================================================================>

#=========================================================================================>
#Comments:
#=========================================================================================>



#===============================================================================
start.time<- Sys.time()
#===============================================================================



#=========================================================================================>
#Simulations: mean bias, median absolute deviation, root-mean squared error, rejection rates

cat("Parallel Trends Illustration \n ")

source("File_1_PT_Illus.R") #Time difference of 50.64453 mins
#=========================================================================================>

#=========================================================================================>
#Simulations: mean bias, median absolute deviation, root-mean squared error, rejection rates

cat("Homogeneous treatment effects \n ")

source("File_3a_Sim.R") #Time difference of 50.64453 mins
#=========================================================================================>

#=========================================================================================>
#Simulations: mean bias, median absolute deviation, root-mean squared error, rejection rates

cat("Heterogeneous treatment effects \n ")

source("File_3b_Sim.R") #Time difference of 48.90229 mins
#=========================================================================================>

#=========================================================================================>
#Simulations: power curves for estimator based t-tests

cat("Power Curves - Homogeneous treatment effects \n ")

source("File_3c_Sim.R") #Time difference of 1.166494 hours
#=========================================================================================>

#=========================================================================================>

#Simulations: power curves for identification tests

cat("Idenfification testing \n ")

source("File_3d_Sim.R") #Time difference of 26.58319 mins
#=========================================================================================>

#=========================================================================================>
#Simulations: mean bias, median absolute deviation, root-mean squared error, rejection rates

cat("Homogeneous treatment effects; non-constant lambda \n ")

source("File_3e_Sim.R") #Time difference of 1.445081 hours
#=========================================================================================>

#=========================================================================================>

#Empirical Application
sink(file.path("output", "out_2a_Empirical.txt"))
source("File_2a_Empirical.R")
sink()
#--------------------------------->
sink(file.path("output", "out_2b_Empirical_More.txt"))
source("File_2b_Empirical_More.R")
sink()
#=========================================================================================>

#===============================================================================

cat("See output/ for generated files \n ")

#===============================================================================
end.time<- Sys.time()
print(end.time-start.time)
#===============================================================================
