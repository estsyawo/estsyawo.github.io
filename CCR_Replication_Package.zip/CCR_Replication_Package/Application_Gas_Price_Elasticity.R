#=========================================================================================>
# Authors: Abdul-Nasah Soale & Emmanuel Selorm Tsyawo
# Project: Clustered Covariate Regression
# Date begun: Jan. 11, 2023
# Date last updated:  June 14, 2023
# Place:        Rabat
# Purpose: Simulations to compare the GPE, the LASSO-CV, LASSO with Belloni et al. lambda,
# and the post-LASSO version
#=========================================================================================>
rm(list=ls()) #clear memory
setwd(dirname(rstudioapi::getActiveDocumentContext()$path)) #set working directory path to source file
#===============================================================================
#load packages
library(cluscov)
library(mvtnorm)
library(fastDummies)
library(sandwich)
library(ggplot2)
library(glmnet)
library(estrpac) #install using 
source("Funktionen.R") #source functions from file
list.files()
#===============================================================================
#Notes: 
# 1. Running time: 2.703919 mins
# 2. Peak RAM usage: about 14 GB
#===============================================================================


start.time<- Sys.time()


#===============================================================================
dat<- read.csv("gasoline_final_tf1.csv",header = T)
dim(dat) # [1] 5001   15
summary(dat)

names(dat)

#---------------------- construct age groups by deciles of age
table(dat$age)
q.age<- c(33, 37, 42, 45, 52, 59, 66)
dat$agegroup<- NA
dat$agegroup[which(dat$age<= q.age[1])]<- 1
age.groups.vec<- nobs.groups.vec<- c()

nobs.groups.vec[1]<- length(which(dat$age<= q.age[1]))
cat("Age group",min(dat$age),"to",q.age[1],",",length(which(dat$age<= q.age[1])),
    "observations \n")
age.groups.vec[1]<- paste(min(dat$age),"-",q.age[1])

for(l in 2:length(q.age)){
  id<- which((dat$age> q.age[l-1]) & (dat$age<= q.age[l]))
  dat$agegroup[id]<- l
  nobs.groups.vec[l]<- length(id)
  age.groups.vec[l]<- paste(q.age[l-1]+1,"-",q.age[l])
  cat("Age group",q.age[l-1]+1,"to",q.age[l],",",length(id),"observations \n") 
}

data.frame(age.groups.vec,nobs.groups.vec)
# 1        20 - 33             713
# 2        34 - 37             552
# 3        38 - 42             751
# 4        43 - 45             372
# 5        46 - 52             821
# 6        53 - 59             604
# 7        60 - 66            1188
#===============================================================================
#Summary Statistics of data
summ.dat<- cbind(gas=dat$gas,price=dat$price,income=dat$income/1000)
#-- full sample
#mean
print.fn(round(apply(summ.dat,2,mean),3),nsmall=3)
#     gas     price    income 
# 291.898 &  0.567 & 49.140 \\

print.fn(round(apply(summ.dat,2,sd),3),nsmall=3)
#     gas     price    income 
# 273.327 &  0.050 & 24.878 \\

for(l in (1:length(q.age))){
  id<- which(dat$agegroup==l)
  cat("Age group",q.age[l],"; Nobs=",length(id),"\n")
  
  print.fn(round(apply(summ.dat[id,],2,mean),3),nsmall=3)
  
  print.fn(round(apply(summ.dat[id,],2,sd),3),nsmall=3)
  
}#end for l

#===============================================================================
#--------------------- Transform categorical variables from integer to factor
cols.to.factor<-c("driver","month","fueltype","prov","year","hhsize")
dat[,cols.to.factor]<-lapply(dat[,cols.to.factor],factor)
#--------------------- Take logs of gas, price, income,age
cols.to.log<-c("gas","price","income","distance") #leave out age for creating subs-samples
dat[,cols.to.log]<-lapply(dat[,cols.to.log],log)
summary(dat)


#---------------------- Create outcome variable
Y=dat$gas

#---------------------- Create the components of the design matrix
X1<- dat[c("price","income","distance")]
X2<-X1^2; colnames(X2)<- c("price2","income2","distance2")
#set of binary variables generated from 
X3<- model.matrix( ~ driver + hhsize + month + prov + year, data = dat)[,-1]#remove intercept

X12<- cbind(X1,X2)[,c(1,4,2,5,3,6)] #re-arrange for easier referencing
names(X12) 
#[1] "price"     "price2"    "income"    "income2"   "distance"  "distance2"

#-- design matrix
Xm<-cbind(X12, X12$price*X3, X12$price2*X3, X3) # 87 covariates
#-- matrix of derivatives w.r.t. price
dXm<- cbind(1,2*X12$price,0,0,0,0,X3,2*X12$price*X3,matrix(0,nrow(X3),ncol(X3)))
dim(Xm)==dim(dXm) #confirm design matrix and its first derivate w.r.t. price are equal

Xm<- as.matrix(Xm); dXm<- as.matrix(dXm)
#===============================================================================
# Run regression on full sample
betas <- c(ADMM(Y, Xm, lambda=1, gam=2, omega=1, maxiter=1000)$beta)
GPE.full<- CCR.reg(Y=Y,X=Xm,c(0,betas),gam=2.7,report=TRUE)
mhat.full<- as.matrix(dummy_cols(GPE.full$CCRobj$clus)[,-1])
tau_X.full<- apply(dXm,2,mean) #average derivative of Xm w.r.t. price 
(est.GPE.full<- c(t(tau_X.full)%*%mhat.full%*%GPE.full$CCRobj$mobj$coefficients[-1]))
# [1] -0.02292326
(sig.GPE.full<- sqrt(c(t(tau_X.full)%*%mhat.full%*%vcovHC(GPE.full$CCRobj$mobj)[-1,-1]%*%t(mhat.full)%*%tau_X.full)))
# [1] 0.002360122
(CI.full<- est.GPE.full + qnorm(0.975)*sig.GPE.full*c(-1,1)) #95% confidence interval
#[1] -0.02754902 -0.01829751
GPE.full$khat #number of groups
# [1] 5
#===============================================================================
# Run regression on age groups
CI.sub.list<- list()
est.GPE.sub.vec<- sig2.GPE.sub.vec<- k.vec<- c(0)
#view frequency of age groups
table(dat$agegroup)
# 1   2   3   4   5   6   7   8 
# 713 552 455 806 683 604 437 751

for(l in (1:length(q.age))){
  id<- which(dat$agegroup==l)
  # detect degenerate covariates in subsamples to exclude
  idvars<- -which((apply(Xm[id,],2,sd))==0)
  if(length(idvars)==0){idvars=1:ncol(Xm)}
  #Generate group starting values
  betas.group <- c(ADMM(Y[id], as.matrix(Xm[id,idvars]), lambda=1, gam=2, omega=1, maxiter=1000)$beta)
  seqCCRobj<- CCR.reg(Y=Y[id],X=as.matrix(Xm[id,idvars]),c(0,betas.group),gam=2.7,report=TRUE)
  (k.vec[l]<- seqCCRobj$khat)
  mhat.sub<- as.matrix(fastDummies::dummy_cols(seqCCRobj$CCRobj$clus)[,-1])
  tau_X.sub<- apply(dXm[id,idvars],2,mean) #average derivative of Xm w.r.t. price 
  est.GPE.sub.vec[l]<- c(t(tau_X.sub)%*%mhat.sub%*%seqCCRobj$CCRobj$mobj$coefficients[-1])
  #compute variance
  sig2.GPE.sub.vec[l]<- c(t(tau_X.sub)%*%mhat.sub%*%
                                   vcovHC(seqCCRobj$CCRobj$mobj)[-1,-1]%*%t(mhat.sub)%*%tau_X.sub)
}
k.vec
cbind(est.GPE.sub.vec,sqrt(sig2.GPE.sub.vec))
#===============================================================================
# Present results; Upper bound of age group (Age), estimated average elasticity of demand (Est.), 
# Heteroskedasticity Robust Standard Error (Ste), Lower Pointwise 95% CI (PW_L.CI), and Upper 
# Pointwise 95% CI (PW_U.CI)
res<- data.frame(q.age,est.GPE.sub.vec,sqrt(sig2.GPE.sub.vec),
            est.GPE.sub.vec - qnorm(0.975)*sqrt(sig2.GPE.sub.vec),
            est.GPE.sub.vec + qnorm(0.975)*sqrt(sig2.GPE.sub.vec))
colnames(res)<- c("Age","Est.","Ste","PW_L.CI","PW_U.CI")
res

#---------------------------------
# Compute equal-tailed simultaneous confidence bands using the 
# Montiel Olea & Plagborg-Moller 2018 simultaneous bands
set.seed(1) #for reproducibility
Sim.Est<- rmvnorm(n=1e06,mean = est.GPE.sub.vec,sigma = diag(sig2.GPE.sub.vec))

BBobj<- BB_CBOM(DQmat = t(Sim.Est),alpha = 0.05)
res$Sim_L.CI<- BBobj$BB[,1]
res$Sim_U.CI<- BBobj$BB[,2]
res


len = nrow(res)
group <-c(rep("UCI",len), rep("PCI",len), rep("Estimate",len),rep("PCIL",len),rep("UCIL",len))
group_type<- c(rep("CI",len), rep("CI",len), rep("Estimate",len),rep("CI",len),rep("CI",len))
group_ci_type<-c(rep("Uniform",len), rep("Point",len), rep("Uniform",len),rep("Point",len),rep("Uniform",len))

df<-data.frame(age=rep(res$Age,5), elasticity = c(res$Sim_L.CI,res$PW_L.CI,res$Est.,res$PW_U.CI,res$Sim_U.CI),
               group=group, group_col = group_type,group_line =group_ci_type)
make_plot(df,lowy = -0.050, highy = -0.020,out.file="Price_Elasticity_Age.pdf")
#===============================================================================

#Interesting hypotheses:
# Is the income elasticity of demand constant across age groups?
min(res$Sim_U.CI)>max(res$Sim_L.CI) #  we reject the null
#[1] FALSE

#===============================================================================





#===============================================================================
# Run pLASSO regression on full sample
amelior.X<- c(1,3)
pLASSO.full<- pLASSO.reg(Y=Y,X=Xm,amelior.X = amelior.X)

(est.pLASSO.full<- pLASSO.full$postLASSO$coefficients[2])
# -0.2274567
(sig.pLASSO.full<- sqrt(vcovHC(pLASSO.full$postLASSO)[2,2]))
# [1] 0.05253292
(CI.full<- est.pLASSO.full + qnorm(0.975)*sig.pLASSO.full*c(-1,1)) #95% confidence interval
# [1] -0.3304193 -0.1244941
(pLASSO.full$khat<- length(pLASSO.full$postLASSO$id.vars)) #number of groups
# [1] 2
amelior.X%in%pLASSO.full$postLASSO$id.vars  #Income was not included in the original pLASSO.
# [1] FALSE
#===============================================================================
# Run regression on age groups
CI.sub.list<- list()
est.pLASSO.sub.vec<- sig.pLASSO.sub.vec<- pLASSO.k.vec<- c(0)

for(l in (1:length(q.age))){
  id<- which(dat$agegroup==l)
  # detect degenerate covariates in subsamples to exclude
  idvars<- -which((apply(Xm[id,],2,sd))==0)
  if(length(idvars)==0){idvars=1:ncol(Xm)}
  #Generate group starting values
  pLASSOobj<- pLASSO.reg(Y=Y[id],X=as.matrix(Xm[id,idvars]),amelior.X = amelior.X)
  cat("l=",l,"\n")
  print(pLASSOobj$postLASSO$coefficients)
  cat("\n")
  est.pLASSO.sub.vec[l]<- pLASSOobj$postLASSO$coefficients[2]
  #compute variance
  sig.pLASSO.sub.vec[l]<- sqrt(vcovHC(pLASSOobj$postLASSO)[2,2])
  pLASSO.k.vec[l]<- length(pLASSOobj$postLASSO$id.vars)
}

cbind(est.pLASSO.sub.vec,sig.pLASSO.sub.vec)
#===============================================================================



#===============================================================================
res.dmat<- data.frame(c("All",age.groups.vec),c(dim(dat)[1],nobs.groups.vec),
                      c(est.GPE.full,est.GPE.sub.vec),c(sig.GPE.full,sqrt(sig2.GPE.sub.vec)),
                      c(est.pLASSO.full,est.pLASSO.sub.vec),c(sig.pLASSO.full,sig.pLASSO.sub.vec))
res.dmat[,-c(1,2)]<- round(res.dmat[,-c(1,2)],3)
names(res.dmat)<- c("Age-Group","Nobs","est.GPE","ste.GPE","est.pLASSO","ste.pLASSO")

res.dmat

sink("Out_Price.Elasticity.txt")
apply(res.dmat,1,print.fn,nsmall=3)
sink()
#===============================================================================



#===============================================================================
end.time<- Sys.time()
end.time-start.time #Time difference of 4.919239 hours
