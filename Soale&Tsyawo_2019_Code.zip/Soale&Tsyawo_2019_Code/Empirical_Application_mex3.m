%% Implementation - clustered covariate regression using _mex() function.

%% load data:
clearvars;
load datlm.csv

% checking data:
[n,p] = size(datlm); % 1404       2791
Y = datlm(:,1);
XX = datlm(:,((1:p)~=1));
clear datlm; %free up memory
size(Y);
size(XX);

%% setting parameters
nC = 9; %first 9 columns in X not to cluster - check .R file

kmin = 90; kmax = 400; %interval over which to search k

%% First specification - without Bloom's Spilltech & Spillsic

[optk1,clus1,bets1,BIC1] = goldsscoord3_mex(Y,XX(:,[1,4:end]),nC-2,kmin,kmax);

%% Second specification - without Bloom's Spillsic

[optk2,clus2,bets2,BIC2] = goldsscoord3_mex(Y,XX(:,[1,2,4:end]),nC-1,kmin,kmax);

%% Third specification - with Bloom's Spilltech & Spillsic

[optk3,clus3,bets3,BIC3] = goldsscoord3_mex(Y,XX,nC,kmin,kmax);

%% Results:
% Optimal number of clusters optk is 163 for all three specifications.
 



%% Demonstration:
Xk = ones(n,(optkm+nC)); Xk(:,(1:nC)) = XX(:,(1:nC));
for j = 1:optkm
    Xk(:,(nC+j)) = sum(XX(:,clusm==j),2); %sum rows of columns in same cluster
end
deltasm = Xk\Y;

%% write out results to csv
writetable(array2table(clus1),'clus1.csv');
writetable(array2table(clus2),'clus2.csv');
writetable(array2table(clus3),'clus3.csv');



