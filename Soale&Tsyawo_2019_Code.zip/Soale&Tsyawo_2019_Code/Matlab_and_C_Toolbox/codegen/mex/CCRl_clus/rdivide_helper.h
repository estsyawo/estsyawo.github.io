/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * rdivide_helper.h
 *
 * Code generation for function 'rdivide_helper'
 *
 */

#ifndef RDIVIDE_HELPER_H
#define RDIVIDE_HELPER_H

/* Include files */
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "tmwtypes.h"
#include "mex.h"
#include "emlrt.h"
#include "rtwtypes.h"
#include "CCRl_clus_types.h"

/* Type Definitions */
#include <stddef.h>

/* Function Declarations */
extern uint64_T b_rdivide_helper(uint64_T x, real_T y);
extern uint64_T rdivide_helper(uint64_T x);

#endif

/* End of code generation (rdivide_helper.h) */
