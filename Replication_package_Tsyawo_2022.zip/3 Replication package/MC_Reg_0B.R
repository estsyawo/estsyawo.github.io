#=========================================================================================>
# Author: Emmanuel Selorm Tsyawo
# Project: Feasible IV Regression without Excluded Instruments
# Date began:   Jan. 15, 2022
# Last Update:  Jan. 15, 2022
# Place:        Rabat
#=========================================================================================>
# Load packages, clear memory,
#rm(list=ls())
library(MASS)
library(estrpac)#install from binary file estrpac_0.1.0.tgz or
# use devtools::install_github("estsyawo/estrpac")
library(pbapply)
library(AER)
setwd(dirname(rstudioapi::getActiveDocumentContext()$path)) #set working directory path to source file
list.files()
#=========================================================================================>
# Comments: Monte Carlo Simulations, n = 250 & n = 500, DGP_0B
#=========================================================================================>
# Set Parameters
R = 1000 # set number of simulations
a=b=1

RMSE = function(x) sqrt(mean(x^2))
MAD = function(x) median(abs(x))

#-------------------------------------------------------
#this allows for multiple endogenous covariates
gdat1<- function(n,gam){
  datl=list()
  for (l in 1:R) {
    set.seed(l) #generate seed
    Z=rnorm(n)
    
    Sig = diag(2); Sig[1,2]=Sig[2,1]=0.5
    set.seed(l+10)
    EU=mvrnorm(n=n,mu=c(0,0),Sigma = Sig)
    #generate endogenous covariate
    D1 = 1/4 + Z + gam*Z^2+EU[,2]/sqrt(2)
    D2 = Z+EU[,1]/sqrt(2)
    #generate outcome
    Y = a + D1 + D2 + EU[,1] #Both covariates are endogenous
    
    #save in a list
    datl[[l]]<- list(Y=Y,X=cbind(D1,D2),Z=Z)
  }
  datl
}


MCfun1<- function(j=NULL,datl,b){
  dat = datl[[j]] #null operation for looping
  Y = dat$Y; X = as.matrix(dat$X)
  Z = as.matrix(dat$Z)
  
  #run Integrated Moment regressions
  MMDobj=imlmreg2.fit(Y,X,Z,Kern = "Euclid")
  WMDobj=imlmreg2.fit(Y,X,Z,Kern = "WMD")
  WMDFobj=imlmreg2.fit(Y,X,Z,Kern = "WMDF")
  DLobj=imlmreg2.fit(Y,X,Z,Kern = "DL")
  Esc6obj=imlmreg2.fit(Y,X,Z,Kern = "Esc6")
  IIVobj=imlmreg2.fit(Y,X,Z,Kern = "Gauss.W")
  
  #compute bias
  bias.MMD = MMDobj$coefficients[2]-b 
  bias.WMD = WMDobj$coefficients[2]-b
  bias.WMDF = WMDFobj$coefficients[2]-b
  bias.DL = DLobj$coefficients[2]-b
  bias.Esc6 = Esc6obj$coefficients[2]-b
  bias.IIV = IIVobj$coefficients[2]-b
  
  #compute size (for rejection probabilities)
  size.MMD = 1*(abs(bias.MMD/MMDobj$HC_Std.Err[2])>qnorm(0.975))
  size.WMD = 1*(abs(bias.WMD/WMDobj$HC_Std.Err[2])>qnorm(0.975))
  size.WMDF = 1*(abs(bias.WMDF/WMDFobj$HC_Std.Err[2])>qnorm(0.975))
  size.DL = 1*(abs(bias.DL/DLobj$HC_Std.Err[2])>qnorm(0.975))
  size.Esc6 = 1*(abs(bias.Esc6/Esc6obj$HC_Std.Err[2])>qnorm(0.975))
  size.IIV = 1*(abs(bias.IIV/IIVobj$HC_Std.Err[2])>qnorm(0.975))
  
  res=c(bias.MMD,bias.WMD,bias.WMDF,bias.DL,bias.Esc6,bias.IIV,
        size.MMD,size.WMD,size.WMDF,size.DL,size.Esc6,size.IIV)
  names(res)=c("BiasMMD","BiasWMD","BiasWMDF","BiasDL","BiasEsc6","BiasIIV",
               "SizeMMD","SizeWMD","SizeWMDF","SizeDL","SizeEsc6","SizeIIV")
  res
}
# 
#-------------------------------------------------------
#n = 250
datl1a=gdat1(n=250,gam = 0.1)
Bias1a = pbsapply(1:R, FUN=MCfun1,cl=5,datl=datl1a,b=b)
summary(t(Bias1a))

#n = 250
datl1aM=gdat1(n=250,gam = 0.5)
Bias1a.M = pbsapply(1:R, FUN=MCfun1,cl=5,datl=datl1aM,b=b)
summary(t(Bias1a.M))

#n = 250
datl1aMM=gdat1(n=250,gam = 1.0)
Bias1a.MM = pbsapply(1:R, FUN=MCfun1,cl=5,datl=datl1aMM,b=b)
summary(t(Bias1a.MM))
#-------------------------------------------------------

#-------------------------------------------------------
# specification b
#n = 500
datl1b=gdat1(n=500,gam = 0.1)
Bias1b = pbsapply(1:R, FUN=MCfun1,cl=5,datl=datl1b,b=b)
summary(t(Bias1b))

#n = 500
datl1bM=gdat1(n=500,gam = 0.5)
Bias1b.M = pbsapply(1:R, FUN=MCfun1,cl=5,datl=datl1bM,b=b)
summary(t(Bias1b.M))

#n = 500
datl1bMM=gdat1(n=500,gam = 1.0)
Bias1b.MM = pbsapply(1:R, FUN=MCfun1,cl=5,datl=datl1bMM,b=b)
summary(t(Bias1b.MM))
#=========================================================================================>

# Results:

Res.A1=round(cbind(apply(Bias1a[1:6,],1,mean),apply(Bias1a[1:6,],1,MAD),
                   apply(Bias1a[1:6,],1,RMSE),
                   apply(Bias1a[7:12,],1,mean)),3)
colnames(Res.A1)=c("MB","MAD","RMSE","Rej")
rownames(Res.A1)=c("MMD","WMD","WMDF","DL","ESC6","IIV")
Res.A1

Res.A2=round(cbind(apply(Bias1a.M[1:6,],1,mean),apply(Bias1a.M[1:6,],1,MAD),
                   apply(Bias1a.M[1:6,],1,RMSE),
                   apply(Bias1a.M[7:12,],1,mean)),3)
colnames(Res.A2)=c("MB","MAD","RMSE","Rej")
rownames(Res.A2)=c("MMD","WMD","WMDF","DL","ESC6","IIV")
Res.A2

Res.A3=round(cbind(apply(Bias1a.MM[1:6,],1,mean),apply(Bias1a.MM[1:6,],1,MAD),
                   apply(Bias1a.MM[1:6,],1,RMSE),
                   apply(Bias1a.MM[7:12,],1,mean)),3)
colnames(Res.A3)=c("MB","MAD","RMSE","Rej")
rownames(Res.A3)=c("MMD","WMD","WMDF","DL","ESC6","IIV")
Res.A3

cbind(Res.A1,Res.A2,Res.A3)
#         MB   MAD   RMSE   Rej     MB   MAD  RMSE   Rej     MB   MAD  RMSE   Rej
# MMD   0.172 0.316  0.992 0.042  0.008 0.060 0.095 0.051  0.002 0.030 0.047 0.060
# WMD   1.765 0.301 51.310 0.043  0.010 0.062 0.126 0.052  0.004 0.039 0.104 0.056
# WMDF  0.187 0.308  1.312 0.043  0.011 0.062 0.130 0.050  0.005 0.039 0.101 0.056
# DL   -1.353 0.380 52.332 0.043 -0.006 0.079 0.126 0.047 -0.007 0.041 0.066 0.046
# ESC6  0.081 0.358  5.484 0.032  0.010 0.067 0.104 0.040  0.003 0.033 0.050 0.044
# IIV   0.246 0.319  2.162 0.039  0.017 0.061 0.173 0.051  0.007 0.040 0.096 0.056

#writing out output to pasting into TeX
apply(cbind(Res.A1,Res.A2,Res.A3),1,paste,collapse=" & ")
# MMD 0.172 & 0.316 & 0.992 & 0.042 & 0.008 & 0.06 & 0.095 & 0.051 & 0.002 & 0.03 & 0.047 & 0.06" 
# WMD 1.765 & 0.301 & 51.31 & 0.043 & 0.01 & 0.062 & 0.126 & 0.052 & 0.004 & 0.039 & 0.104 & 0.056" 
# WMDF 0.187 & 0.308 & 1.312 & 0.043 & 0.011 & 0.062 & 0.13 & 0.05 & 0.005 & 0.039 & 0.101 & 0.056" 
# DL -1.353 & 0.38 & 52.332 & 0.043 & -0.006 & 0.079 & 0.126 & 0.047 & -0.007 & 0.041 & 0.066 & 0.046" 
# ESC6 0.081 & 0.358 & 5.484 & 0.032 & 0.01 & 0.067 & 0.104 & 0.04 & 0.003 & 0.033 & 0.05 & 0.044" 
# IIV 0.246 & 0.319 & 2.162 & 0.039 & 0.017 & 0.061 & 0.173 & 0.051 & 0.007 & 0.04 & 0.096 & 0.056"

#=========================================================================================>
Res.B1=round(cbind(apply(Bias1b[1:6,],1,mean),apply(Bias1b[1:6,],1,MAD),
                   apply(Bias1b[1:6,],1,RMSE),
                   apply(Bias1b[7:12,],1,mean)),3)
colnames(Res.B1)=c("MB","MAD","RMSE","Rej")
rownames(Res.B1)=c("MMD","WMD","WMDF","DL","ESC6","IIV")
Res.B1

Res.B2=round(cbind(apply(Bias1b.M[1:6,],1,mean),apply(Bias1b.M[1:6,],1,MAD),
                   apply(Bias1b.M[1:6,],1,RMSE),
                   apply(Bias1b.M[7:12,],1,mean)),3)
colnames(Res.B2)=c("MB","MAD","RMSE","Rej")
rownames(Res.B2)=c("MMD","WMD","WMDF","DL","ESC6","IIV")
Res.B2

Res.B3=round(cbind(apply(Bias1b.MM[1:6,],1,mean),apply(Bias1b.MM[1:6,],1,MAD),
                   apply(Bias1b.MM[1:6,],1,RMSE),
                   apply(Bias1b.MM[7:12,],1,mean)),3)
colnames(Res.B3)=c("MB","MAD","RMSE","Rej")
rownames(Res.B3)=c("MMD","WMD","WMDF","DL","ESC6","IIV")
Res.B3

cbind(Res.B1,Res.B2,Res.B3)
#       MB   MAD  RMSE   Rej     MB   MAD  RMSE   Rej     MB   MAD  RMSE   Rej
# MMD  0.067 0.217 0.372 0.034  0.005 0.041 0.065 0.050  0.002 0.021 0.032 0.056
# WMD  0.050 0.215 0.363 0.038  0.005 0.043 0.066 0.051  0.004 0.026 0.041 0.061
# WMDF 0.051 0.216 0.365 0.038  0.005 0.043 0.066 0.051  0.004 0.026 0.041 0.061
# DL   0.069 0.281 0.703 0.048 -0.004 0.056 0.085 0.053 -0.004 0.030 0.045 0.051
# ESC6 0.085 0.244 0.449 0.034  0.006 0.044 0.069 0.040  0.002 0.022 0.034 0.040
# IIV  0.061 0.220 0.371 0.035  0.007 0.043 0.067 0.051  0.005 0.026 0.041 0.062

#for pasting into TeX
apply(cbind(Res.B1,Res.B2,Res.B3),1,paste,collapse=" & ")
# MMD 0.067 & 0.217 & 0.372 & 0.034 & 0.005 & 0.041 & 0.065 & 0.05 & 0.002 & 0.021 & 0.032 & 0.056" 
# WMD 0.05 & 0.215 & 0.363 & 0.038 & 0.005 & 0.043 & 0.066 & 0.051 & 0.004 & 0.026 & 0.041 & 0.061" 
# WMDF 0.051 & 0.216 & 0.365 & 0.038 & 0.005 & 0.043 & 0.066 & 0.051 & 0.004 & 0.026 & 0.041 & 0.061" 
# DL 0.069 & 0.281 & 0.703 & 0.048 & -0.004 & 0.056 & 0.085 & 0.053 & -0.004 & 0.03 & 0.045 & 0.051" 
# ESC6 0.085 & 0.244 & 0.449 & 0.034 & 0.006 & 0.044 & 0.069 & 0.04 & 0.002 & 0.022 & 0.034 & 0.04" 
# IIV 0.061 & 0.22 & 0.371 & 0.035 & 0.007 & 0.043 & 0.067 & 0.051 & 0.005 & 0.026 & 0.041 & 0.062"
#=========================================================================================>


#=========================================================================================>