/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 * File: CCRls.c
 *
 * MATLAB Coder version            : 4.1
 * C/C++ source code generated on  : 22-Nov-2018 23:51:16
 */

/* Include Files */
#include <math.h>
#include "CCRls.h"
#include "CCRls_emxutil.h"
#include "mldivide.h"
#include "round.h"
#include <stdio.h>

/* Function Definitions */

/*
 * Arguments    : const emxArray_real_T *Y
 *                const emxArray_real_T *X
 *                emxArray_real_T *betas
 * Return Type  : void
 */
void CCRls(const emxArray_real_T *Y, const emxArray_real_T *X, emxArray_real_T
           *betas)
{
  emxArray_real_T *lcls;
  int n;
  int slc;
  int i0;
  int i1;
  int loop_ub;
  int b_n;
  double nlcls;
  int k;
  emxArray_real_T *X0;
  double bet0;
  emxArray_real_T *bet_vec;
  emxArray_real_T *coefs;
  double val0;
  double val1;
  double dv0[2];
  double l;
  double dev;
  emxArray_boolean_T *ngIDLS;
  emxArray_boolean_T *IDls;
  emxArray_real_T *XX;
  emxArray_real_T *r0;
  emxArray_int32_T *r1;
  emxArray_int32_T *r2;
  emxArray_int32_T *r3;
  cell_wrap_0 reshapes[3];
  emxArray_real_T *y;
  emxArray_char_T *charStr;
  emxArray_int32_T *a_tmp;
  emxArray_real_T *b_X;
  emxArray_real_T *b_bet_vec;
  int inner;
  boolean_T empty_non_axis_sizes;
  signed char input_sizes_idx_1;
  boolean_T guard1 = false;
  unsigned int a_idx_0;
  emxInit_real_T(&lcls, 2);
  n = X->size[0];

  /*  vector to store parameters, excludes intercept */
  /*  fraction of total number of observations as partition size */
  slc = (int)floor(0.1 * (double)X->size[0]);

  /* maximum size of a local covariate cluster. */
  if (X->size[1] < 1) {
    lcls->size[0] = 1;
    lcls->size[1] = 0;
  } else {
    i0 = X->size[1];
    i1 = lcls->size[0] * lcls->size[1];
    lcls->size[0] = 1;
    loop_ub = (int)((double)i0 - 1.0);
    lcls->size[1] = loop_ub + 1;
    emxEnsureCapacity_real_T(lcls, i1);
    for (i0 = 0; i0 <= loop_ub; i0++) {
      lcls->data[i0] = 1.0 + (double)i0;
    }
  }

  i0 = lcls->size[0] * lcls->size[1];
  i1 = lcls->size[0] * lcls->size[1];
  lcls->size[0] = 1;
  emxEnsureCapacity_real_T(lcls, i1);
  loop_ub = i0 - 1;
  for (i0 = 0; i0 <= loop_ub; i0++) {
    lcls->data[i0] /= (double)slc;
  }

  b_round(lcls);
  i0 = lcls->size[0] * lcls->size[1];
  i1 = lcls->size[0] * lcls->size[1];
  lcls->size[0] = 1;
  emxEnsureCapacity_real_T(lcls, i1);
  loop_ub = i0 - 1;
  for (i0 = 0; i0 <= loop_ub; i0++) {
    lcls->data[i0]++;
  }

  /* partition covarites into clusters */
  b_n = lcls->size[1];
  if (lcls->size[1] <= 2) {
    if (lcls->size[1] == 1) {
      nlcls = lcls->data[0];
    } else if (lcls->data[0] < lcls->data[1]) {
      nlcls = lcls->data[1];
    } else {
      nlcls = lcls->data[0];
    }
  } else {
    nlcls = lcls->data[0];
    for (k = 2; k <= b_n; k++) {
      if (nlcls < lcls->data[k - 1]) {
        nlcls = lcls->data[k - 1];
      }
    }
  }

  emxInit_real_T(&X0, 2);

  /*  number of partitions */
  /*  Initialise parameters */
  bet0 = 0.0;

  /* initialise intercept */
  i0 = X0->size[0] * X0->size[1];
  X0->size[0] = X->size[0];
  X0->size[1] = 2;
  emxEnsureCapacity_real_T(X0, i0);
  loop_ub = X->size[0] << 1;
  for (i0 = 0; i0 < loop_ub; i0++) {
    X0->data[i0] = 1.0;
  }

  emxInit_real_T(&bet_vec, 2);

  /*  coef0 = zeros(1,2)'; */
  i0 = X->size[1];
  i1 = bet_vec->size[0] * bet_vec->size[1];
  bet_vec->size[0] = 1;
  bet_vec->size[1] = X->size[1];
  emxEnsureCapacity_real_T(bet_vec, i1);
  for (b_n = 0; b_n < i0; b_n++) {
    loop_ub = X->size[0] - 1;
    for (i1 = 0; i1 <= loop_ub; i1++) {
      X0->data[i1 + X0->size[0]] = X->data[i1 + X->size[0] * b_n];
    }

    mldivide(X0, Y, dv0);
    bet_vec->data[b_n] = dv0[1];
  }

  emxFree_real_T(&X0);
  emxInit_real_T(&coefs, 1);
  val0 = 1.00000000001E+10;
  val1 = 0.0;
  l = 0.0;
  dev = 1.00000000001E+10;
  i0 = coefs->size[0];
  coefs->size[0] = slc;
  emxEnsureCapacity_real_T(coefs, i0);
  for (i0 = 0; i0 < slc; i0++) {
    coefs->data[i0] = 0.0;
  }

  emxInit_boolean_T(&ngIDLS, 2);
  i0 = ngIDLS->size[0] * ngIDLS->size[1];
  ngIDLS->size[0] = 1;
  ngIDLS->size[1] = X->size[1] - slc;
  emxEnsureCapacity_boolean_T(ngIDLS, i0);
  loop_ub = X->size[1] - slc;
  for (i0 = 0; i0 < loop_ub; i0++) {
    ngIDLS->data[i0] = false;
  }

  emxInit_boolean_T(&IDls, 2);
  i0 = IDls->size[0] * IDls->size[1];
  IDls->size[0] = 1;
  IDls->size[1] = slc;
  emxEnsureCapacity_boolean_T(IDls, i0);
  for (i0 = 0; i0 < slc; i0++) {
    IDls->data[i0] = false;
  }

  emxInit_real_T(&XX, 2);
  emxInit_real_T(&r0, 2);
  emxInit_int32_T(&r1, 2);
  emxInit_int32_T(&r2, 2);
  emxInit_int32_T(&r3, 2);
  emxInitMatrix_cell_wrap_0(reshapes);
  emxInit_real_T(&y, 1);
  emxInit_char_T(&charStr, 2);
  emxInit_int32_T(&a_tmp, 1);
  emxInit_real_T(&b_X, 2);
  emxInit_real_T(&b_bet_vec, 1);
  while (dev > 1.0E-6) {
    if (l > 0.0) {
      val0 = val1;
      if (2.0 > (double)coefs->size[0] - 1.0) {
        i0 = 1;
      } else {
        i0 = 2;
      }

      slc = IDls->size[1];
      b_n = -1;
      for (loop_ub = 0; loop_ub < slc; loop_ub++) {
        if (IDls->data[loop_ub]) {
          bet_vec->data[loop_ub] = coefs->data[i0 + b_n];
          b_n++;
        }
      }

      bet0 = coefs->data[0];
      slc = ngIDLS->size[1] - 1;
      b_n = 0;
      for (loop_ub = 0; loop_ub <= slc; loop_ub++) {
        if (ngIDLS->data[loop_ub]) {
          b_n++;
        }
      }

      i0 = r3->size[0] * r3->size[1];
      r3->size[0] = 1;
      r3->size[1] = b_n;
      emxEnsureCapacity_int32_T(r3, i0);
      b_n = 0;
      for (loop_ub = 0; loop_ub <= slc; loop_ub++) {
        if (ngIDLS->data[loop_ub]) {
          r3->data[b_n] = loop_ub + 1;
          b_n++;
        }
      }

      i0 = r0->size[0] * r0->size[1];
      r0->size[0] = 1;
      r0->size[1] = r3->size[1];
      emxEnsureCapacity_real_T(r0, i0);
      val1 = coefs->data[coefs->size[0] - 1];
      loop_ub = r3->size[0] * r3->size[1];
      for (i0 = 0; i0 < loop_ub; i0++) {
        r0->data[i0] = bet_vec->data[r3->data[i0] - 1] * val1;
      }

      slc = ngIDLS->size[1];
      b_n = 0;
      for (loop_ub = 0; loop_ub < slc; loop_ub++) {
        if (ngIDLS->data[loop_ub]) {
          bet_vec->data[loop_ub] = r0->data[b_n];
          b_n++;
        }
      }
    }

    l++;
    val1 = l - (ceil(l / nlcls) - 1.0) * nlcls;
    i0 = IDls->size[0] * IDls->size[1];
    IDls->size[0] = 1;
    IDls->size[1] = lcls->size[1];
    emxEnsureCapacity_boolean_T(IDls, i0);
    loop_ub = lcls->size[0] * lcls->size[1];
    for (i0 = 0; i0 < loop_ub; i0++) {
      IDls->data[i0] = (lcls->data[i0] == val1);
    }

    /*  nIDls = length(IDls); */
    i0 = ngIDLS->size[0] * ngIDLS->size[1];
    ngIDLS->size[0] = 1;
    ngIDLS->size[1] = lcls->size[1];
    emxEnsureCapacity_boolean_T(ngIDLS, i0);
    loop_ub = lcls->size[0] * lcls->size[1];
    for (i0 = 0; i0 < loop_ub; i0++) {
      ngIDLS->data[i0] = (lcls->data[i0] != val1);
    }

    slc = ngIDLS->size[1] - 1;
    b_n = 0;
    for (loop_ub = 0; loop_ub <= slc; loop_ub++) {
      if (ngIDLS->data[loop_ub]) {
        b_n++;
      }
    }

    i0 = r1->size[0] * r1->size[1];
    r1->size[0] = 1;
    r1->size[1] = b_n;
    emxEnsureCapacity_int32_T(r1, i0);
    b_n = 0;
    for (loop_ub = 0; loop_ub <= slc; loop_ub++) {
      if (ngIDLS->data[loop_ub]) {
        r1->data[b_n] = loop_ub + 1;
        b_n++;
      }
    }

    i0 = a_tmp->size[0];
    a_tmp->size[0] = r1->size[1];
    emxEnsureCapacity_int32_T(a_tmp, i0);
    loop_ub = r1->size[1];
    for (i0 = 0; i0 < loop_ub; i0++) {
      a_tmp->data[i0] = r1->data[i0];
    }

    if (a_tmp->size[0] == 1) {
      loop_ub = X->size[0];
      i0 = b_X->size[0] * b_X->size[1];
      b_X->size[0] = loop_ub;
      b_X->size[1] = a_tmp->size[0];
      emxEnsureCapacity_real_T(b_X, i0);
      b_n = a_tmp->size[0];
      for (i0 = 0; i0 < b_n; i0++) {
        for (i1 = 0; i1 < loop_ub; i1++) {
          b_X->data[i1 + b_X->size[0] * i0] = X->data[i1 + X->size[0] *
            (a_tmp->data[i0] - 1)];
        }
      }

      i0 = b_bet_vec->size[0];
      b_bet_vec->size[0] = a_tmp->size[0];
      emxEnsureCapacity_real_T(b_bet_vec, i0);
      loop_ub = a_tmp->size[0];
      for (i0 = 0; i0 < loop_ub; i0++) {
        b_bet_vec->data[i0] = bet_vec->data[a_tmp->data[i0] - 1];
      }

      i0 = coefs->size[0];
      coefs->size[0] = b_X->size[0];
      emxEnsureCapacity_real_T(coefs, i0);
      loop_ub = b_X->size[0];
      for (i0 = 0; i0 < loop_ub; i0++) {
        coefs->data[i0] = 0.0;
        b_n = b_X->size[1];
        for (i1 = 0; i1 < b_n; i1++) {
          coefs->data[i0] += b_X->data[i0 + b_X->size[0] * i1] * b_bet_vec->
            data[i1];
        }
      }
    } else {
      i0 = X->size[0];
      inner = a_tmp->size[0];
      i1 = X->size[0];
      b_n = coefs->size[0];
      coefs->size[0] = i1;
      emxEnsureCapacity_real_T(coefs, b_n);
      for (loop_ub = 0; loop_ub < i0; loop_ub++) {
        coefs->data[loop_ub] = 0.0;
      }

      for (k = 0; k < inner; k++) {
        slc = k * i0;
        for (loop_ub = 0; loop_ub < i0; loop_ub++) {
          i1 = X->size[0];
          b_n = slc + loop_ub;
          coefs->data[loop_ub] += bet_vec->data[a_tmp->data[k] - 1] * X->
            data[b_n % i1 + X->size[0] * (a_tmp->data[b_n / i1] - 1)];
        }
      }
    }

    slc = IDls->size[1] - 1;
    b_n = 0;
    for (loop_ub = 0; loop_ub <= slc; loop_ub++) {
      if (IDls->data[loop_ub]) {
        b_n++;
      }
    }

    i0 = r2->size[0] * r2->size[1];
    r2->size[0] = 1;
    r2->size[1] = b_n;
    emxEnsureCapacity_int32_T(r2, i0);
    b_n = 0;
    for (loop_ub = 0; loop_ub <= slc; loop_ub++) {
      if (IDls->data[loop_ub]) {
        r2->data[b_n] = loop_ub + 1;
        b_n++;
      }
    }

    if (n != 0) {
      slc = n;
    } else {
      i0 = X->size[0];
      i1 = a_tmp->size[0];
      a_tmp->size[0] = r2->size[1];
      emxEnsureCapacity_int32_T(a_tmp, i1);
      loop_ub = r2->size[1];
      for (i1 = 0; i1 < loop_ub; i1++) {
        a_tmp->data[i1] = r2->data[i1];
      }

      if ((i0 != 0) && (a_tmp->size[0] != 0)) {
        slc = X->size[0];
      } else if (coefs->size[0] != 0) {
        slc = coefs->size[0];
      } else {
        slc = 0;
        i0 = X->size[0];
        if (i0 > 0) {
          slc = X->size[0];
        }
      }
    }

    empty_non_axis_sizes = (slc == 0);
    if (empty_non_axis_sizes || (n != 0)) {
      input_sizes_idx_1 = 1;
    } else {
      input_sizes_idx_1 = 0;
    }

    i0 = reshapes[0].f1->size[0] * reshapes[0].f1->size[1];
    reshapes[0].f1->size[0] = slc;
    reshapes[0].f1->size[1] = input_sizes_idx_1;
    emxEnsureCapacity_real_T(reshapes[0].f1, i0);
    loop_ub = slc * input_sizes_idx_1;
    for (i0 = 0; i0 < loop_ub; i0++) {
      reshapes[0].f1->data[i0] = 1.0;
    }

    guard1 = false;
    if (empty_non_axis_sizes) {
      guard1 = true;
    } else {
      i0 = X->size[0];
      i1 = a_tmp->size[0];
      a_tmp->size[0] = r2->size[1];
      emxEnsureCapacity_int32_T(a_tmp, i1);
      loop_ub = r2->size[1];
      for (i1 = 0; i1 < loop_ub; i1++) {
        a_tmp->data[i1] = r2->data[i1];
      }

      if ((i0 != 0) && (a_tmp->size[0] != 0)) {
        guard1 = true;
      } else {
        inner = 0;
      }
    }

    if (guard1) {
      i0 = a_tmp->size[0];
      a_tmp->size[0] = r2->size[1];
      emxEnsureCapacity_int32_T(a_tmp, i0);
      loop_ub = r2->size[1];
      for (i0 = 0; i0 < loop_ub; i0++) {
        a_tmp->data[i0] = r2->data[i0];
      }

      inner = a_tmp->size[0];
    }

    if (empty_non_axis_sizes || (coefs->size[0] != 0)) {
      input_sizes_idx_1 = 1;
    } else {
      input_sizes_idx_1 = 0;
    }

    loop_ub = X->size[0];
    i0 = b_X->size[0] * b_X->size[1];
    b_X->size[0] = loop_ub;
    b_X->size[1] = r2->size[1];
    emxEnsureCapacity_real_T(b_X, i0);
    b_n = r2->size[1];
    for (i0 = 0; i0 < b_n; i0++) {
      for (i1 = 0; i1 < loop_ub; i1++) {
        b_X->data[i1 + b_X->size[0] * i0] = X->data[i1 + X->size[0] * (r2->
          data[i0] - 1)];
      }
    }

    i0 = XX->size[0] * XX->size[1];
    XX->size[0] = reshapes[0].f1->size[0];
    XX->size[1] = (reshapes[0].f1->size[1] + inner) + input_sizes_idx_1;
    emxEnsureCapacity_real_T(XX, i0);
    loop_ub = reshapes[0].f1->size[1];
    for (i0 = 0; i0 < loop_ub; i0++) {
      b_n = reshapes[0].f1->size[0];
      for (i1 = 0; i1 < b_n; i1++) {
        XX->data[i1 + XX->size[0] * i0] = reshapes[0].f1->data[i1 + reshapes[0].
          f1->size[0] * i0];
      }
    }

    for (i0 = 0; i0 < inner; i0++) {
      for (i1 = 0; i1 < slc; i1++) {
        XX->data[i1 + XX->size[0] * (i0 + reshapes[0].f1->size[1])] = b_X->
          data[i1 + slc * i0];
      }
    }

    loop_ub = input_sizes_idx_1;
    for (i0 = 0; i0 < loop_ub; i0++) {
      for (i1 = 0; i1 < slc; i1++) {
        XX->data[i1 + XX->size[0] * (reshapes[0].f1->size[1] + inner)] =
          coefs->data[i1];
      }
    }

    /* make room for intercept term */
    i0 = coefs->size[0];
    coefs->size[0] = Y->size[0];
    emxEnsureCapacity_real_T(coefs, i0);
    loop_ub = Y->size[0];
    for (i0 = 0; i0 < loop_ub; i0++) {
      coefs->data[i0] = Y->data[i0];
    }

    b_mldivide(XX, coefs);
    if ((XX->size[1] == 1) || (coefs->size[0] == 1)) {
      i0 = b_bet_vec->size[0];
      b_bet_vec->size[0] = XX->size[0];
      emxEnsureCapacity_real_T(b_bet_vec, i0);
      loop_ub = XX->size[0];
      for (i0 = 0; i0 < loop_ub; i0++) {
        b_bet_vec->data[i0] = 0.0;
        b_n = XX->size[1];
        for (i1 = 0; i1 < b_n; i1++) {
          b_bet_vec->data[i0] += XX->data[i0 + XX->size[0] * i1] * coefs->
            data[i1];
        }
      }
    } else {
      b_n = XX->size[0];
      inner = XX->size[1];
      i0 = b_bet_vec->size[0];
      b_bet_vec->size[0] = XX->size[0];
      emxEnsureCapacity_real_T(b_bet_vec, i0);
      for (loop_ub = 0; loop_ub < b_n; loop_ub++) {
        b_bet_vec->data[loop_ub] = 0.0;
      }

      for (k = 0; k < inner; k++) {
        slc = k * b_n;
        for (loop_ub = 0; loop_ub < b_n; loop_ub++) {
          b_bet_vec->data[loop_ub] += coefs->data[k] * XX->data[slc + loop_ub];
        }
      }
    }

    i0 = b_bet_vec->size[0];
    b_bet_vec->size[0] = Y->size[0];
    emxEnsureCapacity_real_T(b_bet_vec, i0);
    loop_ub = Y->size[0];
    for (i0 = 0; i0 < loop_ub; i0++) {
      b_bet_vec->data[i0] = Y->data[i0] - b_bet_vec->data[i0];
    }

    a_idx_0 = (unsigned int)b_bet_vec->size[0];
    i0 = y->size[0];
    y->size[0] = (int)a_idx_0;
    emxEnsureCapacity_real_T(y, i0);
    a_idx_0 = (unsigned int)b_bet_vec->size[0];
    b_n = (int)a_idx_0;
    for (k = 0; k < b_n; k++) {
      y->data[k] = b_bet_vec->data[k] * b_bet_vec->data[k];
    }

    b_n = y->size[0];
    if (y->size[0] == 0) {
      val1 = 0.0;
    } else {
      val1 = y->data[0];
      for (k = 2; k <= b_n; k++) {
        val1 += y->data[k - 1];
      }
    }

    if (l > 1.0) {
      dev = (val0 - val1) / (1.0 + fabs(val0));
    } else {
      dev = 1.0;
    }

    /*  print progress */
    if (fmod(l, 100.0) == 0.0) {
      b_n = (int)snprintf(NULL, 0, "iter = %.0f fval = %f and dev = %f", l, val1,
                          dev) + 1;
      i0 = charStr->size[0] * charStr->size[1];
      charStr->size[0] = 1;
      charStr->size[1] = b_n;
      emxEnsureCapacity_char_T(charStr, i0);
      snprintf(&charStr->data[0], (size_t)b_n,
               "iter = %.0f fval = %f and dev = %f", l, val1, dev);
    }
  }

  emxFree_real_T(&b_bet_vec);
  emxFree_real_T(&b_X);
  emxFree_int32_T(&a_tmp);
  emxFree_char_T(&charStr);
  emxFree_real_T(&y);
  emxFreeMatrix_cell_wrap_0(reshapes);
  emxFree_int32_T(&r3);
  emxFree_int32_T(&r2);
  emxFree_int32_T(&r1);
  emxFree_real_T(&r0);
  emxFree_real_T(&XX);
  emxFree_boolean_T(&IDls);
  emxFree_boolean_T(&ngIDLS);
  emxFree_real_T(&coefs);
  emxFree_real_T(&lcls);
  i0 = betas->size[0] * betas->size[1];
  betas->size[0] = 1;
  betas->size[1] = 1 + bet_vec->size[1];
  emxEnsureCapacity_real_T(betas, i0);
  betas->data[0] = bet0;
  loop_ub = bet_vec->size[1];
  for (i0 = 0; i0 < loop_ub; i0++) {
    betas->data[i0 + 1] = bet_vec->data[i0];
  }

  emxFree_real_T(&bet_vec);

  /* concatenate final parameter estimates */
}

/*
 * File trailer for CCRls.c
 *
 * [EOF]
 */
