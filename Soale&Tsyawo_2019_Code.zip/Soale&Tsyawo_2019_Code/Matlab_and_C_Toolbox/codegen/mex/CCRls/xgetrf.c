/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * xgetrf.c
 *
 * Code generation for function 'xgetrf'
 *
 */

/* Include files */
#include "mwmathutil.h"
#include "rt_nonfinite.h"
#include "CCRls.h"
#include "xgetrf.h"
#include "CCRls_emxutil.h"
#include "CCRls_data.h"
#include "lapacke.h"

/* Function Definitions */
void xgetrf(int32_T m, int32_T n, emxArray_real_T *A, int32_T lda,
            emxArray_int32_T *ipiv, int32_T *info)
{
  emxArray_ptrdiff_t *ipiv_t;
  int32_T i5;
  int32_T i6;
  ptrdiff_t info_t;
  int32_T k;
  int32_T loop_ub;
  int32_T i7;
  emlrtHeapReferenceStackEnterFcnR2012b(emlrtRootTLSGlobal);
  if ((A->size[0] == 0) || (A->size[1] == 0)) {
    ipiv->size[0] = 1;
    ipiv->size[1] = 0;
    *info = 0;
  } else {
    emxInit_ptrdiff_t(&ipiv_t, 1, true);
    i5 = ipiv_t->size[0];
    i6 = muIntScalarMin_sint32(m, n);
    ipiv_t->size[0] = muIntScalarMax_sint32(i6, 1);
    emxEnsureCapacity_ptrdiff_t(ipiv_t, i5);
    info_t = LAPACKE_dgetrf_work(102, (ptrdiff_t)m, (ptrdiff_t)n, &A->data[0],
      (ptrdiff_t)lda, &ipiv_t->data[0]);
    *info = (int32_T)info_t;
    i5 = ipiv->size[0] * ipiv->size[1];
    ipiv->size[0] = 1;
    ipiv->size[1] = ipiv_t->size[0];
    emxEnsureCapacity_int32_T(ipiv, i5);
    if (*info < 0) {
      i5 = A->size[0] * A->size[1];
      emxEnsureCapacity_real_T(A, i5);
      k = A->size[1];
      for (i5 = 0; i5 < k; i5++) {
        loop_ub = A->size[0];
        for (i7 = 0; i7 < loop_ub; i7++) {
          A->data[i7 + A->size[0] * i5] = rtNaN;
        }
      }

      i5 = ipiv->size[1] - 1;
      for (k = 0; k <= i5; k++) {
        ipiv->data[k] = k + 1;
      }
    } else {
      i5 = ipiv->size[1] - 1;
      for (k = 0; k <= i5; k++) {
        ipiv->data[k] = (int32_T)ipiv_t->data[k];
      }
    }

    emxFree_ptrdiff_t(&ipiv_t);
  }

  emlrtHeapReferenceStackLeaveFcnR2012b(emlrtRootTLSGlobal);
}

/* End of code generation (xgetrf.c) */
