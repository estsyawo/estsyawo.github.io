function [bets,deltas,klus, RSS1]=cordlin_clus(Y,X,k,nC)
%% use coordinate descent to estimate linear regression
% and incorporate covariate clustering into k clusters.

%% inputs:
% Y - vector of outcome variable
% X - matrix of p covariates, including 1's for intercept
% k - number of clusters
% nC - the first nC covariates in X are not to be clustered. nC=1 if only
% intercept is excluded from clustering.


%%
[n,p] = size(X); az = 1e-20; tol = 1e-010;
bets = zeros(1,p); %initialise vector of parameters
clus = zeros(1,p);
Xdot = zeros(1,p); cnt = 0;

%% initialise parameters
X0 = ones(n,2); % for the initialisation of coefficients
for j=2:p %intercept initialised at zero
   X0(:,2) = X(:,j); 
   coef0 = X0\Y;
   bets(j) = coef0(2) ;
   Xdot(1,j) = dot(X(:,j),X(:,j)); %sum of squared X[,j]
end
Xdot(1,1) = n; %sum of squared X[,1] (intercept)
RSS0 = sum((Y-X*bets(1,:)').^2); % initial RSS0
%% Initial clustering
rng(1); % For reproducibility
[klus,clmns] = kmeans(bets(1,((nC+1):p))',k); % bets of length p
clus(1,((nC+1):p)) = klus;
%% to run in a while loop
while 1
    cnt = cnt+1;
for j = 1:p
    id = (1:p)~=j;
    err = Y-X(:,id)*bets(1,id)';
    
    if(j>nC)
    bj = dot(err,X(:,j))/Xdot(1,j);
    idj = clus(j); %identify current cluster assignment
    [~,idmn]=min(abs(clmns-bj)); % identify nearest cluster centre
        if(idmn~=idj)
        id = clus==idmn;
        bets(1,j) = mean([bj bets(1,id)]); %update clustered j
        clus(j) = idmn; %update j's cluster
        end 
    else
        bets(1,j) = dot(err,X(:,j))/Xdot(1,j);%update directly for non-clustered
    end %end if(j>nC)
end

%% Compute RSS & check convergence
RSS1 = sum((Y-X*bets(1,:)').^2); dev = (RSS0 - RSS1)/(az + abs(RSS0));

if(dev<=tol)
    break;
end
sprintf('iter = %u RSS = %0.5f and dev = %0.5f',uint64(cnt),double(RSS1),double(dev))
RSS0=RSS1; %update RSS
end % end while loop

klus = clus(1,((nC+1):p)); % clusters


Xk = ones(n,(k+nC)); Xk(:,(1:nC)) = X(:,(1:nC));
for j = 1:k
    Xk(:,(nC+j)) = sum(X(:,clus==j),2); %sum rows of columns in same cluster
end
deltas = Xk\Y;

