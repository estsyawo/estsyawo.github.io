#===============================================================================
# Author: Feiyu Jiang & Emmanuel Selorm Tsyawo
# Project: A Consistent ICM-based X2 Specification Test
# Date began:   Feb 03, 2022
# Last Update:  Nov 12, 2025
# Place:        Shanghai & Tuscaloosa  
#===============================================================================
# Load packages, clear memory,
rm(list=ls())
library(MASS)
library(parallel)
library(pbapply)
library(estrpac) #install from github using devtools::install_github("estsyawo/estrpac")
library(ivreg)
library(latex2exp)
library(ggplot2)
library(pstest)
#set working directory path to source file
#setwd(dirname(rstudioapi::getActiveDocumentContext()$path))
project_dir <- normalizePath(getwd())
output_dir <- file.path(project_dir, "output")
if (!dir.exists(output_dir)) dir.create(output_dir, recursive = TRUE)
#===============================================================================
#Notes: 
# 1. Running time: 
# 2. Peak RAM usage: 
#===============================================================================

#===============================================================================
# Comments: 
# Computes the size and power of the pivotal chi-squared specification test
# compared to the multiplier test and the specification test of propensity scores of
# Sant'Anna & Song (2019) using the Gaussian Kernel
#===============================================================================
# Set Parameters
R = 1000 # set number of simulations
B=999 # number of wild bootstrap samples
levls = c(0.10,0.05,0.01) #nominal levels of the test
nvec=c(200,400,600,800) #sample sizes
gamvec=seq(0,1,by=0.2) #tuning the deviation away from the null
Sig.X = 0.25^as.matrix(dist(1:5)) #covariance matrix for generating instruments
Sig.U = 0.25^as.matrix(dist(1:2)) #covariance matrix for 1st & 2nd stage 
bet = eta = rep(1,ncol(Sig.X)) #vector of coefficients on X and transforms of Z
#generate auxiliary variables for the bootstrap; n=400 fixed
wmat400=wmat.mammen(n=nvec[2],B=B,seed = 2)
cl = floor(2*detectCores()/3) #number of cores to use in parallel computation
#===============================================================================
source("JT05_Fonctions.R")
source("JT06_Fonctions_Sim.R")
list.files()
#===============================================================================
start.time<- Sys.time()
#===============================================================================


#===============================================================================
# *** Compute Power Curve with alternatives in mind for the chi-squared test *** 

MCOBJ.Gauss_5p=list()

# ------------------------- Compute Power

cat("Compute Power Curve - DGP GLM - targeting alternatives \n ")

for (l in 1:length(gamvec)) {
  #generate data
  datl_5p =gdatGLM(n=nvec[2],gam = gamvec[l])
  
  #--------------------------------------
  #results for the Gaussian kernel
  MCOBJ.Gauss_5p[[l]]=pbsapply(1:R,MC_glm.type,datl=datl_5p,cl=cl,wmat=wmat400,
                               Kern = "Gauss")
  cat("Kern=Gauss, gamma = ",gamvec[l],"\n")
  print(apply(MCOBJ.Gauss_5p[[l]],1,mean)); cat("\n")
  #--------------------------------------
}
#===============================================================================


#===============================================================================
# Write out results for Tex tables
n.test<- 3 #number of tests being compared
n.levels<- length(levls)#number of significance levels being considered

#column ids for empirical size at significance levels 0.1,0.05, and 0.01
id.10 = 1+(0:(n.test-1))*n.levels
id.05 = 2+(0:(n.test-1))*n.levels
id.01 = 3+(0:(n.test-1))*n.levels

#column ids for computational times in seconds
Ts<- c(n.test*n.levels+1, n.test*n.levels + 2 + (0:(n.test-2))*2)
#column ids for computational times relative to the t-test
Trel<- n.test*n.levels+1 + (1:(n.test-1))*2
#--------------------------------------------

# plot power curve, DGP LS5
plot.pow.NLM(MCOBJ=MCOBJ.Gauss_5p,id=c(id.10,id.05,id.01),
             filename=file.path(output_dir, "PCNLM_Gauss_1"))
#===============================================================================

cat("See the output folder for output tables and plots \n ")

#===============================================================================
end.time<- Sys.time()
print(end.time-start.time)
#===============================================================================
