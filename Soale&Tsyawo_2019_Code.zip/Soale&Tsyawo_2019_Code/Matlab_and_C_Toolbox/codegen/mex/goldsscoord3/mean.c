/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * mean.c
 *
 * Code generation for function 'mean'
 *
 */

/* Include files */
#include "rt_nonfinite.h"
#include "goldsscoord3.h"
#include "mean.h"
#include "eml_int_forloop_overflow_check.h"
#include "goldsscoord3_data.h"

/* Variable Definitions */
static emlrtRSInfo pf_emlrtRSI = { 38, /* lineNo */
  "mean",                              /* fcnName */
  "/usr/local/MATLAB/R2018b/toolbox/eml/lib/matlab/datafun/mean.m"/* pathName */
};

/* Function Definitions */
real_T mean(const emlrtStack *sp, const emxArray_real_T *x)
{
  real_T y;
  int32_T vlen;
  boolean_T overflow;
  int32_T k;
  emlrtStack st;
  emlrtStack b_st;
  emlrtStack c_st;
  emlrtStack d_st;
  st.prev = sp;
  st.tls = sp->tls;
  b_st.prev = &st;
  b_st.tls = st.tls;
  c_st.prev = &b_st;
  c_st.tls = b_st.tls;
  d_st.prev = &c_st;
  d_st.tls = c_st.tls;
  st.site = &pf_emlrtRSI;
  vlen = x->size[1];
  b_st.site = &uc_emlrtRSI;
  y = x->data[0];
  c_st.site = &vc_emlrtRSI;
  overflow = ((2 <= x->size[1]) && (x->size[1] > 2147483646));
  if (overflow) {
    d_st.site = &fb_emlrtRSI;
    check_forloop_overflow_error(&d_st);
  }

  for (k = 2; k <= vlen; k++) {
    y += x->data[k - 1];
  }

  y /= (real_T)x->size[1];
  return y;
}

/* End of code generation (mean.c) */
