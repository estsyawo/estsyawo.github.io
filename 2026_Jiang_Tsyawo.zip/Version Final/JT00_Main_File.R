#===============================================================================
# Author: Feiyu Jiang & Emmanuel Selorm Tsyawo
# Project: A Consistent ICM-based X2 Specification Test
# Date began:   Feb 03, 2022
# Last Update:  April 14, 2026
# Place:        Shanghai & Tuscaloosa  
#===============================================================================
# Load packages, clear memory,
rm(list=ls())
#set working directory path to source file
setwd(dirname(rstudioapi::getActiveDocumentContext()$path)) 
output_dir <- file.path(getwd(), "output")
if (!dir.exists(output_dir)) dir.create(output_dir, recursive = TRUE)
list.files()
#===============================================================================
#6.69 GB

#===============================================================================
#Simulations: Specification test

cat("Simulation - Specification Testing - Linear Models \n ")

source("JT01_MCSim_LM.R") #Time difference of 9.591203 hours

#-------------------------------------------------------------------------------

cat("Simulation - Specification Testing - Non-Linear Models \n ")

source("JT01_MCSim_NLM.R") #Time difference of 56.38981 mins
#===============================================================================
#Simulations: Test of Mean Independence

cat("Simulation - Test of Mean Independence \n ")

source("JT02_MCSim_MI.R") #Time difference of 4.63872 hours
#===============================================================================
#Simulations: Test of Mean Independence

cat("Simulation - Test of Mean Independence - Extensions \n ")

source("JT03_MCSim_MI_ext.R") #Time difference of 55.33367 mins
#===============================================================================
#Numerical Integration: Bahadur Slopes

cat("Computing Bahadur Slopes \n ")

source("JT04_Power_Comparison.R") #Time difference of 1.005089 hours
#===============================================================================
