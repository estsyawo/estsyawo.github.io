/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * CCRl_clus_data.h
 *
 * Code generation for function 'CCRl_clus_data'
 *
 */

#ifndef CCRL_CLUS_DATA_H
#define CCRL_CLUS_DATA_H

/* Include files */
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "tmwtypes.h"
#include "mex.h"
#include "emlrt.h"
#include "rtwtypes.h"
#include "CCRl_clus_types.h"

/* Variable Declarations */
extern emlrtCTX emlrtRootTLSGlobal;
extern uint32_T state[625];
extern emlrtContext emlrtContextGlobal;

#endif

/* End of code generation (CCRl_clus_data.h) */
