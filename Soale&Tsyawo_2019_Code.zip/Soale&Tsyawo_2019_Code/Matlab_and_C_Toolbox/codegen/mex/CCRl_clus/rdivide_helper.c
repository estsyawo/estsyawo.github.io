/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * rdivide_helper.c
 *
 * Code generation for function 'rdivide_helper'
 *
 */

/* Include files */
#include <math.h>
#include <string.h>
#include "mwmathutil.h"
#include "rt_nonfinite.h"
#include "CCRl_clus.h"
#include "rdivide_helper.h"

/* Type Definitions */
#include <stddef.h>

/* Function Definitions */
uint64_T b_rdivide_helper(uint64_T x, real_T y)
{
  uint64_T z;
  real_T b_x;
  int32_T shiftAmount;
  uint32_T ux[2];
  uint64_T xint;
  int32_T xexp;
  uint64_T n;
  uint64_T b_xint;
  int32_T exitg1;
  int32_T i6;
  uint64_T t;
  uint64_T c_xint;
  if (y == 0.0) {
    if (x != 0UL) {
      memcpy((void *)&ux[0], (void *)&y, (uint32_T)((size_t)2 * sizeof(uint32_T)));
      if ((ux[0] != 0U) || (ux[1] != 0U)) {
        z = 0UL;
      } else {
        z = MAX_uint64_T;
      }
    } else {
      z = 0UL;
    }
  } else if ((x == 0UL) || (y < 0.0) || (muDoubleScalarIsInf(y) ||
              muDoubleScalarIsNaN(y))) {
    z = 0UL;
  } else {
    b_x = frexp(y, &shiftAmount);
    xint = (uint64_T)muDoubleScalarRound(b_x * 9.007199254740992E+15);
    xexp = shiftAmount - 53;
    if (shiftAmount - 53 > 12) {
      z = 0UL;
    } else if (shiftAmount - 53 < -116) {
      z = MAX_uint64_T;
    } else {
      if (xint == 0UL) {
        z = MAX_uint64_T;
      } else {
        z = x / xint;
      }

      if (shiftAmount - 53 > 0) {
        z = (z >> (shiftAmount - 53)) + (z >> (shiftAmount - 54) & 1UL);
      } else {
        if (xint == 0UL) {
          n = x;
        } else {
          if (xint == 0UL) {
            b_xint = MAX_uint64_T;
          } else {
            b_xint = x / xint;
          }

          n = x - b_xint * xint;
        }

        do {
          exitg1 = 0;
          if (xexp < 0) {
            i6 = -xexp;
            shiftAmount = muIntScalarMin_sint32(i6, 11);
            if ((z >> (64 - shiftAmount)) > 0UL) {
              z = MAX_uint64_T;
              exitg1 = 1;
            } else {
              z <<= shiftAmount;
              n <<= shiftAmount;
              xexp += shiftAmount;
              if (xint == 0UL) {
                t = MAX_uint64_T;
              } else {
                t = n / xint;
              }

              if (MAX_uint64_T - t <= z) {
                z = MAX_uint64_T;
                exitg1 = 1;
              } else {
                z += t;
                if (xint != 0UL) {
                  if (xint == 0UL) {
                    c_xint = MAX_uint64_T;
                  } else {
                    c_xint = n / xint;
                  }

                  n -= c_xint * xint;
                }
              }
            }
          } else {
            if ((n << 1) >= xint) {
              z++;
            }

            exitg1 = 1;
          }
        } while (exitg1 == 0);
      }
    }
  }

  return z;
}

uint64_T rdivide_helper(uint64_T x)
{
  uint64_T z;
  int32_T xexp;
  uint64_T n;
  int32_T exitg1;
  int32_T i3;
  int32_T shiftAmount;
  uint64_T t;
  if (x == 0UL) {
    z = 0UL;
  } else {
    frexp(1.6180339887498949, &xexp);
    xexp = -52;
    z = x / 7286977268806824UL;
    n = x - x / 7286977268806824UL * 7286977268806824UL;
    do {
      exitg1 = 0;
      if (xexp < 0) {
        i3 = -xexp;
        shiftAmount = muIntScalarMin_sint32(i3, 11);
        if ((z >> (64 - shiftAmount)) > 0UL) {
          z = MAX_uint64_T;
          exitg1 = 1;
        } else {
          z <<= shiftAmount;
          n <<= shiftAmount;
          xexp += shiftAmount;
          t = n / 7286977268806824UL;
          if (MAX_uint64_T - t <= z) {
            z = MAX_uint64_T;
            exitg1 = 1;
          } else {
            z += t;
            n -= n / 7286977268806824UL * 7286977268806824UL;
          }
        }
      } else {
        if ((n << 1) >= 7286977268806824UL) {
          z++;
        }

        exitg1 = 1;
      }
    } while (exitg1 == 0);
  }

  return z;
}

/* End of code generation (rdivide_helper.c) */
