/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * qrsolve.c
 *
 * Code generation for function 'qrsolve'
 *
 */

/* Include files */
#include "mwmathutil.h"
#include "rt_nonfinite.h"
#include "goldsscoord3.h"
#include "qrsolve.h"
#include "goldsscoord3_emxutil.h"
#include "error.h"
#include "warning.h"
#include "xgeqp3.h"
#include "goldsscoord3_mexutil.h"
#include "goldsscoord3_data.h"
#include "lapacke.h"

/* Variable Definitions */
static emlrtRSInfo p_emlrtRSI = { 29,  /* lineNo */
  "qrsolve",                           /* fcnName */
  "/usr/local/MATLAB/R2018b/toolbox/eml/eml/+coder/+internal/qrsolve.m"/* pathName */
};

static emlrtRSInfo q_emlrtRSI = { 33,  /* lineNo */
  "qrsolve",                           /* fcnName */
  "/usr/local/MATLAB/R2018b/toolbox/eml/eml/+coder/+internal/qrsolve.m"/* pathName */
};

static emlrtRSInfo r_emlrtRSI = { 40,  /* lineNo */
  "qrsolve",                           /* fcnName */
  "/usr/local/MATLAB/R2018b/toolbox/eml/eml/+coder/+internal/qrsolve.m"/* pathName */
};

static emlrtRSInfo gb_emlrtRSI = { 124,/* lineNo */
  "qrsolve",                           /* fcnName */
  "/usr/local/MATLAB/R2018b/toolbox/eml/eml/+coder/+internal/qrsolve.m"/* pathName */
};

static emlrtRSInfo hb_emlrtRSI = { 123,/* lineNo */
  "qrsolve",                           /* fcnName */
  "/usr/local/MATLAB/R2018b/toolbox/eml/eml/+coder/+internal/qrsolve.m"/* pathName */
};

static emlrtRSInfo ib_emlrtRSI = { 73, /* lineNo */
  "qrsolve",                           /* fcnName */
  "/usr/local/MATLAB/R2018b/toolbox/eml/eml/+coder/+internal/qrsolve.m"/* pathName */
};

static emlrtRSInfo jb_emlrtRSI = { 80, /* lineNo */
  "qrsolve",                           /* fcnName */
  "/usr/local/MATLAB/R2018b/toolbox/eml/eml/+coder/+internal/qrsolve.m"/* pathName */
};

static emlrtRSInfo kb_emlrtRSI = { 90, /* lineNo */
  "qrsolve",                           /* fcnName */
  "/usr/local/MATLAB/R2018b/toolbox/eml/eml/+coder/+internal/qrsolve.m"/* pathName */
};

static emlrtRSInfo lb_emlrtRSI = { 31, /* lineNo */
  "xunormqr",                          /* fcnName */
  "/usr/local/MATLAB/R2018b/toolbox/eml/eml/+coder/+internal/+lapack/xunormqr.m"/* pathName */
};

static emlrtRSInfo mb_emlrtRSI = { 102,/* lineNo */
  "xunormqr",                          /* fcnName */
  "/usr/local/MATLAB/R2018b/toolbox/eml/eml/+coder/+internal/+lapack/xunormqr.m"/* pathName */
};

static emlrtRSInfo nb_emlrtRSI = { 93, /* lineNo */
  "xunormqr",                          /* fcnName */
  "/usr/local/MATLAB/R2018b/toolbox/eml/eml/+coder/+internal/+lapack/xunormqr.m"/* pathName */
};

static emlrtRSInfo ob_emlrtRSI = { 80, /* lineNo */
  "xunormqr",                          /* fcnName */
  "/usr/local/MATLAB/R2018b/toolbox/eml/eml/+coder/+internal/+lapack/xunormqr.m"/* pathName */
};

static emlrtRSInfo pb_emlrtRSI = { 79, /* lineNo */
  "xunormqr",                          /* fcnName */
  "/usr/local/MATLAB/R2018b/toolbox/eml/eml/+coder/+internal/+lapack/xunormqr.m"/* pathName */
};

static emlrtRSInfo qb_emlrtRSI = { 59, /* lineNo */
  "xunormqr",                          /* fcnName */
  "/usr/local/MATLAB/R2018b/toolbox/eml/eml/+coder/+internal/+lapack/xunormqr.m"/* pathName */
};

static emlrtMCInfo c_emlrtMCI = { 53,  /* lineNo */
  19,                                  /* colNo */
  "flt2str",                           /* fName */
  "/usr/local/MATLAB/R2018b/toolbox/eml/eml/+coder/+internal/flt2str.m"/* pName */
};

static emlrtRTEInfo w_emlrtRTEI = { 29,/* lineNo */
  2,                                   /* colNo */
  "qrsolve",                           /* fName */
  "/usr/local/MATLAB/R2018b/toolbox/eml/eml/+coder/+internal/qrsolve.m"/* pName */
};

static emlrtRTEInfo x_emlrtRTEI = { 40,/* lineNo */
  26,                                  /* colNo */
  "qrsolve",                           /* fName */
  "/usr/local/MATLAB/R2018b/toolbox/eml/eml/+coder/+internal/qrsolve.m"/* pName */
};

static emlrtRTEInfo y_emlrtRTEI = { 73,/* lineNo */
  5,                                   /* colNo */
  "qrsolve",                           /* fName */
  "/usr/local/MATLAB/R2018b/toolbox/eml/eml/+coder/+internal/qrsolve.m"/* pName */
};

static emlrtRSInfo tf_emlrtRSI = { 53, /* lineNo */
  "flt2str",                           /* fcnName */
  "/usr/local/MATLAB/R2018b/toolbox/eml/eml/+coder/+internal/flt2str.m"/* pathName */
};

/* Function Declarations */
static void b_emlrt_marshallIn(const emlrtStack *sp, const mxArray *u, const
  emlrtMsgIdentifier *parentId, char_T y[14]);
static const mxArray *b_sprintf(const emlrtStack *sp, const mxArray *b, const
  mxArray *c, emlrtMCInfo *location);
static void emlrt_marshallIn(const emlrtStack *sp, const mxArray *c_sprintf,
  const char_T *identifier, char_T y[14]);
static void i_emlrt_marshallIn(const emlrtStack *sp, const mxArray *src, const
  emlrtMsgIdentifier *msgId, char_T ret[14]);

/* Function Definitions */
static void b_emlrt_marshallIn(const emlrtStack *sp, const mxArray *u, const
  emlrtMsgIdentifier *parentId, char_T y[14])
{
  i_emlrt_marshallIn(sp, emlrtAlias(u), parentId, y);
  emlrtDestroyArray(&u);
}

static const mxArray *b_sprintf(const emlrtStack *sp, const mxArray *b, const
  mxArray *c, emlrtMCInfo *location)
{
  const mxArray *pArrays[2];
  const mxArray *m37;
  pArrays[0] = b;
  pArrays[1] = c;
  return emlrtCallMATLABR2012b(sp, 1, &m37, 2, pArrays, "sprintf", true,
    location);
}

static void emlrt_marshallIn(const emlrtStack *sp, const mxArray *c_sprintf,
  const char_T *identifier, char_T y[14])
{
  emlrtMsgIdentifier thisId;
  thisId.fIdentifier = (const char *)identifier;
  thisId.fParent = NULL;
  thisId.bParentIsCell = false;
  b_emlrt_marshallIn(sp, emlrtAlias(c_sprintf), &thisId, y);
  emlrtDestroyArray(&c_sprintf);
}

static void i_emlrt_marshallIn(const emlrtStack *sp, const mxArray *src, const
  emlrtMsgIdentifier *msgId, char_T ret[14])
{
  static const int32_T dims[2] = { 1, 14 };

  emlrtCheckBuiltInR2012b(sp, msgId, src, "char", false, 2U, dims);
  emlrtImportCharArrayR2015b(sp, src, &ret[0], 14);
  emlrtDestroyArray(&src);
}

void qrsolve(const emlrtStack *sp, const emxArray_real_T *A, const
             emxArray_real_T *B, real_T Y[2])
{
  emxArray_real_T *b_A;
  int32_T minmn;
  int32_T maxmn;
  real_T tau_data[2];
  int32_T tau_size[1];
  int32_T jpvt[2];
  int32_T rankR;
  real_T tol;
  emxArray_real_T *b_B;
  const mxArray *y;
  const mxArray *m19;
  static const int32_T iv12[2] = { 1, 6 };

  static const char_T rfmt[6] = { '%', '1', '4', '.', '6', 'e' };

  char_T cv0[14];
  int32_T Y_tmp;
  ptrdiff_t nrc_t;
  ptrdiff_t info_t;
  boolean_T p;
  boolean_T b_p;
  emlrtStack st;
  emlrtStack b_st;
  emlrtStack c_st;
  emlrtStack d_st;
  emlrtStack e_st;
  st.prev = sp;
  st.tls = sp->tls;
  b_st.prev = &st;
  b_st.tls = st.tls;
  c_st.prev = &b_st;
  c_st.tls = b_st.tls;
  d_st.prev = &c_st;
  d_st.tls = c_st.tls;
  e_st.prev = &d_st;
  e_st.tls = d_st.tls;
  emlrtHeapReferenceStackEnterFcnR2012b(sp);
  emxInit_real_T(sp, &b_A, 2, &w_emlrtRTEI, true);
  minmn = b_A->size[0] * b_A->size[1];
  b_A->size[0] = A->size[0];
  b_A->size[1] = 2;
  emxEnsureCapacity_real_T(sp, b_A, minmn, &w_emlrtRTEI);
  maxmn = A->size[0] * A->size[1];
  for (minmn = 0; minmn < maxmn; minmn++) {
    b_A->data[minmn] = A->data[minmn];
  }

  st.site = &p_emlrtRSI;
  xgeqp3(&st, b_A, tau_data, tau_size, jpvt);
  st.site = &q_emlrtRSI;
  rankR = 0;
  tol = 0.0;
  if (b_A->size[0] < 2) {
    minmn = b_A->size[0];
    maxmn = 2;
  } else {
    minmn = 2;
    maxmn = b_A->size[0];
  }

  if (minmn > 0) {
    tol = muDoubleScalarMin(1.4901161193847656E-8, 2.2204460492503131E-15 *
      (real_T)maxmn) * muDoubleScalarAbs(b_A->data[0]);
    while ((rankR < minmn) && (!(muDoubleScalarAbs(b_A->data[rankR + b_A->size[0]
              * rankR]) <= tol))) {
      rankR++;
    }
  }

  if (rankR < minmn) {
    b_st.site = &gb_emlrtRSI;
    y = NULL;
    m19 = emlrtCreateCharArray(2, iv12);
    emlrtInitCharArrayR2013a(&b_st, 6, m19, &rfmt[0]);
    emlrtAssign(&y, m19);
    c_st.site = &tf_emlrtRSI;
    emlrt_marshallIn(&c_st, b_sprintf(&c_st, y, emlrt_marshallOut(tol),
      &c_emlrtMCI), "sprintf", cv0);
    b_st.site = &hb_emlrtRSI;
    b_warning(&b_st, rankR, cv0);
  }

  emxInit_real_T(&st, &b_B, 1, &x_emlrtRTEI, true);
  st.site = &r_emlrtRSI;
  minmn = b_B->size[0];
  b_B->size[0] = B->size[0];
  emxEnsureCapacity_real_T(&st, b_B, minmn, &x_emlrtRTEI);
  maxmn = B->size[0];
  for (minmn = 0; minmn < maxmn; minmn++) {
    b_B->data[minmn] = B->data[minmn];
  }

  Y[0] = 0.0;
  Y[1] = 0.0;
  b_st.site = &ib_emlrtRSI;
  c_st.site = &lb_emlrtRSI;
  minmn = muIntScalarMin_sint32(b_A->size[0], 2);
  d_st.site = &qb_emlrtRSI;
  if (b_A->size[0] != 0) {
    d_st.site = &pb_emlrtRSI;
    d_st.site = &ob_emlrtRSI;
    nrc_t = (ptrdiff_t)b_B->size[0];
    d_st.site = &nb_emlrtRSI;
    info_t = LAPACKE_dormqr(102, 'L', 'T', nrc_t, (ptrdiff_t)1, (ptrdiff_t)minmn,
      &b_A->data[0], (ptrdiff_t)b_A->size[0], &tau_data[0], &b_B->data[0], nrc_t);
    minmn = (int32_T)info_t;
    d_st.site = &mb_emlrtRSI;
    if (minmn != 0) {
      p = true;
      b_p = false;
      if (minmn == -7) {
        b_p = true;
      } else if (minmn == -9) {
        b_p = true;
      } else {
        if (minmn == -10) {
          b_p = true;
        }
      }

      if (!b_p) {
        if (minmn == -1010) {
          e_st.site = &db_emlrtRSI;
          error(&e_st);
        } else {
          e_st.site = &eb_emlrtRSI;
          c_error(&e_st, minmn);
        }
      }
    } else {
      p = false;
    }

    if (p) {
      maxmn = b_B->size[0];
      minmn = b_B->size[0];
      b_B->size[0] = maxmn;
      emxEnsureCapacity_real_T(&c_st, b_B, minmn, &y_emlrtRTEI);
      for (minmn = 0; minmn < maxmn; minmn++) {
        b_B->data[minmn] = rtNaN;
      }
    }
  }

  b_st.site = &jb_emlrtRSI;
  for (minmn = 0; minmn < rankR; minmn++) {
    Y[jpvt[minmn] - 1] = b_B->data[minmn];
  }

  emxFree_real_T(&b_B);
  for (maxmn = rankR; maxmn >= 1; maxmn--) {
    Y_tmp = jpvt[maxmn - 1] - 1;
    Y[Y_tmp] /= b_A->data[(maxmn + b_A->size[0] * (maxmn - 1)) - 1];
    b_st.site = &kb_emlrtRSI;
    for (minmn = 0; minmn <= maxmn - 2; minmn++) {
      Y[jpvt[0] - 1] -= Y[Y_tmp] * b_A->data[b_A->size[0] * (maxmn - 1)];
    }
  }

  emxFree_real_T(&b_A);
  emlrtHeapReferenceStackLeaveFcnR2012b(sp);
}

/* End of code generation (qrsolve.c) */
