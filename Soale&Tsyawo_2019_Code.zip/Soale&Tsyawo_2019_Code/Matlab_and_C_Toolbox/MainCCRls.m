%% MainCCRls

n=1000; p = 20000;
X = ones(n,p); XX = ones(n,(p+1));
s = RandStream('mlfg6331_64'); 
X(:,(1:p)) = rand(s,n,p); XX(:,(2:(p+1))) = X;
B = randsample(s,5,(p+1),true);
Y = XX*B + rand(s,[n,1]);
%bhat=(XX\Y)';
%errs = abs(bhat-B'); % looks good

%% Compare two renditions of the function
ant=CCRls(Y,X);
ant2=CCRls2(Y,X(:),n,p);
isequal(ant,ant2);% excellent. Give exact results!

%% Compare matlab and mex file
tic
CCRls(Y,X); 
toc
% Elapsed time is 21.148797 seconds.

tic
CCRls2(Y,X(:),n,p); 
toc
% Elapsed time is 21.807316 seconds.

tic
CCRls_mex(Y,X);
toc
% Elapsed time is 8.460566 seconds.

%% Assign vector of parameters to 10 clusters
rng(1); % For reproducibility
[idx,C] = kmeans(ant',7);
tabulate(idx) % a tabulation of cluster assignments










%% Some testing with vectorising and reconstructing matrices
% this piece of code is used in CRRls2.m
[n, p] = size(XX) ;
Xv = XX(:);
Z = zeros(n,p); %convert design vector into design matrix
for i=1:n
   for j=1:p
      Z(i,j) = Xv((j-1)*n +i);
   end
end
isequal(Z,XX) %correct!

