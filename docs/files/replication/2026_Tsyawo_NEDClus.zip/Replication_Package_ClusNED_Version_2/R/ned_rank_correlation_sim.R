#=====================================================
# Weak-dependence Monte Carlo library
# Purpose:
#   Provide the NED / weak-dependence simulation arm used in
#   CLT_U_Stats.tex, Section Sect:Simulations. The design is calibrated to the
#   Tong-Hansen application and studies Kendall's tau and Spearman's rho with
#   HAC inference.
# Inputs:
#   None when sourced.
# Outputs:
#   Reusable simulation, summary, calibration, and table-writing functions.
# Side effects:
#   None when sourced; functions may write files and print progress when called.
#=====================================================

# Manuscript-facing note:
#   The public grid runner in this file feeds the weak-dependence Monte Carlo
#   table reported in `Sect:Sim_NED`.

#=====================================================
# Data-generation layer
#=====================================================

simulate_bivar_ar1 <- function(n, rho = 0.0, alpha = 0.5) {
  if (abs(rho) >= 1) stop("rho must be strictly inside (-1, 1).")
  if (abs(alpha) > 1) stop("alpha must be in [-1, 1].")

  x <- numeric(n)
  y <- numeric(n)
  x[1] <- rnorm(1)
  y[1] <- alpha * x[1] + sqrt(max(0, 1 - alpha^2)) * rnorm(1)

  innov_sd <- sqrt(max(1e-12, 1 - rho^2))
  for (t in 2:n) {
    ux <- rnorm(1)
    uy <- alpha * ux + sqrt(max(0, 1 - alpha^2)) * rnorm(1)
    x[t] <- rho * x[t - 1] + innov_sd * ux
    y[t] <- rho * y[t - 1] + innov_sd * uy
  }
  list(x = x, y = y)
}

generate_ned_rank_replicates <- function(n, n_reps, rho = 0.0, alpha = 0.5, seed = 1) {
  set.seed(seed)
  replicate(n_reps, simulate_bivar_ar1(n, rho, alpha), simplify = FALSE)
}

#=====================================================
# Population targets and HAC helpers
#=====================================================

gaussian_kendall_target <- function(rho) {
  (2 / pi) * asin(rho)
}

gaussian_spearman_target <- function(rho) {
  (6 / pi) * asin(rho / 2)
}

default_rank_hac_bandwidth <- function(n) {
  max(1L, floor(n^(1 / 4)))
}

rank_hac_lrv <- function(hat_phi1, bandwidth = NULL) {
  n <- length(hat_phi1)
  fit <- lm(hat_phi1 ~ 1)
  as.numeric(n * sandwich::NeweyWest(
    fit,
    lag = bandwidth,
    prewhite = FALSE,
    adjust = FALSE
  )[1, 1])
}

#=====================================================
# One-replication evaluator
#=====================================================

ned_rank_one_replication <- function(rep_data, alpha, bandwidth) {
  n <- length(rep_data$x)

  kendall <- kendall_u2_projection_cpp(rep_data$x, rep_data$y)
  spearman <- spearman_u3_projection_cpp(rep_data$x, rep_data$y)

  kendall_target <- gaussian_kendall_target(alpha)
  spearman_target <- gaussian_spearman_target(alpha)

  k_kendall <- 2
  k_spearman <- 3
  kendall_sigma2_rob <- k_kendall^2 * rank_hac_lrv(kendall$projection, bandwidth)
  spearman_sigma2_rob <- k_spearman^2 * rank_hac_lrv(spearman$projection, bandwidth)
  kendall_sigma2_iid <- k_kendall^2 * mean(kendall$projection^2)
  spearman_sigma2_iid <- k_spearman^2 * mean(spearman$projection^2)
  kendall_se_rob <- sqrt(kendall_sigma2_rob / n)
  kendall_se_iid <- sqrt(kendall_sigma2_iid / n)
  spearman_se_rob <- sqrt(spearman_sigma2_rob / n)
  spearman_se_iid <- sqrt(spearman_sigma2_iid / n)

  c(
    kendall = kendall$estimate,
    kendall_target = kendall_target,
    kendall_se_rob = kendall_se_rob,
    kendall_se_iid = kendall_se_iid,
    kendall_t_rob = if (kendall_se_rob > 0) (kendall$estimate - kendall_target) / kendall_se_rob else NA_real_,
    kendall_t_iid = if (kendall_se_iid > 0) (kendall$estimate - kendall_target) / kendall_se_iid else NA_real_,
    spearman = spearman$estimate,
    spearman_target = spearman_target,
    spearman_se_rob = spearman_se_rob,
    spearman_se_iid = spearman_se_iid,
    spearman_t_rob = if (spearman_se_rob > 0) (spearman$estimate - spearman_target) / spearman_se_rob else NA_real_,
    spearman_t_iid = if (spearman_se_iid > 0) (spearman$estimate - spearman_target) / spearman_se_iid else NA_real_,
    n = n
  )
}

#=====================================================
# Monte Carlo summaries
#=====================================================

summarise_rank_results <- function(out) {
  kendall_rejections_rob <- summarise_t_rejections(out$kendall_t_rob)
  names(kendall_rejections_rob) <- paste0("kendall_rob_", names(kendall_rejections_rob))
  kendall_rejections_iid <- summarise_t_rejections(out$kendall_t_iid)
  names(kendall_rejections_iid) <- paste0("kendall_iid_", names(kendall_rejections_iid))
  spearman_rejections_rob <- summarise_t_rejections(out$spearman_t_rob)
  names(spearman_rejections_rob) <- paste0("spearman_rob_", names(spearman_rejections_rob))
  spearman_rejections_iid <- summarise_t_rejections(out$spearman_t_iid)
  names(spearman_rejections_iid) <- paste0("spearman_iid_", names(spearman_rejections_iid))

  c(
    mean_kendall = mean(out$kendall),
    target_kendall = mean(out$kendall_target),
    mc_sd_kendall = sd(out$kendall),
    mc_mad_kendall = monte_carlo_mad(out$kendall),
    mean_se_kendall_rob = mean(out$kendall_se_rob),
    se_sd_ratio_kendall_rob = mean(out$kendall_se_rob) / sd(out$kendall),
    mean_kendall_t_rob = mean(out$kendall_t_rob),
    sd_kendall_t_rob = sd(out$kendall_t_rob),
    kendall_rejections_rob,
    mean_se_kendall_iid = mean(out$kendall_se_iid),
    se_sd_ratio_kendall_iid = mean(out$kendall_se_iid) / sd(out$kendall),
    mean_kendall_t_iid = mean(out$kendall_t_iid),
    sd_kendall_t_iid = sd(out$kendall_t_iid),
    kendall_rejections_iid,
    mean_spearman = mean(out$spearman),
    target_spearman = mean(out$spearman_target),
    mc_sd_spearman = sd(out$spearman),
    mc_mad_spearman = monte_carlo_mad(out$spearman),
    mean_se_spearman_rob = mean(out$spearman_se_rob),
    se_sd_ratio_spearman_rob = mean(out$spearman_se_rob) / sd(out$spearman),
    mean_spearman_t_rob = mean(out$spearman_t_rob),
    sd_spearman_t_rob = sd(out$spearman_t_rob),
    spearman_rejections_rob,
    mean_se_spearman_iid = mean(out$spearman_se_iid),
    se_sd_ratio_spearman_iid = mean(out$spearman_se_iid) / sd(out$spearman),
    mean_spearman_t_iid = mean(out$spearman_t_iid),
    sd_spearman_t_iid = sd(out$spearman_t_iid),
    spearman_rejections_iid
  )
}

#=====================================================
# Manuscript-facing scenario runner
#=====================================================

# Workflow note:
#   `run_ned_rank_scenario()` evaluates one calibrated design point. The
#   manuscript-facing grid is assembled downstream by
#   `run_ned_rank_calibrated_grid()`.

run_ned_rank_scenario <- function(n = 400, rho = 0.0, alpha = 0.5, label = "scenario", bandwidth = NULL, n_reps = 100, seed = 1, cl = default_sim_cl(), replicates = NULL, output_prefix = NULL) {
  n <- force(n)
  rho <- force(rho)
  alpha <- force(alpha)
  label <- force(label)
  n_reps <- force(n_reps)
  seed <- force(seed)
  output_prefix <- force(output_prefix)
  if (is.null(bandwidth)) bandwidth <- default_rank_hac_bandwidth(n)
  bandwidth <- force(bandwidth)

  if (is.null(replicates)) {
    replicates <- generate_ned_rank_replicates(n, n_reps, rho, alpha, seed)
  } else {
    n_reps <- length(replicates)
  }

  prepare_sim_cluster(
    cl,
    c(
      "simulate_bivar_ar1",
      "generate_ned_rank_replicates",
      "gaussian_kendall_target",
      "gaussian_spearman_target",
      "default_rank_hac_bandwidth",
      "rank_hac_lrv",
      "ned_rank_one_replication",
      "summarise_rank_results",
      "summarise_t_rejections",
      "monte_carlo_mad",
      "write_sim_outputs",
      "sim_output_dir",
      "sim_cl_label",
      "prepare_sim_cluster",
      "kendall_u2_projection_cpp",
      "spearman_u3_projection_cpp"
    )
  )

  out <- t(pbapply::pbsapply(replicates, function(rep_data) {
    ned_rank_one_replication(rep_data, alpha, bandwidth)
  }, cl = cl))
  out <- as.data.frame(out)
  summary <- summarise_rank_results(out)
  summary <- c(
    label = label,
    n = n,
    rho = rho,
    alpha = alpha,
    bandwidth = bandwidth,
    n_reps = n_reps,
    summary
  )

  cat(sprintf("label=%s n=%d rho=%.2f alpha=%.4f bandwidth=%d reps=%d cl=%s\n", label, n, rho, alpha, bandwidth, n_reps, sim_cl_label(cl)))
  cat(sprintf("  Kendall target/mean/MC sd/MC MAD = %.4f / %.4f / %.4f / %.4f\n",
              as.numeric(summary["target_kendall"]), as.numeric(summary["mean_kendall"]),
              as.numeric(summary["mc_sd_kendall"]), as.numeric(summary["mc_mad_kendall"])))
  cat(sprintf("  Kendall mean SE robust / iid     = %.4f / %.4f\n",
              as.numeric(summary["mean_se_kendall_rob"]), as.numeric(summary["mean_se_kendall_iid"])))
  cat(sprintf("  Kendall SE/SD robust / iid       = %.4f / %.4f\n",
              as.numeric(summary["se_sd_ratio_kendall_rob"]), as.numeric(summary["se_sd_ratio_kendall_iid"])))
  cat(sprintf("  Kendall rejection 5%% r/iid       = %.3f / %.3f\n",
              as.numeric(summary["kendall_rob_reject_5pct"]), as.numeric(summary["kendall_iid_reject_5pct"])))
  cat(sprintf("  Spearman target/mean/MC sd/MC MAD = %.4f / %.4f / %.4f / %.4f\n",
              as.numeric(summary["target_spearman"]), as.numeric(summary["mean_spearman"]),
              as.numeric(summary["mc_sd_spearman"]), as.numeric(summary["mc_mad_spearman"])))
  cat(sprintf("  Spearman mean SE robust / iid     = %.4f / %.4f\n",
              as.numeric(summary["mean_se_spearman_rob"]), as.numeric(summary["mean_se_spearman_iid"])))
  cat(sprintf("  Spearman SE/SD robust / iid       = %.4f / %.4f\n",
              as.numeric(summary["se_sd_ratio_spearman_rob"]), as.numeric(summary["se_sd_ratio_spearman_iid"])))
  cat(sprintf("  Spearman rejection 5%% r/iid       = %.3f / %.3f\n\n",
              as.numeric(summary["spearman_rob_reject_5pct"]), as.numeric(summary["spearman_iid_reject_5pct"])))

  output_files <- write_sim_outputs(output_prefix, out, summary)
  invisible(list(results = out, replicates = replicates, summary = summary, output_files = output_files))
}

#=====================================================
# Calibration-driven grid assembly
#=====================================================

# Workflow note:
#   The calibration loader reads the retained Tong-Hansen calibration CSV from
#   data/, and the grid runner expands that calibration across
#   the persistence values used in `Sect:Sim_NED`.

load_tong_hansen_rank_calibration <- function(path = NULL) {
  if (is.null(path)) {
    path <- file.path(sim_root, "data", "tong_hansen_ned_sim_calibration_selected.csv")
  }
  read.csv(path, stringsAsFactors = FALSE)
}

run_ned_rank_calibrated_grid <- function(n = 400, rhos = c(0, 0.25, 0.5), n_reps = 100, seed = 1, bandwidth = NULL, cl = default_sim_cl(), output_prefix = NULL) {
  calibration <- load_tong_hansen_rank_calibration()
  rows <- list()
  idx <- 1L
  for (i in seq_len(nrow(calibration))) {
    for (rho in rhos) {
      label <- paste(calibration$calibration_role[i], calibration$sector[i], sep = "_")
      ans <- run_ned_rank_scenario(
        n = n,
        rho = rho,
        alpha = calibration$pearson[i],
        label = label,
        bandwidth = bandwidth,
        n_reps = n_reps,
        seed = seed + idx - 1L,
        cl = cl,
        output_prefix = NULL
      )
      rows[[idx]] <- as.data.frame(t(ans$summary), check.names = FALSE)
      idx <- idx + 1L
    }
  }
  out <- do.call(rbind, rows)
  row.names(out) <- NULL
  if (!is.null(output_prefix)) write_sim_table(paste0(output_prefix, "_summary_grid"), out)
  out
}

#=====================================================
# Manuscript table writer
#=====================================================

write_ned_rank_latex_table <- function(tab, path) {
  scenario_label <- function(x) {
    x <- sub("_.*$", "", x)
    x <- tools::toTitleCase(x)
    x <- gsub("%", "\\\\%", x, fixed = TRUE)
    x <- gsub("&", "\\\\&", x, fixed = TRUE)
    x
  }
  con <- file(path, open = "wt")
  on.exit(close(con), add = TRUE)
  writeLines(c(
    "\\begin{tabular}{lrrrrrrrrrrrr}",
    "\\toprule",
    " &  &  &  & \\multicolumn{4}{c}{Kendall} & \\multicolumn{4}{c}{Spearman} \\\\",
    "\\cmidrule(lr){5-8}\\cmidrule(lr){9-12}",
    "$n$ & Scenario & $\\rho$ & $\\alpha$ & $\\mathrm{MAD}$ & $\\frac{\\mathrm{SE}}{\\mathrm{SD}}_{\\mathrm{rob}}$ & 5\\%$_{\\mathrm{rob}}$ & 5\\%$_{\\mathrm{iid}}$ & $\\mathrm{MAD}$ & $\\frac{\\mathrm{SE}}{\\mathrm{SD}}_{\\mathrm{rob}}$ & 5\\%$_{\\mathrm{rob}}$ & 5\\%$_{\\mathrm{iid}}$ \\\\",
    "\\midrule"
  ), con)
  previous_n <- NA_integer_
  for (i in seq_len(nrow(tab))) {
    current_n <- as.integer(tab$n[i])
    if (!is.na(previous_n) && current_n != previous_n) writeLines("\\midrule", con)
    writeLines(sprintf(
      "%s & %s & %.3f & %.2f & %.4f & %.4f & %.3f & %.3f & %.4f & %.4f & %.3f & %.3f \\\\",
      if (is.na(previous_n) || current_n != previous_n) as.character(current_n) else "",
      scenario_label(tab$label[i]),
      as.numeric(tab$rho[i]),
      as.numeric(tab$alpha[i]),
      as.numeric(tab$mc_mad_kendall[i]),
      as.numeric(tab$se_sd_ratio_kendall_rob[i]),
      as.numeric(tab$kendall_rob_reject_5pct[i]),
      as.numeric(tab$kendall_iid_reject_5pct[i]),
      as.numeric(tab$mc_mad_spearman[i]),
      as.numeric(tab$se_sd_ratio_spearman_rob[i]),
      as.numeric(tab$spearman_rob_reject_5pct[i]),
      as.numeric(tab$spearman_iid_reject_5pct[i])
    ), con)
    previous_n <- current_n
  }
  writeLines(c("\\bottomrule", "\\end{tabular}"), con)
  invisible(path)
}

#=====================================================
# Direct smoke run
#=====================================================

if (sys.nframe() == 0) {
  source("00_setup.R")
  run_ned_rank_calibrated_grid(
    n = 400,
    rhos = c(0, 0.5),
    n_reps = 100,
    seed = 1,
    cl = 1L,
    output_prefix = paste0("ned_rank_smoke_", format(Sys.time(), "%Y%m%d_%H%M%S"))
  )
}
