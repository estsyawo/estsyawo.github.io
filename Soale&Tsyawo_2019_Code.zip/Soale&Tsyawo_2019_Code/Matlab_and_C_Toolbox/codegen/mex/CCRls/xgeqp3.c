/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * xgeqp3.c
 *
 * Code generation for function 'xgeqp3'
 *
 */

/* Include files */
#include "mwmathutil.h"
#include "rt_nonfinite.h"
#include "CCRls.h"
#include "xgeqp3.h"
#include "CCRls_emxutil.h"
#include "CCRls_data.h"
#include "lapacke.h"

/* Function Definitions */
void b_xgeqp3(emxArray_real_T *A, emxArray_real_T *tau, emxArray_int32_T *jpvt)
{
  int32_T m;
  int32_T n;
  emxArray_ptrdiff_t *jpvt_t;
  int32_T i8;
  int32_T loop_ub;
  ptrdiff_t m_t;
  ptrdiff_t info_t;
  int32_T i9;
  emlrtHeapReferenceStackEnterFcnR2012b(emlrtRootTLSGlobal);
  m = A->size[0];
  n = A->size[1];
  if ((A->size[0] == 0) || (A->size[1] == 0)) {
    tau->size[0] = 0;
    if (A->size[1] < 1) {
      n = 0;
    } else {
      n = A->size[1];
    }

    i8 = jpvt->size[0] * jpvt->size[1];
    jpvt->size[0] = 1;
    jpvt->size[1] = n;
    emxEnsureCapacity_int32_T(jpvt, i8);
    if (n > 0) {
      jpvt->data[0] = 1;
      m = 1;
      for (loop_ub = 2; loop_ub <= n; loop_ub++) {
        m++;
        jpvt->data[loop_ub - 1] = m;
      }
    }
  } else {
    emxInit_ptrdiff_t(&jpvt_t, 1, true);
    i8 = tau->size[0];
    tau->size[0] = muIntScalarMin_sint32(m, n);
    emxEnsureCapacity_real_T(tau, i8);
    i8 = jpvt_t->size[0];
    jpvt_t->size[0] = A->size[1];
    emxEnsureCapacity_ptrdiff_t(jpvt_t, i8);
    m = A->size[1];
    for (i8 = 0; i8 < m; i8++) {
      jpvt_t->data[i8] = (ptrdiff_t)0;
    }

    m_t = (ptrdiff_t)A->size[0];
    info_t = LAPACKE_dgeqp3(102, m_t, (ptrdiff_t)A->size[1], &A->data[0], m_t,
      &jpvt_t->data[0], &tau->data[0]);
    if ((int32_T)info_t != 0) {
      i8 = A->size[0] * A->size[1];
      emxEnsureCapacity_real_T(A, i8);
      m = A->size[1];
      for (i8 = 0; i8 < m; i8++) {
        loop_ub = A->size[0];
        for (i9 = 0; i9 < loop_ub; i9++) {
          A->data[i9 + A->size[0] * i8] = rtNaN;
        }
      }

      m = tau->size[0];
      i8 = tau->size[0];
      tau->size[0] = m;
      emxEnsureCapacity_real_T(tau, i8);
      for (i8 = 0; i8 < m; i8++) {
        tau->data[i8] = rtNaN;
      }

      if (n < 1) {
        n = 0;
      }

      i8 = jpvt->size[0] * jpvt->size[1];
      jpvt->size[0] = 1;
      jpvt->size[1] = n;
      emxEnsureCapacity_int32_T(jpvt, i8);
      if (n > 0) {
        jpvt->data[0] = 1;
        m = 1;
        for (loop_ub = 2; loop_ub <= n; loop_ub++) {
          m++;
          jpvt->data[loop_ub - 1] = m;
        }
      }
    } else {
      i8 = jpvt->size[0] * jpvt->size[1];
      jpvt->size[0] = 1;
      jpvt->size[1] = jpvt_t->size[0];
      emxEnsureCapacity_int32_T(jpvt, i8);
      m = jpvt_t->size[0];
      for (i8 = 0; i8 < m; i8++) {
        jpvt->data[i8] = (int32_T)jpvt_t->data[i8];
      }
    }

    emxFree_ptrdiff_t(&jpvt_t);
  }

  emlrtHeapReferenceStackLeaveFcnR2012b(emlrtRootTLSGlobal);
}

void xgeqp3(emxArray_real_T *A, real_T tau_data[], int32_T tau_size[1], int32_T
            jpvt[2])
{
  int32_T m;
  ptrdiff_t jpvt_t[2];
  ptrdiff_t m_t;
  ptrdiff_t info_t;
  int32_T i4;
  int32_T loop_ub;
  m = A->size[0];
  if (A->size[0] == 0) {
    tau_size[0] = 0;
    jpvt[0] = 1;
    jpvt[1] = 2;
  } else {
    m = muIntScalarMin_sint32(m, 2);
    tau_size[0] = m;
    jpvt_t[0] = (ptrdiff_t)0;
    jpvt_t[1] = (ptrdiff_t)0;
    m_t = (ptrdiff_t)A->size[0];
    info_t = LAPACKE_dgeqp3(102, m_t, (ptrdiff_t)2, &A->data[0], m_t, &jpvt_t[0],
      &tau_data[0]);
    if ((int32_T)info_t != 0) {
      i4 = A->size[0] * A->size[1];
      A->size[1] = 2;
      emxEnsureCapacity_real_T(A, i4);
      loop_ub = A->size[0];
      for (i4 = 0; i4 < loop_ub; i4++) {
        A->data[i4] = rtNaN;
      }

      loop_ub = A->size[0];
      for (i4 = 0; i4 < loop_ub; i4++) {
        A->data[i4 + A->size[0]] = rtNaN;
      }

      for (i4 = 0; i4 < m; i4++) {
        tau_data[i4] = rtNaN;
      }

      jpvt[0] = 1;
      jpvt[1] = 2;
    } else {
      jpvt[0] = (int32_T)jpvt_t[0];
      jpvt[1] = (int32_T)jpvt_t[1];
    }
  }
}

/* End of code generation (xgeqp3.c) */
