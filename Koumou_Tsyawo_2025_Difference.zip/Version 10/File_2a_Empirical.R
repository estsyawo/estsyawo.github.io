#=========================================================================================>
# Authors: Gilles Koumou & Emmanuel Selorm Tsyawo
# Project: Difference-in-differences with as few as two cross-sectional units\\ 
#-- A new perspective to the democracy-growth debate
# Date begun: Sept. 13, 2022
# Date last updated:   Oct. 2, 2025
# Place:        Tuscaloosa
# Purpose: Empirical Application (Togo as control)
#=========================================================================================>
rm(list=ls()) # clear entire memory
library(tseries)
library(lmtest)
library(sandwich)
library(nlme)
#setwd(dirname(rstudioapi::getActiveDocumentContext()$path)) #set working directory path to source file
#=========================================================================================>
source("File_0_Fonctions.R")
#=========================================================================================>
#load data:

daten<- read.table(file = "Daten_2015_USD.txt",header = T)
head(daten)
names(daten)[1:2]<- c("Period","Year_Code")
#=========================================================================================>

#=========================================================================================>
# plots of GDP per capita
pdf("out_GDP_per_Capita.png")

plot(daten$Period,daten$Benin,type = "l",pch=1,xlab = "Year",ylab = " Level ",ylim = c(400,1200))
lines(daten$Period,daten$Togo,type = "l",lty=2,pch=2)
legend(1970, 1000, legend=c("Benin", "Togo"),lty=1:2, cex=0.8)
abline(v=1990,lty=3)

dev.off()

pdf("out_logGDP_per_Capita.png")

plot(daten$Period,log(daten$Benin),type = "l",pch=1,xlab = "Year",ylab = " Log ",ylim = c(6,7.2))
lines(daten$Period,log(daten$Togo),type = "l",lty=2,pch=2)
legend(1970, 7.0, legend=c("Benin", "Togo"),lty=1:2, cex=0.8)
abline(v=1990,lty=3)

dev.off()


#compute average GDP of Benin in post treatment >= 1991

#=========================================================================================>
#Naming Convention: L_t0, 
#                   Lag: either lev (Level of Y) or loglev (Log-level of Y) with lagged 
#                         outcome included to remove the unit root or alleviate autocorrelation
#                   t0: 1990,1991,1992,1990_1992  - treatment periods
#=========================================================================================>



#=========================================================================================>
# Computations in Levels with lagged outcome (to remove unit root/very high autocorrelation)

#----------------------->
#                       Treatment Period: 1990-1992
#level
(lag_1990.1992=ATT.fun(Y1=daten$Benin,Y0=daten$Togo,var.time = daten$Period,
                        time.treat = 1990:1992,t.X="Lag",se.type="NW",weight=T))


#----------------------->
#                       Treatment Period: 1990
#level
(lag_1990=ATT.fun(Y1=daten$Benin,Y0=daten$Togo,var.time = daten$Period,
                   time.treat = 1990,t.X="Lag",se.type="NW",weight=T))

#----------------------->
#                       Treatment Period: 1991
#level
(lag_1991=ATT.fun(Y1=daten$Benin,Y0=daten$Togo,var.time = daten$Period,
                   time.treat = 1991,t.X="Lag",se.type="NW",weight=T))

#----------------------->
#                       Treatment Period: 1992
#level
(lag_1992=ATT.fun(Y1=daten$Benin,Y0=daten$Togo,var.time = daten$Period,
                   time.treat = 1992,t.X="Lag",se.type="NW",weight=T))

#=========================================================================================>


#=========================================================================================>
# Computations in Levels with lagged outcome (to remove unit root/very high autocorrelation)

#----------------------->
#                       Treatment Period: 1990-1992
#level
(log_lag_1990.1992=ATT.fun(Y1=daten$Benin,Y0=daten$Togo,var.time = daten$Period,
                       time.treat = 1990:1992,t.X="Lag",se.type="NW",transf=log
                       ,weight=T))

#----------------------->
#                       Treatment Period: 1990
#level
(log_lag_1990=ATT.fun(Y1=daten$Benin,Y0=daten$Togo,var.time = daten$Period,
                  time.treat = 1990,t.X="Lag",se.type="NW",transf=log,weight=T))

#----------------------->
#                       Treatment Period: 1991
#level
(log_lag_1991=ATT.fun(Y1=daten$Benin,Y0=daten$Togo,var.time = daten$Period,
                  time.treat = 1991,t.X="Lag",se.type="NW",transf=log,weight=T))


#----------------------->
#                       Treatment Period: 1992
#level
(log_lag_1992=ATT.fun(Y1=daten$Benin,Y0=daten$Togo,var.time = daten$Period,
                  time.treat = 1992,t.X="Lag",se.type="NW",transf=log,weight=T))

#=========================================================================================>


#=========================================================================================>
# Print Out Empirical Results
#----------------------->

res.tab<- res.fun(LaTeX=F)

#           1990.1992   1990   1991   1992   1990.1992  1990  1991  1992
# ATT          46.586 56.536 54.101 42.786       0.064 0.078 0.074 0.059
# Ste.ATT      16.178 14.886  16.04 16.076       0.017 0.018 0.019 0.017
# p-val         0.004      0  0.001  0.008           0     0     0     0
# lag.Y         0.835  0.806  0.805  0.835       0.803 0.775 0.775 0.802
# Ste.lag.Y      0.06   0.06  0.064  0.059        0.05  0.06  0.06 0.049
# ADF           0.023  0.034  0.033  0.024       0.028 0.025 0.035 0.043
# KPSS            0.1    0.1    0.1    0.1         0.1   0.1   0.1   0.1
# DW            0.432  0.822  0.906  0.441       0.159 0.977 0.798 0.153


res.TeX<- res.fun(LaTeX=T,outfile="tab.empirical.txt")

#=========================================================================================>


#=========================================================================================>
# Authors' calculations reported in the text

#----------------------->
# Effect on Level GDP per capita as a fraction of 2015 Benin GDP per capita

bench.2015=100*round(as.numeric(res.tab["ATT",-(1:5)])/c(daten$Benin[which(daten$Period==2015)]),3)
print.fn(x=bench.2015,nsmall=1)
#4.4 &5.4 &5.2 &4.0 \\



#----------------------->
# ATT in percentages as a ratio of the World GDP per capita average over 1991-2018

round(round(100*as.numeric(res.tab["ATT",1:4]),1)/round(3.5971428,1),1)

# 1.8 2.2 2.1 1.6 #from 1.6 through 2.2

#Conversion Factor: ratio of Benin's PPP adjusted GDP per capita to its 2015 constant USD
CF.2022<- round(3067.54054450397/1041.65252312918,1) #[1] 2.9

CF.2022*as.numeric(res.tab["ATT",-(1:5)])

#[1] 131.9819 163.4295 155.8257 120.6922
#=========================================================================================>



#=========================================================================================>
# Unreported MA Specifications
(q1_MA_1990.1992=ATT.fun(Y1=daten$Benin,Y0=daten$Togo,var.time = daten$Period,
                      time.treat = 1990:1992,t.X="MA",se.type="NW",weight=T,q=1))

(q2_MA_1990.1992=ATT.fun(Y1=daten$Benin,Y0=daten$Togo,var.time = daten$Period,
                         time.treat = 1990:1992,t.X="MA",se.type="NW",weight=T,q=2))

(q3_MA_1990.1992=ATT.fun(Y1=daten$Benin,Y0=daten$Togo,var.time = daten$Period,
                         time.treat = 1990:1992,t.X="MA",se.type="NW",weight=T,q=3))

(q4_MA_1990.1992=ATT.fun(Y1=daten$Benin,Y0=daten$Togo,var.time = daten$Period,
                         time.treat = 1990:1992,t.X="MA",se.type="NW",weight=T,q=4))
#-------------------------------------------------------------------------------

#-------------------------------------------------------------------------------
(q1_log_MA_1990.1992=ATT.fun(Y1=daten$Benin,Y0=daten$Togo,var.time = daten$Period,
                           time.treat = 1990:1992,t.X="MA",se.type="NW",transf=log
                           ,weight=T,q=1))

(q2_log_MA_1990.1992=ATT.fun(Y1=daten$Benin,Y0=daten$Togo,var.time = daten$Period,
                             time.treat = 1990:1992,t.X="MA",se.type="NW",transf=log
                             ,weight=T,q=2))

(q3_log_MA_1990.1992=ATT.fun(Y1=daten$Benin,Y0=daten$Togo,var.time = daten$Period,
                             time.treat = 1990:1992,t.X="MA",se.type="NW",transf=log
                             ,weight=T,q=3))

(q4_log_MA_1990.1992=ATT.fun(Y1=daten$Benin,Y0=daten$Togo,var.time = daten$Period,
                             time.treat = 1990:1992,t.X="MA",se.type="NW",transf=log
                             ,weight=T,q=4))
#=========================================================================================>