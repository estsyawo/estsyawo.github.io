MATLAB="/Applications/MATLAB_R2018b.app"
Arch=maci64
ENTRYPOINT=mexFunction
MAPFILE=$ENTRYPOINT'.map'
PREFDIR="/Users/Selorm/Library/Application Support/MathWorks/MATLAB/R2018b"
OPTSFILE_NAME="./setEnv.sh"
. $OPTSFILE_NAME
COMPILER=$CC
. $OPTSFILE_NAME
echo "# Make settings for CCRls" > CCRls_mex.mki
echo "CC=$CC" >> CCRls_mex.mki
echo "CFLAGS=$CFLAGS" >> CCRls_mex.mki
echo "CLIBS=$CLIBS" >> CCRls_mex.mki
echo "COPTIMFLAGS=$COPTIMFLAGS" >> CCRls_mex.mki
echo "CDEBUGFLAGS=$CDEBUGFLAGS" >> CCRls_mex.mki
echo "CXX=$CXX" >> CCRls_mex.mki
echo "CXXFLAGS=$CXXFLAGS" >> CCRls_mex.mki
echo "CXXLIBS=$CXXLIBS" >> CCRls_mex.mki
echo "CXXOPTIMFLAGS=$CXXOPTIMFLAGS" >> CCRls_mex.mki
echo "CXXDEBUGFLAGS=$CXXDEBUGFLAGS" >> CCRls_mex.mki
echo "LDFLAGS=$LDFLAGS" >> CCRls_mex.mki
echo "LDOPTIMFLAGS=$LDOPTIMFLAGS" >> CCRls_mex.mki
echo "LDDEBUGFLAGS=$LDDEBUGFLAGS" >> CCRls_mex.mki
echo "Arch=$Arch" >> CCRls_mex.mki
echo "LD=$LD" >> CCRls_mex.mki
echo OMPFLAGS= >> CCRls_mex.mki
echo OMPLINKFLAGS= >> CCRls_mex.mki
echo "EMC_COMPILER=clang" >> CCRls_mex.mki
echo "EMC_CONFIG=optim" >> CCRls_mex.mki
"/Applications/MATLAB_R2018b.app/bin/maci64/gmake" -j 1 -B -f CCRls_mex.mk
