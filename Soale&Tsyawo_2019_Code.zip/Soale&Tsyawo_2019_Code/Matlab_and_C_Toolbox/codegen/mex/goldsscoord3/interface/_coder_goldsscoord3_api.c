/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * _coder_goldsscoord3_api.c
 *
 * Code generation for function '_coder_goldsscoord3_api'
 *
 */

/* Include files */
#include "rt_nonfinite.h"
#include "goldsscoord3.h"
#include "_coder_goldsscoord3_api.h"
#include "goldsscoord3_emxutil.h"
#include "goldsscoord3_mexutil.h"
#include "goldsscoord3_data.h"

/* Variable Definitions */
static emlrtRTEInfo ac_emlrtRTEI = { 1,/* lineNo */
  1,                                   /* colNo */
  "_coder_goldsscoord3_api",           /* fName */
  ""                                   /* pName */
};

/* Function Declarations */
static const mxArray *b_emlrt_marshallOut(const emxArray_real_T *u);
static const mxArray *c_emlrt_marshallOut(const emxArray_real_T *u);
static void e_emlrt_marshallIn(const emlrtStack *sp, const mxArray *Y, const
  char_T *identifier, emxArray_real_T *y);
static void f_emlrt_marshallIn(const emlrtStack *sp, const mxArray *u, const
  emlrtMsgIdentifier *parentId, emxArray_real_T *y);
static void g_emlrt_marshallIn(const emlrtStack *sp, const mxArray *X, const
  char_T *identifier, emxArray_real_T *y);
static void h_emlrt_marshallIn(const emlrtStack *sp, const mxArray *u, const
  emlrtMsgIdentifier *parentId, emxArray_real_T *y);
static void k_emlrt_marshallIn(const emlrtStack *sp, const mxArray *src, const
  emlrtMsgIdentifier *msgId, emxArray_real_T *ret);
static void l_emlrt_marshallIn(const emlrtStack *sp, const mxArray *src, const
  emlrtMsgIdentifier *msgId, emxArray_real_T *ret);

/* Function Definitions */
static const mxArray *b_emlrt_marshallOut(const emxArray_real_T *u)
{
  const mxArray *y;
  const mxArray *m34;
  static const int32_T iv24[1] = { 0 };

  y = NULL;
  m34 = emlrtCreateNumericArray(1, iv24, mxDOUBLE_CLASS, mxREAL);
  emlrtMxSetData((mxArray *)m34, &u->data[0]);
  emlrtSetDimensions((mxArray *)m34, u->size, 1);
  emlrtAssign(&y, m34);
  return y;
}

static const mxArray *c_emlrt_marshallOut(const emxArray_real_T *u)
{
  const mxArray *y;
  const mxArray *m35;
  static const int32_T iv25[2] = { 0, 0 };

  y = NULL;
  m35 = emlrtCreateNumericArray(2, iv25, mxDOUBLE_CLASS, mxREAL);
  emlrtMxSetData((mxArray *)m35, &u->data[0]);
  emlrtSetDimensions((mxArray *)m35, u->size, 2);
  emlrtAssign(&y, m35);
  return y;
}

static void e_emlrt_marshallIn(const emlrtStack *sp, const mxArray *Y, const
  char_T *identifier, emxArray_real_T *y)
{
  emlrtMsgIdentifier thisId;
  thisId.fIdentifier = (const char *)identifier;
  thisId.fParent = NULL;
  thisId.bParentIsCell = false;
  f_emlrt_marshallIn(sp, emlrtAlias(Y), &thisId, y);
  emlrtDestroyArray(&Y);
}

static void f_emlrt_marshallIn(const emlrtStack *sp, const mxArray *u, const
  emlrtMsgIdentifier *parentId, emxArray_real_T *y)
{
  k_emlrt_marshallIn(sp, emlrtAlias(u), parentId, y);
  emlrtDestroyArray(&u);
}

static void g_emlrt_marshallIn(const emlrtStack *sp, const mxArray *X, const
  char_T *identifier, emxArray_real_T *y)
{
  emlrtMsgIdentifier thisId;
  thisId.fIdentifier = (const char *)identifier;
  thisId.fParent = NULL;
  thisId.bParentIsCell = false;
  h_emlrt_marshallIn(sp, emlrtAlias(X), &thisId, y);
  emlrtDestroyArray(&X);
}

static void h_emlrt_marshallIn(const emlrtStack *sp, const mxArray *u, const
  emlrtMsgIdentifier *parentId, emxArray_real_T *y)
{
  l_emlrt_marshallIn(sp, emlrtAlias(u), parentId, y);
  emlrtDestroyArray(&u);
}

static void k_emlrt_marshallIn(const emlrtStack *sp, const mxArray *src, const
  emlrtMsgIdentifier *msgId, emxArray_real_T *ret)
{
  static const int32_T dims[1] = { -1 };

  const boolean_T bv0[1] = { true };

  int32_T iv26[1];
  int32_T i12;
  emlrtCheckVsBuiltInR2012b(sp, msgId, src, "double", false, 1U, dims, &bv0[0],
    iv26);
  ret->allocatedSize = iv26[0];
  i12 = ret->size[0];
  ret->size[0] = iv26[0];
  emxEnsureCapacity_real_T(sp, ret, i12, (emlrtRTEInfo *)NULL);
  ret->data = (real_T *)emlrtMxGetData(src);
  ret->canFreeData = false;
  ret->canFreeData = false;
  emlrtDestroyArray(&src);
}

static void l_emlrt_marshallIn(const emlrtStack *sp, const mxArray *src, const
  emlrtMsgIdentifier *msgId, emxArray_real_T *ret)
{
  static const int32_T dims[2] = { -1, -1 };

  const boolean_T bv1[2] = { true, true };

  int32_T iv27[2];
  int32_T i13;
  emlrtCheckVsBuiltInR2012b(sp, msgId, src, "double", false, 2U, dims, &bv1[0],
    iv27);
  ret->allocatedSize = iv27[0] * iv27[1];
  i13 = ret->size[0] * ret->size[1];
  ret->size[0] = iv27[0];
  ret->size[1] = iv27[1];
  emxEnsureCapacity_real_T(sp, ret, i13, (emlrtRTEInfo *)NULL);
  ret->data = (real_T *)emlrtMxGetData(src);
  ret->canFreeData = false;
  ret->canFreeData = false;
  emlrtDestroyArray(&src);
}

void goldsscoord3_api(const mxArray * const prhs[5], int32_T nlhs, const mxArray
                      *plhs[4])
{
  emxArray_real_T *Y;
  emxArray_real_T *X;
  emxArray_real_T *clus;
  emxArray_real_T *bets;
  real_T nC;
  real_T a;
  real_T b;
  real_T optk;
  real_T BIC;
  emlrtStack st = { NULL,              /* site */
    NULL,                              /* tls */
    NULL                               /* prev */
  };

  st.tls = emlrtRootTLSGlobal;
  emlrtHeapReferenceStackEnterFcnR2012b(&st);
  emxInit_real_T(&st, &Y, 1, &ac_emlrtRTEI, true);
  emxInit_real_T(&st, &X, 2, &ac_emlrtRTEI, true);
  emxInit_real_T(&st, &clus, 1, &ac_emlrtRTEI, true);
  emxInit_real_T(&st, &bets, 2, &ac_emlrtRTEI, true);

  /* Marshall function inputs */
  Y->canFreeData = false;
  e_emlrt_marshallIn(&st, emlrtAlias(prhs[0]), "Y", Y);
  X->canFreeData = false;
  g_emlrt_marshallIn(&st, emlrtAlias(prhs[1]), "X", X);
  nC = c_emlrt_marshallIn(&st, emlrtAliasP(prhs[2]), "nC");
  a = c_emlrt_marshallIn(&st, emlrtAliasP(prhs[3]), "a");
  b = c_emlrt_marshallIn(&st, emlrtAliasP(prhs[4]), "b");

  /* Invoke the target function */
  goldsscoord3(&st, Y, X, nC, a, b, &optk, clus, bets, &BIC);

  /* Marshall function outputs */
  plhs[0] = emlrt_marshallOut(optk);
  emxFree_real_T(&X);
  emxFree_real_T(&Y);
  if (nlhs > 1) {
    clus->canFreeData = false;
    plhs[1] = b_emlrt_marshallOut(clus);
  }

  emxFree_real_T(&clus);
  if (nlhs > 2) {
    bets->canFreeData = false;
    plhs[2] = c_emlrt_marshallOut(bets);
  }

  emxFree_real_T(&bets);
  if (nlhs > 3) {
    plhs[3] = emlrt_marshallOut(BIC);
  }

  emlrtHeapReferenceStackLeaveFcnR2012b(&st);
}

/* End of code generation (_coder_goldsscoord3_api.c) */
