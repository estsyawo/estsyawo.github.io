#===============================================================================
rm(list=ls()) #clear memory
setwd(dirname(rstudioapi::getActiveDocumentContext()$path)) #set working directory
#path to source file
#===============================================================================


#===============================================================================
#Notes: 
# 1. Running time: 5 hours
# 2. Peak RAM usage: about 10 GB
# 3. Parallel computation on: 16 cores
#===============================================================================
start.time<- Sys.time()
#===============================================================================
cat("Linear Models, sample sizes 50, 100, 200 \n")
source("ST1_MC_LM_ker_A.R")
cat("\n")
#---------------------------
cat("Linear Models, sample sizes 500, 750, 1000 \n")
source("ST1_MC_LM_ker_B.R")
cat("\n")
#---------------------------
cat("Non-Linear Models, sample sizes 50, 100, 200 \n")
source("ST2_MC_NLM_ker_A.R")
cat("\n")
#---------------------------
cat("Non-Linear Models, sample sizes 500, 750, 1000 \n")
source("ST2_MC_NLM_ker_B.R")
cat("\n")
#---------------------------
cat("Produce ggplot plots \n")
source("ST3_Plots.R")
cat("\n")
#===============================================================================
end.time<- Sys.time()
end.time-start.time #Time difference of 4.88499 hours
#===============================================================================