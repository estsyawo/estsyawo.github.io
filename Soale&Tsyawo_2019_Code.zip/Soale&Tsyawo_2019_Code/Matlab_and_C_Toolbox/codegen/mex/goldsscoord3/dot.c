/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * dot.c
 *
 * Code generation for function 'dot'
 *
 */

/* Include files */
#include "rt_nonfinite.h"
#include "goldsscoord3.h"
#include "dot.h"
#include "blas.h"

/* Variable Definitions */
static emlrtRTEInfo vd_emlrtRTEI = { 13,/* lineNo */
  15,                                  /* colNo */
  "dot",                               /* fName */
  "/usr/local/MATLAB/R2018b/toolbox/eml/lib/matlab/specfun/dot.m"/* pName */
};

/* Function Definitions */
real_T dot(const emlrtStack *sp, const emxArray_real_T *a, const emxArray_real_T
           *b)
{
  real_T c;
  uint32_T varargin_1[2];
  uint32_T varargin_2[2];
  boolean_T p;
  boolean_T b_p;
  int32_T k;
  boolean_T exitg1;
  ptrdiff_t n_t;
  ptrdiff_t incx_t;
  ptrdiff_t incy_t;
  varargin_1[0] = (uint32_T)a->size[0];
  varargin_1[1] = 1U;
  varargin_2[0] = (uint32_T)b->size[0];
  varargin_2[1] = 1U;
  p = false;
  b_p = true;
  k = 0;
  exitg1 = false;
  while ((!exitg1) && (k < 2)) {
    if ((int32_T)varargin_1[k] != (int32_T)varargin_2[k]) {
      b_p = false;
      exitg1 = true;
    } else {
      k++;
    }
  }

  if (b_p) {
    p = true;
  }

  if (p || (a->size[0] == b->size[0])) {
  } else {
    emlrtErrorWithMessageIdR2018a(sp, &vd_emlrtRTEI,
      "MATLAB:dot:InputSizeMismatch", "MATLAB:dot:InputSizeMismatch", 0);
  }

  if (a->size[0] < 1) {
    c = 0.0;
  } else {
    n_t = (ptrdiff_t)a->size[0];
    incx_t = (ptrdiff_t)1;
    incy_t = (ptrdiff_t)1;
    c = ddot(&n_t, &a->data[0], &incx_t, &b->data[0], &incy_t);
  }

  return c;
}

/* End of code generation (dot.c) */
