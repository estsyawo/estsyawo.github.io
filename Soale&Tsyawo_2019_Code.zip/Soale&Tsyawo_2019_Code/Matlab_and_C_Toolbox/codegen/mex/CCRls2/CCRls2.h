/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * CCRls2.h
 *
 * Code generation for function 'CCRls2'
 *
 */

#ifndef CCRLS2_H
#define CCRLS2_H

/* Include files */
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "tmwtypes.h"
#include "mex.h"
#include "emlrt.h"
#include "rtwtypes.h"
#include "CCRls2_types.h"

/* Function Declarations */
extern void CCRls2(const real_T Y[1000], const real_T Xv[20000000], uint32_T n,
                   uint32_T p, emxArray_real_T *betas);

#endif

/* End of code generation (CCRls2.h) */
