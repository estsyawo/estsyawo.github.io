/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * goldsscoord_data.c
 *
 * Code generation for function 'goldsscoord_data'
 *
 */

/* Include files */
#include "rt_nonfinite.h"
#include "goldsscoord.h"
#include "goldsscoord_data.h"

/* Variable Definitions */
emlrtCTX emlrtRootTLSGlobal = NULL;
uint32_T state[625];
emlrtContext emlrtContextGlobal = { true,/* bFirstTime */
  false,                               /* bInitialized */
  131467U,                             /* fVersionInfo */
  NULL,                                /* fErrorFunction */
  "goldsscoord",                       /* fFunctionName */
  NULL,                                /* fRTCallStack */
  false,                               /* bDebugMode */
  { 2433290357U, 2237796540U, 4066813863U, 833189415U },/* fSigWrd */
  NULL                                 /* fSigMem */
};

/* End of code generation (goldsscoord_data.c) */
