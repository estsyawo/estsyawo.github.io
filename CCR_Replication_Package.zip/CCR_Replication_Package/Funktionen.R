#=====================================================================================>
MCsim.run<- function(j=NULL,datl,beta0,betas,beta0.orac,datl_Orac){
  dat = datl[[j]] #null operation for looping
  # preliminaries
  Y=dat[,1]; X=as.matrix(dat[,-1]);n<- length(Y); p<- ncol(X)
  tau_p<- rep(1,p)/sqrt(p); tol=1e-7
  #---------------------------------------------------------------------------------
  #---------------------Run GPE
  GPE<- CCR.reg(Y=Y,X=X,gam=2.7,betas = c(0,betas))
  mhat<- as.matrix(dummy_cols(GPE$CCRobj$clus)[,-1])
  bias.GPE<- c(t(tau_p)%*%(c(mhat%*%GPE$CCRobj$mobj$coefficients[-1]) - beta0))
  nbias.GPE<- Norm(c(mhat%*%GPE$CCRobj$mobj$coefficients[-1]) - beta0)/sqrt(p)
  sig.GPE<- sqrt(c(t(tau_p)%*%mhat%*%vcovHC(GPE$CCRobj$mobj)[-1,-1]%*%t(mhat)%*%tau_p))
  size.GPE = 1*(abs(bias.GPE/sig.GPE)>qnorm(0.975))
  #---------------------------------------------------------------------------------
  #---------------------Run pLASSO Belloni et al. 2014 (BCH)
  LASSO.BCH<- pLASSO.reg(Y,X)
  k.pLASSO<- length(LASSO.BCH$postLASSO$id.vars)
  pLASSO<- LASSO.BCH$postLASSO
  pLASSO$koefs<- rep(0,p)
  pLASSO$koefs[pLASSO$id.vars]=pLASSO$coefficients[-1] #ignore intercept
  bias.pLASSO <- c(t(tau_p)%*%(pLASSO$koefs - beta0))
  nbias.pLASSO <- Norm(pLASSO$koefs - beta0)/sqrt(p)
  sig.pLASSO<- sqrt(c(t(tau_p[pLASSO$id.vars])%*%vcovHC(pLASSO)[-1,-1]%*%tau_p[pLASSO$id.vars]))
  size.pLASSO<- 1*(abs(bias.pLASSO/sig.pLASSO)>qnorm(0.975))
  #---------------------------------------------------------------------------------
  #---------------------Run GDS Chernozhukov et al. 2022 (CNS)
  GDS.CNS<- pGDS.reg(Y,X,tol = tol)
  ## extract results corresponding to the BCCH LASSO estimator
  k.pGDS<- length(GDS.CNS$postGDS$id.vars)
  pGDS<- GDS.CNS$postGDS
  pGDS$koefs<- rep(0,p)
  pGDS$koefs[pGDS$id.vars]=pGDS$coefficients[-1] #ignore intercept
  bias.pGDS <- c(t(tau_p)%*%(pGDS$koefs - beta0))
  nbias.pGDS <- Norm(pGDS$koefs - beta0)/sqrt(p)
  sig.pGDS<- sqrt(c(t(tau_p[pGDS$id.vars])%*%vcovHC(pGDS)[-1,-1]%*%tau_p[pGDS$id.vars]))
  size.pGDS<- 1*(abs(bias.pGDS/sig.pGDS)>qnorm(0.975))
  #---------------------------------------------------------------------------------
  #---------------------Run OLS
  ## fit OLS
  if(p<n){
    OLS <- lm(Y~X)
    bias.OLS<- c(t(tau_p)%*%(c(OLS$coefficients[-1]) - beta0))
    nbias.OLS<- Norm(c(OLS$coefficients[-1]) - beta0)/sqrt(p)
    sig.OLS<- sqrt(c(t(tau_p)%*%vcovHC(OLS)[-1,-1]%*%tau_p))
    size.OLS<- 1*(abs(bias.OLS/sig.OLS)>qnorm(0.975))
    k.OLS<- p
  }else{
    bias.OLS<- nbias.OLS<- size.OLS<- k.OLS<- NA
  }
  #---------------------------------------------------------------------------------
  #---------------------Run ``Oracle" OLS
  ## fit OLS on larger sample 3xn for ``Oracle" estimator
  dat.Orac = datl_Orac[[j]]; Y.Orac=dat.Orac[,1]; X.Orac=as.matrix(dat.Orac[,-1])
  Orac.OLS <- lm(Y.Orac~X.Orac)
  bias.Orac.OLS<- c(t(tau_p)%*%(c(Orac.OLS$coefficients[-1]) - beta0))
  nbias.Orac.OLS<- Norm(c(Orac.OLS$coefficients[-1]) - beta0)/sqrt(p)
  sig.Orac.OLS<- sqrt(c(t(tau_p)%*%vcovHC(Orac.OLS)[-1,-1]%*%tau_p))
  size.Orac.OLS<- 1*(abs(bias.Orac.OLS/sig.Orac.OLS)>qnorm(0.975))
  k.Orac.OLS<- p
  #---------------------------------------------------------------------------------
  #---------------------Run ``Oracle" GPE Infeasible GPE that uses beta0 as starting values
  Orac.GPE<- CCR.reg(Y=Y,X=X,gam=2.7,betas = c(0,beta0.orac))
  mhat<- as.matrix(dummy_cols(Orac.GPE$CCRobj$clus)[,-1])
  bias.Orac.GPE<- c(t(tau_p)%*%(c(mhat%*%Orac.GPE$CCRobj$mobj$coefficients[-1]) - beta0))
  nbias.Orac.GPE<- Norm(c(mhat%*%Orac.GPE$CCRobj$mobj$coefficients[-1]) - beta0)/sqrt(p)
  sig.Orac.GPE<- sqrt(c(t(tau_p)%*%mhat%*%vcovHC(Orac.GPE$CCRobj$mobj)[-1,-1]%*%t(mhat)%*%tau_p))
  size.Orac.GPE = 1*(abs(bias.Orac.GPE/sig.Orac.GPE)>qnorm(0.975))
  #---------------------------------------------------------------------------------
  res<- c(bias.GPE,nbias.GPE,size.GPE,GPE$khat,
          bias.pLASSO,nbias.pLASSO,size.pLASSO,k.pLASSO,
          bias.pGDS,nbias.pGDS,size.pGDS,k.pGDS,
          bias.OLS,nbias.OLS,size.OLS,k.OLS,
          bias.Orac.OLS,nbias.Orac.OLS,size.Orac.OLS,k.Orac.OLS,
          bias.Orac.GPE,nbias.Orac.GPE,size.Orac.GPE,Orac.GPE$khat)
  names(res)<- c("bias.GPE","nbias.GPE","size.GPE","k.GPE",
                 "bias.pLASSO","nbias.pLASSO","size.pLASSO","k.pLASSO",
                 "bias.pGDS","nbias.pGDS","size.pGDS","k.pGDS",
                 "bias.OLS","nbias.OLS","size.OLS","k.OLS",
                 "bias.Orac.OLS","nbias.Orac.OLS","size.Orac.OLS","k.Orac.OLS",
                 "bias.Orac.GPE","nbias.Orac.GPE","size.Orac.GPE","k.Orac.GPE")
  #---------------------------------------------------------------------------------
  
  #---------------------------------------------------------------------------------
  res
}
#=====================================================================================>

#=====================================================================================>
#wrap MCsim.run() in tryCatch()
# ensures matrices are always returned after parallel runs
MCsim.fun<- function(j,datl,beta0,betas,beta0.orac,datl_Orac,n.est=6){
  tryCatch(
    expr = {
      return(MCsim.run(j=j,datl=datl,beta0=beta0,betas=betas,beta0.orac=beta0.orac,datl_Orac=datl_Orac))
      },
    error = function(e){return(rep(NA,4*n.est))},
    warning = function(w){return(NULL)},
    finally = { }
  )#end tryCatch    
}
#=====================================================================================>

#=====================================================================================>
CCR.reg <- function(Y,X,betas,gam=2.7,demean.X=FALSE,demean.Y=FALSE,report=FALSE) {
  p <- dim(X)[2]; n <- dim(X)[1]; kmax <- min((n-2),p)
  az<- 1e-20 #for numerical stability in computing nphi
  nphi <- numeric()
  
  if(demean.X){for(j in 1:p) X[,j]<- X[,j]-mean(X[,j])}; if(demean.Y){Y<- Y-mean(Y)}
  
  ccr1 <- CCR.reg.k(Y=Y,X=X,k=1)
  betas[is.na(betas)]<- 0
  
  for(j in 1:(kmax-1)) {
    ccr2 <- CCR.reg.k(Y=Y,X=X,k=j+1,betas = betas)
    nphi[j]<- n*mean(ccr1$mobj$residuals^2 - ccr2$mobj$residuals^2)/(az+mean(ccr2$mobj$residuals^2))
    if(report){message("j=",j,", nphi=",nphi[j],"\n")}
    if((nphi[j]>=0) & (nphi[j] <= gam)){ break }
    ccr1<- ccr2 #update CCR object
  } #end for(j in 1:(kmax-1))
  
  return(list(khat=j,nphi=nphi,CCRobj=ccr1))
}
#=====================================================================================>

#=====================================================================================>
#starting beta values; should contain first element as intercept;
#runs CCR with k fixed and starting values betas supplied
CCR.reg.k<- function (Y, X, k, betas, nC = 1){
  p = ncol(X);n = nrow(X)
  if(k>1){#avoid running CCR algorithm when k==1
    clus = cluscov::dcluspar(k, betas[-1])
    uniclus <- unique(clus)
    clusmns <- rep(NA, k)
    for (j in 1:k) {
      clusmns[j] <- mean(betas[-1][clus == uniclus[j]])
    }
    ans = cluscov::linrclus(Y, X, k, betas, clus, clusmns, nC, x = TRUE)
    X1 <- matrix(NA, n, k); Xnc = ans$X[, (1:nC)]; Xc = ans$X[, -c(1:nC)]
    for (j in 1:k) {
      X1[, j] <- apply(as.matrix(Xc[, which(clus == j)]), 1,sum)
    }
    mobj <- stats::lm(Y ~ as.matrix(cbind(Xnc, X1)[, -1]))
  }else{
    clus<- rep(1,p); mobj<- stats::lm(Y ~ as.matrix(X%*%clus)); ans=NA
  }
  
  list(mobj = mobj, clus = clus,linrclus.obj=ans)
}
#=====================================================================================>

#=====================================================================================>
#Purpose: This function runs a linear post-LASSO of Belloni et al. 2012

pLASSO.reg<- function(Y,X,amelior.X=NULL,tol=1e-10){
  
  #-----------------preliminaries
  n<- length(Y); p<- ncol(X); C<- 1.1; gam<- 0.1/log(max(c(n,p))); K=15
  lambda = 2*C*sqrt(n)*qnorm(1-gam/(2*p))#set penalty term lambda
  
  #-----------------initial penalty loading:
  Upsilon<- rep(NA,p); for(j in 1:p){Upsilon[j]<- sqrt(mean(X[,j]^2*((Y-mean(Y))^2)))}
  #-----------------initial LASSO & Post-LASSO regressions
  reg.LASSO<- glmnet(X%*%diag(1/Upsilon),Y,lambda= lambda/n) 
  #lambda adjusted to agree
  id.vars<- which(abs(c(coef(reg.LASSO)[,1])[-1]) > tol)
  if(length(id.vars)>0){
    reg.postLASSO<- lm(Y~as.matrix(X[,id.vars]))
  }else{
    reg.postLASSO<- lm(Y~1)
  }
  
  #----------------begin iterations
  iter = 0 #initiate counter
  while(iter<K){
    iter<- iter + 1 #update counter
    
    #-----------------update penalty loading:
    for(j in 1:p){Upsilon[j]<- sqrt(mean(X[,j]^2*(reg.postLASSO$residuals^2)))}
    #-----------------update LASSO & Post-LASSO regressions
    reg.LASSO<- glmnet(X%*%diag(1/Upsilon),Y,lambda= lambda/n) #lambda adjusted to agree
    id.vars<- which(abs(c(coef(reg.LASSO)[,1])[-1]) > tol)
    if(length(id.vars)>0){
      reg.postLASSO<- lm(Y~as.matrix(X[,id.vars]))
    }else{
      reg.postLASSO<- lm(Y~1)
    }
  }#end while(iter<=K)
  
  #add an amelioration set
  if((!is.null(amelior.X)) & !all(amelior.X%in%id.vars)){
    id.vars.aug<- unique(c(amelior.X,id.vars))
    reg.postLASSO<- lm(Y~as.matrix(X[,id.vars.aug]))
  }
  reg.postLASSO$id.vars<- id.vars
  
  return(list(postLASSO=reg.postLASSO,LASSO=reg.LASSO,lambda=lambda/n,Upsilon=Upsilon))
}
#=====================================================================================>

#=====================================================================================>
#Purpose: This function runs a linear post-GDS (Generalised Dantzig Selector) of 
# Chernozhukov, Newey & Singh 2022

pGDS.reg<- function(Y,X,tol=1e-20,K=15){
  
  #-----------------preliminaries
  n<- length(Y); p<- ncol(X); C<- 1.1; a<- 0.1
  lambda = C*qnorm(1-a/(2*p))/sqrt(n)#set penalty term lambda
  Y<- Y - mean(Y) #remove intercept
  #-----------------initial penalty loading:
  diag.D<- rep(NA,p); for(j in 1:p){diag.D[j]<- sqrt(mean(X[,j]^2*Y^2))}
  #-----------------initial GDS & Post-GDS regressions
  reg.GDS<- gds(X%*%diag(1/diag.D), Y, family = "gaussian",lambda = lambda)
  
  id.vars<- which(abs(c(reg.GDS$beta)) > tol)
  if(length(id.vars)>0){
    reg.postGDS<- lm(Y~as.matrix(X[,id.vars]))
  }else{
    reg.postGDS<- lm(Y~1)
  }
  
  #----------------begin iterations
  iter = 0 #initiate counter
  while(iter<K){
    iter<- iter + 1 #update counter
    
    #-----------------update penalty loading:
    reg.postGDS$residuals <- Y - X%*%c(reg.GDS$beta)
    for(j in 1:p){diag.D[j]<- sqrt(mean(X[,j]^2*(reg.postGDS$residuals^2)))}
    #-----------------update GDS & Post-GDS regressions
    reg.GDS<- gds(X%*%diag(1/diag.D), Y, family = "gaussian",lambda = lambda)
    id.vars<- which(abs(c(reg.GDS$beta)) > tol)
    if(length(id.vars)>0){
      reg.postGDS<- lm(Y~as.matrix(X[,id.vars]))
    }else{
      reg.postGDS<- lm(Y~1)
    }
  }#end while(iter<=K)
  
  reg.postGDS$id.vars<- id.vars
  
  return(list(postGDS=reg.postGDS,GDS=reg.GDS,lambda=lambda,diag.D=diag.D))
}
#=====================================================================================>





#=====================================================================================>
#Functions for generating different configurations of \beta_o
gen.beta0<- function(Config,p,n=NULL,mu=0.0,sig=1.0,s=5){
  switch (Config,
          
          "CnS" = beta0 <- seq(2,4,length.out=p),
          
          "CaS1" = beta0 <- qnorm(p=seq(0.05,0.95,length.out=p),mean=mu,sd=sig),
          
          "CaS2" = beta0 <- 0.7^(0:(p-1)),
          
          # "MnS" = {beta0 <- rep(0,p);beta0[1:s]<- 1
          # beta0<- beta0*qnorm(p=seq(0.05,0.95,length.out=p),mean=mu,sd=sig) + 0.1},
          
          "MnS" = {beta0 <- rep(0,p);beta0[1:s]<- 1
          beta0<- beta0*abs(qnorm(p=seq(0.05,0.95,length.out=p),mean=mu,sd=sig)) + 0.1},
          
          "MaS" = {beta0 <- rep(0,p);beta0[1:s]<- 1
          beta0<- beta0*qnorm(p=seq(0.05,0.95,length.out=p),mean=mu,sd=sig) + 0.5^p},
          
          "M_S" = {beta0 <- rep(0,p);beta0[1:s]<- 1
          beta0<- beta0*qnorm(p=seq(0.05,0.95,length.out=p),mean=mu,sd=sig)},
          
          "DnS" = {beta0 <- rep(0.1,p); beta0[1:s]<- beta0[1:s]+1},
          
          "DaS1" = {beta0 <- rep(0.5^p,p); beta0[1:s]<- beta0[1:s]+1},
          
          "DaS2" = {beta0 <- rep(0,p); beta0[1:s]<- 1;
          beta0 <- beta0 + qchisq(p=seq(0.05,0.95,length.out=p),df=1)/sqrt(2*n)},
          
          "D_S1" = {beta0 <- rep(0,p); beta0[1:s]<- 1},
          
          "D_S2" = {beta0 <- rep(0,p); beta0[1:ceil(p/2)]<- 1}
  )#end switch()
  return(beta0)
}
#---- test gen.beta0()
# gen.beta0(Config="CnS",p=10)
# gen.beta0(Config="CaS1",p=10)
# gen.beta0(Config="CaS2",p=10)
# gen.beta0(Config="MnS",p=10)
# gen.beta0(Config="MaS",p=10)
# gen.beta0(Config="M_S",p=10)
# gen.beta0(Config="DnS",p=10)
# gen.beta0(Config="DaS",p=10)
# gen.beta0(Config="D_S1",p=10)
# gen.beta0(Config="D_S2",p=10)
# gen.beta0(Config="D_S1.loc",p=10,n=100)
#=====================================================================================>
#Function to generate data
gen.dat<- function(beta0,rho,n,p,R=1000,dist.eps="chisq"){
  datl=list()
  for (l in 1:R) {
    if(dist.eps=="chisq"){
      set.seed(-2*l);eps <- (rchisq(n,df=1)-1)/sqrt(2)  
    }else if(dist.eps=="normal"){
      set.seed(-2*l);eps <- rnorm(n)
    }
    set.seed(l+R) #generate seed
    X <- rmvnorm(n,rep(0,p),ar1cor(p,rho))
    Y <- 0 + X%*%beta0 + sqrt(0.5*(1+X[,1]^2))*eps
    #Y <- 0 + X%*%beta0 + eps
    #save in a list
    datl[[l]]<- data.frame(Y,X)
  }
  datl
}
#test:
#gen.dat(beta0 = gen.beta0(Config="CnS",p=3),rho = rho,n=5,p=3,R=2,dist.eps="chisq")
#gen.dat(beta0 = gen.beta0(Config="CnS",p=3),rho = rho,n=5,p=3,R=2,dist.eps = "normal")
#=====================================================================================>

#=====================================================================================>
#Code to run ADMM() algorithm

## sum of squares function
sqrt_sum <- function(x) sqrt(sum(x^2))
normalise<- function(x) x/sqrt_sum(x)

## Soft Threshold function (equation 15)
softTHRESH <- function(z,a){
  norm_z <- sqrt_sum(z)
  za <- z*max(1-a/norm_z, 0)
  return(za)
}

## minimax concave penalty (MCP)
mcp <- function(x, gam, lambda, omega){
  if(gam <= 1/omega) stop("MCP: Gamma needs to be greater than 1/omega.")
  norm_x <- sqrt_sum(x)
  if(norm_x <= (gam*lambda) )
    x.mcp <- (gam/(gam-1/omega))*softTHRESH(x, lambda/omega)
  else 
    x.mcp <- x 
  
  return(x.mcp)
}

## Subtract a matrix's column from every other of its column
stepMinus_matX <- function(M){
  n <- dim(M)[1]
  p <- dim(M)[2]
  temp <- apply(M, 2, function(x) x-M)
  for(i in 1:p){
    ls <- matrix(temp[,i],n,p)
    add <- ls[, -1:-i]
    if(i==1) tempM <- add
    else tempM <- cbind(tempM, add)
  }
  colnames(tempM) <- NULL
  return(tempM)
}

##--------- multiple alternating direction method of multipliers ----------###
ADMM <- function(Y, X, gam=2, lambda=1, omega=1, tol=1e-3, maxiter=5000) {
  
  ## Initialization
  N <- dim(X)[1]
  p <- dim(X)[2]
  d <- p*(p-1)/2
  I_p <- diag(p)
  
  DELTA <- t(stepMinus_matX(I_p))
  A <- DELTA
  tA <- t(A)
  
  ## step 1
  beta <- numeric(p)
  for(i in 1:p) beta[i] <- coef(lm(Y~X[,i]))[-1]
  nu <- rep(0, d)
  eta <-  A%*%beta
  
  ## --------- Start iteration for m step
  niter <- 1
  eps <- 1
  
  while((eps >= tol) & (niter<=maxiter)){ 
    
    
    ## given beta and nu, update eta
    eta_old <- eta
    xi <- A%*%beta + nu/omega
    eta <- sapply(xi, FUN=mcp, gam=gam, lambda = lambda,omega=omega)
    sqrt_sum(eta-eta_old)
    
    ## update nu
    nu_old <- nu
    nu <- nu_old + omega*(A%*%beta - eta)
    norm(nu-nu_old, "f")
    
    ## Update beta
    beta_old <- beta
    beta <- solve(omega*crossprod(A)+crossprod(X), crossprod(X,Y)+crossprod(A, omega*eta-nu))
    norm(beta-beta_old, "f")
    
    ## stopping rule
    eps <- sqrt(sum((A%*%beta - eta)^2))  
    niter <- niter + 1
    
  }  
  
  output <- list(beta=beta, eta=eta, nu=nu, niter=niter, eps=eps)
  
  return(output)
  
}
#=====================================================================================>

#=====================================================================================>
#results to return:
# MnB - mean norm bias, 
# MAD - scaled Median Absolute Regression
# RMSE - Root Mean Squared Error
# Rej. - 5% Empirical Size
# kbar - median k (number of non-zero parameters estimated)

res.fun<- function(MC.mat,LaTeX=FALSE){
  nE<- nrow(MC.mat)/4 #number of estimators
  res<- data.frame(matrix(NA,nE,5))
  rownames(res)<- c("GPE","pLASSO","pGDS","OLS","Orac.OLS","Orac.GPE")
  colnames(res)<- c("MnB","MAD","RMSE","Rej.","kbar")
  id.bias<- (0:(nE-1))*4+1
  
  res$MnB<- round(apply(MC.mat[id.bias+1,],1,mean,na.rm=T),3)
  res$MAD<- round(apply(abs(MC.mat[id.bias,]),1,median,na.rm=T),3)
  res$RMSE<- round(apply(MC.mat[id.bias,],1,RMSE),3)
  res$Rej.<- round(apply(MC.mat[id.bias+2,],1,mean,na.rm=T),3)
  #res$kbar<- apply(MC.mat[id.bias+3,],1,getmode)
  res$kbar<- apply(MC.mat[id.bias+3,],1,median,na.rm=T)
  
  if(!LaTeX){
    cat("\n");print(res);cat("\n")
  }else{
      cat("\n");apply(cbind(rownames(res),res),1,print.fn,nsmall=3);cat("\n")
    }
  res
}
#=====================================================================================>

#=====================================================================================>
#the following function ensures printing to exactly nsmall decimal places
print.fn<-function(x,nsmall=3) cat(paste(format(x,nsmall=nsmall),collapse=" &"),paste("\\","\\",sep=""),"\n")
#=====================================================================================>
RMSE<- function(x) sqrt(mean(x^2,na.rm=T))
#=====================================================================================>
# Generate covariance matrix Sigma
ar1cor <- function(p,rho){
  if(rho==0) sigma = diag(p)
  else sigma = rho^abs(outer(1:p,1:p,'-'))
  return(sigma)
}
#=====================================================================================>

#=====================================================================================>
# Source: Code copied from: https://www.tutorialspoint.com/r/r_mean_median_mode.htm
# compute the mode from a number, i.e., the most frequently occuring number in the vector v
getmode <- function(v) {
  uniqv <- unique(v)
  uniqv[which.max(tabulate(match(v, uniqv)))]
}
#=====================================================================================>

#===============================================================================
gen.sim.res<- function(Config="CnS",n.vec,p.vec,R=1000,dist.eps="chisq"){
  #Preliminaries
  dat.list<- dat.list_Orac<- MCobj.list<- list(); cnt<- 0
  ref.mat<- data.frame(matrix(NA,length(p.vec)*length(n.vec),3))
  colnames(ref.mat)<- c("cnt","n","p")
  #----------------------
  #loop over all (n,p) pairs
  for(p in p.vec){ #p=p.vec[1];n=n.vec[1]
    for(n in n.vec){
      beta0<- gen.beta0(Config=Config,p=p,n=n)
      cnt<- cnt+1
      cat("cnt = ",cnt,"; n = ",n,"; p= ",p,"\n")
      ref.mat[cnt,]<- c(cnt,n,p) #for referencing
      #----------------------
      dat.list[[cnt]]<- gen.dat(beta0=beta0,rho=rho,n=n,p=p,R=R,dist.eps=dist.eps)
      #data augmentation for the ``Oracle"
      dat.list_Orac[[cnt]]<- gen.dat(beta0=beta0,rho=rho,n=3*n,p=p,R=R,dist.eps=dist.eps) 
      #generate starting values for the GPE
      dat = dat.list[[cnt]][[1]]; Y=dat[,1]; X=as.matrix(dat[,-1])
      betas <- c(ADMM(Y, X, lambda=1, gam=2, omega=1, maxiter=1000)$beta)
      set.seed(0);beta0.orac=beta0+runif(p,-1e-02,1e-02)
      # to avoid the Oracle GPE throwing an error in case of failure to identify k<=p groups
    
      MCobj.list[[cnt]]<- pbsapply(1:R, FUN=MCsim.fun,cl=4,datl=dat.list[[cnt]],beta0=beta0,betas=betas,
                                   beta0.orac=beta0.orac,datl_Orac=dat.list_Orac[[cnt]],n.est=6)
      
      res.fun(MCobj.list[[cnt]]) #print result to console
    }#end for p
  }#end for n
  return(MCobj.list) #output to return
}
#=====================================================================================>

#===============================================================================
gen.sim.pow<- function(Config="CnS",h.vec,n=100,p=75,R=1000,dist.eps="chisq",n.est=6){
  #Preliminaries
  dat.list<- dat.list_Orac<- MCobj.list<- list()
  cnt<- 0; MCobj.mat<- matrix(NA,length(h.vec),n.est)
  #----------------------
  #loop over all (n,p) pairs
  for(h in h.vec){ #p=p.vec[1];n=n.vec[1]
      beta0<- gen.beta0(Config=Config,p=p,n=n)
      cnt<- cnt+1
      cat("cnt = ",cnt,"; h= ",h,"; n= ",n,"; p=",p,"\n")
      #----------------------
      dat.list[[cnt]]<- gen.dat(beta0=-h+beta0,rho=rho,n=n,p=p,R=R,dist.eps=dist.eps)
      #data augmentation for the ``Oracle"
      dat.list_Orac[[cnt]]<- gen.dat(beta0=-h+beta0,rho=rho,n=3*n,p=p,R=R,dist.eps=dist.eps) 
      #generate starting values for the GPE
      dat = dat.list[[cnt]][[1]]; Y=dat[,1]; X=as.matrix(dat[,-1])
      betas <- c(ADMM(Y, X, lambda=1, gam=2, omega=1, maxiter=1000)$beta)
      set.seed(0);beta0.orac=-h+beta0+runif(p,-1e-02,1e-02)
      # to avoid the Oracle GPE throwing an error in case of failure to identify k<=p groups
      #MCsim.fun(j=1,datl=dat.list[[cnt]],beta0=beta0,betas=betas,beta0.orac=beta0.orac,datl_Orac=dat.list_Orac[[cnt]],n.est=6)
      MCobj.list[[cnt]]<- pbsapply(1:R, FUN=MCsim.fun,cl=4,datl=dat.list[[cnt]],beta0=beta0,betas=betas,
                                   beta0.orac=beta0.orac,datl_Orac=dat.list_Orac[[cnt]],n.est=6)
      MCobj.mat[cnt,]<- res.fun(MCobj.list[[cnt]])$Rej. #print result to console
  }#end for h
  return(MCobj.mat) #output to return
}
#=====================================================================================>

#=====================================================================================>
print.res.file<- function(MCobj.list,n.vec,p.vec,outfile="outfile.txt"){
  cnt<- 0
  sink(outfile)
  for(p in p.vec){
    for(n in n.vec){
      cnt<- cnt+1
      cat("cnt = ",cnt,"; n = ",n,"; p= ",p,"\n")
      res.fun(MCobj.list[[cnt]],LaTeX = T)
    }
  }
  sink()
}
#=====================================================================================>
# Box plots for bias, normed bias (nbias), and k
box_plot<- function(MCobj.list,res.type=c("bias","nbias","k"),group.est
                    ,title.name,out.file="out.pdf",np=1){
  if(res.type=="bias"){
    #t=1; ylab="Bias"
    t=1; ylab=TeX('$\\hat{\\theta}_n -\\theta_o$')
  }else if(res.type=="nbias"){
    #t=2; ylab="nBias"
    t=2; ylab=TeX('$||\\hat{\\beta}_n -\\beta_o||/\\sqrt{p}$')
  }else if(res.type=="k"){
    t=4; ylab=TeX('$\\hat{k}$')
  }
  n.est<- nrow(MCobj.list[[1]])/4
  id.bias<- (0:(n.est-1))*4+t
  df<- data.frame(bias.theta=c(t(MCobj.list[[np]][id.bias,])),
                  group=group.est, group_col = group.est,group_line =group.est)
  
  BPlot = ggplot(df, aes(y=bias.theta, x=group.est)) + 
    geom_boxplot() +
    scale_x_discrete(limits=unique(group.est))+
    labs(title=title.name, x = "Estimator", y = ylab) + 
    theme_gray(base_size = 15, base_family = "") + 
    #scale_color_manual(values=c("black","red","blue","darkorchid","brown","darkblue","purple4")[1:n.est])+
    theme(axis.text=element_text(size=15),axis.title=element_text(size=15),
          #plot.title = element_text(hjust = 0.5),plot.title = element_text(size=18),legend.position="none")+
          plot.title = element_text(hjust = 0.5,size=18),legend.position="none")+
    coord_cartesian(ylim=range(df$bias.theta)*1.1)
  BPlot
  
  ggsave(out.file,width=30,height=20,unit="cm")
}
#=====================================================================================>
pow_plot<- function(powmat,group.Rej,h.vec,title.name,out.file="out.pdf",Legend=T){
  n.est<- length(unique(group.Rej))
  df.pow<-data.frame(h=rep(h.vec,n.est), 
                     Rej = c(powmat),
                     group=group.Rej, group_col = group.Rej,group_line =group.Rej)
  
  if(Legend){
    ppt.Rej<- ggplot(data=df.pow)+
    aes(x=h,y=Rej,colour=group.Rej)+
    theme_gray()+
    labs(title=title.name,x="h", y = "Power")+
    scale_colour_manual(values=c("black","red","blue","darkorchid","brown","darkblue"))+
    theme(legend.title=element_blank())+
    theme(axis.text=element_text(size=20),axis.title=element_text(size=20,face="bold"),
          plot.title = element_text(hjust = 0.5,size=22,face="bold"))+
    theme(legend.text = element_text(colour="black", size=15))+
    theme(legend.position = c(0.80,0.60))+
    ylim(low=0.0,high=max(df.pow$Rej,na.rm = T))+
    geom_line(aes(linetype = group.Rej),linewidth=1.0)+
    geom_hline(yintercept=0.05, linetype="dashed", color = "black")
  }else{
    ppt.Rej<- ggplot(data=df.pow)+
      aes(x=h,y=Rej,colour=group.Rej)+
      theme_gray()+
      labs(title=title.name,x="h", y = "Power")+
      scale_colour_manual(values=c("black","red","blue","darkorchid","brown","darkblue"))+
      theme(legend.title=element_blank())+
      theme(axis.text=element_text(size=20),axis.title=element_text(size=20,face="bold"),
            plot.title = element_text(hjust = 0.5,size=22))+
      theme(legend.text = element_text(colour="black", size=15,face="bold"))+
      theme(legend.position = "none")+
      ylim(low=0.0,high=max(df.pow$Rej,na.rm = T))+
      geom_line(aes(linetype = group.Rej),linewidth=1.0)+
      geom_hline(yintercept=0.05, linetype="dashed", color = "black")
  }
  ppt.Rej
  ggsave(out.file,width=30,height=20,unit="cm")
}
#=====================================================================================>

#=====================================================================================>
make_plot<-function(df,lowy,highy,out.file) {
  ppp<- ggplot(data=df)+
    aes(x=age,y=elasticity,colour=group )+
    theme_gray()+
    xlab("Age")+
    ylab("Elasticity")+
    scale_colour_manual(values=c("black","darkblue","darkblue","darkblue","darkblue"))+
    scale_shape_manual(values=c("","O"))+
    # theme(plot.title = element_text(hjust = 0.5),text=element_text(size=20,  family="serif"))+
    # theme(legend.title=element_blank())+
    theme(axis.text=element_text(size=20),axis.title=element_text(size=20),
          legend.position="none")+
    ylim(low=lowy,high=highy)+
    geom_line(aes(linetype = group_line),size=1.0)+
    geom_point(aes(shape=group_col),size=2)+
    scale_linetype_manual(values=c("dashed","solid"))
  ggsave(out.file,width=30,height=20,unit="cm")
}
#=====================================================================================>