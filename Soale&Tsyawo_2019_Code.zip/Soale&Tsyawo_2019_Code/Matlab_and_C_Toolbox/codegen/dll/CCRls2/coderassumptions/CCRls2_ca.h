/*
 * File: CCRls2_ca.h
 *
 * Abstract: Tests assumptions in the generated code.
 */

#ifndef CCRLS2_CA_H
#define CCRLS2_CA_H

/* preprocessor validation checks */
#include "CCRls2_ca_preproc.h"
#include "coder_assumptions_hwimpl.h"

/* variables holding test results */
extern CA_HWImpl_TestResults CA_CCRls2_HWRes;
extern CA_PWS_TestResults CA_CCRls2_PWSRes;

/* variables holding "expected" and "actual" hardware implementation */
extern const CA_HWImpl CA_CCRls2_ExpHW;
extern CA_HWImpl CA_CCRls2_ActHW;

/* entry point function to run tests */
void CCRls2_caRunTests(void);

#endif                                 /* CCRLS2_CA_H */
