/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * Xkrun.c
 *
 * Code generation for function 'Xkrun'
 *
 */

/* Include files */
#include "mwmathutil.h"
#include "rt_nonfinite.h"
#include "CCRl_clus.h"
#include "Xkrun.h"
#include "CCRl_clus_emxutil.h"
#include "mldivide.h"
#include "kmeans.h"
#include "CCRl_clus_data.h"
#include "blas.h"

/* Function Definitions */
void Xkrun(const emxArray_real_T *coefs, const emxArray_real_T *Y, const
           emxArray_real_T *X, const emxArray_real_T *Xc, uint64_T k,
           emxArray_real_T *clus, emxArray_real_T *deltas, real_T *RSS)
{
  emxArray_real_T *Xk;
  int32_T lXc;
  int32_T i4;
  uint64_T j;
  int32_T xoffset;
  int32_T n;
  uint32_T r;
  int32_T nx;
  int32_T i5;
  emxArray_real_T *b_X;
  emxArray_boolean_T *wasnan;
  boolean_T hadnans;
  emxArray_int32_T *idx;
  int32_T end;
  emxArray_real_T *Cbest;
  int32_T b_j;
  emxArray_int32_T *r6;
  real_T alpha1;
  real_T beta1;
  ptrdiff_t m_t;
  ptrdiff_t n_t;
  ptrdiff_t k_t;
  ptrdiff_t lda_t;
  ptrdiff_t ldb_t;
  ptrdiff_t ldc_t;
  char_T TRANSA;
  char_T TRANSB;
  emlrtHeapReferenceStackEnterFcnR2012b(emlrtRootTLSGlobal);
  emxInit_real_T(&Xk, 2, true);

  /*  input X,Xk,p,k */
  lXc = Xc->size[1];
  i4 = Xk->size[0] * Xk->size[1];
  Xk->size[0] = X->size[0];
  Xk->size[1] = (int32_T)(eml_i64dplus(k, Xc->size[1]) + 1UL);
  emxEnsureCapacity_real_T(Xk, i4);
  j = eml_i64dplus(k, Xc->size[1]) + 1UL;
  xoffset = X->size[0] * (int32_T)j;
  for (i4 = 0; i4 < xoffset; i4++) {
    Xk->data[i4] = 1.0;
  }

  i4 = (2U <= Xc->size[1] + 1U);
  xoffset = Xc->size[1];
  for (n = 0; n < xoffset; n++) {
    nx = Xc->size[0];
    for (i5 = 0; i5 < nx; i5++) {
      Xk->data[i5 + Xk->size[0] * (i4 + n)] = Xc->data[i5 + Xc->size[0] * n];
    }
  }

  r = 1U;
  state[0] = 1U;
  for (nx = 0; nx < 623; nx++) {
    r = ((r ^ r >> 30U) * 1812433253U + nx) + 1U;
    state[nx + 1] = r;
  }

  emxInit_real_T(&b_X, 1, true);
  state[624] = 624U;

  /*  For reproducibility */
  i4 = b_X->size[0];
  b_X->size[0] = coefs->size[0];
  emxEnsureCapacity_real_T(b_X, i4);
  xoffset = coefs->size[0];
  for (i4 = 0; i4 < xoffset; i4++) {
    b_X->data[i4] = coefs->data[i4];
  }

  emxInit_boolean_T(&wasnan, 1, true);
  n = coefs->size[0] - 1;
  i4 = wasnan->size[0];
  wasnan->size[0] = coefs->size[0];
  emxEnsureCapacity_boolean_T(wasnan, i4);
  xoffset = coefs->size[0];
  for (i4 = 0; i4 < xoffset; i4++) {
    wasnan->data[i4] = false;
  }

  hadnans = false;
  for (xoffset = 0; xoffset <= n; xoffset++) {
    if (muDoubleScalarIsNaN(coefs->data[xoffset])) {
      hadnans = true;
      wasnan->data[xoffset] = true;
    }
  }

  emxInit_int32_T(&idx, 1, true);
  if (hadnans) {
    end = wasnan->size[0] - 1;
    nx = 0;
    for (xoffset = 0; xoffset <= end; xoffset++) {
      if (!wasnan->data[xoffset]) {
        nx++;
      }
    }

    i4 = idx->size[0];
    idx->size[0] = nx;
    emxEnsureCapacity_int32_T(idx, i4);
    nx = 0;
    for (xoffset = 0; xoffset <= end; xoffset++) {
      if (!wasnan->data[xoffset]) {
        idx->data[nx] = xoffset + 1;
        nx++;
      }
    }

    i4 = b_X->size[0];
    b_X->size[0] = idx->size[0];
    emxEnsureCapacity_real_T(b_X, i4);
    xoffset = idx->size[0];
    for (i4 = 0; i4 < xoffset; i4++) {
      b_X->data[i4] = coefs->data[idx->data[i4] - 1];
    }
  }

  emxInit_real_T(&Cbest, 1, true);
  local_kmeans(b_X, (int32_T)k, idx, Cbest);
  if (hadnans) {
    b_j = -1;
    i4 = clus->size[0];
    clus->size[0] = coefs->size[0];
    emxEnsureCapacity_real_T(clus, i4);
    for (xoffset = 0; xoffset <= n; xoffset++) {
      if (wasnan->data[xoffset]) {
        clus->data[xoffset] = rtNaN;
      } else {
        b_j++;
        clus->data[xoffset] = idx->data[b_j];
      }
    }
  } else {
    i4 = clus->size[0];
    clus->size[0] = idx->size[0];
    emxEnsureCapacity_real_T(clus, i4);
    xoffset = idx->size[0];
    for (i4 = 0; i4 < xoffset; i4++) {
      clus->data[i4] = idx->data[i4];
    }
  }

  emxFree_int32_T(&idx);

  /*  coefs of length p */
  j = 1UL;
  emxInit_int32_T(&r6, 1, true);
  while (j <= k) {
    r = (uint32_T)clus->size[0];
    i4 = wasnan->size[0];
    wasnan->size[0] = (int32_T)r;
    emxEnsureCapacity_boolean_T(wasnan, i4);
    i4 = wasnan->size[0];
    for (end = 0; end < i4; end++) {
      if ((0.0 <= clus->data[end]) && (clus->data[end] < 1.8446744073709552E+19)
          && (clus->data[end] == clus->data[end])) {
        wasnan->data[end] = (j == (uint64_T)muDoubleScalarRound(clus->data[end]));
      } else {
        wasnan->data[end] = false;
      }
    }

    end = wasnan->size[0] - 1;
    nx = 0;
    for (xoffset = 0; xoffset <= end; xoffset++) {
      if (wasnan->data[xoffset]) {
        nx++;
      }
    }

    i4 = r6->size[0];
    r6->size[0] = nx;
    emxEnsureCapacity_int32_T(r6, i4);
    nx = 0;
    for (xoffset = 0; xoffset <= end; xoffset++) {
      if (wasnan->data[xoffset]) {
        r6->data[nx] = xoffset + 1;
        nx++;
      }
    }

    nx = r6->size[0];
    i4 = X->size[0];
    if ((i4 == 0) || (r6->size[0] == 0) || (r6->size[0] == 0)) {
      i4 = X->size[0];
      r = (uint32_T)i4;
      i4 = b_X->size[0];
      b_X->size[0] = (int32_T)r;
      emxEnsureCapacity_real_T(b_X, i4);
      xoffset = (int32_T)r;
      for (i4 = 0; i4 < xoffset; i4++) {
        b_X->data[i4] = 0.0;
      }
    } else {
      i4 = X->size[0];
      n = X->size[0];
      i5 = b_X->size[0];
      b_X->size[0] = n;
      emxEnsureCapacity_real_T(b_X, i5);
      for (b_j = 0; b_j < i4; b_j++) {
        n = X->size[0];
        b_X->data[b_j] = X->data[b_j % n + X->size[0] * (r6->data[b_j / n] - 1)];
      }

      for (end = 2; end <= nx; end++) {
        xoffset = (end - 1) * i4;
        for (b_j = 0; b_j < i4; b_j++) {
          n = X->size[0];
          i5 = xoffset + b_j;
          b_X->data[b_j] += X->data[i5 % n + X->size[0] * (r6->data[i5 / n] - 1)];
        }
      }
    }

    i4 = (int32_T)eml_i64dplus(j, (real_T)lXc + 1.0);
    xoffset = b_X->size[0];
    for (n = 0; n < xoffset; n++) {
      Xk->data[n + Xk->size[0] * (i4 - 1)] = b_X->data[n];
    }

    /* sum rows of columns in same cluster */
    j++;
  }

  emxFree_boolean_T(&wasnan);
  emxFree_int32_T(&r6);
  i4 = deltas->size[0];
  deltas->size[0] = Y->size[0];
  emxEnsureCapacity_real_T(deltas, i4);
  xoffset = Y->size[0];
  for (i4 = 0; i4 < xoffset; i4++) {
    deltas->data[i4] = Y->data[i4];
  }

  b_mldivide(Xk, deltas);
  if ((Xk->size[1] == 1) || (deltas->size[0] == 1)) {
    i4 = b_X->size[0];
    b_X->size[0] = Xk->size[0];
    emxEnsureCapacity_real_T(b_X, i4);
    xoffset = Xk->size[0];
    for (i4 = 0; i4 < xoffset; i4++) {
      b_X->data[i4] = 0.0;
      nx = Xk->size[1];
      for (n = 0; n < nx; n++) {
        b_X->data[i4] += Xk->data[i4 + Xk->size[0] * n] * deltas->data[n];
      }
    }
  } else if ((Xk->size[0] == 0) || (Xk->size[1] == 0) || (deltas->size[0] == 0))
  {
    i4 = b_X->size[0];
    b_X->size[0] = Xk->size[0];
    emxEnsureCapacity_real_T(b_X, i4);
    xoffset = Xk->size[0];
    for (i4 = 0; i4 < xoffset; i4++) {
      b_X->data[i4] = 0.0;
    }
  } else {
    alpha1 = 1.0;
    beta1 = 0.0;
    m_t = (ptrdiff_t)Xk->size[0];
    n_t = (ptrdiff_t)1;
    k_t = (ptrdiff_t)Xk->size[1];
    lda_t = (ptrdiff_t)Xk->size[0];
    ldb_t = (ptrdiff_t)Xk->size[1];
    ldc_t = (ptrdiff_t)Xk->size[0];
    i4 = b_X->size[0];
    b_X->size[0] = Xk->size[0];
    emxEnsureCapacity_real_T(b_X, i4);
    TRANSA = 'N';
    TRANSB = 'N';
    dgemm(&TRANSA, &TRANSB, &m_t, &n_t, &k_t, &alpha1, &Xk->data[0], &lda_t,
          &deltas->data[0], &ldb_t, &beta1, &b_X->data[0], &ldc_t);
  }

  emxFree_real_T(&Xk);
  i4 = b_X->size[0];
  b_X->size[0] = Y->size[0];
  emxEnsureCapacity_real_T(b_X, i4);
  xoffset = Y->size[0];
  for (i4 = 0; i4 < xoffset; i4++) {
    b_X->data[i4] = Y->data[i4] - b_X->data[i4];
  }

  r = (uint32_T)b_X->size[0];
  i4 = Cbest->size[0];
  Cbest->size[0] = (int32_T)r;
  emxEnsureCapacity_real_T(Cbest, i4);
  r = (uint32_T)b_X->size[0];
  nx = (int32_T)r;
  for (end = 0; end < nx; end++) {
    Cbest->data[end] = b_X->data[end] * b_X->data[end];
  }

  emxFree_real_T(&b_X);
  nx = Cbest->size[0];
  if (Cbest->size[0] == 0) {
    *RSS = 0.0;
  } else {
    *RSS = Cbest->data[0];
    for (end = 2; end <= nx; end++) {
      *RSS += Cbest->data[end - 1];
    }
  }

  emxFree_real_T(&Cbest);
  emlrtHeapReferenceStackLeaveFcnR2012b(emlrtRootTLSGlobal);
}

/* End of code generation (Xkrun.c) */
