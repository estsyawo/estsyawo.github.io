/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * goldsscoord.h
 *
 * Code generation for function 'goldsscoord'
 *
 */

#ifndef GOLDSSCOORD_H
#define GOLDSSCOORD_H

/* Include files */
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "tmwtypes.h"
#include "mex.h"
#include "emlrt.h"
#include "rtwtypes.h"
#include "goldsscoord_types.h"

/* Function Declarations */
extern void goldsscoord(const emxArray_real_T *Y, const emxArray_real_T *X,
  real_T nC, real_T a, real_T b, real_T *optk, emxArray_real_T *clus,
  emxArray_real_T *bets, emxArray_real_T *deltas, real_T *BIC);

#endif

/* End of code generation (goldsscoord.h) */
