#=========================================================================================>
# Authors: Gilles Koumou & Emmanuel Selorm Tsyawo
# Project: Difference-in-differences with as few as two cross-sectional units\\ 
#-- A new perspective to the democracy-growth debate
# Date begun: Sept. 13, 2022
# Date last updated:   Oct. 2, 2025
# Place:        Tuscaloosa
# Purpose: Simulations
#=========================================================================================>
rm(list=ls()) # clear entire memory
library(tseries)
library(lmtest)
library(sandwich)
library(parallel)
library(pbapply)
library(ggplot2)
#setwd(dirname(rstudioapi::getActiveDocumentContext()$path)) #set working directory path to source file
#=========================================================================================>
source("File_0_Fonctions.R")
#=========================================================================================>
#Comments:
# Compare the power curves of identification tests (t-tests) at the 10%, 5%, 1% levels 
# using competing tests: over-identifying restrictions using the DiD, SC, and BA 
# and pre-tests using the DiD, SC, and BA
#=========================================================================================>
# Set parameters
R=10000 #number of Monte Carlo Samples
a=0.5 #difference in counterfactual group mean outcomes
n.vec=c(25,50,100,200,400) #vector samples sizes nT,nTau
h.vec1=seq(0,1,length.out=11)
h.vec2=-c(0.9,seq(0.5,0.0,length.out=11)) #tuning the degree of violation of the PT and NA assumptions
cl=floor(detectCores()/2) #number of cores for parallel computation
#=========================================================================================>
#Comments:
# Compare the power curves of over-identifying restrictions identification and pre-trend 
# t-tests at the 10%, 5%, 1% levels using competing estimators: 
# DiD, SC, and BA with homogeneous treatment effects.
#=========================================================================================>


#===============================================================================
#start.time<- Sys.time()
#===============================================================================


#=========================================================================================>
# DGP_1
MC_test_DGP_1 = MC_idtest.pow(test.DGP=1,out.file="test_DGP_1",n=n.vec[1],h.vec=h.vec1,R=R,
                             ATT=0.0,error.type="MDS",alph=c(a,-a),phi=NULL,
                             t.X="Level",se.type="NW",cl=cl)
#=========================================================================================>


#=========================================================================================>
# DGP_2
phi_2<- function(var.time){(var.time>=4)*sqrt(2)}; phi_2=Vectorize(phi_2)
MC_test_DGP_2 = MC_idtest.pow(test.DGP=2,out.file="test_DGP_2",n=n.vec[1],h.vec=h.vec1,R=R,
                              ATT=0.0,error.type="MDS",alph=c(a,a),phi=phi_2,
                              t.X="Level",se.type="NW",cl=cl)
#=========================================================================================>


#=========================================================================================>
# DGP_3
MC_test_DGP_3 = MC_idtest.pow(test.DGP=3,out.file="test_DGP_3",n=n.vec[1],h.vec=h.vec1,R=R,
                              ATT=0.0,error.type="MDS",alph=c(a,-a),phi=phi_2,
                              t.X="Level",se.type="NW",cl=cl)
#=========================================================================================>


#===============================================================================

cat("See working directory for output tables and plots \n ")

#===============================================================================
# end.time<- Sys.time()
# print(end.time-start.time)
#===============================================================================

