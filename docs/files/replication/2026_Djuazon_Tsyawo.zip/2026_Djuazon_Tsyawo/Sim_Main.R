#=========================================================================================>
# Authors: Nelly Charlotte Djuazon & Emmanuel Selorm Tsyawo
# Project: Quantile and Distribution Treatment Effects on the Treated with Possibly 
#          Non-Continuous Outcomes
# Date began:   Apr. 13, 2023
# Last Update:  March 28, 2026
# Place:        Tuscaloosa, AL
#=========================================================================================>
# Comment: Runs the main Monte Carlo designs and writes simulation result tables for each 
#          configured DGP.
#=========================================================================================>
# Load packages, clear memory,

rm(list=ls()) #clear memory

#set working directory
get_script_dir <- function() {
  cmd_args <- commandArgs(trailingOnly = FALSE)
  file_arg <- grep("^--file=", cmd_args, value = TRUE)
  if (length(file_arg) > 0) {
    p <- sub("^--file=", "", file_arg[1])
    p <- gsub("~\\+~", " ", p)
    return(dirname(normalizePath(p, winslash = "/", mustWork = FALSE)))
  }
  if (requireNamespace("rstudioapi", quietly = TRUE)) {
    p <- tryCatch(rstudioapi::getActiveDocumentContext()$path, error = function(e) "")
    if (nzchar(p)) return(dirname(p))
  }
  getwd()
}

setwd(get_script_dir())
library(pbapply)

#=========================================================================================>
# Load packages and source functions
source("Fonctions.R")

#=========================================================================================>
# Simulation parameters
#=========================================================================================>
alpha <- 0.1; beta <- 0.2; gamma <- -0.1; delta <- 0
B <- 499
R <- 500
taus <- seq(0.05, 0.95, length.out = 101)
n_vec <- c(200, 400, 600, 800, 1000)
seed <- 123
cl = ceiling(parallel::detectCores()*(0.75))

#=========================================================================================>
# Configuration grid: DGP0 (empirical), DGP1 (discrete), DGP2 (continuous)
#=========================================================================================>
configs <- list(
  list(name="Empirical_DGP0", dgp="DGP0", e_dist="normal"),

  # DGP1
  list(name="Ald_p0.1_DGP1", dgp="DGP1", e_dist="ald", e_params=list(p=0.1)),
  list(name="Ald_p0.25_DGP1", dgp="DGP1", e_dist="ald", e_params=list(p=0.25)),
  list(name="Ald_p0.5_DGP1", dgp="DGP1", e_dist="ald", e_params=list(p=0.5)),
  list(name="Normal_DGP1", dgp="DGP1", e_dist="normal"),

  # DGP2
  list(name="Ald_p0.1_DGP2", dgp="DGP2", e_dist="ald", e_params=list(p=0.1)),
  list(name="Ald_p0.25_DGP2", dgp="DGP2", e_dist="ald", e_params=list(p=0.25)),
  list(name="Ald_p0.5_DGP2", dgp="DGP2", e_dist="ald", e_params=list(p=0.5)),
  list(name="Normal_DGP2", dgp="DGP2", e_dist="normal")
)

#=========================================================================================>
# Run all configurations
#=========================================================================================>
for (cfg in configs) {
  run_sim_table(
    dgp=cfg$dgp,
    e_dist=cfg$e_dist,
    e_params=if (is.null(cfg$e_params)) list() else cfg$e_params,
    alpha=alpha,
    beta=beta,
    gamma=gamma,
    delta=delta,
    B=B,
    R=R,
    taus=taus,
    n_vec=n_vec,
    seed=seed,
    cl=cl,
    output_dir="output",
    output_prefix=cfg$name
  )
}
#=========================================================================================>
