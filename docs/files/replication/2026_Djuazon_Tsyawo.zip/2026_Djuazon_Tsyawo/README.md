# Replication Files

This folder contains the replication files for the empirical applications and simulations in *Quantile and Distribution Treatment Effects on the Treated with Possibly Non-Continuous Outcomes* by Nelly K. Djuazon and Emmanuel S. Tsyawo.

The main batch runner is `run_all.R`. It checks required R packages, sets the working directory to this folder, creates `output/` when needed, and runs the empirical applications before the simulation scripts.

## Quick Start

Open R with this folder as the working directory and run:

```r
source("run_all.R")
```

The full run includes bootstrap and Monte Carlo routines and can take substantial time. To reproduce only the empirical figures and tables, run:

```r
source("a_Empirical_Application.R")
source("b_Empirical_Application.R")
source("c_Empirical_Application_logis.R")
```

The scripts write generated files to `output/`. The folder also contains precomputed output files that can be used as reference results.

## Requirements

The replication files were checked under R 4.5.2. The required R packages are:

- `ald`
- `dplyr`
- `ggplot2`
- `haven`
- `latex2exp`
- `pbapply`
- `plm`
- `purrr`
- `sandwich`

If any required package is missing, `run_all.R` attempts to install it from CRAN. This requires internet access and permission to install packages in the active R library.

## Recommended Run Order

The complete workflow is:

1. `a_Empirical_Application.R`
2. `b_Empirical_Application.R`
3. `c_Empirical_Application_logis.R`
4. `Sim_Main.R`
5. `Sim_Overid_Test.R`

The empirical scripts use fixed random seeds. The simulation scripts also set seeds internally, but small numerical differences can arise across platforms or parallel backends.

## File Guide

### `run_all.R`

Master runner for the full replication workflow.

It:

- sets the working directory to this folder;
- creates `output/` if needed;
- checks and, if necessary, installs required packages;
- runs the five main analysis scripts in the required order;
- executes each script in its own environment so internal `rm(list=ls())` calls do not interrupt the batch run;
- writes `output/session_info.txt` after a successful run.

### `a_Empirical_Application.R`

Empirical application using the standard normal working CDF.

Main outputs:

- `output/DTT_normal.pdf`
- `output/QTT_normal.pdf`
- `output/DTT_QTT_tables_normal.txt`

### `b_Empirical_Application.R`

Empirical application using the standard uniform working CDF.

Main outputs:

- `output/DTT_unif.pdf`
- `output/QTT_unif.pdf`
- `output/DTT_QTT_tables_unif.txt`

### `c_Empirical_Application_logis.R`

Empirical application using the standard logistic working CDF.

Main outputs:

- `output/DTT_logis.pdf`
- `output/QTT_logis.pdf`
- `output/DTT_QTT_tables_logis.txt`

### `Sim_Main.R`

Main Monte Carlo simulation runner for the paper's simulation designs.

It sources `Fonctions.R`, sets the simulation parameters, and runs the empirical, discrete, and continuous data-generating processes.

Main outputs:

- `output/Empirical_DGP0.txt`
- `output/Ald_p0.1_DGP1.txt`
- `output/Ald_p0.25_DGP1.txt`
- `output/Ald_p0.5_DGP1.txt`
- `output/Normal_DGP1.txt`
- `output/Ald_p0.1_DGP2.txt`
- `output/Ald_p0.25_DGP2.txt`
- `output/Ald_p0.5_DGP2.txt`
- `output/Normal_DGP2.txt`

### `Sim_Overid_Test.R`

Monte Carlo study for the functional over-identification tests.

It calibrates simulation inputs from the empirical dataset, simulates data for different values of `eta`, evaluates CvM and KS tests, and saves rejection-rate summaries and power-curve plots.

Main outputs:

- `output/empirical_rejection_rates.txt`
- `output/empirical_rejection_rates_identity.txt`
- `output/empirical_rejection_rates_normal.txt`
- `output/empirical_rejection_rates_uniform.txt`
- `output/Power_Curve_CvM.pdf`
- `output/Power_Curve_KS.pdf`
- `output/Power_Curve_identity_CvM.pdf`
- `output/Power_Curve_identity_KS.pdf`
- `output/Power_Curve_normal_CvM.pdf`
- `output/Power_Curve_normal_KS.pdf`
- `output/Power_Curve_uniform_CvM.pdf`
- `output/Power_Curve_uniform_KS.pdf`

### `Fonctions.R`

Shared function library for the main Monte Carlo simulations. It supports `Sim_Main.R` and does not produce standalone output when sourced directly.

### `Fonctions2.R`

Shared function library for the empirical applications and over-identification test script. It provides estimation, bootstrap, band-construction, plotting, inverse-quantile, and testing utilities.

### `MonthlyPanel_tab3ABC.dta`

Input dataset for the empirical applications and for calibration of the over-identification Monte Carlo study. The data are sourced from the Di Tella and Schargrodsky (2004) replication package deposited with the *American Economic Review*.

## Output Folder

Most generated results are written to `output/`. Existing files in `output/` are precomputed reference outputs and may be overwritten when the scripts are rerun.

## Notes

- The full simulation workflow uses parallel computation, with the number of cores set inside the scripts.
- The empirical scripts and simulation scripts set seeds internally.
- `run_all.R` records the R session information in `output/session_info.txt` after a successful full run.
- For questions about these files, please contact the authors.
