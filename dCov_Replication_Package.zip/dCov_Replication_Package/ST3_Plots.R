#=========================================================================================>
# Load packages, clear memory,
rm(list=ls()) #clear memory
library(ggplot2)
#=========================================================================================>
# Plots of the Objective function
n = 1e6
set.seed(0)
Ut1 = rnorm(n)
Ut2 = rcauchy(n)
Ut3 = rtri(n,-1,1,0)/sqrt(1/6)

Xt = c(rep(-1,0.25*n),rep(0,0.5*n),rep(1,0.25*n))
Qtheta.MC1=function(b){mean((abs(Xt)-0.5)*(abs(Ut1-Xt*b)-abs(Ut1)))}
Qtheta.MC2=function(b){mean((abs(Xt)-0.5)*(abs(Ut2-Xt*b)-abs(Ut2)))}
Qtheta.MC3=function(b){mean((abs(Xt)-0.5)*(abs(Ut3-Xt*b)-abs(Ut3)))}
Qtheta.MC1=Vectorize(Qtheta.MC1);Qtheta.MC2=Vectorize(Qtheta.MC2)
Qtheta.MC3=Vectorize(Qtheta.MC3)

ggplot(data.frame(x = seq(-1, 1, length.out = 10001)), aes(x = x)) +
  stat_function(fun = Qtheta.MC1) +
  labs(title = " ",
       x = TeX("\\theta$"),
       y = TeX("Q(\\theta)$"))+
  ylim(low=-0.005,high=0.095)+
  theme(axis.text=element_text(size=30),axis.title=element_text(size=30))
ggsave(filename = "fig_Qtheta_norm.pdf",width=30,height=30,unit="cm")

ggplot(data.frame(x = seq(-1, 1, length.out = 10001)), aes(x = x)) +
  stat_function(fun = Qtheta.MC2) +
  labs(title = " ",
       x = TeX("\\theta$"),
       y = TeX("Q(\\theta)$"))+
  ylim(low=-0.005,high=0.095)+
  theme(axis.text=element_text(size=30),axis.title=element_text(size=30))
ggsave(filename = "fig_Qtheta_cauchy.pdf",width=30,height=30,unit="cm")

ggplot(data.frame(x = seq(-1, 1, length.out = 10001)), aes(x = x)) +
  stat_function(fun = Qtheta.MC3) +
  labs(title = " ",
       x = TeX("\\theta$"),
       y = TeX("Q(\\theta)$"))+
  ylim(low=-0.005,high=0.095)+
  theme(axis.text=element_text(size=30),axis.title=element_text(size=30))
ggsave(filename = "fig_Qtheta_unif.pdf",width=30,height=30,unit="cm")
#=========================================================================================>