/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * CCRl_clus.c
 *
 * Code generation for function 'CCRl_clus'
 *
 */

/* Include files */
#include "mwmathutil.h"
#include <math.h>
#include "rt_nonfinite.h"
#include "CCRl_clus.h"
#include "CCRl_clus_emxutil.h"
#include "log.h"
#include "Xkrun.h"
#include "goldssopt.h"
#include "sprintf.h"
#include "mod.h"
#include "mldivide.h"
#include "rdivide_helper.h"
#include "randsample.h"
#include "CCRl_clus_data.h"
#include "blas.h"

/* Function Declarations */
static void b_eml_i64relops(const emxArray_real_T *a, uint64_T b,
  emxArray_boolean_T *p);
static void eml_i64relops(const emxArray_real_T *a, uint64_T b,
  emxArray_boolean_T *p);

/* Function Definitions */
static void b_eml_i64relops(const emxArray_real_T *a, uint64_T b,
  emxArray_boolean_T *p)
{
  int32_T i8;
  int32_T k;
  boolean_T b_p;
  i8 = p->size[0] * p->size[1];
  p->size[0] = 1;
  p->size[1] = a->size[1];
  emxEnsureCapacity_boolean_T(p, i8);
  i8 = p->size[1];
  for (k = 0; k < i8; k++) {
    if ((0.0 <= a->data[k]) && (a->data[k] < 1.8446744073709552E+19) && (a->
         data[k] == muDoubleScalarFloor(a->data[k]))) {
      b_p = (b == (uint64_T)muDoubleScalarRound(a->data[k]));
    } else {
      b_p = false;
    }

    p->data[k] = !b_p;
  }
}

static void eml_i64relops(const emxArray_real_T *a, uint64_T b,
  emxArray_boolean_T *p)
{
  int32_T i7;
  int32_T k;
  i7 = p->size[0] * p->size[1];
  p->size[0] = 1;
  p->size[1] = a->size[1];
  emxEnsureCapacity_boolean_T(p, i7);
  i7 = p->size[1];
  for (k = 0; k < i7; k++) {
    if ((0.0 <= a->data[k]) && (a->data[k] < 1.8446744073709552E+19) && (a->
         data[k] == muDoubleScalarFloor(a->data[k]))) {
      p->data[k] = (b == (uint64_T)muDoubleScalarRound(a->data[k]));
    } else {
      p->data[k] = false;
    }
  }
}

void CCRl_clus(const emxArray_real_T *Y, const emxArray_real_T *X, const
               emxArray_real_T *Xc, uint64_T frql, real_T kp, uint64_T kmin,
               uint64_T kmax, boolean_T rpt, uint64_T *k, emxArray_real_T *betas,
               emxArray_real_T *clus)
{
  emxArray_real_T *bet_vecv;
  int32_T p;
  int32_T n;
  int32_T lXc;
  int32_T i0;
  int32_T loop_ub;
  emxArray_real_T *lcls;
  real_T slc;
  int32_T i1;
  int32_T nx;
  int32_T input_sizes_idx_1;
  int32_T b_n;
  real_T nlcls;
  boolean_T exitg1;
  emxArray_real_T *coefs;
  emxArray_real_T *b;
  emxArray_real_T *betc;
  uint64_T l;
  emxArray_int32_T *r0;
  emxArray_real_T *X0;
  emxArray_real_T *bet_vec;
  real_T coef0[2];
  emxArray_real_T *b_bet_vecv;
  real_T val0;
  real_T val1;
  real_T dev;
  emxArray_boolean_T *IDls;
  emxArray_boolean_T *ngIDLS;
  emxArray_real_T *XB;
  emxArray_real_T *r1;
  emxArray_int32_T *r2;
  emxArray_int32_T *r3;
  emxArray_int32_T *r4;
  emxArray_real_T *a;
  emxArray_int32_T *a_tmp;
  emxArray_real_T *r5;
  int32_T exitg2;
  uint64_T temp;
  real_T yd;
  int32_T ex_t;
  uint64_T yint;
  uint64_T b_y1;
  uint64_T b_y0;
  uint64_T n1;
  uint64_T ldword;
  uint64_T temp0;
  real_T beta1;
  ptrdiff_t m_t;
  ptrdiff_t n_t;
  ptrdiff_t k_t;
  ptrdiff_t lda_t;
  ptrdiff_t ldb_t;
  ptrdiff_t ldc_t;
  char_T TRANSA;
  char_T TRANSB;
  boolean_T empty_non_axis_sizes;
  int8_T b_input_sizes_idx_1;
  boolean_T guard1 = false;
  int8_T c_input_sizes_idx_1;
  int32_T d_input_sizes_idx_1;
  int32_T b_ex_t;
  emlrtHeapReferenceStackEnterFcnR2012b(emlrtRootTLSGlobal);
  emxInit_real_T(&bet_vecv, 2, true);

  /*  Info: */
  /*  Author: Emmanuel Selorm Tsyawo */
  /*  Date: Feb. 23, 2019 */
  /*  Linear Clustered covariate regression with BIC criterion */
  /*  Function: CCRl_clus(Y,X,frql,kmin,kmax) */
  /*  Arguments: */
  /*          Y - outcome variable, length n */
  /*          X - n x p matrix of covariates to be clustered (should not include 1s for intercept) */
  /*          Xc - matrix of lXc covariates of interest not to be clustered, eg. */
  /*          treamtment variable(s). */
  /*          frql - number of iterations after which to search anew for the */
  /*          number of clusters. Recommended: a multiple of p */
  /*          kp - the fraction in (0,1) of n that constitutes a partition */
  /*          [kmin,kmax] - the interval over which to search for the optimal */
  /*          number of clusters. Should be kmin >= 2 and kmax<= */
  /*          min(floor(kp*n),p) where kp in (0,1).  */
  /*          rpt - logical for randomising partition assignment of columns in */
  /*          X */
  /*  Output:  */
  /*          k - optimal number of clusters */
  /*          betas - the parameter estimates (length p + lXc + 1). The first */
  /*          element is the intercept term. */
  /*          clus - cluster assignments of covariate elements */
  /*  1 Initialise parameters */
  p = X->size[1];
  n = X->size[0];
  lXc = Xc->size[1];

  /*  vector to store parameters, excludes intercept */
  i0 = bet_vecv->size[0] * bet_vecv->size[1];
  bet_vecv->size[0] = 1;
  bet_vecv->size[1] = X->size[1];
  emxEnsureCapacity_real_T(bet_vecv, i0);
  loop_ub = X->size[1];
  for (i0 = 0; i0 < loop_ub; i0++) {
    bet_vecv->data[i0] = 0.0;
  }

  emxInit_real_T(&lcls, 2, true);

  /* : vector of same length as bet_vec that keeps varied */
  /*  for intercepts */
  slc = muDoubleScalarFloor(kp * (real_T)X->size[0]);

  /* maximum size of a local covariate clusters. */
  if (X->size[1] < 1) {
    lcls->size[0] = 1;
    lcls->size[1] = 0;
  } else {
    i0 = X->size[1];
    i1 = lcls->size[0] * lcls->size[1];
    lcls->size[0] = 1;
    loop_ub = (int32_T)((real_T)i0 - 1.0);
    lcls->size[1] = loop_ub + 1;
    emxEnsureCapacity_real_T(lcls, i1);
    for (i0 = 0; i0 <= loop_ub; i0++) {
      lcls->data[i0] = 1.0 + (real_T)i0;
    }
  }

  i0 = lcls->size[0] * lcls->size[1];
  i1 = lcls->size[0] * lcls->size[1];
  lcls->size[0] = 1;
  emxEnsureCapacity_real_T(lcls, i1);
  loop_ub = i0 - 1;
  for (i0 = 0; i0 <= loop_ub; i0++) {
    lcls->data[i0] /= slc;
  }

  nx = lcls->size[1];
  for (input_sizes_idx_1 = 0; input_sizes_idx_1 < nx; input_sizes_idx_1++) {
    lcls->data[input_sizes_idx_1] = muDoubleScalarCeil(lcls->
      data[input_sizes_idx_1]);
  }

  /* partition covarites into clusters */
  b_n = lcls->size[1];
  if (lcls->size[1] <= 2) {
    if (lcls->size[1] == 1) {
      nlcls = lcls->data[0];
    } else if ((lcls->data[0] < lcls->data[1]) || (muDoubleScalarIsNaN
                (lcls->data[0]) && (!muDoubleScalarIsNaN(lcls->data[1])))) {
      nlcls = lcls->data[1];
    } else {
      nlcls = lcls->data[0];
    }
  } else {
    if (!muDoubleScalarIsNaN(lcls->data[0])) {
      nx = 1;
    } else {
      nx = 0;
      input_sizes_idx_1 = 2;
      exitg1 = false;
      while ((!exitg1) && (input_sizes_idx_1 <= lcls->size[1])) {
        if (!muDoubleScalarIsNaN(lcls->data[input_sizes_idx_1 - 1])) {
          nx = input_sizes_idx_1;
          exitg1 = true;
        } else {
          input_sizes_idx_1++;
        }
      }
    }

    if (nx == 0) {
      nlcls = lcls->data[0];
    } else {
      nlcls = lcls->data[nx - 1];
      i0 = nx + 1;
      for (input_sizes_idx_1 = i0; input_sizes_idx_1 <= b_n; input_sizes_idx_1++)
      {
        if (nlcls < lcls->data[input_sizes_idx_1 - 1]) {
          nlcls = lcls->data[input_sizes_idx_1 - 1];
        }
      }
    }
  }

  /*  number of partitions */
  emxInit_real_T(&coefs, 1, true);
  emxInit_real_T(&b, 1, true);
  if (rpt) {
    if (1 > X->size[1]) {
      loop_ub = 0;
    } else {
      loop_ub = X->size[1];
    }

    randsample(X->size[1], X->size[1], coefs);
    i0 = b->size[0];
    b->size[0] = coefs->size[0];
    emxEnsureCapacity_real_T(b, i0);
    nx = coefs->size[0];
    for (i0 = 0; i0 < nx; i0++) {
      b->data[i0] = lcls->data[(int32_T)coefs->data[i0] - 1];
    }

    emxInit_int32_T(&r0, 2, true);
    i0 = r0->size[0] * r0->size[1];
    r0->size[0] = 1;
    r0->size[1] = loop_ub;
    emxEnsureCapacity_int32_T(r0, i0);
    for (i0 = 0; i0 < loop_ub; i0++) {
      r0->data[i0] = i0;
    }

    loop_ub = r0->size[0] * r0->size[1] - 1;
    for (i0 = 0; i0 <= loop_ub; i0++) {
      lcls->data[r0->data[i0]] = b->data[i0];
    }

    emxFree_int32_T(&r0);
  }

  emxInit_real_T(&betc, 2, true);
  l = 0UL;

  /*  initialise counter */
  /*  initialise parameters */
  i0 = betc->size[0] * betc->size[1];
  betc->size[0] = 1;
  betc->size[1] = Xc->size[1] + 1;
  emxEnsureCapacity_real_T(betc, i0);
  loop_ub = Xc->size[1] + 1;
  for (i0 = 0; i0 < loop_ub; i0++) {
    betc->data[i0] = 0.0;
  }

  emxInit_real_T(&X0, 2, true);

  /* initialise intercept and coefficients of on Xc */
  i0 = X0->size[0] * X0->size[1];
  X0->size[0] = X->size[0];
  X0->size[1] = 2;
  emxEnsureCapacity_real_T(X0, i0);
  loop_ub = X->size[0] << 1;
  for (i0 = 0; i0 < loop_ub; i0++) {
    X0->data[i0] = 1.0;
  }

  emxInit_real_T(&bet_vec, 2, true);

  /*  for the initialisation of coefficients */
  i0 = X->size[1];
  i1 = bet_vec->size[0] * bet_vec->size[1];
  bet_vec->size[0] = 1;
  bet_vec->size[1] = X->size[1];
  emxEnsureCapacity_real_T(bet_vec, i1);
  for (nx = 0; nx < i0; nx++) {
    loop_ub = X->size[0] - 1;
    for (i1 = 0; i1 <= loop_ub; i1++) {
      X0->data[i1 + X0->size[0]] = X->data[i1 + X->size[0] * nx];
    }

    mldivide(X0, Y, coef0);
    bet_vec->data[nx] = coef0[1];
  }

  emxFree_real_T(&X0);

  /*  initial search for optimal number of clusters k and clustering */
  if (1 > X->size[1]) {
    loop_ub = -1;
  } else {
    loop_ub = X->size[1] - 1;
  }

  for (i0 = 0; i0 <= loop_ub; i0++) {
    bet_vecv->data[i0] = bet_vec->data[i0];
  }

  emxInit_real_T(&b_bet_vecv, 1, true);

  /*  pass bet_vec to bet_vecv */
  i0 = b_bet_vecv->size[0];
  b_bet_vecv->size[0] = bet_vecv->size[1];
  emxEnsureCapacity_real_T(b_bet_vecv, i0);
  loop_ub = bet_vecv->size[1];
  for (i0 = 0; i0 < loop_ub; i0++) {
    b_bet_vecv->data[i0] = bet_vecv->data[i0];
  }

  goldssopt(b_bet_vecv, Y, X, Xc, kmin, kmax, k, clus, coefs, &val0);
  loop_ub = Xc->size[1];
  for (i0 = 0; i0 <= loop_ub; i0++) {
    betc->data[i0] = coefs->data[i0];
  }

  /*  extract intercept and coefficients on Xc */
  if (Xc->size[1] + 2U > (uint32_T)coefs->size[0]) {
    i0 = -1;
  } else {
    i0 = Xc->size[1];
  }

  i1 = X->size[1];
  for (nx = 0; nx < i1; nx++) {
    bet_vec->data[nx] = coefs->data[i0 + (int32_T)clus->data[nx]];

    /* update betas with deltas */
  }

  val1 = val0 - 0.9 * muDoubleScalarAbs(val0);
  dev = 10.0;

  /*  2 Commence main iteration until convergence */
  emxInit_boolean_T(&IDls, 2, true);
  emxInit_boolean_T(&ngIDLS, 2, true);
  emxInit_real_T(&XB, 1, true);
  emxInit_real_T(&r1, 2, true);
  emxInit_int32_T(&r2, 2, true);
  emxInit_int32_T(&r3, 2, true);
  emxInit_int32_T(&r4, 2, true);
  emxInit_real_T(&a, 2, true);
  emxInit_int32_T(&a_tmp, 1, true);
  emxInit_real_T(&r5, 2, true);
  do {
    exitg2 = 0;

    /*  iterate and identify partition */
    l++;
    temp = b_rdivide_helper(l, nlcls) + MAX_uint64_T;
    if (muDoubleScalarIsNaN(nlcls) || (nlcls <= 0.0)) {
      yint = 0UL;
    } else {
      yd = frexp(nlcls, &ex_t);
      if ((int16_T)ex_t <= -64) {
        yint = 0UL;
      } else {
        yint = (uint64_T)muDoubleScalarRound(yd * 9.007199254740992E+15);
        b_y1 = yint >> 32;
        b_y0 = yint & 4294967295UL;
        if (temp == 0UL) {
          yint = 0UL;
        } else if (muDoubleScalarIsInf(nlcls)) {
          yint = MAX_uint64_T;
        } else if ((int16_T)((int16_T)ex_t - 53) > 64) {
          yint = MAX_uint64_T;
        } else {
          n1 = temp >> 32;
          yint = temp & 4294967295UL;
          ldword = yint * b_y0;
          temp0 = yint * b_y1;
          yint = n1 * b_y0;
          temp = ((temp0 & 4294967295UL) + (ldword >> 32)) + (yint
            & 4294967295UL);
          ldword = (ldword & 4294967295UL) + (temp << 32);
          yint = ((n1 * b_y1 + (temp0 >> 32)) + (yint >> 32)) + (temp >> 32);
          if ((int16_T)((int16_T)ex_t - 53) >= 0) {
            if (yint > 0UL) {
              yint = MAX_uint64_T;
            } else if ((ldword >> (uint8_T)((int16_T)ex_t - 117)) > 0UL) {
              yint = MAX_uint64_T;
            } else {
              yint = ldword << (uint8_T)((int16_T)ex_t - 53);
            }
          } else if ((int16_T)((int16_T)ex_t - 53) >= -64) {
            if ((yint >> (uint8_T)(53 - (int16_T)ex_t)) > 0UL) {
              yint = MAX_uint64_T;
            } else {
              yint = ((ldword >> (uint8_T)(53 - (int16_T)ex_t)) + (yint <<
                       (uint8_T)((int16_T)ex_t + 11))) + (ldword >> (uint8_T)(52
                - (int16_T)ex_t) & 1UL);
            }
          } else {
            yint = (yint >> (uint8_T)-(int16_T)((int16_T)ex_t + 11)) + (yint >>
              (uint8_T)-(int16_T)((int16_T)ex_t + 12) & 1UL);
          }
        }
      }
    }

    yint = l - yint;

    /* identify partition index */
    eml_i64relops(lcls, yint, IDls);

    /*  identify covariates in active partition */
    b_eml_i64relops(lcls, yint, ngIDLS);

    /*  identify covariates not in active partition */
    b_n = ngIDLS->size[1] - 1;
    nx = 0;
    for (input_sizes_idx_1 = 0; input_sizes_idx_1 <= b_n; input_sizes_idx_1++) {
      if (ngIDLS->data[input_sizes_idx_1]) {
        nx++;
      }
    }

    i0 = r2->size[0] * r2->size[1];
    r2->size[0] = 1;
    r2->size[1] = nx;
    emxEnsureCapacity_int32_T(r2, i0);
    nx = 0;
    for (input_sizes_idx_1 = 0; input_sizes_idx_1 <= b_n; input_sizes_idx_1++) {
      if (ngIDLS->data[input_sizes_idx_1]) {
        r2->data[nx] = input_sizes_idx_1 + 1;
        nx++;
      }
    }

    i0 = a_tmp->size[0];
    a_tmp->size[0] = r2->size[1];
    emxEnsureCapacity_int32_T(a_tmp, i0);
    loop_ub = r2->size[1];
    for (i0 = 0; i0 < loop_ub; i0++) {
      a_tmp->data[i0] = r2->data[i0];
    }

    loop_ub = X->size[0];
    i0 = a->size[0] * a->size[1];
    a->size[0] = loop_ub;
    a->size[1] = a_tmp->size[0];
    emxEnsureCapacity_real_T(a, i0);
    nx = a_tmp->size[0];
    for (i0 = 0; i0 < nx; i0++) {
      for (i1 = 0; i1 < loop_ub; i1++) {
        a->data[i1 + a->size[0] * i0] = X->data[i1 + X->size[0] * (a_tmp->
          data[i0] - 1)];
      }
    }

    i0 = b->size[0];
    b->size[0] = a_tmp->size[0];
    emxEnsureCapacity_real_T(b, i0);
    loop_ub = a_tmp->size[0];
    for (i0 = 0; i0 < loop_ub; i0++) {
      b->data[i0] = bet_vec->data[a_tmp->data[i0] - 1];
    }

    if (a_tmp->size[0] == 1) {
      i0 = XB->size[0];
      XB->size[0] = a->size[0];
      emxEnsureCapacity_real_T(XB, i0);
      loop_ub = a->size[0];
      for (i0 = 0; i0 < loop_ub; i0++) {
        XB->data[i0] = 0.0;
        nx = a->size[1];
        for (i1 = 0; i1 < nx; i1++) {
          XB->data[i0] += a->data[i0 + a->size[0] * i1] * b->data[i1];
        }
      }
    } else {
      i0 = X->size[0];
      if ((i0 == 0) || (a_tmp->size[0] == 0) || (a_tmp->size[0] == 0)) {
        loop_ub = X->size[0];
        i0 = XB->size[0];
        XB->size[0] = loop_ub;
        emxEnsureCapacity_real_T(XB, i0);
        for (i0 = 0; i0 < loop_ub; i0++) {
          XB->data[i0] = 0.0;
        }
      } else {
        slc = 1.0;
        beta1 = 0.0;
        i0 = X->size[0];
        m_t = (ptrdiff_t)i0;
        n_t = (ptrdiff_t)1;
        k_t = (ptrdiff_t)a_tmp->size[0];
        i0 = X->size[0];
        lda_t = (ptrdiff_t)i0;
        ldb_t = (ptrdiff_t)a_tmp->size[0];
        i0 = X->size[0];
        ldc_t = (ptrdiff_t)i0;
        i0 = X->size[0];
        i1 = XB->size[0];
        XB->size[0] = i0;
        emxEnsureCapacity_real_T(XB, i1);
        TRANSA = 'N';
        TRANSB = 'N';
        dgemm(&TRANSA, &TRANSB, &m_t, &n_t, &k_t, &slc, &a->data[0], &lda_t,
              &b->data[0], &ldb_t, &beta1, &XB->data[0], &ldc_t);
      }
    }

    /*  linear combination of inactive partion */
    /*  extract covariates in active partition */
    b_n = IDls->size[1] - 1;
    nx = 0;
    for (input_sizes_idx_1 = 0; input_sizes_idx_1 <= b_n; input_sizes_idx_1++) {
      if (IDls->data[input_sizes_idx_1]) {
        nx++;
      }
    }

    i0 = r3->size[0] * r3->size[1];
    r3->size[0] = 1;
    r3->size[1] = nx;
    emxEnsureCapacity_int32_T(r3, i0);
    nx = 0;
    for (input_sizes_idx_1 = 0; input_sizes_idx_1 <= b_n; input_sizes_idx_1++) {
      if (IDls->data[input_sizes_idx_1]) {
        r3->data[nx] = input_sizes_idx_1 + 1;
        nx++;
      }
    }

    if (X->size[0] != 0) {
      b_n = n;
    } else if ((Xc->size[0] != 0) && (Xc->size[1] != 0)) {
      b_n = Xc->size[0];
    } else {
      i0 = X->size[0];
      i1 = a_tmp->size[0];
      a_tmp->size[0] = r3->size[1];
      emxEnsureCapacity_int32_T(a_tmp, i1);
      loop_ub = r3->size[1];
      for (i1 = 0; i1 < loop_ub; i1++) {
        a_tmp->data[i1] = r3->data[i1];
      }

      if ((i0 != 0) && (a_tmp->size[0] != 0)) {
        b_n = X->size[0];
      } else if (XB->size[0] != 0) {
        b_n = XB->size[0];
      } else {
        b_n = muIntScalarMax_sint32(n, 0);
        if (Xc->size[0] > b_n) {
          b_n = Xc->size[0];
        }

        i0 = X->size[0];
        if (i0 > b_n) {
          b_n = X->size[0];
        }
      }
    }

    empty_non_axis_sizes = (b_n == 0);
    if (empty_non_axis_sizes || (X->size[0] != 0)) {
      b_input_sizes_idx_1 = 1;
    } else {
      b_input_sizes_idx_1 = 0;
    }

    if (empty_non_axis_sizes || ((Xc->size[0] != 0) && (Xc->size[1] != 0))) {
      input_sizes_idx_1 = Xc->size[1];
    } else {
      input_sizes_idx_1 = 0;
    }

    guard1 = false;
    if (empty_non_axis_sizes) {
      guard1 = true;
    } else {
      i0 = X->size[0];
      i1 = a_tmp->size[0];
      a_tmp->size[0] = r3->size[1];
      emxEnsureCapacity_int32_T(a_tmp, i1);
      loop_ub = r3->size[1];
      for (i1 = 0; i1 < loop_ub; i1++) {
        a_tmp->data[i1] = r3->data[i1];
      }

      if ((i0 != 0) && (a_tmp->size[0] != 0)) {
        guard1 = true;
      } else {
        d_input_sizes_idx_1 = 0;
      }
    }

    if (guard1) {
      i0 = a_tmp->size[0];
      a_tmp->size[0] = r3->size[1];
      emxEnsureCapacity_int32_T(a_tmp, i0);
      loop_ub = r3->size[1];
      for (i0 = 0; i0 < loop_ub; i0++) {
        a_tmp->data[i0] = r3->data[i0];
      }

      d_input_sizes_idx_1 = a_tmp->size[0];
    }

    if (empty_non_axis_sizes || (XB->size[0] != 0)) {
      c_input_sizes_idx_1 = 1;
    } else {
      c_input_sizes_idx_1 = 0;
    }

    /* make room for intercept term */
    i0 = coefs->size[0];
    coefs->size[0] = Y->size[0];
    emxEnsureCapacity_real_T(coefs, i0);
    loop_ub = Y->size[0];
    for (i0 = 0; i0 < loop_ub; i0++) {
      coefs->data[i0] = Y->data[i0];
    }

    loop_ub = X->size[0];
    i0 = a->size[0] * a->size[1];
    a->size[0] = loop_ub;
    a->size[1] = r3->size[1];
    emxEnsureCapacity_real_T(a, i0);
    nx = r3->size[1];
    for (i0 = 0; i0 < nx; i0++) {
      for (i1 = 0; i1 < loop_ub; i1++) {
        a->data[i1 + a->size[0] * i0] = X->data[i1 + X->size[0] * (r3->data[i0]
          - 1)];
      }
    }

    i0 = r5->size[0] * r5->size[1];
    r5->size[0] = b_n;
    r5->size[1] = ((b_input_sizes_idx_1 + input_sizes_idx_1) +
                   d_input_sizes_idx_1) + c_input_sizes_idx_1;
    emxEnsureCapacity_real_T(r5, i0);
    loop_ub = b_input_sizes_idx_1;
    for (i0 = 0; i0 < loop_ub; i0++) {
      for (i1 = 0; i1 < b_n; i1++) {
        r5->data[i1] = 1.0;
      }
    }

    for (i0 = 0; i0 < input_sizes_idx_1; i0++) {
      for (i1 = 0; i1 < b_n; i1++) {
        r5->data[i1 + r5->size[0] * (i0 + b_input_sizes_idx_1)] = Xc->data[i1 +
          b_n * i0];
      }
    }

    for (i0 = 0; i0 < d_input_sizes_idx_1; i0++) {
      for (i1 = 0; i1 < b_n; i1++) {
        r5->data[i1 + r5->size[0] * ((i0 + b_input_sizes_idx_1) +
          input_sizes_idx_1)] = a->data[i1 + b_n * i0];
      }
    }

    loop_ub = c_input_sizes_idx_1;
    for (i0 = 0; i0 < loop_ub; i0++) {
      for (i1 = 0; i1 < b_n; i1++) {
        r5->data[i1 + r5->size[0] * ((b_input_sizes_idx_1 + input_sizes_idx_1) +
          d_input_sizes_idx_1)] = XB->data[i1];
      }
    }

    b_mldivide(r5, coefs);

    /* compute coefficients */
    /* sprintf('iter = %.0f ',l) */
    /*      %% print progress */
    if (b_mod(l, frql) != 0UL) {
      if ((real_T)lXc + 2.0 > (real_T)coefs->size[0] - 1.0) {
        i0 = 1;
      } else {
        i0 = (int32_T)(lXc + 2U);
      }

      b_n = IDls->size[1];
      nx = -1;
      for (input_sizes_idx_1 = 0; input_sizes_idx_1 < b_n; input_sizes_idx_1++)
      {
        if (IDls->data[input_sizes_idx_1]) {
          bet_vec->data[input_sizes_idx_1] = coefs->data[i0 + nx];
          nx++;
        }
      }

      /*  update parameters */
      b_n = IDls->size[1];
      for (input_sizes_idx_1 = 0; input_sizes_idx_1 < b_n; input_sizes_idx_1++)
      {
        if (IDls->data[input_sizes_idx_1]) {
          bet_vecv->data[input_sizes_idx_1] = bet_vec->data[input_sizes_idx_1];
        }
      }

      /* update bet_vecv */
      for (i0 = 0; i0 <= lXc; i0++) {
        betc->data[i0] = coefs->data[i0];
      }

      /*  extract intercept and coefficients on Xc */
      b_n = ngIDLS->size[1] - 1;
      nx = 0;
      for (input_sizes_idx_1 = 0; input_sizes_idx_1 <= b_n; input_sizes_idx_1++)
      {
        if (ngIDLS->data[input_sizes_idx_1]) {
          nx++;
        }
      }

      i0 = r4->size[0] * r4->size[1];
      r4->size[0] = 1;
      r4->size[1] = nx;
      emxEnsureCapacity_int32_T(r4, i0);
      nx = 0;
      for (input_sizes_idx_1 = 0; input_sizes_idx_1 <= b_n; input_sizes_idx_1++)
      {
        if (ngIDLS->data[input_sizes_idx_1]) {
          r4->data[nx] = input_sizes_idx_1 + 1;
          nx++;
        }
      }

      i0 = r1->size[0] * r1->size[1];
      r1->size[0] = 1;
      r1->size[1] = r4->size[1];
      emxEnsureCapacity_real_T(r1, i0);
      slc = coefs->data[coefs->size[0] - 1];
      loop_ub = r4->size[0] * r4->size[1];
      for (i0 = 0; i0 < loop_ub; i0++) {
        r1->data[i0] = bet_vec->data[r4->data[i0] - 1] * slc;
      }

      b_n = ngIDLS->size[1];
      nx = 0;
      for (input_sizes_idx_1 = 0; input_sizes_idx_1 < b_n; input_sizes_idx_1++)
      {
        if (ngIDLS->data[input_sizes_idx_1]) {
          bet_vec->data[input_sizes_idx_1] = r1->data[nx];
          nx++;
        }
      }

      /* correction for inactive partition */
      i0 = b_bet_vecv->size[0];
      b_bet_vecv->size[0] = bet_vec->size[1];
      emxEnsureCapacity_real_T(b_bet_vecv, i0);
      loop_ub = bet_vec->size[1];
      for (i0 = 0; i0 < loop_ub; i0++) {
        b_bet_vecv->data[i0] = bet_vec->data[i0];
      }

      Xkrun(b_bet_vecv, Y, X, Xc, *k, clus, coefs, &slc);
      if (lXc + 2U > (uint32_T)coefs->size[0]) {
        i0 = -1;
      } else {
        i0 = lXc;
      }

      for (nx = 0; nx < p; nx++) {
        bet_vec->data[nx] = coefs->data[i0 + (int32_T)clus->data[nx]];

        /* update betas with deltas */
      }

      beta1 = n;
      b_log(&beta1);
      if (muDoubleScalarIsNaN(beta1) || (beta1 <= 0.0)) {
        yint = 0UL;
      } else {
        yd = frexp(beta1, &b_ex_t);
        if ((int16_T)b_ex_t <= -64) {
          yint = 0UL;
        } else {
          yint = (uint64_T)muDoubleScalarRound(yd * 9.007199254740992E+15);
          b_y1 = yint >> 32;
          b_y0 = yint & 4294967295UL;
          if (*k == 0UL) {
            yint = 0UL;
          } else if (muDoubleScalarIsInf(beta1)) {
            yint = MAX_uint64_T;
          } else if ((int16_T)((int16_T)b_ex_t - 53) > 64) {
            yint = MAX_uint64_T;
          } else {
            n1 = *k >> 32;
            yint = *k & 4294967295UL;
            ldword = yint * b_y0;
            temp0 = yint * b_y1;
            yint = n1 * b_y0;
            temp = ((temp0 & 4294967295UL) + (ldword >> 32)) + (yint
              & 4294967295UL);
            ldword = (ldword & 4294967295UL) + (temp << 32);
            yint = ((n1 * b_y1 + (temp0 >> 32)) + (yint >> 32)) + (temp >> 32);
            if ((int16_T)((int16_T)b_ex_t - 53) >= 0) {
              if (yint > 0UL) {
                yint = MAX_uint64_T;
              } else if ((ldword >> (uint8_T)((int16_T)b_ex_t - 117)) > 0UL) {
                yint = MAX_uint64_T;
              } else {
                yint = ldword << (uint8_T)((int16_T)b_ex_t - 53);
              }
            } else if ((int16_T)((int16_T)b_ex_t - 53) >= -64) {
              if ((yint >> (uint8_T)(53 - (int16_T)b_ex_t)) > 0UL) {
                yint = MAX_uint64_T;
              } else {
                yint = ((ldword >> (uint8_T)(53 - (int16_T)b_ex_t)) + (yint <<
                         (uint8_T)((int16_T)b_ex_t + 11))) + (ldword >> (uint8_T)
                  (52 - (int16_T)b_ex_t) & 1UL);
              }
            } else {
              yint = (yint >> (uint8_T)-(int16_T)((int16_T)b_ex_t + 11)) + (yint
                >> (uint8_T)-(int16_T)((int16_T)b_ex_t + 12) & 1UL);
            }
          }
        }
      }

      slc /= (real_T)n;
      b_log(&slc);
      val1 = (real_T)eml_i64dplus(yint, (real_T)n * slc);

      /* compute BIC */
    } else {
      /* sprintf('iter = %.0f fval = %f and dev = %f',l,val1,dev) */
      b_sprintf(l, val1, dev);

      /* sprintf('fval = %f and dev = %f',val1,dev) */
      i0 = b_bet_vecv->size[0];
      b_bet_vecv->size[0] = bet_vecv->size[1];
      emxEnsureCapacity_real_T(b_bet_vecv, i0);
      loop_ub = bet_vecv->size[1];
      for (i0 = 0; i0 < loop_ub; i0++) {
        b_bet_vecv->data[i0] = bet_vecv->data[i0];
      }

      goldssopt(b_bet_vecv, Y, X, Xc, kmin, kmax, k, clus, coefs, &val1);
      for (i0 = 0; i0 <= lXc; i0++) {
        betc->data[i0] = coefs->data[i0];
      }

      /*  extract intercept and coefficients on Xc */
      if (lXc + 2U > (uint32_T)coefs->size[0]) {
        i0 = -1;
      } else {
        i0 = lXc;
      }

      for (nx = 0; nx < p; nx++) {
        bet_vec->data[nx] = coefs->data[i0 + (int32_T)clus->data[nx]];

        /* update betas with deltas */
      }
    }

    /* end if */
    dev = (val0 - val1) / (1.0E-20 + muDoubleScalarAbs(val0));

    /*      %% 3 check for convergence */
    if (dev <= 1.0E-6) {
      exitg2 = 1;
    } else {
      /*      %% 4 update value */
      val0 = val1;
    }
  } while (exitg2 == 0);

  emxFree_real_T(&b_bet_vecv);
  emxFree_real_T(&r5);
  emxFree_int32_T(&a_tmp);
  emxFree_real_T(&b);
  emxFree_real_T(&a);
  emxFree_int32_T(&r4);
  emxFree_int32_T(&r3);
  emxFree_int32_T(&r2);
  emxFree_real_T(&r1);
  emxFree_real_T(&coefs);
  emxFree_real_T(&XB);
  emxFree_boolean_T(&ngIDLS);
  emxFree_boolean_T(&IDls);
  emxFree_real_T(&lcls);
  emxFree_real_T(&bet_vecv);

  /*  end while */
  i0 = betas->size[0] * betas->size[1];
  betas->size[0] = 1;
  betas->size[1] = betc->size[1] + bet_vec->size[1];
  emxEnsureCapacity_real_T(betas, i0);
  loop_ub = betc->size[1];
  for (i0 = 0; i0 < loop_ub; i0++) {
    betas->data[i0] = betc->data[i0];
  }

  loop_ub = bet_vec->size[1];
  for (i0 = 0; i0 < loop_ub; i0++) {
    betas->data[i0 + betc->size[1]] = bet_vec->data[i0];
  }

  emxFree_real_T(&betc);
  emxFree_real_T(&bet_vec);

  /* concatenate final parameter estimates */
  /*  end function */
  emlrtHeapReferenceStackLeaveFcnR2012b(emlrtRootTLSGlobal);
}

uint64_T eml_i64dplus(uint64_T x, real_T y)
{
  uint64_T z;
  real_T roundedy;
  roundedy = muDoubleScalarRound(y);
  if (y >= 0.0) {
    if (y < 1.8446744073709552E+19) {
      z = x + (uint64_T)roundedy;
    } else {
      z = MAX_uint64_T;
    }
  } else if (y < 0.0) {
    if (-y < 1.8446744073709552E+19) {
      if (y - roundedy == 0.5) {
        z = x - (uint64_T)muDoubleScalarFloor(-y);
      } else {
        z = x - (uint64_T)muDoubleScalarRound(-y);
      }
    } else {
      z = 0UL;
    }
  } else {
    z = 0UL;
  }

  return z;
}

/* End of code generation (CCRl_clus.c) */
