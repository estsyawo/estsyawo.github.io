function [optk,clus,bets,BIC] = goldsscoord3(Y,X,nC,a,b)
%% Golden Section Search for coordinate descent linear reg
tol = 1;
[nd,p] = size(X); n = double(nd);
Xdot = zeros(1,p);
clus = zeros(1,p);
bets= zeros(1,p);
cnt = 0; %counter
%% initialise parameters
X0 = ones(n,2); % for the initialisation of coefficients
for j=2:p %intercept initialised at zero
   X0(:,2) = X(:,j); 
   coef0 = X0\Y;
   bets(j) = coef0(2) ;
   Xdot(1,j) = dot(X(:,j),X(:,j)); %sum of squared X[,j]
end
Xdot(1,1) = n; %sum of squared X[,1] (intercept)

%% begin golden section search optimisation for k

gr = (sqrt(5) + 1) / 2;
f = @(k,bets) cordlinopt_clus3(Y,X,k,nC,bets,Xdot,clus); %define function in k
    
    c = ceil(b - (b - a) / gr); 
    d = floor(a + (b - a) / gr);
    
    [bets_d,clus_d, RSS_d] = f(d,bets); fd = n*log(RSS_d/n) + d*log(n);
    cnt=cnt+1; %print
    fprintf('\n Outer iter = %u, k = %u, BIC = %0.5f \n',uint64(cnt),uint64(c),double(fd))
    
    [bets_c,clus_c, RSS_c] = f(c,bets_d); fc = n*log(RSS_c/n) + c*log(n);
    cnt=cnt+1; %print
    fprintf('\n Outer iter = %u, k = %u, BIC = %0.5f \n',uint64(cnt),uint64(c),double(fc))
    
    if fc<=fd
      optk=c;bets=bets_c; BIC = fc; clus = clus_c;
    else
       optk=d;bets = bets_d; BIC = fd; clus = clus_d;
    end % end if
    
    %% begin while loop
    while abs(c - d) > tol
        if fc <= fd
            b = d;
        else
            a = c;
        end % end if
         
    c = ceil(b - (b - a) / gr);
    d = floor(a + (b - a) / gr); 
    [bets_c,clus_c, RSS_c] = f(c,bets_d); fc = n*log(RSS_c/n) + c*log(n);
    cnt=cnt+1; %print
    fprintf('\n Outer iter = %u, k = %u, BIC = %0.5f \n',uint64(cnt),uint64(c),double(fc))
    [bets_d,clus_d, RSS_d] = f(d,bets_c); fd = n*log(RSS_d/n) + d*log(n);
    cnt=cnt+1; %print
    fprintf('\n Outer iter = %u, k = %u, BIC = %0.5f \n',uint64(cnt),uint64(c),double(fd))

    if(fc<BIC)
       optk=c;bets=bets_c; BIC = fc; clus = clus_c; 
    end
    if(fd<BIC)
       optk=d;bets=bets_d; BIC = fd; clus = clus_d; 
    end
    
    end %end while loop
    
end