#===============================================================================
# Author: Feiyu Jiang & Emmanuel Selorm Tsyawo
# Project: A Consistent ICM-based X2 Specification Test
# Date began:   Feb 03, 2022
# Last Update:  Nov 12, 2025
# Place:        Shanghai & Tuscaloosa  
#===============================================================================
# Load packages, clear memory,
rm(list=ls())
library(MASS)
library(parallel)
library(pbapply)
#install from github using devtools::install_github("estsyawo/estrpac")
library(estrpac)
library(latex2exp)
library(ggplot2)
#set working directory path to source file
#setwd(dirname(rstudioapi::getActiveDocumentContext()$path)) 
project_dir <- normalizePath(getwd())
output_dir <- file.path(project_dir, "output")
if (!dir.exists(output_dir)) dir.create(output_dir, recursive = TRUE)
source("JT05_Fonctions.R")
list.files()
#===============================================================================
#Notes: 
# 1. Running time: 
# 2. Peak RAM usage: 
#===============================================================================

#===============================================================================
# Comments: 
# Computes the size and power of the pivotal chi-squared test of mean
# independence compared to the bootstrap-based GMDD tests of mean independence
# based on different kernels: Gaussian, MDD, and Esc6.
#===============================================================================
#Parameters:
R = 1000 # set number of Monte Carlo samples
B=999 # number of wild bootstrap samples
levls = c(0.10,0.05,0.01) #nominal levels of the test
nvec=c(200,400,600,800) #sample sizes
gamvec=seq(0,1,by=0.2) #tuning the deviation away from the null hypothesis
(Sig = 0.25^as.matrix(dist(1:2))) #covariance matrix for generating predictors
cl = floor(2*detectCores()/3) #number of cores to use in parallel computation
#===============================================================================


#===============================================================================
start.time<- Sys.time()
#===============================================================================


#===============================================================================
# DGP MI 6 - sensitivity to the dimension of V

cat("Compute Power Curve - DGP MI 6 - sensitivity to dimension of V \n ")

gdat6<- function(gam,n=nvec[2]){
  datl=list()
  for (l in 1:R) {
    set.seed(l) #generate seed
    Z = rnorm(n)
    Eps = runif(n,min = -sqrt(3),max = sqrt(3))
    Y = 1 + gam*(exp(-Z^2/3) - sqrt(3/5))/0.233 + Eps
    datl[[l]]<- data.frame(Y,Z)
  }
  datl
}

MCOBJ_6=list(); wmat=wmat.mammen(nvec[2],B, seed = 1)


for (l in 1:length(gamvec)) {
  datl =gdat6(gam=gamvec[l])
  MCOBJ_6[[l]]=pbsapply(1:R,MCfun4.MI,datl=datl,wmat=wmat,cl=cl)
  cat("At gam = ",gamvec[l],"\n")
  print(apply(MCOBJ_6[[l]],1,mean)); cat("\n")
}
#===============================================================================


#===============================================================================
# DGP MI 7 - robustness of tuning rule for regularized inverse 
# n^{-2/5,-1/3,1/4,1/6}

cat("Compute Power Curve - DGP MI 7 - robustness of tuning rule for 
    regularized inverse \n ")

gdat7<- function(gam=0.0,n=nvec[2]){
  datl=list()
  for (l in 1:R) {
    set.seed(l) #generate seed
    Z = rnorm(n)
    Eps = runif(n,min = -sqrt(3),max = sqrt(3))
    Y = 1 + gam*(Z^2)/sqrt(2) + Eps
    datl[[l]]<- data.frame(Y,Z)
  }
  datl
}

MCOBJ_7=list()
for (l in 1:length(gamvec)) {
  datl =gdat7(gam=gamvec[l])
  MCOBJ_7[[l]]=pbsapply(1:R,MCfun5.MI,datl=datl,wmat=wmat,cl=cl)
  cat("At gam = ",gamvec[l],"\n")
  print(apply(MCOBJ_7[[l]],1,mean)); cat("\n")
}
#===============================================================================


#===============================================================================
# DGP MI 6 - robustness of tuning rule for regularized inverse 
# n^{-2/5,-1/3,1/4,1/6}, SVD criteria added

cat("Compute Power Curve - DGP MI 6 - robustness to tuning parameter cn and 
    other SVD selection criteria \n ")

MCOBJ_6a=list()
for (l in 1:length(gamvec)) {
  datl =gdat6(gam=gamvec[l])
  MCOBJ_6a[[l]]=pbsapply(1:R,MCfun6.MI,datl=datl,wmat=wmat,cl=cl)
  cat("At gam = ",gamvec[l],"\n")
  print(apply(MCOBJ_6a[[l]],1,mean)); cat("\n")
}
#===============================================================================


#===============================================================================
# DGP MI 6* - test of joint nullity with comparison
# using
# DGP 7 - robustness of tuning rule for regularized inverse 
# n^{-2/5,-1/3,1/4,1/6}

cat("Compute Power Curve - DGP MI 6* - test of nullity E[U|Z]=E[U]=0 a.s. \n ")


gdat6star<- function(gam,n=nvec[2],d1=1,d2=1){
  datl=list()
  for (l in 1:R) {
    set.seed(l) #generate seed
    Z = rnorm(n)
    Eps = runif(n,min = -sqrt(3),max = sqrt(3))
    Y = gam*(d1*exp(-Z^2/3) - d2*sqrt(3/5))/0.5 + Eps
    datl[[l]]<- data.frame(Y,Z)
  }
  datl
}

cat("Compute Power Curve - DGP MI 6* - with E[U]=!0 a.s. \n ")

MCOBJ_6b=list()
for (l in 1:length(gamvec)) {
  datl =gdat6star(gam=gamvec[l],d1=0.0,d2=-1)
  MCOBJ_6b[[l]]=pbsapply(1:R,MCfun5star.MI,datl=datl,wmat=wmat,cl=cl)
  cat("At gam = ",gamvec[l],"\n")
  print(apply(MCOBJ_6b[[l]],1,mean)); cat("\n")
}
#-------------------------------------------------------------------------------

cat("Compute Power Curve - DGP MI 6* - with E[U|Z]=!E[U] a.s. \n ")

MCOBJ_6c=list()
for (l in 1:length(gamvec)) {
  datl =gdat6star(gam=gamvec[l],d2=0.0)
  MCOBJ_6c[[l]]=pbsapply(1:R,MCfun5star.MI,datl=datl,wmat=wmat,cl=cl)
  cat("At gam = ",gamvec[l],"\n")
  print(apply(MCOBJ_6c[[l]],1,mean)); cat("\n")
}

#===============================================================================


#===============================================================================
# Write out results for Tex tables
n.test<- 4 #number of tests being compared
n.levels<- length(levls)#number of significance levels being considered

#column ids for empirical size at significance levels 0.1,0.05, and 0.01
id.10 = 1+(0:(n.test-1))*n.levels; id.05 = 2+(0:(n.test-1))*n.levels
id.01 = 3+(0:(n.test-1))*n.levels

#column ids for computational times in seconds
Ts<- c(n.test*n.levels+1, n.test*n.levels + 2 + (0:(n.test-2))*2)
#column ids for computational times relative to the t-test
Trel<- n.test*n.levels+1 + (1:(n.test-1))*2
#--------------------------------------------

#print results for power performance by tuning cn
sink(file.path(output_dir, "tab.pow.MI_7.txt")) #print to file
print.tab(MCOBJ=MCOBJ_7,id.10=id.10,id.05=id.05,id.01=id.01,vec=gamvec)
sink()

sink(file.path(output_dir, "tab.pow.MI_6b.txt")) #print to file
print.tab(MCOBJ=MCOBJ_6b,id.10=id.10,id.05=id.05,id.01=id.01,vec=gamvec)
sink()

sink(file.path(output_dir, "tab.pow.MI_6c.txt")) #print to file
print.tab(MCOBJ=MCOBJ_6c,id.10=id.10,id.05=id.05,id.01=id.01,vec=gamvec)
sink()


#print results for power performance by dim(V)
n.test6<- 11

id6.10 = 1+(0:(n.test6-1))*n.levels
id6.05 = 2+(0:(n.test6-1))*n.levels
id6.01 = 3+(0:(n.test6-1))*n.levels

sink(file.path(output_dir, "tab.pow.MI_6.txt")) #print to file
print.tab(MCOBJ=MCOBJ_6,id.10=id6.10,id.05=id6.05,id.01=id6.01,vec=gamvec)
sink()

sink(file.path(output_dir, "tab.pow.MI_6a.txt")) #print to file
print.tab(MCOBJ=MCOBJ_6a,id.10=id6.10,id.05=id6.05,id.01=id6.01,vec=gamvec)
sink()

#===============================================================================

cat("See the output folder for output tables and plots \n ")

#===============================================================================
end.time<- Sys.time()
print(end.time-start.time) #Time difference of 1.753972 hours
#===============================================================================
