				*** ReadME file ***
** R files
1. Main_file.R: This is the main file that produces all simulation results in the paper.

2.a. Application_Gas_Price_Elasticity.R: This file computes empirical results for the price elasticity of demand.

2.b. Application_Gas_Income_Elasticity.R: This file computes empirical results for the income elasticity of demand.

3. Funktionen.R: This is the file containing all supplementary functions (not available in the packages) that are used in simulations and empirical analyses.

4. gasoline_final_tf1.csv: This is the data file for the empirical application

** Output files			

* The following files contain the box plots
fig.box_CaS1.bias.pdf
fig.box_CaS1.k.pdf
fig.box_CaS1.nbias.pdf

fig.box_CaS2.bias.pdf
fig.box_CaS2.k.pdf
fig.box_CaS2.nbias.pdf

fig.box_CnS.bias.pdf
fig.box_CnS.k.pdf
fig.box_CnS.nbias.pdf

fig.box_D_S1.bias.pdf
fig.box_D_S1.k.pdf
fig.box_D_S1.nbias.pdf

* The following files contain the plots of power curves
fig.pow_CaS1.pdf
fig.pow_CaS2.pdf
fig.pow_CnS.pdf
fig.pow_D_S1.pdf

* The following files contain output pasted into the LaTeX tables
Out_1.Cns.txt
Out_2.CaS1.txt
Out_3.CaS2.txt
Out_4.D_S1.txt
Out_5.MnS.txt
Out_6.M_S.txt
Out_7.DnS.txt
Out_8.D_S2.txt
Out_9.DaS2.txt

* The following files contain the plots of in the empirical application
Income_Elasticity_Age.pdf
Price_Elasticity_Age.pdf
