/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * mldivide.c
 *
 * Code generation for function 'mldivide'
 *
 */

/* Include files */
#include "mwmathutil.h"
#include "rt_nonfinite.h"
#include "goldsscoord3.h"
#include "mldivide.h"
#include "warning.h"
#include "qrsolve.h"

/* Variable Definitions */
static emlrtRSInfo k_emlrtRSI = { 34,  /* lineNo */
  "mldivide",                          /* fcnName */
  "/usr/local/MATLAB/R2018b/toolbox/eml/lib/matlab/ops/mldivide.m"/* pathName */
};

static emlrtRSInfo l_emlrtRSI = { 36,  /* lineNo */
  "mldivide",                          /* fcnName */
  "/usr/local/MATLAB/R2018b/toolbox/eml/lib/matlab/ops/mldivide.m"/* pathName */
};

static emlrtRSInfo m_emlrtRSI = { 55,  /* lineNo */
  "lusolve",                           /* fcnName */
  "/usr/local/MATLAB/R2018b/toolbox/eml/eml/+coder/+internal/lusolve.m"/* pathName */
};

static emlrtRSInfo n_emlrtRSI = { 210, /* lineNo */
  "lusolve",                           /* fcnName */
  "/usr/local/MATLAB/R2018b/toolbox/eml/eml/+coder/+internal/lusolve.m"/* pathName */
};

static emlrtRSInfo o_emlrtRSI = { 90,  /* lineNo */
  "lusolve",                           /* fcnName */
  "/usr/local/MATLAB/R2018b/toolbox/eml/eml/+coder/+internal/lusolve.m"/* pathName */
};

static emlrtRTEInfo sd_emlrtRTEI = { 18,/* lineNo */
  15,                                  /* colNo */
  "mldivide",                          /* fName */
  "/usr/local/MATLAB/R2018b/toolbox/eml/lib/matlab/ops/mldivide.m"/* pName */
};

/* Function Definitions */
void mldivide(const emlrtStack *sp, const emxArray_real_T *A, const
              emxArray_real_T *B, real_T Y[2])
{
  int32_T r1;
  int32_T r2;
  real_T a21;
  real_T a22;
  emlrtStack st;
  emlrtStack b_st;
  emlrtStack c_st;
  emlrtStack d_st;
  st.prev = sp;
  st.tls = sp->tls;
  b_st.prev = &st;
  b_st.tls = st.tls;
  c_st.prev = &b_st;
  c_st.tls = b_st.tls;
  d_st.prev = &c_st;
  d_st.tls = c_st.tls;
  if (B->size[0] != A->size[0]) {
    emlrtErrorWithMessageIdR2018a(sp, &sd_emlrtRTEI, "Coder:MATLAB:dimagree",
      "Coder:MATLAB:dimagree", 0);
  }

  if ((A->size[0] == 0) || (B->size[0] == 0)) {
    Y[0] = 0.0;
    Y[1] = 0.0;
  } else if (A->size[0] == 2) {
    st.site = &k_emlrtRSI;
    b_st.site = &m_emlrtRSI;
    if (muDoubleScalarAbs(A->data[1]) > muDoubleScalarAbs(A->data[0])) {
      r1 = 1;
      r2 = 0;
    } else {
      r1 = 0;
      r2 = 1;
    }

    a21 = A->data[r2] / A->data[r1];
    a22 = A->data[r2 + A->size[0]] - a21 * A->data[r1 + A->size[0]];
    if ((a22 == 0.0) || (A->data[r1] == 0.0)) {
      c_st.site = &n_emlrtRSI;
      d_st.site = &o_emlrtRSI;
      warning(&d_st);
    }

    Y[1] = (B->data[r2] - B->data[r1] * a21) / a22;
    Y[0] = (B->data[r1] - Y[1] * A->data[r1 + A->size[0]]) / A->data[r1];
  } else {
    st.site = &l_emlrtRSI;
    qrsolve(&st, A, B, Y);
  }
}

/* End of code generation (mldivide.c) */
