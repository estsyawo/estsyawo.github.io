/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 * File: CCRls2_terminate.c
 *
 * MATLAB Coder version            : 4.1
 * C/C++ source code generated on  : 23-Nov-2018 17:24:14
 */

/* Include Files */
#include "CCRls2.h"
#include "CCRls2_terminate.h"

/* Function Definitions */

/*
 * Arguments    : void
 * Return Type  : void
 */
void CCRls2_terminate(void)
{
  /* (no terminate code required) */
}

/*
 * File trailer for CCRls2_terminate.c
 *
 * [EOF]
 */
