/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * _coder_CCRls2_api.c
 *
 * Code generation for function '_coder_CCRls2_api'
 *
 */

/* Include files */
#include "rt_nonfinite.h"
#include "CCRls2.h"
#include "_coder_CCRls2_api.h"
#include "CCRls2_emxutil.h"
#include "CCRls2_data.h"

/* Function Declarations */
static real_T (*b_emlrt_marshallIn(const mxArray *u, const emlrtMsgIdentifier
  *parentId))[1000];
static real_T (*c_emlrt_marshallIn(const mxArray *Xv, const char_T *identifier))
  [20000000];
static real_T (*d_emlrt_marshallIn(const mxArray *u, const emlrtMsgIdentifier
  *parentId))[20000000];
static uint32_T e_emlrt_marshallIn(const mxArray *n, const char_T *identifier);
static real_T (*emlrt_marshallIn(const mxArray *Y, const char_T *identifier))
  [1000];
static const mxArray *emlrt_marshallOut(const emxArray_real_T *u);
static uint32_T f_emlrt_marshallIn(const mxArray *u, const emlrtMsgIdentifier
  *parentId);
static real_T (*g_emlrt_marshallIn(const mxArray *src, const emlrtMsgIdentifier *
  msgId))[1000];
static real_T (*h_emlrt_marshallIn(const mxArray *src, const emlrtMsgIdentifier *
  msgId))[20000000];
static uint32_T i_emlrt_marshallIn(const mxArray *src, const emlrtMsgIdentifier *
  msgId);

/* Function Definitions */
static real_T (*b_emlrt_marshallIn(const mxArray *u, const emlrtMsgIdentifier
  *parentId))[1000]
{
  real_T (*y)[1000];
  y = g_emlrt_marshallIn(emlrtAlias(u), parentId);
  emlrtDestroyArray(&u);
  return y;
}
  static real_T (*c_emlrt_marshallIn(const mxArray *Xv, const char_T *identifier))
  [20000000]
{
  real_T (*y)[20000000];
  emlrtMsgIdentifier thisId;
  thisId.fIdentifier = (const char *)identifier;
  thisId.fParent = NULL;
  thisId.bParentIsCell = false;
  y = d_emlrt_marshallIn(emlrtAlias(Xv), &thisId);
  emlrtDestroyArray(&Xv);
  return y;
}

static real_T (*d_emlrt_marshallIn(const mxArray *u, const emlrtMsgIdentifier
  *parentId))[20000000]
{
  real_T (*y)[20000000];
  y = h_emlrt_marshallIn(emlrtAlias(u), parentId);
  emlrtDestroyArray(&u);
  return y;
}
  static uint32_T e_emlrt_marshallIn(const mxArray *n, const char_T *identifier)
{
  uint32_T y;
  emlrtMsgIdentifier thisId;
  thisId.fIdentifier = (const char *)identifier;
  thisId.fParent = NULL;
  thisId.bParentIsCell = false;
  y = f_emlrt_marshallIn(emlrtAlias(n), &thisId);
  emlrtDestroyArray(&n);
  return y;
}

static real_T (*emlrt_marshallIn(const mxArray *Y, const char_T *identifier))
  [1000]
{
  real_T (*y)[1000];
  emlrtMsgIdentifier thisId;
  thisId.fIdentifier = (const char *)identifier;
  thisId.fParent = NULL;
  thisId.bParentIsCell = false;
  y = b_emlrt_marshallIn(emlrtAlias(Y), &thisId);
  emlrtDestroyArray(&Y);
  return y;
}
  static const mxArray *emlrt_marshallOut(const emxArray_real_T *u)
{
  const mxArray *y;
  const mxArray *m0;
  static const int32_T iv0[2] = { 0, 0 };

  y = NULL;
  m0 = emlrtCreateNumericArray(2, iv0, mxDOUBLE_CLASS, mxREAL);
  emlrtMxSetData((mxArray *)m0, &u->data[0]);
  emlrtSetDimensions((mxArray *)m0, u->size, 2);
  emlrtAssign(&y, m0);
  return y;
}

static uint32_T f_emlrt_marshallIn(const mxArray *u, const emlrtMsgIdentifier
  *parentId)
{
  uint32_T y;
  y = i_emlrt_marshallIn(emlrtAlias(u), parentId);
  emlrtDestroyArray(&u);
  return y;
}

static real_T (*g_emlrt_marshallIn(const mxArray *src, const emlrtMsgIdentifier *
  msgId))[1000]
{
  real_T (*ret)[1000];
  static const int32_T dims[1] = { 1000 };

  emlrtCheckBuiltInR2012b(emlrtRootTLSGlobal, msgId, src, "double", false, 1U,
    dims);
  ret = (real_T (*)[1000])emlrtMxGetData(src);
  emlrtDestroyArray(&src);
  return ret;
}
  static real_T (*h_emlrt_marshallIn(const mxArray *src, const
  emlrtMsgIdentifier *msgId))[20000000]
{
  real_T (*ret)[20000000];
  static const int32_T dims[1] = { 20000000 };

  emlrtCheckBuiltInR2012b(emlrtRootTLSGlobal, msgId, src, "double", false, 1U,
    dims);
  ret = (real_T (*)[20000000])emlrtMxGetData(src);
  emlrtDestroyArray(&src);
  return ret;
}

static uint32_T i_emlrt_marshallIn(const mxArray *src, const emlrtMsgIdentifier *
  msgId)
{
  uint32_T ret;
  static const int32_T dims = 0;
  emlrtCheckBuiltInR2012b(emlrtRootTLSGlobal, msgId, src, "uint32", false, 0U,
    &dims);
  ret = *(uint32_T *)emlrtMxGetData(src);
  emlrtDestroyArray(&src);
  return ret;
}

void CCRls2_api(const mxArray * const prhs[4], int32_T nlhs, const mxArray *
                plhs[1])
{
  emxArray_real_T *betas;
  real_T (*Y)[1000];
  real_T (*Xv)[20000000];
  uint32_T n;
  uint32_T p;
  (void)nlhs;
  emlrtHeapReferenceStackEnterFcnR2012b(emlrtRootTLSGlobal);
  emxInit_real_T(&betas, 2, true);

  /* Marshall function inputs */
  Y = emlrt_marshallIn(emlrtAlias(prhs[0]), "Y");
  Xv = c_emlrt_marshallIn(emlrtAlias(prhs[1]), "Xv");
  n = e_emlrt_marshallIn(emlrtAliasP(prhs[2]), "n");
  p = e_emlrt_marshallIn(emlrtAliasP(prhs[3]), "p");

  /* Invoke the target function */
  CCRls2(*Y, *Xv, n, p, betas);

  /* Marshall function outputs */
  betas->canFreeData = false;
  plhs[0] = emlrt_marshallOut(betas);
  emxFree_real_T(&betas);
  emlrtHeapReferenceStackLeaveFcnR2012b(emlrtRootTLSGlobal);
}

/* End of code generation (_coder_CCRls2_api.c) */
