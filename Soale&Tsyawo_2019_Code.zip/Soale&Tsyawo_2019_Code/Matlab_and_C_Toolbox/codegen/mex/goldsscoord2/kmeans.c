/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * kmeans.c
 *
 * Code generation for function 'kmeans'
 *
 */

/* Include files */
#include "mwmathutil.h"
#include "rt_nonfinite.h"
#include "goldsscoord2.h"
#include "kmeans.h"
#include "goldsscoord2_emxutil.h"
#include "rand.h"
#include "goldsscoord2_data.h"

/* Function Declarations */
static void batchUpdate(const emxArray_real_T *X, int32_T k, emxArray_int32_T
  *idx, emxArray_real_T *C, emxArray_real_T *D, emxArray_int32_T *counts,
  boolean_T *converged, int32_T *iter);
static void distfun(emxArray_real_T *D, const emxArray_real_T *X, const
                    emxArray_real_T *C, const emxArray_int32_T *crows, int32_T
                    ncrows);
static void gcentroids(emxArray_real_T *C, emxArray_int32_T *counts, const
  emxArray_real_T *X, const emxArray_int32_T *idx, const emxArray_int32_T
  *clusters, int32_T nclusters);
static void local_kmeans(const emxArray_real_T *X, int32_T k, emxArray_int32_T
  *idxbest, emxArray_real_T *Cbest);
static void mindim2(const emxArray_real_T *D, emxArray_real_T *d,
                    emxArray_int32_T *idx);

/* Function Definitions */
static void batchUpdate(const emxArray_real_T *X, int32_T k, emxArray_int32_T
  *idx, emxArray_real_T *C, emxArray_real_T *D, emxArray_int32_T *counts,
  boolean_T *converged, int32_T *iter)
{
  emxArray_int32_T *empties;
  int32_T n;
  int32_T ei;
  emxArray_int32_T *previdx;
  int32_T lonely;
  emxArray_int32_T *moved;
  emxArray_int32_T *changed;
  int32_T j;
  int32_T nchanged;
  real_T prevtotsumD;
  emxArray_real_T *d;
  emxArray_int32_T *nidx;
  emxArray_boolean_T *b;
  int32_T exitg1;
  int32_T nempty;
  int32_T i;
  real_T maxd;
  int32_T from;
  boolean_T exitg2;
  int32_T cc;
  uint32_T unnamed_idx_0;
  emlrtHeapReferenceStackEnterFcnR2012b(emlrtRootTLSGlobal);
  emxInit_int32_T(&empties, 1, true);
  n = X->size[0] - 1;
  ei = empties->size[0];
  empties->size[0] = k;
  emxEnsureCapacity_int32_T(empties, ei);
  for (ei = 0; ei < k; ei++) {
    empties->data[ei] = 0;
  }

  emxInit_int32_T(&previdx, 1, true);
  ei = previdx->size[0];
  previdx->size[0] = X->size[0];
  emxEnsureCapacity_int32_T(previdx, ei);
  lonely = X->size[0];
  for (ei = 0; ei < lonely; ei++) {
    previdx->data[ei] = 0;
  }

  emxInit_int32_T(&moved, 1, true);
  ei = moved->size[0];
  moved->size[0] = X->size[0];
  emxEnsureCapacity_int32_T(moved, ei);
  lonely = X->size[0];
  for (ei = 0; ei < lonely; ei++) {
    moved->data[ei] = 0;
  }

  emxInit_int32_T(&changed, 1, true);
  ei = changed->size[0];
  changed->size[0] = k;
  emxEnsureCapacity_int32_T(changed, ei);
  for (j = 0; j < k; j++) {
    changed->data[j] = j + 1;
  }

  nchanged = k;
  prevtotsumD = rtInf;
  *iter = 0;
  *converged = false;
  emxInit_real_T(&d, 1, true);
  emxInit_int32_T(&nidx, 1, true);
  emxInit_boolean_T(&b, 1, true);
  do {
    exitg1 = 0;
    (*iter)++;
    gcentroids(C, counts, X, idx, changed, nchanged);
    distfun(D, X, C, changed, nchanged);
    nempty = -1;
    for (j = 0; j < nchanged; j++) {
      if (counts->data[changed->data[j] - 1] == 0) {
        nempty++;
        empties->data[nempty] = changed->data[j];
      }
    }

    if (nempty + 1 > 0) {
      for (i = 0; i <= nempty; i++) {
        ei = d->size[0];
        d->size[0] = n + 1;
        emxEnsureCapacity_real_T(d, ei);
        d->data[0] = D->data[D->size[0] * (idx->data[0] - 1)];
        maxd = d->data[0];
        lonely = 0;
        for (j = 0; j <= n; j++) {
          d->data[j] = D->data[j + D->size[0] * (idx->data[j] - 1)];
          if (d->data[j] > maxd) {
            maxd = d->data[j];
            lonely = j;
          }
        }

        from = idx->data[lonely] - 1;
        if (counts->data[idx->data[lonely] - 1] < 2) {
          j = 0;
          exitg2 = false;
          while ((!exitg2) && (j <= n)) {
            if (counts->data[j] > 1) {
              from = j;
              exitg2 = true;
            } else {
              j++;
            }
          }

          j = 0;
          exitg2 = false;
          while ((!exitg2) && (j <= n)) {
            if (idx->data[j] == from + 1) {
              lonely = j;
              exitg2 = true;
            } else {
              j++;
            }
          }
        }

        ei = empties->data[i] - 1;
        C->data[empties->data[i] - 1] = X->data[lonely];
        counts->data[empties->data[i] - 1] = 1;
        idx->data[lonely] = empties->data[i];
        lonely = X->size[0];
        for (cc = 0; cc < lonely; cc++) {
          maxd = X->data[cc] - C->data[ei];
          D->data[cc + D->size[0] * ei] = maxd * maxd;
        }

        lonely = X->size[0];
        counts->data[from] = 0;
        C->data[from] = rtNaN;
        cc = 0;
        C->data[from] = 0.0;
        for (ei = 0; ei < lonely; ei++) {
          if (idx->data[ei] == from + 1) {
            cc++;
            C->data[from] += X->data[ei];
          }
        }

        counts->data[from] = cc;
        C->data[from] /= (real_T)cc;
        lonely = X->size[0];
        for (cc = 0; cc < lonely; cc++) {
          maxd = X->data[cc] - C->data[from];
          D->data[cc + D->size[0] * from] = maxd * maxd;
        }

        if (nchanged < k) {
          j = 0;
          exitg2 = false;
          while ((!exitg2) && ((j <= nchanged - 1) && (from + 1 != changed->
                   data[j]))) {
            if (from + 1 > changed->data[j]) {
              for (lonely = nchanged; lonely >= j + 1; lonely--) {
                changed->data[lonely] = changed->data[lonely - 1];
              }

              changed->data[j] = from + 1;
              nchanged++;
              exitg2 = true;
            } else {
              j++;
            }
          }
        }
      }
    }

    maxd = 0.0;
    for (i = 0; i <= n; i++) {
      maxd += D->data[i + D->size[0] * (idx->data[i] - 1)];
    }

    if (prevtotsumD <= maxd) {
      ei = idx->size[0];
      idx->size[0] = previdx->size[0];
      emxEnsureCapacity_int32_T(idx, ei);
      lonely = previdx->size[0];
      for (ei = 0; ei < lonely; ei++) {
        idx->data[ei] = previdx->data[ei];
      }

      gcentroids(C, counts, X, previdx, changed, nchanged);
      (*iter)--;
      exitg1 = 1;
    } else if (*iter >= 100) {
      exitg1 = 1;
    } else {
      ei = previdx->size[0];
      previdx->size[0] = idx->size[0];
      emxEnsureCapacity_int32_T(previdx, ei);
      lonely = idx->size[0];
      for (ei = 0; ei < lonely; ei++) {
        previdx->data[ei] = idx->data[ei];
      }

      prevtotsumD = maxd;
      mindim2(D, d, nidx);
      cc = -1;
      for (i = 0; i <= n; i++) {
        if ((nidx->data[i] != previdx->data[i]) && (D->data[i + D->size[0] *
             (previdx->data[i] - 1)] > d->data[i])) {
          cc++;
          moved->data[cc] = i + 1;
          idx->data[i] = nidx->data[i];
        }
      }

      if (cc + 1 == 0) {
        *converged = true;
        exitg1 = 1;
      } else {
        unnamed_idx_0 = (uint32_T)moved->size[0];
        ei = b->size[0];
        b->size[0] = (int32_T)unnamed_idx_0;
        emxEnsureCapacity_boolean_T(b, ei);
        lonely = (int32_T)unnamed_idx_0;
        for (ei = 0; ei < lonely; ei++) {
          b->data[ei] = false;
        }

        for (j = 0; j <= cc; j++) {
          b->data[idx->data[moved->data[j] - 1] - 1] = true;
          b->data[previdx->data[moved->data[j] - 1] - 1] = true;
        }

        nchanged = 0;
        ei = b->size[0];
        for (j = 0; j < ei; j++) {
          if (b->data[j]) {
            nchanged++;
            changed->data[nchanged - 1] = j + 1;
          }
        }
      }
    }
  } while (exitg1 == 0);

  emxFree_boolean_T(&b);
  emxFree_int32_T(&nidx);
  emxFree_real_T(&d);
  emxFree_int32_T(&changed);
  emxFree_int32_T(&moved);
  emxFree_int32_T(&previdx);
  emxFree_int32_T(&empties);
  emlrtHeapReferenceStackLeaveFcnR2012b(emlrtRootTLSGlobal);
}

static void distfun(emxArray_real_T *D, const emxArray_real_T *X, const
                    emxArray_real_T *C, const emxArray_int32_T *crows, int32_T
                    ncrows)
{
  int32_T n;
  int32_T i;
  int32_T cr;
  int32_T r;
  real_T a;
  n = X->size[0];
  for (i = 0; i < ncrows; i++) {
    cr = crows->data[i] - 1;
    for (r = 0; r < n; r++) {
      a = X->data[r] - C->data[cr];
      D->data[r + D->size[0] * cr] = a * a;
    }
  }
}

static void gcentroids(emxArray_real_T *C, emxArray_int32_T *counts, const
  emxArray_real_T *X, const emxArray_int32_T *idx, const emxArray_int32_T
  *clusters, int32_T nclusters)
{
  int32_T n;
  int32_T ic;
  int32_T clic;
  int32_T cc;
  int32_T i;
  n = X->size[0];
  for (ic = 0; ic < nclusters; ic++) {
    counts->data[clusters->data[ic] - 1] = 0;
    C->data[clusters->data[ic] - 1] = rtNaN;
  }

  for (ic = 0; ic < nclusters; ic++) {
    clic = clusters->data[ic];
    cc = 0;
    C->data[clusters->data[ic] - 1] = 0.0;
    for (i = 0; i < n; i++) {
      if (idx->data[i] == clic) {
        cc++;
        C->data[clic - 1] += X->data[i];
      }
    }

    counts->data[clusters->data[ic] - 1] = cc;
    C->data[clusters->data[ic] - 1] /= (real_T)cc;
  }
}

static void local_kmeans(const emxArray_real_T *X, int32_T k, emxArray_int32_T
  *idxbest, emxArray_real_T *Cbest)
{
  emxArray_real_T *D;
  int32_T n;
  int32_T i2;
  int32_T b_n;
  real_T b_index;
  int32_T low_i;
  emxArray_real_T *d;
  emxArray_real_T *sampleDist;
  boolean_T DNeedsComputing;
  int32_T c;
  boolean_T exitg1;
  emxArray_int32_T *crows;
  emxArray_int32_T *nonEmpties;
  int32_T low_ip1;
  int32_T mid_i;
  real_T pt;
  real_T u;
  emlrtHeapReferenceStackEnterFcnR2012b(emlrtRootTLSGlobal);
  emxInit_real_T(&D, 2, true);
  n = X->size[0] - 1;
  i2 = D->size[0] * D->size[1];
  D->size[0] = X->size[0];
  D->size[1] = k;
  emxEnsureCapacity_real_T(D, i2);
  b_n = X->size[0] * k;
  for (i2 = 0; i2 < b_n; i2++) {
    D->data[i2] = 0.0;
  }

  b_index = b_rand();
  i2 = Cbest->size[0];
  Cbest->size[0] = k;
  emxEnsureCapacity_real_T(Cbest, i2);
  for (i2 = 0; i2 < k; i2++) {
    Cbest->data[i2] = 0.0;
  }

  Cbest->data[0] = X->data[(int32_T)(1.0 + muDoubleScalarFloor(b_index * (real_T)
    X->size[0])) - 1];
  b_n = X->size[0];
  for (low_i = 0; low_i < b_n; low_i++) {
    b_index = X->data[low_i] - Cbest->data[0];
    D->data[low_i] = b_index * b_index;
  }

  emxInit_real_T(&d, 1, true);
  b_n = D->size[0];
  i2 = d->size[0];
  d->size[0] = b_n;
  emxEnsureCapacity_real_T(d, i2);
  for (i2 = 0; i2 < b_n; i2++) {
    d->data[i2] = D->data[i2];
  }

  i2 = idxbest->size[0];
  idxbest->size[0] = X->size[0];
  emxEnsureCapacity_int32_T(idxbest, i2);
  b_n = X->size[0];
  for (i2 = 0; i2 < b_n; i2++) {
    idxbest->data[i2] = 1;
  }

  emxInit_real_T(&sampleDist, 1, true);
  i2 = sampleDist->size[0];
  sampleDist->size[0] = X->size[0] + 1;
  emxEnsureCapacity_real_T(sampleDist, i2);
  b_n = X->size[0];
  for (i2 = 0; i2 <= b_n; i2++) {
    sampleDist->data[i2] = 0.0;
  }

  DNeedsComputing = false;
  c = 1;
  exitg1 = false;
  while ((!exitg1) && (c + 1 <= k)) {
    b_index = 0.0;
    sampleDist->data[0] = 0.0;
    for (low_i = 0; low_i <= n; low_i++) {
      sampleDist->data[low_i + 1] = sampleDist->data[low_i] + d->data[low_i];
      b_index += d->data[low_i];
    }

    if ((b_index == 0.0) || (muDoubleScalarIsInf(b_index) || muDoubleScalarIsNaN
         (b_index))) {
      b_n = k - c;
      low_i = 0;
      i2 = idxbest->size[0];
      idxbest->size[0] = n + 1;
      emxEnsureCapacity_int32_T(idxbest, i2);
      for (i2 = 0; i2 <= n; i2++) {
        idxbest->data[i2] = 0;
      }

      i2 = b_n - 1;
      for (low_ip1 = 0; low_ip1 <= i2; low_ip1++) {
        mid_i = b_n - low_ip1;
        b_index = (n - low_i) + 1;
        pt = (real_T)mid_i / b_index;
        u = b_rand();
        while (u > pt) {
          low_i++;
          b_index--;
          pt += (1.0 - pt) * ((real_T)mid_i / b_index);
        }

        low_i++;
        b_index = b_rand() * (real_T)(low_ip1 + 1);
        b_index = muDoubleScalarFloor(b_index);
        idxbest->data[low_ip1] = idxbest->data[(int32_T)b_index];
        idxbest->data[(int32_T)b_index] = low_i;
      }

      for (low_i = c + 1; low_i <= k; low_i++) {
        Cbest->data[low_i - 1] = X->data[idxbest->data[(low_i - c) - 1] - 1];
      }

      DNeedsComputing = true;
      exitg1 = true;
    } else {
      i2 = sampleDist->size[0];
      emxEnsureCapacity_real_T(sampleDist, i2);
      b_n = sampleDist->size[0];
      for (i2 = 0; i2 < b_n; i2++) {
        sampleDist->data[i2] /= b_index;
      }

      b_index = b_rand();
      b_n = sampleDist->size[0];
      low_i = 1;
      low_ip1 = 2;
      while (b_n > low_ip1) {
        mid_i = (low_i >> 1) + (b_n >> 1);
        if (((low_i & 1) == 1) && ((b_n & 1) == 1)) {
          mid_i++;
        }

        if (b_index >= sampleDist->data[mid_i - 1]) {
          low_i = mid_i;
          low_ip1 = mid_i + 1;
        } else {
          b_n = mid_i;
        }
      }

      b_index = sampleDist->data[low_i - 1];
      if (sampleDist->data[low_i - 1] < 1.0) {
        while ((low_i <= n + 1) && (sampleDist->data[low_i] <= b_index)) {
          low_i++;
        }
      } else {
        while ((low_i >= 2) && (sampleDist->data[low_i - 2] >= b_index)) {
          low_i--;
        }
      }

      Cbest->data[c] = X->data[low_i - 1];
      b_n = X->size[0];
      for (low_i = 0; low_i < b_n; low_i++) {
        b_index = X->data[low_i] - Cbest->data[c];
        D->data[low_i + D->size[0] * c] = b_index * b_index;
      }

      for (low_i = 0; low_i <= n; low_i++) {
        if (D->data[low_i + D->size[0] * c] < d->data[low_i]) {
          d->data[low_i] = D->data[low_i + D->size[0] * c];
          idxbest->data[low_i] = c + 1;
        }
      }

      c++;
    }
  }

  emxFree_real_T(&sampleDist);
  emxInit_int32_T(&crows, 1, true);
  if (DNeedsComputing) {
    i2 = crows->size[0];
    crows->size[0] = k;
    emxEnsureCapacity_int32_T(crows, i2);
    for (c = 0; c < k; c++) {
      crows->data[c] = c + 1;
    }

    distfun(D, X, Cbest, crows, k);
    mindim2(D, d, idxbest);
  }

  emxFree_real_T(&d);
  i2 = crows->size[0];
  crows->size[0] = k;
  emxEnsureCapacity_int32_T(crows, i2);
  for (i2 = 0; i2 < k; i2++) {
    crows->data[i2] = 0;
  }

  for (low_i = 0; low_i <= n; low_i++) {
    crows->data[idxbest->data[low_i] - 1]++;
  }

  emxInit_int32_T(&nonEmpties, 1, true);
  i2 = nonEmpties->size[0];
  nonEmpties->size[0] = k;
  emxEnsureCapacity_int32_T(nonEmpties, i2);
  for (i2 = 0; i2 < k; i2++) {
    nonEmpties->data[i2] = 0;
  }

  batchUpdate(X, k, idxbest, Cbest, D, crows, &DNeedsComputing, &b_n);
  b_n = 0;
  for (low_i = 0; low_i < k; low_i++) {
    if (crows->data[low_i] > 0) {
      b_n++;
      nonEmpties->data[b_n - 1] = low_i + 1;
    }
  }

  emxFree_int32_T(&crows);
  distfun(D, X, Cbest, nonEmpties, b_n);
  emxFree_real_T(&D);
  emxFree_int32_T(&nonEmpties);
  emlrtHeapReferenceStackLeaveFcnR2012b(emlrtRootTLSGlobal);
}

static void mindim2(const emxArray_real_T *D, emxArray_real_T *d,
                    emxArray_int32_T *idx)
{
  int32_T n;
  int32_T k;
  int32_T outsize_idx_0;
  int32_T i;
  n = D->size[0];
  k = D->size[1];
  outsize_idx_0 = D->size[0];
  i = d->size[0];
  d->size[0] = outsize_idx_0;
  emxEnsureCapacity_real_T(d, i);
  for (i = 0; i < outsize_idx_0; i++) {
    d->data[i] = rtInf;
  }

  i = idx->size[0];
  idx->size[0] = D->size[0];
  emxEnsureCapacity_int32_T(idx, i);
  outsize_idx_0 = D->size[0];
  for (i = 0; i < outsize_idx_0; i++) {
    idx->data[i] = 1;
  }

  for (outsize_idx_0 = 0; outsize_idx_0 < k; outsize_idx_0++) {
    for (i = 0; i < n; i++) {
      if (D->data[i + D->size[0] * outsize_idx_0] < d->data[i]) {
        idx->data[i] = outsize_idx_0 + 1;
        d->data[i] = D->data[i + D->size[0] * outsize_idx_0];
      }
    }
  }
}

void kmeans(emxArray_real_T *X, real_T kin, emxArray_real_T *idxbest,
            emxArray_real_T *Cbest)
{
  emxArray_boolean_T *wasnan;
  int32_T n;
  int32_T i;
  int32_T j;
  boolean_T hadnans;
  emxArray_int32_T *idx;
  int32_T end;
  emxArray_real_T *b_X;
  emlrtHeapReferenceStackEnterFcnR2012b(emlrtRootTLSGlobal);
  emxInit_boolean_T(&wasnan, 1, true);
  n = X->size[0];
  i = wasnan->size[0];
  wasnan->size[0] = X->size[0];
  emxEnsureCapacity_boolean_T(wasnan, i);
  j = X->size[0];
  for (i = 0; i < j; i++) {
    wasnan->data[i] = false;
  }

  hadnans = false;
  for (i = 0; i < n; i++) {
    if (muDoubleScalarIsNaN(X->data[i])) {
      hadnans = true;
      wasnan->data[i] = true;
    }
  }

  emxInit_int32_T(&idx, 1, true);
  if (hadnans) {
    end = wasnan->size[0] - 1;
    j = 0;
    for (i = 0; i <= end; i++) {
      if (!wasnan->data[i]) {
        j++;
      }
    }

    i = idx->size[0];
    idx->size[0] = j;
    emxEnsureCapacity_int32_T(idx, i);
    j = 0;
    for (i = 0; i <= end; i++) {
      if (!wasnan->data[i]) {
        idx->data[j] = i + 1;
        j++;
      }
    }

    emxInit_real_T(&b_X, 1, true);
    i = b_X->size[0];
    b_X->size[0] = idx->size[0];
    emxEnsureCapacity_real_T(b_X, i);
    j = idx->size[0];
    for (i = 0; i < j; i++) {
      b_X->data[i] = X->data[idx->data[i] - 1];
    }

    i = X->size[0];
    X->size[0] = b_X->size[0];
    emxEnsureCapacity_real_T(X, i);
    j = b_X->size[0];
    for (i = 0; i < j; i++) {
      X->data[i] = b_X->data[i];
    }

    emxFree_real_T(&b_X);
  }

  local_kmeans(X, (int32_T)kin, idx, Cbest);
  if (hadnans) {
    j = -1;
    i = idxbest->size[0];
    idxbest->size[0] = n;
    emxEnsureCapacity_real_T(idxbest, i);
    for (i = 0; i < n; i++) {
      if (wasnan->data[i]) {
        idxbest->data[i] = rtNaN;
      } else {
        j++;
        idxbest->data[i] = idx->data[j];
      }
    }
  } else {
    i = idxbest->size[0];
    idxbest->size[0] = idx->size[0];
    emxEnsureCapacity_real_T(idxbest, i);
    j = idx->size[0];
    for (i = 0; i < j; i++) {
      idxbest->data[i] = idx->data[i];
    }
  }

  emxFree_int32_T(&idx);
  emxFree_boolean_T(&wasnan);
  emlrtHeapReferenceStackLeaveFcnR2012b(emlrtRootTLSGlobal);
}

/* End of code generation (kmeans.c) */
