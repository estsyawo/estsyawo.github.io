/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * CCRl_clus_terminate.c
 *
 * Code generation for function 'CCRl_clus_terminate'
 *
 */

/* Include files */
#include "rt_nonfinite.h"
#include "CCRl_clus.h"
#include "CCRl_clus_terminate.h"
#include "_coder_CCRl_clus_mex.h"
#include "CCRl_clus_data.h"

/* Function Definitions */
void CCRl_clus_atexit(void)
{
  mexFunctionCreateRootTLS();
  emlrtEnterRtStackR2012b(emlrtRootTLSGlobal);
  emlrtLeaveRtStackR2012b(emlrtRootTLSGlobal);
  emlrtDestroyRootTLS(&emlrtRootTLSGlobal);
}

void CCRl_clus_terminate(void)
{
  emlrtLeaveRtStackR2012b(emlrtRootTLSGlobal);
  emlrtDestroyRootTLS(&emlrtRootTLSGlobal);
}

/* End of code generation (CCRl_clus_terminate.c) */
