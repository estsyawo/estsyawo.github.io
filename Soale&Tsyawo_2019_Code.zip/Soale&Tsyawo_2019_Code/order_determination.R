matpower <- function(A,n){
  A = round((A+t(A))/2,7)
  tmp = eigen(A)
  return(tmp$vectors%*%diag((tmp$values)^n)%*%t(tmp$vectors))
}

discretize = function(y,h){
 n = length(y)
 m = floor(n/h)
 y = y + 0.00001*mean(y)*rnorm(n)
 yord = y[order(y)]
 divpt = numeric();
 for(i in 1:(h-1)) divpt = c(divpt,yord[i*m+1])
 y1 = rep(0,n)
 y1[y < divpt[1]] = 1
 y1[y >= divpt[h-1]] = h
 for(i in 2:(h-1)) y1[(y >= divpt[i-1]) & (y < divpt[i])] = i
 return(y1)
}


ssdr = function(x,y,h,r,ytype="continuous"){
n = nrow(x)
p = ncol(x)
signrt = matpower(var(x),-0.5)
xc = t(t(x) - apply(x,2,mean))
z = xc%*%signrt

if(ytype=="continuous") ydis = discretize(y,h)
if(ytype=="categorical") ydis = y
ylabel = unique(ydis)

prob = numeric()
for(i in 1:h) prob=c(prob,length(ydis[ydis==ylabel[i]])/n)

exy = numeric()
for(i in 1:h) exy = rbind(exy,apply(z[ydis==ylabel[i],],2,mean))
sirmat = t(exy)%*%diag(prob)%*%exy

vxy = array(0,c(p,p,h))
for(i in 1:h) vxy[,,i] = var(z[ydis==ylabel[i],])

savemat = 0
for(i in 1:h){savemat = savemat + prob[i]*(vxy[,,i]-diag(p))%*%(vxy[,,i]-diag(p))} 

mat1 <- matrix(0,p,p)
mat2 <- matrix(0,p,p)
mat3 <- 0
for(i in 1:h){
    mat1 = mat1 + prob[i]*(vxy[,,i]-diag(p))%*%(vxy[,,i]-diag(p))
    mat2 = mat2 + (prob[i]*exy[i,]%*%t(exy[i,]))
    mat3 = mat3 + c(prob[i]*t(exy[i,])%*%exy[i,])
  }
drmat = 2*mat1 + 2*mat2%*%mat2 + 2*mat3*mat2

return(list(sirmat=sirmat,savemat=savemat,drmat=drmat))
}


#### Ladle estimator
ladle=function(x,y,h,nboot,method,ytype){
r=2;n=dim(x)[1];p=dim(x)[2]
if(p<=10) kmax=p-2;if(p>10) kmax=round(p/log(p))

candmat=function(x,y,h,r,ytype,method,lambda=0.1){
if(method=="sir") mat=ssdr(x,y,h,r,ytype="continuous")$sirmat
if(method=="save") mat=ssdr(x,y,h,r,ytype="continuous")$savemat
if(method=="dr") mat=ssdr(x,y,h,r,ytype="continuous")$drmat
if(method=="EAsir") mat=EAMRS(X,Y,h,lambda=lambda)$EAsirmat
if(method=="EAsave") mat=EAMRS(X,Y,h,lambda=lambda)$EAsavemat
if(method=="EAdr") mat=EAMRS(X,Y,h,lambda=lambda)$EAdrmat
return(mat)
}

phin=function(kmax,eval){
den=1+sum(eval[1:(kmax+1)]);return(eval[1:(kmax+1)]/den)}
out=candmat(x,y,h,r,ytype,method)
eval.full=eigen(out)$values;evec.full=eigen(out)$vectors
pn=phin(kmax,eval.full)

prefn0=function(kmax,evec1,evec2){
out=numeric();for(k in 0:kmax){
if(k==0) out=c(out,0)
if(k==1) out=c(out,1-abs(t(evec1[,1])%*%evec2[,1]))
if(k!=0&k!=1) out=c(out,1-abs(det(t(evec1[,1:k])%*%evec2[,1:k])))}
return(out)}
fn0=0
for(iboot in 1:nboot){
bootindex=round(runif(n,min=-0.5,max=n+0.5))
xs=x[bootindex,];ys=y[bootindex]
mat=candmat(xs,ys,h,r,ytype,method)
eval=eigen(mat)$values;evec=eigen(mat)$vectors
fn0=fn0+prefn0(kmax,evec.full,evec)/nboot}
minimizer=function(a,b) return(a[order(b)][1])
fn=fn0/(1+sum(fn0));gn=pn+fn;rhat=minimizer(0:kmax,gn)
return(list(kset=(0:kmax),gn=gn,rhat=rhat))
}


bic=function(x,y,h,ytype="continuous",criterion,method){
maximizer=function(x,y) return(x[order(y)[length(y)]])
r=2;n=dim(x)[1];p=dim(x)[2]
if(method=="sir") candmat=ssdr(x,y,h,r,ytype)$sirmat
if(method=="save") candmat=ssdr(x,y,h,r,ytype)$savemat
if(method=="dr") candmat=ssdr(x,y,h,r,ytype)$drmat
out=eigen(candmat);lam=out$values
if(criterion=="lal"){
gn=numeric();for(k in 0:p){
if(k==0) gn=c(gn,0) else
gn=c(gn,sum(lam[1:k])-(2*lam[1])*n^(-1/2)*(log(n))^(1/2)*k)}}
if(criterion=="zmp"){
gn=numeric();for(k in 0:(p-1)){
c1=(lam[1]/3)*(0.5* log(n)+0.1* n^(1/3))/(2*n)
c2=k*(2*p-k+1)
gn=c(gn,sum(log(lam[(k+1):p]+1)-lam[(k+1):p])-c1*c2)}
gn=c(gn,-c1*p*(2*p-p+1))}
return(list(rhat=maximizer(0:p,gn),rcurve=gn))
}


seqtestsir = function(x,y,h,r,ytype="continuous"){
n = nrow(x)
p = ncol(x)
signrt = matpower(var(x),-0.5)
xc = t(t(x) - apply(x,2,mean))
z = xc%*%signrt
if(ytype=="continuous") ydis = discretize(y,h)
if(ytype=="categorical") ydis = y
ylabel = unique(ydis)
prob = numeric()
exy = numeric()
for(i in 1:h) prob=c(prob,length(ydis[ydis==ylabel[i]])/n)
for(i in 1:h) exy = rbind(exy,apply(z[ydis==ylabel[i],],2,mean))
sirmat = t(exy)%*%diag(prob)%*%exy
test = n*sum(eigen(sirmat)$values[(r+1):p])
pval = 1-pchisq(test,(p-r)*(h-1-r))
return(pval)
}







