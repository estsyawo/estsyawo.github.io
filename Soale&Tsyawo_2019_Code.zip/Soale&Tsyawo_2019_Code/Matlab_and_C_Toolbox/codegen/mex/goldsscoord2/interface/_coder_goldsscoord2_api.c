/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * _coder_goldsscoord2_api.c
 *
 * Code generation for function '_coder_goldsscoord2_api'
 *
 */

/* Include files */
#include "rt_nonfinite.h"
#include "goldsscoord2.h"
#include "_coder_goldsscoord2_api.h"
#include "goldsscoord2_emxutil.h"
#include "goldsscoord2_data.h"

/* Function Declarations */
static void b_emlrt_marshallIn(const mxArray *u, const emlrtMsgIdentifier
  *parentId, emxArray_real_T *y);
static const mxArray *b_emlrt_marshallOut(const emxArray_real_T *u);
static void c_emlrt_marshallIn(const mxArray *X, const char_T *identifier,
  emxArray_real_T *y);
static const mxArray *c_emlrt_marshallOut(const emxArray_real_T *u);
static void d_emlrt_marshallIn(const mxArray *u, const emlrtMsgIdentifier
  *parentId, emxArray_real_T *y);
static real_T e_emlrt_marshallIn(const mxArray *nC, const char_T *identifier);
static void emlrt_marshallIn(const mxArray *Y, const char_T *identifier,
  emxArray_real_T *y);
static const mxArray *emlrt_marshallOut(const real_T u);
static real_T f_emlrt_marshallIn(const mxArray *u, const emlrtMsgIdentifier
  *parentId);
static void g_emlrt_marshallIn(const mxArray *src, const emlrtMsgIdentifier
  *msgId, emxArray_real_T *ret);
static void h_emlrt_marshallIn(const mxArray *src, const emlrtMsgIdentifier
  *msgId, emxArray_real_T *ret);
static real_T i_emlrt_marshallIn(const mxArray *src, const emlrtMsgIdentifier
  *msgId);

/* Function Definitions */
static void b_emlrt_marshallIn(const mxArray *u, const emlrtMsgIdentifier
  *parentId, emxArray_real_T *y)
{
  g_emlrt_marshallIn(emlrtAlias(u), parentId, y);
  emlrtDestroyArray(&u);
}

static const mxArray *b_emlrt_marshallOut(const emxArray_real_T *u)
{
  const mxArray *y;
  const mxArray *m1;
  static const int32_T iv0[1] = { 0 };

  y = NULL;
  m1 = emlrtCreateNumericArray(1, iv0, mxDOUBLE_CLASS, mxREAL);
  emlrtMxSetData((mxArray *)m1, &u->data[0]);
  emlrtSetDimensions((mxArray *)m1, u->size, 1);
  emlrtAssign(&y, m1);
  return y;
}

static void c_emlrt_marshallIn(const mxArray *X, const char_T *identifier,
  emxArray_real_T *y)
{
  emlrtMsgIdentifier thisId;
  thisId.fIdentifier = (const char *)identifier;
  thisId.fParent = NULL;
  thisId.bParentIsCell = false;
  d_emlrt_marshallIn(emlrtAlias(X), &thisId, y);
  emlrtDestroyArray(&X);
}

static const mxArray *c_emlrt_marshallOut(const emxArray_real_T *u)
{
  const mxArray *y;
  const mxArray *m2;
  static const int32_T iv1[2] = { 0, 0 };

  y = NULL;
  m2 = emlrtCreateNumericArray(2, iv1, mxDOUBLE_CLASS, mxREAL);
  emlrtMxSetData((mxArray *)m2, &u->data[0]);
  emlrtSetDimensions((mxArray *)m2, u->size, 2);
  emlrtAssign(&y, m2);
  return y;
}

static void d_emlrt_marshallIn(const mxArray *u, const emlrtMsgIdentifier
  *parentId, emxArray_real_T *y)
{
  h_emlrt_marshallIn(emlrtAlias(u), parentId, y);
  emlrtDestroyArray(&u);
}

static real_T e_emlrt_marshallIn(const mxArray *nC, const char_T *identifier)
{
  real_T y;
  emlrtMsgIdentifier thisId;
  thisId.fIdentifier = (const char *)identifier;
  thisId.fParent = NULL;
  thisId.bParentIsCell = false;
  y = f_emlrt_marshallIn(emlrtAlias(nC), &thisId);
  emlrtDestroyArray(&nC);
  return y;
}

static void emlrt_marshallIn(const mxArray *Y, const char_T *identifier,
  emxArray_real_T *y)
{
  emlrtMsgIdentifier thisId;
  thisId.fIdentifier = (const char *)identifier;
  thisId.fParent = NULL;
  thisId.bParentIsCell = false;
  b_emlrt_marshallIn(emlrtAlias(Y), &thisId, y);
  emlrtDestroyArray(&Y);
}

static const mxArray *emlrt_marshallOut(const real_T u)
{
  const mxArray *y;
  const mxArray *m0;
  y = NULL;
  m0 = emlrtCreateDoubleScalar(u);
  emlrtAssign(&y, m0);
  return y;
}

static real_T f_emlrt_marshallIn(const mxArray *u, const emlrtMsgIdentifier
  *parentId)
{
  real_T y;
  y = i_emlrt_marshallIn(emlrtAlias(u), parentId);
  emlrtDestroyArray(&u);
  return y;
}

static void g_emlrt_marshallIn(const mxArray *src, const emlrtMsgIdentifier
  *msgId, emxArray_real_T *ret)
{
  static const int32_T dims[1] = { -1 };

  const boolean_T bv0[1] = { true };

  int32_T iv2[1];
  int32_T i3;
  emlrtCheckVsBuiltInR2012b(emlrtRootTLSGlobal, msgId, src, "double", false, 1U,
    dims, &bv0[0], iv2);
  ret->allocatedSize = iv2[0];
  i3 = ret->size[0];
  ret->size[0] = iv2[0];
  emxEnsureCapacity_real_T(ret, i3);
  ret->data = (real_T *)emlrtMxGetData(src);
  ret->canFreeData = false;
  ret->canFreeData = false;
  emlrtDestroyArray(&src);
}

static void h_emlrt_marshallIn(const mxArray *src, const emlrtMsgIdentifier
  *msgId, emxArray_real_T *ret)
{
  static const int32_T dims[2] = { -1, -1 };

  const boolean_T bv1[2] = { true, true };

  int32_T iv3[2];
  int32_T i4;
  emlrtCheckVsBuiltInR2012b(emlrtRootTLSGlobal, msgId, src, "double", false, 2U,
    dims, &bv1[0], iv3);
  ret->allocatedSize = iv3[0] * iv3[1];
  i4 = ret->size[0] * ret->size[1];
  ret->size[0] = iv3[0];
  ret->size[1] = iv3[1];
  emxEnsureCapacity_real_T(ret, i4);
  ret->data = (real_T *)emlrtMxGetData(src);
  ret->canFreeData = false;
  ret->canFreeData = false;
  emlrtDestroyArray(&src);
}

static real_T i_emlrt_marshallIn(const mxArray *src, const emlrtMsgIdentifier
  *msgId)
{
  real_T ret;
  static const int32_T dims = 0;
  emlrtCheckBuiltInR2012b(emlrtRootTLSGlobal, msgId, src, "double", false, 0U,
    &dims);
  ret = *(real_T *)emlrtMxGetData(src);
  emlrtDestroyArray(&src);
  return ret;
}

void goldsscoord2_api(const mxArray * const prhs[5], int32_T nlhs, const mxArray
                      *plhs[4])
{
  emxArray_real_T *Y;
  emxArray_real_T *X;
  emxArray_real_T *clus;
  emxArray_real_T *bets;
  real_T nC;
  real_T a;
  real_T b;
  real_T optk;
  real_T BIC;
  emlrtHeapReferenceStackEnterFcnR2012b(emlrtRootTLSGlobal);
  emxInit_real_T(&Y, 1, true);
  emxInit_real_T(&X, 2, true);
  emxInit_real_T(&clus, 1, true);
  emxInit_real_T(&bets, 2, true);

  /* Marshall function inputs */
  Y->canFreeData = false;
  emlrt_marshallIn(emlrtAlias(prhs[0]), "Y", Y);
  X->canFreeData = false;
  c_emlrt_marshallIn(emlrtAlias(prhs[1]), "X", X);
  nC = e_emlrt_marshallIn(emlrtAliasP(prhs[2]), "nC");
  a = e_emlrt_marshallIn(emlrtAliasP(prhs[3]), "a");
  b = e_emlrt_marshallIn(emlrtAliasP(prhs[4]), "b");

  /* Invoke the target function */
  goldsscoord2(Y, X, nC, a, b, &optk, clus, bets, &BIC);

  /* Marshall function outputs */
  plhs[0] = emlrt_marshallOut(optk);
  emxFree_real_T(&X);
  emxFree_real_T(&Y);
  if (nlhs > 1) {
    clus->canFreeData = false;
    plhs[1] = b_emlrt_marshallOut(clus);
  }

  emxFree_real_T(&clus);
  if (nlhs > 2) {
    bets->canFreeData = false;
    plhs[2] = c_emlrt_marshallOut(bets);
  }

  emxFree_real_T(&bets);
  if (nlhs > 3) {
    plhs[3] = emlrt_marshallOut(BIC);
  }

  emlrtHeapReferenceStackLeaveFcnR2012b(emlrtRootTLSGlobal);
}

/* End of code generation (_coder_goldsscoord2_api.c) */
