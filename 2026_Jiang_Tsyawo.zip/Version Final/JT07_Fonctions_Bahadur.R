#===============================================================================
# JT07_Fonctions_Bahadur.R
# Helpers used by `JT04_Power_Comparison.R` to compute Bahadur slopes.
#===============================================================================

# Purpose: Generate one Monte Carlo draw for the Bahadur-slope comparison.
# Input: `l` is an unused replication index kept for `lapply` compatibility and
# `n` is the sample size.
# Output: A data frame with columns `U`, `Z`, and `Eps`.
gdat.Bahadur2 <- function(l, n = 1e03) {
  Z <- rnorm(n)
  Eps <- runif(n, min = -sqrt(3), max = sqrt(3))
  U <- exp(-Z^2 / 3) - sqrt(3 / 5) + Eps
  data.frame(U, Z, Eps)
}

#===============================================================================

# Purpose: Compute the GMDD component entering the Bahadur slope calculation.
# Input: `U`, `Z`, and `Eps` are vectors from one generated sample and `Ker`
# is the kernel matrix used by the comparison.
# Output: A length-2 numeric vector containing the GMDD numerator and the
# leading eigenvalue term.
GMDD.Bahadur <- function(U, Z, Eps, Ker) {
  n <- length(U)
  aZ <- exp(-Z^2 / 3) - sqrt(3 / 5)
  GMDD <- sum(c(tcrossprod(aZ) * Ker)) / (n * (n - 1))

  lam1 <- eigen(tcrossprod(Eps) * Ker)$values[1] / (n - 1)
  c(GMDD, lam1)
}

#===============================================================================

# Purpose: Compute the chi-squared Bahadur components for one choice of basis.
# Input: `U` and `Z` are sample vectors, `Ker` is the kernel matrix, and
# `hZ.type` selects the basis specification used in the paper.
# Output: A list containing the local-drift vector `ao` and covariance `Omg`.
Chi.Bahadur <- function(U, Z, Ker, hZ.type = 1) {
  n <- length(U)
  aZ <- exp(-Z^2 / 3) - sqrt(3 / 5)

  if (hZ.type == 1) {
    hZ <- exp(Z) - exp(1 / 2)
    V <- cbind(hZ, aZ - hZ)
    ao <- c(t(V) %*% Ker %*% aZ / (n * (n - 1)))
    qZU <- 0.5 * (c(U) * Ker %*% V + c(Ker %*% c(U)) * V) / (n - 1)
    Omg <- 4 * cov(qZU)
  } else if (hZ.type == "1a") {
    hZ <- exp(Z) - exp(1 / 2)
    V <- cbind(hZ, aZ - hZ, Z)
    ao <- c(t(V) %*% Ker %*% aZ / (n * (n - 1)))
    qZU <- 0.5 * (c(U) * Ker %*% V + c(Ker %*% c(U)) * V) / (n - 1)
    Omg <- 4 * cov(qZU)
  } else if (hZ.type == 2) {
    ao <- sum(c(tcrossprod(aZ) * Ker)) / (n * (n - 1))
    phi.D <- c(U) * Ker %*% aZ / (n - 1)
    Omg <- 4 * var(phi.D)
  } else if (hZ.type == 3) {
    hZ <- sqrt(3) * exp(-Z^2 / 2) - sqrt(3 / 2)
    V <- cbind(hZ, aZ - hZ)
    ao <- c(t(V) %*% Ker %*% aZ / (n * (n - 1)))
    qZU <- 0.5 * (c(U) * Ker %*% V + c(Ker %*% c(U)) * V) / (n - 1)
    Omg <- 4 * cov(qZU)
  } else if (hZ.type == "3a") {
    hZ <- sqrt(3) * exp(-Z^2 / 2) - sqrt(3 / 2)
    V <- cbind(hZ, aZ - hZ, Z)
    ao <- c(t(V) %*% Ker %*% aZ / (n * (n - 1)))
    qZU <- 0.5 * (c(U) * Ker %*% V + c(Ker %*% c(U)) * V) / (n - 1)
    Omg <- 4 * cov(qZU)
  } else {
    stop("hZ.type not recognised.\n")
  }

  list(ao = ao, Omg = Omg)
}

#===============================================================================

# Purpose: Run one Monte Carlo replication of the Bahadur-slope comparison.
# Input: `s` selects the sample inside `dbl`, which is a list of generated draws.
# Output: A list containing the GMDD and chi-squared components for all basis
# choices used in `JT04_Power_Comparison.R`.
MC.fn.Bahadur <- function(s, dbl) {
  Ker <- Kern.fun(Z = dbl[[s]]$Z, Kern = "Gauss")

  GMDD.obj <- GMDD.Bahadur(U = dbl[[s]]$U, Z = dbl[[s]]$Z,
                           Eps = dbl[[s]]$Eps, Ker)
  Chi.obj1 <- Chi.Bahadur(U = dbl[[s]]$U, Z = dbl[[s]]$Z, Ker, hZ.type = 1)
  Chi.obj1a <- Chi.Bahadur(U = dbl[[s]]$U, Z = dbl[[s]]$Z, Ker, hZ.type = "1a")
  Chi.obj2 <- Chi.Bahadur(U = dbl[[s]]$U, Z = dbl[[s]]$Z, Ker, hZ.type = 2)
  Chi.obj3 <- Chi.Bahadur(U = dbl[[s]]$U, Z = dbl[[s]]$Z, Ker, hZ.type = 3)
  Chi.obj3a <- Chi.Bahadur(U = dbl[[s]]$U, Z = dbl[[s]]$Z, Ker, hZ.type = "3a")

  list(
    GMDD.obj = GMDD.obj,
    Chi.obj1 = Chi.obj1,
    Chi.obj1a = Chi.obj1a,
    Chi.obj2 = Chi.obj2,
    Chi.obj3 = Chi.obj3,
    Chi.obj3a = Chi.obj3a
  )
}

#===============================================================================
