/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * kmeans.c
 *
 * Code generation for function 'kmeans'
 *
 */

/* Include files */
#include "mwmathutil.h"
#include "rt_nonfinite.h"
#include "goldsscoord3.h"
#include "kmeans.h"
#include "goldsscoord3_emxutil.h"
#include "eml_int_forloop_overflow_check.h"
#include "rand.h"
#include "warning.h"
#include "goldsscoord3_data.h"

/* Variable Definitions */
static emlrtRSInfo wc_emlrtRSI = { 43, /* lineNo */
  "kmeans",                            /* fcnName */
  "/usr/local/MATLAB/R2018b/toolbox/stats/eml/kmeans.m"/* pathName */
};

static emlrtRSInfo xc_emlrtRSI = { 53, /* lineNo */
  "kmeans",                            /* fcnName */
  "/usr/local/MATLAB/R2018b/toolbox/stats/eml/kmeans.m"/* pathName */
};

static emlrtRSInfo yc_emlrtRSI = { 198,/* lineNo */
  "kmeans",                            /* fcnName */
  "/usr/local/MATLAB/R2018b/toolbox/stats/eml/kmeans.m"/* pathName */
};

static emlrtRSInfo ad_emlrtRSI = { 210,/* lineNo */
  "kmeans",                            /* fcnName */
  "/usr/local/MATLAB/R2018b/toolbox/stats/eml/kmeans.m"/* pathName */
};

static emlrtRSInfo bd_emlrtRSI = { 320,/* lineNo */
  "kmeans",                            /* fcnName */
  "/usr/local/MATLAB/R2018b/toolbox/stats/eml/kmeans.m"/* pathName */
};

static emlrtRSInfo cd_emlrtRSI = { 399,/* lineNo */
  "kmeans",                            /* fcnName */
  "/usr/local/MATLAB/R2018b/toolbox/stats/eml/kmeans.m"/* pathName */
};

static emlrtRSInfo dd_emlrtRSI = { 402,/* lineNo */
  "kmeans",                            /* fcnName */
  "/usr/local/MATLAB/R2018b/toolbox/stats/eml/kmeans.m"/* pathName */
};

static emlrtRSInfo ed_emlrtRSI = { 412,/* lineNo */
  "kmeans",                            /* fcnName */
  "/usr/local/MATLAB/R2018b/toolbox/stats/eml/kmeans.m"/* pathName */
};

static emlrtRSInfo fd_emlrtRSI = { 415,/* lineNo */
  "kmeans",                            /* fcnName */
  "/usr/local/MATLAB/R2018b/toolbox/stats/eml/kmeans.m"/* pathName */
};

static emlrtRSInfo gd_emlrtRSI = { 421,/* lineNo */
  "kmeans",                            /* fcnName */
  "/usr/local/MATLAB/R2018b/toolbox/stats/eml/kmeans.m"/* pathName */
};

static emlrtRSInfo hd_emlrtRSI = { 423,/* lineNo */
  "kmeans",                            /* fcnName */
  "/usr/local/MATLAB/R2018b/toolbox/stats/eml/kmeans.m"/* pathName */
};

static emlrtRSInfo id_emlrtRSI = { 431,/* lineNo */
  "kmeans",                            /* fcnName */
  "/usr/local/MATLAB/R2018b/toolbox/stats/eml/kmeans.m"/* pathName */
};

static emlrtRSInfo jd_emlrtRSI = { 447,/* lineNo */
  "kmeans",                            /* fcnName */
  "/usr/local/MATLAB/R2018b/toolbox/stats/eml/kmeans.m"/* pathName */
};

static emlrtRSInfo kd_emlrtRSI = { 450,/* lineNo */
  "kmeans",                            /* fcnName */
  "/usr/local/MATLAB/R2018b/toolbox/stats/eml/kmeans.m"/* pathName */
};

static emlrtRSInfo ld_emlrtRSI = { 463,/* lineNo */
  "kmeans",                            /* fcnName */
  "/usr/local/MATLAB/R2018b/toolbox/stats/eml/kmeans.m"/* pathName */
};

static emlrtRSInfo md_emlrtRSI = { 466,/* lineNo */
  "kmeans",                            /* fcnName */
  "/usr/local/MATLAB/R2018b/toolbox/stats/eml/kmeans.m"/* pathName */
};

static emlrtRSInfo nd_emlrtRSI = { 468,/* lineNo */
  "kmeans",                            /* fcnName */
  "/usr/local/MATLAB/R2018b/toolbox/stats/eml/kmeans.m"/* pathName */
};

static emlrtRSInfo od_emlrtRSI = { 472,/* lineNo */
  "kmeans",                            /* fcnName */
  "/usr/local/MATLAB/R2018b/toolbox/stats/eml/kmeans.m"/* pathName */
};

static emlrtRSInfo pd_emlrtRSI = { 478,/* lineNo */
  "kmeans",                            /* fcnName */
  "/usr/local/MATLAB/R2018b/toolbox/stats/eml/kmeans.m"/* pathName */
};

static emlrtRSInfo qd_emlrtRSI = { 490,/* lineNo */
  "kmeans",                            /* fcnName */
  "/usr/local/MATLAB/R2018b/toolbox/stats/eml/kmeans.m"/* pathName */
};

static emlrtRSInfo rd_emlrtRSI = { 501,/* lineNo */
  "kmeans",                            /* fcnName */
  "/usr/local/MATLAB/R2018b/toolbox/stats/eml/kmeans.m"/* pathName */
};

static emlrtRSInfo sd_emlrtRSI = { 507,/* lineNo */
  "kmeans",                            /* fcnName */
  "/usr/local/MATLAB/R2018b/toolbox/stats/eml/kmeans.m"/* pathName */
};

static emlrtRSInfo td_emlrtRSI = { 510,/* lineNo */
  "kmeans",                            /* fcnName */
  "/usr/local/MATLAB/R2018b/toolbox/stats/eml/kmeans.m"/* pathName */
};

static emlrtRSInfo ud_emlrtRSI = { 515,/* lineNo */
  "kmeans",                            /* fcnName */
  "/usr/local/MATLAB/R2018b/toolbox/stats/eml/kmeans.m"/* pathName */
};

static emlrtRSInfo vd_emlrtRSI = { 520,/* lineNo */
  "kmeans",                            /* fcnName */
  "/usr/local/MATLAB/R2018b/toolbox/stats/eml/kmeans.m"/* pathName */
};

static emlrtRSInfo xd_emlrtRSI = { 1137,/* lineNo */
  "kmeans",                            /* fcnName */
  "/usr/local/MATLAB/R2018b/toolbox/stats/eml/kmeans.m"/* pathName */
};

static emlrtRSInfo yd_emlrtRSI = { 1149,/* lineNo */
  "kmeans",                            /* fcnName */
  "/usr/local/MATLAB/R2018b/toolbox/stats/eml/kmeans.m"/* pathName */
};

static emlrtRSInfo ae_emlrtRSI = { 1150,/* lineNo */
  "kmeans",                            /* fcnName */
  "/usr/local/MATLAB/R2018b/toolbox/stats/eml/kmeans.m"/* pathName */
};

static emlrtRSInfo de_emlrtRSI = { 1508,/* lineNo */
  "kmeans",                            /* fcnName */
  "/usr/local/MATLAB/R2018b/toolbox/stats/eml/kmeans.m"/* pathName */
};

static emlrtRSInfo ee_emlrtRSI = { 1520,/* lineNo */
  "kmeans",                            /* fcnName */
  "/usr/local/MATLAB/R2018b/toolbox/stats/eml/kmeans.m"/* pathName */
};

static emlrtRSInfo fe_emlrtRSI = { 1521,/* lineNo */
  "kmeans",                            /* fcnName */
  "/usr/local/MATLAB/R2018b/toolbox/stats/eml/kmeans.m"/* pathName */
};

static emlrtRSInfo ge_emlrtRSI = { 27, /* lineNo */
  "repmat",                            /* fcnName */
  "/usr/local/MATLAB/R2018b/toolbox/eml/lib/matlab/elmat/repmat.m"/* pathName */
};

static emlrtRSInfo he_emlrtRSI = { 557,/* lineNo */
  "kmeans",                            /* fcnName */
  "/usr/local/MATLAB/R2018b/toolbox/stats/eml/kmeans.m"/* pathName */
};

static emlrtRSInfo ie_emlrtRSI = { 569,/* lineNo */
  "kmeans",                            /* fcnName */
  "/usr/local/MATLAB/R2018b/toolbox/stats/eml/kmeans.m"/* pathName */
};

static emlrtRSInfo je_emlrtRSI = { 571,/* lineNo */
  "kmeans",                            /* fcnName */
  "/usr/local/MATLAB/R2018b/toolbox/stats/eml/kmeans.m"/* pathName */
};

static emlrtRSInfo ke_emlrtRSI = { 575,/* lineNo */
  "kmeans",                            /* fcnName */
  "/usr/local/MATLAB/R2018b/toolbox/stats/eml/kmeans.m"/* pathName */
};

static emlrtRSInfo le_emlrtRSI = { 624,/* lineNo */
  "kmeans",                            /* fcnName */
  "/usr/local/MATLAB/R2018b/toolbox/stats/eml/kmeans.m"/* pathName */
};

static emlrtRSInfo me_emlrtRSI = { 629,/* lineNo */
  "kmeans",                            /* fcnName */
  "/usr/local/MATLAB/R2018b/toolbox/stats/eml/kmeans.m"/* pathName */
};

static emlrtRSInfo ne_emlrtRSI = { 645,/* lineNo */
  "kmeans",                            /* fcnName */
  "/usr/local/MATLAB/R2018b/toolbox/stats/eml/kmeans.m"/* pathName */
};

static emlrtRSInfo oe_emlrtRSI = { 651,/* lineNo */
  "kmeans",                            /* fcnName */
  "/usr/local/MATLAB/R2018b/toolbox/stats/eml/kmeans.m"/* pathName */
};

static emlrtRSInfo pe_emlrtRSI = { 662,/* lineNo */
  "kmeans",                            /* fcnName */
  "/usr/local/MATLAB/R2018b/toolbox/stats/eml/kmeans.m"/* pathName */
};

static emlrtRSInfo qe_emlrtRSI = { 666,/* lineNo */
  "kmeans",                            /* fcnName */
  "/usr/local/MATLAB/R2018b/toolbox/stats/eml/kmeans.m"/* pathName */
};

static emlrtRSInfo re_emlrtRSI = { 668,/* lineNo */
  "kmeans",                            /* fcnName */
  "/usr/local/MATLAB/R2018b/toolbox/stats/eml/kmeans.m"/* pathName */
};

static emlrtRSInfo se_emlrtRSI = { 673,/* lineNo */
  "kmeans",                            /* fcnName */
  "/usr/local/MATLAB/R2018b/toolbox/stats/eml/kmeans.m"/* pathName */
};

static emlrtRSInfo te_emlrtRSI = { 692,/* lineNo */
  "kmeans",                            /* fcnName */
  "/usr/local/MATLAB/R2018b/toolbox/stats/eml/kmeans.m"/* pathName */
};

static emlrtRSInfo ue_emlrtRSI = { 699,/* lineNo */
  "kmeans",                            /* fcnName */
  "/usr/local/MATLAB/R2018b/toolbox/stats/eml/kmeans.m"/* pathName */
};

static emlrtRSInfo ve_emlrtRSI = { 711,/* lineNo */
  "kmeans",                            /* fcnName */
  "/usr/local/MATLAB/R2018b/toolbox/stats/eml/kmeans.m"/* pathName */
};

static emlrtRSInfo we_emlrtRSI = { 714,/* lineNo */
  "kmeans",                            /* fcnName */
  "/usr/local/MATLAB/R2018b/toolbox/stats/eml/kmeans.m"/* pathName */
};

static emlrtRSInfo xe_emlrtRSI = { 727,/* lineNo */
  "kmeans",                            /* fcnName */
  "/usr/local/MATLAB/R2018b/toolbox/stats/eml/kmeans.m"/* pathName */
};

static emlrtRSInfo ye_emlrtRSI = { 1265,/* lineNo */
  "kmeans",                            /* fcnName */
  "/usr/local/MATLAB/R2018b/toolbox/stats/eml/kmeans.m"/* pathName */
};

static emlrtRSInfo af_emlrtRSI = { 1273,/* lineNo */
  "kmeans",                            /* fcnName */
  "/usr/local/MATLAB/R2018b/toolbox/stats/eml/kmeans.m"/* pathName */
};

static emlrtRSInfo bf_emlrtRSI = { 1279,/* lineNo */
  "kmeans",                            /* fcnName */
  "/usr/local/MATLAB/R2018b/toolbox/stats/eml/kmeans.m"/* pathName */
};

static emlrtRSInfo cf_emlrtRSI = { 1534,/* lineNo */
  "kmeans",                            /* fcnName */
  "/usr/local/MATLAB/R2018b/toolbox/stats/eml/kmeans.m"/* pathName */
};

static emlrtRSInfo df_emlrtRSI = { 1342,/* lineNo */
  "kmeans",                            /* fcnName */
  "/usr/local/MATLAB/R2018b/toolbox/stats/eml/kmeans.m"/* pathName */
};

static emlrtRSInfo ef_emlrtRSI = { 1347,/* lineNo */
  "kmeans",                            /* fcnName */
  "/usr/local/MATLAB/R2018b/toolbox/stats/eml/kmeans.m"/* pathName */
};

static emlrtMCInfo e_emlrtMCI = { 46,  /* lineNo */
  5,                                   /* colNo */
  "repmat",                            /* fName */
  "/usr/local/MATLAB/R2018b/toolbox/eml/lib/matlab/elmat/repmat.m"/* pName */
};

static emlrtRTEInfo cb_emlrtRTEI = { 41,/* lineNo */
  5,                                   /* colNo */
  "kmeans",                            /* fName */
  "/usr/local/MATLAB/R2018b/toolbox/stats/eml/kmeans.m"/* pName */
};

static emlrtRTEInfo db_emlrtRTEI = { 228,/* lineNo */
  5,                                   /* colNo */
  "kmeans",                            /* fName */
  "/usr/local/MATLAB/R2018b/toolbox/stats/eml/kmeans.m"/* pName */
};

static emlrtRTEInfo eb_emlrtRTEI = { 1,/* lineNo */
  38,                                  /* colNo */
  "kmeans",                            /* fName */
  "/usr/local/MATLAB/R2018b/toolbox/stats/eml/kmeans.m"/* pName */
};

static emlrtRTEInfo fb_emlrtRTEI = { 203,/* lineNo */
  15,                                  /* colNo */
  "kmeans",                            /* fName */
  "/usr/local/MATLAB/R2018b/toolbox/stats/eml/kmeans.m"/* pName */
};

static emlrtRTEInfo gb_emlrtRTEI = { 54,/* lineNo */
  9,                                   /* colNo */
  "kmeans",                            /* fName */
  "/usr/local/MATLAB/R2018b/toolbox/stats/eml/kmeans.m"/* pName */
};

static emlrtRTEInfo hb_emlrtRTEI = { 400,/* lineNo */
  13,                                  /* colNo */
  "kmeans",                            /* fName */
  "/usr/local/MATLAB/R2018b/toolbox/stats/eml/kmeans.m"/* pName */
};

static emlrtRTEInfo ib_emlrtRTEI = { 402,/* lineNo */
  14,                                  /* colNo */
  "kmeans",                            /* fName */
  "/usr/local/MATLAB/R2018b/toolbox/stats/eml/kmeans.m"/* pName */
};

static emlrtRTEInfo jb_emlrtRTEI = { 404,/* lineNo */
  13,                                  /* colNo */
  "kmeans",                            /* fName */
  "/usr/local/MATLAB/R2018b/toolbox/stats/eml/kmeans.m"/* pName */
};

static emlrtRTEInfo kb_emlrtRTEI = { 405,/* lineNo */
  13,                                  /* colNo */
  "kmeans",                            /* fName */
  "/usr/local/MATLAB/R2018b/toolbox/stats/eml/kmeans.m"/* pName */
};

static emlrtRTEInfo lb_emlrtRTEI = { 407,/* lineNo */
  13,                                  /* colNo */
  "kmeans",                            /* fName */
  "/usr/local/MATLAB/R2018b/toolbox/stats/eml/kmeans.m"/* pName */
};

static emlrtRTEInfo mb_emlrtRTEI = { 471,/* lineNo */
  1,                                   /* colNo */
  "kmeans",                            /* fName */
  "/usr/local/MATLAB/R2018b/toolbox/stats/eml/kmeans.m"/* pName */
};

static emlrtRTEInfo nb_emlrtRTEI = { 320,/* lineNo */
  5,                                   /* colNo */
  "kmeans",                            /* fName */
  "/usr/local/MATLAB/R2018b/toolbox/stats/eml/kmeans.m"/* pName */
};

static emlrtRTEInfo ob_emlrtRTEI = { 430,/* lineNo */
  17,                                  /* colNo */
  "kmeans",                            /* fName */
  "/usr/local/MATLAB/R2018b/toolbox/stats/eml/kmeans.m"/* pName */
};

static emlrtRTEInfo pb_emlrtRTEI = { 475,/* lineNo */
  1,                                   /* colNo */
  "kmeans",                            /* fName */
  "/usr/local/MATLAB/R2018b/toolbox/stats/eml/kmeans.m"/* pName */
};

static emlrtRTEInfo qb_emlrtRTEI = { 421,/* lineNo */
  21,                                  /* colNo */
  "kmeans",                            /* fName */
  "/usr/local/MATLAB/R2018b/toolbox/stats/eml/kmeans.m"/* pName */
};

static emlrtRTEInfo rb_emlrtRTEI = { 514,/* lineNo */
  5,                                   /* colNo */
  "kmeans",                            /* fName */
  "/usr/local/MATLAB/R2018b/toolbox/stats/eml/kmeans.m"/* pName */
};

static emlrtRTEInfo sb_emlrtRTEI = { 358,/* lineNo */
  1,                                   /* colNo */
  "kmeans",                            /* fName */
  "/usr/local/MATLAB/R2018b/toolbox/stats/eml/kmeans.m"/* pName */
};

static emlrtRTEInfo tb_emlrtRTEI = { 462,/* lineNo */
  5,                                   /* colNo */
  "kmeans",                            /* fName */
  "/usr/local/MATLAB/R2018b/toolbox/stats/eml/kmeans.m"/* pName */
};

static emlrtRTEInfo ub_emlrtRTEI = { 346,/* lineNo */
  30,                                  /* colNo */
  "kmeans",                            /* fName */
  "/usr/local/MATLAB/R2018b/toolbox/stats/eml/kmeans.m"/* pName */
};

static emlrtRTEInfo vb_emlrtRTEI = { 1508,/* lineNo */
  1,                                   /* colNo */
  "kmeans",                            /* fName */
  "/usr/local/MATLAB/R2018b/toolbox/stats/eml/kmeans.m"/* pName */
};

static emlrtRTEInfo wb_emlrtRTEI = { 1509,/* lineNo */
  1,                                   /* colNo */
  "kmeans",                            /* fName */
  "/usr/local/MATLAB/R2018b/toolbox/stats/eml/kmeans.m"/* pName */
};

static emlrtRTEInfo xb_emlrtRTEI = { 541,/* lineNo */
  52,                                  /* colNo */
  "kmeans",                            /* fName */
  "/usr/local/MATLAB/R2018b/toolbox/stats/eml/kmeans.m"/* pName */
};

static emlrtRTEInfo jd_emlrtRTEI = { 552,/* lineNo */
  1,                                   /* colNo */
  "kmeans",                            /* fName */
  "/usr/local/MATLAB/R2018b/toolbox/stats/eml/kmeans.m"/* pName */
};

static emlrtRTEInfo kd_emlrtRTEI = { 553,/* lineNo */
  1,                                   /* colNo */
  "kmeans",                            /* fName */
  "/usr/local/MATLAB/R2018b/toolbox/stats/eml/kmeans.m"/* pName */
};

static emlrtRTEInfo ld_emlrtRTEI = { 554,/* lineNo */
  1,                                   /* colNo */
  "kmeans",                            /* fName */
  "/usr/local/MATLAB/R2018b/toolbox/stats/eml/kmeans.m"/* pName */
};

static emlrtRTEInfo md_emlrtRTEI = { 555,/* lineNo */
  11,                                  /* colNo */
  "kmeans",                            /* fName */
  "/usr/local/MATLAB/R2018b/toolbox/stats/eml/kmeans.m"/* pName */
};

static emlrtRTEInfo nd_emlrtRTEI = { 698,/* lineNo */
  9,                                   /* colNo */
  "kmeans",                            /* fName */
  "/usr/local/MATLAB/R2018b/toolbox/stats/eml/kmeans.m"/* pName */
};

static emlrtRTEInfo od_emlrtRTEI = { 709,/* lineNo */
  5,                                   /* colNo */
  "kmeans",                            /* fName */
  "/usr/local/MATLAB/R2018b/toolbox/stats/eml/kmeans.m"/* pName */
};

static emlrtRTEInfo pd_emlrtRTEI = { 1341,/* lineNo */
  1,                                   /* colNo */
  "kmeans",                            /* fName */
  "/usr/local/MATLAB/R2018b/toolbox/stats/eml/kmeans.m"/* pName */
};

static emlrtRTEInfo qd_emlrtRTEI = { 555,/* lineNo */
  1,                                   /* colNo */
  "kmeans",                            /* fName */
  "/usr/local/MATLAB/R2018b/toolbox/stats/eml/kmeans.m"/* pName */
};

static emlrtRTEInfo rd_emlrtRTEI = { 625,/* lineNo */
  21,                                  /* colNo */
  "kmeans",                            /* fName */
  "/usr/local/MATLAB/R2018b/toolbox/stats/eml/kmeans.m"/* pName */
};

static emlrtRTEInfo xd_emlrtRTEI = { 30,/* lineNo */
  23,                                  /* colNo */
  "kmeans",                            /* fName */
  "/usr/local/MATLAB/R2018b/toolbox/stats/eml/kmeans.m"/* pName */
};

static emlrtRTEInfo yd_emlrtRTEI = { 32,/* lineNo */
  23,                                  /* colNo */
  "kmeans",                            /* fName */
  "/usr/local/MATLAB/R2018b/toolbox/stats/eml/kmeans.m"/* pName */
};

static emlrtRTEInfo ae_emlrtRTEI = { 37,/* lineNo */
  1,                                   /* colNo */
  "kmeans",                            /* fName */
  "/usr/local/MATLAB/R2018b/toolbox/stats/eml/kmeans.m"/* pName */
};

static emlrtBCInfo g_emlrtBCI = { -1,  /* iFirst */
  -1,                                  /* iLast */
  45,                                  /* lineNo */
  24,                                  /* colNo */
  "",                                  /* aName */
  "kmeans",                            /* fName */
  "/usr/local/MATLAB/R2018b/toolbox/stats/eml/kmeans.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo h_emlrtBCI = { -1,  /* iFirst */
  -1,                                  /* iLast */
  47,                                  /* lineNo */
  17,                                  /* colNo */
  "",                                  /* aName */
  "kmeans",                            /* fName */
  "/usr/local/MATLAB/R2018b/toolbox/stats/eml/kmeans.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo i_emlrtBCI = { -1,  /* iFirst */
  -1,                                  /* iLast */
  54,                                  /* lineNo */
  15,                                  /* colNo */
  "",                                  /* aName */
  "kmeans",                            /* fName */
  "/usr/local/MATLAB/R2018b/toolbox/stats/eml/kmeans.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo j_emlrtBCI = { -1,  /* iFirst */
  -1,                                  /* iLast */
  211,                                 /* lineNo */
  12,                                  /* colNo */
  "",                                  /* aName */
  "kmeans",                            /* fName */
  "/usr/local/MATLAB/R2018b/toolbox/stats/eml/kmeans.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo k_emlrtBCI = { -1,  /* iFirst */
  -1,                                  /* iLast */
  212,                                 /* lineNo */
  13,                                  /* colNo */
  "",                                  /* aName */
  "kmeans",                            /* fName */
  "/usr/local/MATLAB/R2018b/toolbox/stats/eml/kmeans.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo l_emlrtBCI = { -1,  /* iFirst */
  -1,                                  /* iLast */
  218,                                 /* lineNo */
  26,                                  /* colNo */
  "",                                  /* aName */
  "kmeans",                            /* fName */
  "/usr/local/MATLAB/R2018b/toolbox/stats/eml/kmeans.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo m_emlrtBCI = { -1,  /* iFirst */
  -1,                                  /* iLast */
  218,                                 /* lineNo */
  13,                                  /* colNo */
  "",                                  /* aName */
  "kmeans",                            /* fName */
  "/usr/local/MATLAB/R2018b/toolbox/stats/eml/kmeans.m",/* pName */
  0                                    /* checkKind */
};

static emlrtDCInfo emlrtDCI = { 357,   /* lineNo */
  13,                                  /* colNo */
  "kmeans",                            /* fName */
  "/usr/local/MATLAB/R2018b/toolbox/stats/eml/kmeans.m",/* pName */
  4                                    /* checkKind */
};

static emlrtBCInfo n_emlrtBCI = { -1,  /* iFirst */
  -1,                                  /* iLast */
  401,                                 /* lineNo */
  15,                                  /* colNo */
  "",                                  /* aName */
  "kmeans",                            /* fName */
  "/usr/local/MATLAB/R2018b/toolbox/stats/eml/kmeans.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo o_emlrtBCI = { -1,  /* iFirst */
  -1,                                  /* iLast */
  404,                                 /* lineNo */
  21,                                  /* colNo */
  "",                                  /* aName */
  "kmeans",                            /* fName */
  "/usr/local/MATLAB/R2018b/toolbox/stats/eml/kmeans.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo p_emlrtBCI = { -1,  /* iFirst */
  -1,                                  /* iLast */
  521,                                 /* lineNo */
  34,                                  /* colNo */
  "",                                  /* aName */
  "kmeans",                            /* fName */
  "/usr/local/MATLAB/R2018b/toolbox/stats/eml/kmeans.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo q_emlrtBCI = { -1,  /* iFirst */
  -1,                                  /* iLast */
  320,                                 /* lineNo */
  5,                                   /* colNo */
  "",                                  /* aName */
  "kmeans",                            /* fName */
  "/usr/local/MATLAB/R2018b/toolbox/stats/eml/kmeans.m",/* pName */
  0                                    /* checkKind */
};

static emlrtDCInfo b_emlrtDCI = { 320, /* lineNo */
  5,                                   /* colNo */
  "kmeans",                            /* fName */
  "/usr/local/MATLAB/R2018b/toolbox/stats/eml/kmeans.m",/* pName */
  1                                    /* checkKind */
};

static emlrtBCInfo r_emlrtBCI = { -1,  /* iFirst */
  -1,                                  /* iLast */
  416,                                 /* lineNo */
  41,                                  /* colNo */
  "",                                  /* aName */
  "kmeans",                            /* fName */
  "/usr/local/MATLAB/R2018b/toolbox/stats/eml/kmeans.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo s_emlrtBCI = { -1,  /* iFirst */
  -1,                                  /* iLast */
  416,                                 /* lineNo */
  57,                                  /* colNo */
  "",                                  /* aName */
  "kmeans",                            /* fName */
  "/usr/local/MATLAB/R2018b/toolbox/stats/eml/kmeans.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo t_emlrtBCI = { -1,  /* iFirst */
  -1,                                  /* iLast */
  416,                                 /* lineNo */
  21,                                  /* colNo */
  "",                                  /* aName */
  "kmeans",                            /* fName */
  "/usr/local/MATLAB/R2018b/toolbox/stats/eml/kmeans.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo u_emlrtBCI = { -1,  /* iFirst */
  -1,                                  /* iLast */
  417,                                 /* lineNo */
  49,                                  /* colNo */
  "",                                  /* aName */
  "kmeans",                            /* fName */
  "/usr/local/MATLAB/R2018b/toolbox/stats/eml/kmeans.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo v_emlrtBCI = { -1,  /* iFirst */
  -1,                                  /* iLast */
  473,                                 /* lineNo */
  22,                                  /* colNo */
  "",                                  /* aName */
  "kmeans",                            /* fName */
  "/usr/local/MATLAB/R2018b/toolbox/stats/eml/kmeans.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo w_emlrtBCI = { -1,  /* iFirst */
  -1,                                  /* iLast */
  473,                                 /* lineNo */
  5,                                   /* colNo */
  "",                                  /* aName */
  "kmeans",                            /* fName */
  "/usr/local/MATLAB/R2018b/toolbox/stats/eml/kmeans.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo x_emlrtBCI = { -1,  /* iFirst */
  -1,                                  /* iLast */
  464,                                 /* lineNo */
  9,                                   /* colNo */
  "",                                  /* aName */
  "kmeans",                            /* fName */
  "/usr/local/MATLAB/R2018b/toolbox/stats/eml/kmeans.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo y_emlrtBCI = { -1,  /* iFirst */
  -1,                                  /* iLast */
  434,                                 /* lineNo */
  24,                                  /* colNo */
  "",                                  /* aName */
  "kmeans",                            /* fName */
  "/usr/local/MATLAB/R2018b/toolbox/stats/eml/kmeans.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo ab_emlrtBCI = { -1, /* iFirst */
  -1,                                  /* iLast */
  442,                                 /* lineNo */
  40,                                  /* colNo */
  "",                                  /* aName */
  "kmeans",                            /* fName */
  "/usr/local/MATLAB/R2018b/toolbox/stats/eml/kmeans.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo bb_emlrtBCI = { -1, /* iFirst */
  -1,                                  /* iLast */
  437,                                 /* lineNo */
  40,                                  /* colNo */
  "",                                  /* aName */
  "kmeans",                            /* fName */
  "/usr/local/MATLAB/R2018b/toolbox/stats/eml/kmeans.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo cb_emlrtBCI = { -1, /* iFirst */
  -1,                                  /* iLast */
  502,                                 /* lineNo */
  12,                                  /* colNo */
  "",                                  /* aName */
  "kmeans",                            /* fName */
  "/usr/local/MATLAB/R2018b/toolbox/stats/eml/kmeans.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo db_emlrtBCI = { -1, /* iFirst */
  -1,                                  /* iLast */
  446,                                 /* lineNo */
  17,                                  /* colNo */
  "",                                  /* aName */
  "kmeans",                            /* fName */
  "/usr/local/MATLAB/R2018b/toolbox/stats/eml/kmeans.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo eb_emlrtBCI = { -1, /* iFirst */
  -1,                                  /* iLast */
  1564,                                /* lineNo */
  18,                                  /* colNo */
  "",                                  /* aName */
  "kmeans",                            /* fName */
  "/usr/local/MATLAB/R2018b/toolbox/stats/eml/kmeans.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo fb_emlrtBCI = { -1, /* iFirst */
  -1,                                  /* iLast */
  1564,                                /* lineNo */
  5,                                   /* colNo */
  "",                                  /* aName */
  "kmeans",                            /* fName */
  "/usr/local/MATLAB/R2018b/toolbox/stats/eml/kmeans.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo gb_emlrtBCI = { -1, /* iFirst */
  -1,                                  /* iLast */
  504,                                 /* lineNo */
  13,                                  /* colNo */
  "",                                  /* aName */
  "kmeans",                            /* fName */
  "/usr/local/MATLAB/R2018b/toolbox/stats/eml/kmeans.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo hb_emlrtBCI = { -1, /* iFirst */
  -1,                                  /* iLast */
  1565,                                /* lineNo */
  5,                                   /* colNo */
  "",                                  /* aName */
  "kmeans",                            /* fName */
  "/usr/local/MATLAB/R2018b/toolbox/stats/eml/kmeans.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo ib_emlrtBCI = { -1, /* iFirst */
  -1,                                  /* iLast */
  424,                                 /* lineNo */
  29,                                  /* colNo */
  "",                                  /* aName */
  "kmeans",                            /* fName */
  "/usr/local/MATLAB/R2018b/toolbox/stats/eml/kmeans.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo jb_emlrtBCI = { -1, /* iFirst */
  -1,                                  /* iLast */
  511,                                 /* lineNo */
  16,                                  /* colNo */
  "",                                  /* aName */
  "kmeans",                            /* fName */
  "/usr/local/MATLAB/R2018b/toolbox/stats/eml/kmeans.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo kb_emlrtBCI = { -1, /* iFirst */
  -1,                                  /* iLast */
  511,                                 /* lineNo */
  9,                                   /* colNo */
  "",                                  /* aName */
  "kmeans",                            /* fName */
  "/usr/local/MATLAB/R2018b/toolbox/stats/eml/kmeans.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo lb_emlrtBCI = { -1, /* iFirst */
  -1,                                  /* iLast */
  451,                                 /* lineNo */
  24,                                  /* colNo */
  "",                                  /* aName */
  "kmeans",                            /* fName */
  "/usr/local/MATLAB/R2018b/toolbox/stats/eml/kmeans.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo mb_emlrtBCI = { -1, /* iFirst */
  -1,                                  /* iLast */
  451,                                 /* lineNo */
  33,                                  /* colNo */
  "",                                  /* aName */
  "kmeans",                            /* fName */
  "/usr/local/MATLAB/R2018b/toolbox/stats/eml/kmeans.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo nb_emlrtBCI = { -1, /* iFirst */
  -1,                                  /* iLast */
  452,                                 /* lineNo */
  32,                                  /* colNo */
  "",                                  /* aName */
  "kmeans",                            /* fName */
  "/usr/local/MATLAB/R2018b/toolbox/stats/eml/kmeans.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo ob_emlrtBCI = { -1, /* iFirst */
  -1,                                  /* iLast */
  452,                                 /* lineNo */
  25,                                  /* colNo */
  "",                                  /* aName */
  "kmeans",                            /* fName */
  "/usr/local/MATLAB/R2018b/toolbox/stats/eml/kmeans.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo pb_emlrtBCI = { -1, /* iFirst */
  -1,                                  /* iLast */
  453,                                 /* lineNo */
  25,                                  /* colNo */
  "",                                  /* aName */
  "kmeans",                            /* fName */
  "/usr/local/MATLAB/R2018b/toolbox/stats/eml/kmeans.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo qb_emlrtBCI = { -1, /* iFirst */
  -1,                                  /* iLast */
  516,                                 /* lineNo */
  24,                                  /* colNo */
  "",                                  /* aName */
  "kmeans",                            /* fName */
  "/usr/local/MATLAB/R2018b/toolbox/stats/eml/kmeans.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo rb_emlrtBCI = { -1, /* iFirst */
  -1,                                  /* iLast */
  516,                                 /* lineNo */
  39,                                  /* colNo */
  "",                                  /* aName */
  "kmeans",                            /* fName */
  "/usr/local/MATLAB/R2018b/toolbox/stats/eml/kmeans.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo sb_emlrtBCI = { -1, /* iFirst */
  -1,                                  /* iLast */
  516,                                 /* lineNo */
  9,                                   /* colNo */
  "",                                  /* aName */
  "kmeans",                            /* fName */
  "/usr/local/MATLAB/R2018b/toolbox/stats/eml/kmeans.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo tb_emlrtBCI = { -1, /* iFirst */
  -1,                                  /* iLast */
  1522,                                /* lineNo */
  16,                                  /* colNo */
  "",                                  /* aName */
  "kmeans",                            /* fName */
  "/usr/local/MATLAB/R2018b/toolbox/stats/eml/kmeans.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo ub_emlrtBCI = { -1, /* iFirst */
  -1,                                  /* iLast */
  1522,                                /* lineNo */
  25,                                  /* colNo */
  "",                                  /* aName */
  "kmeans",                            /* fName */
  "/usr/local/MATLAB/R2018b/toolbox/stats/eml/kmeans.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo vb_emlrtBCI = { -1, /* iFirst */
  -1,                                  /* iLast */
  1523,                                /* lineNo */
  17,                                  /* colNo */
  "",                                  /* aName */
  "kmeans",                            /* fName */
  "/usr/local/MATLAB/R2018b/toolbox/stats/eml/kmeans.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo wb_emlrtBCI = { -1, /* iFirst */
  -1,                                  /* iLast */
  1524,                                /* lineNo */
  24,                                  /* colNo */
  "",                                  /* aName */
  "kmeans",                            /* fName */
  "/usr/local/MATLAB/R2018b/toolbox/stats/eml/kmeans.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo xb_emlrtBCI = { -1, /* iFirst */
  -1,                                  /* iLast */
  1524,                                /* lineNo */
  17,                                  /* colNo */
  "",                                  /* aName */
  "kmeans",                            /* fName */
  "/usr/local/MATLAB/R2018b/toolbox/stats/eml/kmeans.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo dd_emlrtBCI = { -1, /* iFirst */
  -1,                                  /* iLast */
  1139,                                /* lineNo */
  22,                                  /* colNo */
  "",                                  /* aName */
  "kmeans",                            /* fName */
  "/usr/local/MATLAB/R2018b/toolbox/stats/eml/kmeans.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo ed_emlrtBCI = { -1, /* iFirst */
  -1,                                  /* iLast */
  1150,                                /* lineNo */
  34,                                  /* colNo */
  "",                                  /* aName */
  "kmeans",                            /* fName */
  "/usr/local/MATLAB/R2018b/toolbox/stats/eml/kmeans.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo fd_emlrtBCI = { -1, /* iFirst */
  -1,                                  /* iLast */
  1150,                                /* lineNo */
  21,                                  /* colNo */
  "",                                  /* aName */
  "kmeans",                            /* fName */
  "/usr/local/MATLAB/R2018b/toolbox/stats/eml/kmeans.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo gd_emlrtBCI = { -1, /* iFirst */
  -1,                                  /* iLast */
  1138,                                /* lineNo */
  18,                                  /* colNo */
  "",                                  /* aName */
  "kmeans",                            /* fName */
  "/usr/local/MATLAB/R2018b/toolbox/stats/eml/kmeans.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo hd_emlrtBCI = { -1, /* iFirst */
  -1,                                  /* iLast */
  658,                                 /* lineNo */
  34,                                  /* colNo */
  "",                                  /* aName */
  "kmeans",                            /* fName */
  "/usr/local/MATLAB/R2018b/toolbox/stats/eml/kmeans.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo id_emlrtBCI = { -1, /* iFirst */
  -1,                                  /* iLast */
  627,                                 /* lineNo */
  30,                                  /* colNo */
  "",                                  /* aName */
  "kmeans",                            /* fName */
  "/usr/local/MATLAB/R2018b/toolbox/stats/eml/kmeans.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo jd_emlrtBCI = { -1, /* iFirst */
  -1,                                  /* iLast */
  626,                                 /* lineNo */
  23,                                  /* colNo */
  "",                                  /* aName */
  "kmeans",                            /* fName */
  "/usr/local/MATLAB/R2018b/toolbox/stats/eml/kmeans.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo kd_emlrtBCI = { -1, /* iFirst */
  -1,                                  /* iLast */
  626,                                 /* lineNo */
  36,                                  /* colNo */
  "",                                  /* aName */
  "kmeans",                            /* fName */
  "/usr/local/MATLAB/R2018b/toolbox/stats/eml/kmeans.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo ld_emlrtBCI = { -1, /* iFirst */
  -1,                                  /* iLast */
  626,                                 /* lineNo */
  30,                                  /* colNo */
  "",                                  /* aName */
  "kmeans",                            /* fName */
  "/usr/local/MATLAB/R2018b/toolbox/stats/eml/kmeans.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo md_emlrtBCI = { -1, /* iFirst */
  -1,                                  /* iLast */
  558,                                 /* lineNo */
  5,                                   /* colNo */
  "",                                  /* aName */
  "kmeans",                            /* fName */
  "/usr/local/MATLAB/R2018b/toolbox/stats/eml/kmeans.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo nd_emlrtBCI = { -1, /* iFirst */
  -1,                                  /* iLast */
  1535,                                /* lineNo */
  8,                                   /* colNo */
  "",                                  /* aName */
  "kmeans",                            /* fName */
  "/usr/local/MATLAB/R2018b/toolbox/stats/eml/kmeans.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo od_emlrtBCI = { -1, /* iFirst */
  -1,                                  /* iLast */
  1537,                                /* lineNo */
  27,                                  /* colNo */
  "",                                  /* aName */
  "kmeans",                            /* fName */
  "/usr/local/MATLAB/R2018b/toolbox/stats/eml/kmeans.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo pd_emlrtBCI = { -1, /* iFirst */
  -1,                                  /* iLast */
  1537,                                /* lineNo */
  9,                                   /* colNo */
  "",                                  /* aName */
  "kmeans",                            /* fName */
  "/usr/local/MATLAB/R2018b/toolbox/stats/eml/kmeans.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo qd_emlrtBCI = { -1, /* iFirst */
  -1,                                  /* iLast */
  693,                                 /* lineNo */
  29,                                  /* colNo */
  "",                                  /* aName */
  "kmeans",                            /* fName */
  "/usr/local/MATLAB/R2018b/toolbox/stats/eml/kmeans.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo rd_emlrtBCI = { -1, /* iFirst */
  -1,                                  /* iLast */
  626,                                 /* lineNo */
  28,                                  /* colNo */
  "",                                  /* aName */
  "kmeans",                            /* fName */
  "/usr/local/MATLAB/R2018b/toolbox/stats/eml/kmeans.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo sd_emlrtBCI = { -1, /* iFirst */
  -1,                                  /* iLast */
  640,                                 /* lineNo */
  28,                                  /* colNo */
  "",                                  /* aName */
  "kmeans",                            /* fName */
  "/usr/local/MATLAB/R2018b/toolbox/stats/eml/kmeans.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo td_emlrtBCI = { -1, /* iFirst */
  -1,                                  /* iLast */
  716,                                 /* lineNo */
  12,                                  /* colNo */
  "",                                  /* aName */
  "kmeans",                            /* fName */
  "/usr/local/MATLAB/R2018b/toolbox/stats/eml/kmeans.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo ud_emlrtBCI = { -1, /* iFirst */
  -1,                                  /* iLast */
  716,                                 /* lineNo */
  23,                                  /* colNo */
  "",                                  /* aName */
  "kmeans",                            /* fName */
  "/usr/local/MATLAB/R2018b/toolbox/stats/eml/kmeans.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo vd_emlrtBCI = { -1, /* iFirst */
  -1,                                  /* iLast */
  641,                                 /* lineNo */
  24,                                  /* colNo */
  "",                                  /* aName */
  "kmeans",                            /* fName */
  "/usr/local/MATLAB/R2018b/toolbox/stats/eml/kmeans.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo wd_emlrtBCI = { -1, /* iFirst */
  -1,                                  /* iLast */
  630,                                 /* lineNo */
  32,                                  /* colNo */
  "",                                  /* aName */
  "kmeans",                            /* fName */
  "/usr/local/MATLAB/R2018b/toolbox/stats/eml/kmeans.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo xd_emlrtBCI = { -1, /* iFirst */
  -1,                                  /* iLast */
  630,                                 /* lineNo */
  25,                                  /* colNo */
  "",                                  /* aName */
  "kmeans",                            /* fName */
  "/usr/local/MATLAB/R2018b/toolbox/stats/eml/kmeans.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo yd_emlrtBCI = { -1, /* iFirst */
  -1,                                  /* iLast */
  716,                                 /* lineNo */
  37,                                  /* colNo */
  "",                                  /* aName */
  "kmeans",                            /* fName */
  "/usr/local/MATLAB/R2018b/toolbox/stats/eml/kmeans.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo ae_emlrtBCI = { -1, /* iFirst */
  -1,                                  /* iLast */
  716,                                 /* lineNo */
  55,                                  /* colNo */
  "",                                  /* aName */
  "kmeans",                            /* fName */
  "/usr/local/MATLAB/R2018b/toolbox/stats/eml/kmeans.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo be_emlrtBCI = { -1, /* iFirst */
  -1,                                  /* iLast */
  631,                                 /* lineNo */
  28,                                  /* colNo */
  "",                                  /* aName */
  "kmeans",                            /* fName */
  "/usr/local/MATLAB/R2018b/toolbox/stats/eml/kmeans.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo ce_emlrtBCI = { -1, /* iFirst */
  -1,                                  /* iLast */
  632,                                 /* lineNo */
  36,                                  /* colNo */
  "",                                  /* aName */
  "kmeans",                            /* fName */
  "/usr/local/MATLAB/R2018b/toolbox/stats/eml/kmeans.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo de_emlrtBCI = { -1, /* iFirst */
  -1,                                  /* iLast */
  718,                                 /* lineNo */
  13,                                  /* colNo */
  "",                                  /* aName */
  "kmeans",                            /* fName */
  "/usr/local/MATLAB/R2018b/toolbox/stats/eml/kmeans.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo ee_emlrtBCI = { -1, /* iFirst */
  -1,                                  /* iLast */
  719,                                 /* lineNo */
  22,                                  /* colNo */
  "",                                  /* aName */
  "kmeans",                            /* fName */
  "/usr/local/MATLAB/R2018b/toolbox/stats/eml/kmeans.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo fe_emlrtBCI = { -1, /* iFirst */
  -1,                                  /* iLast */
  719,                                 /* lineNo */
  13,                                  /* colNo */
  "",                                  /* aName */
  "kmeans",                            /* fName */
  "/usr/local/MATLAB/R2018b/toolbox/stats/eml/kmeans.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo ge_emlrtBCI = { -1, /* iFirst */
  -1,                                  /* iLast */
  659,                                 /* lineNo */
  33,                                  /* colNo */
  "",                                  /* aName */
  "kmeans",                            /* fName */
  "/usr/local/MATLAB/R2018b/toolbox/stats/eml/kmeans.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo he_emlrtBCI = { -1, /* iFirst */
  -1,                                  /* iLast */
  659,                                 /* lineNo */
  21,                                  /* colNo */
  "",                                  /* aName */
  "kmeans",                            /* fName */
  "/usr/local/MATLAB/R2018b/toolbox/stats/eml/kmeans.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo ie_emlrtBCI = { -1, /* iFirst */
  -1,                                  /* iLast */
  660,                                 /* lineNo */
  21,                                  /* colNo */
  "",                                  /* aName */
  "kmeans",                            /* fName */
  "/usr/local/MATLAB/R2018b/toolbox/stats/eml/kmeans.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo je_emlrtBCI = { -1, /* iFirst */
  -1,                                  /* iLast */
  661,                                 /* lineNo */
  21,                                  /* colNo */
  "",                                  /* aName */
  "kmeans",                            /* fName */
  "/usr/local/MATLAB/R2018b/toolbox/stats/eml/kmeans.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo ke_emlrtBCI = { -1, /* iFirst */
  -1,                                  /* iLast */
  1343,                                /* lineNo */
  5,                                   /* colNo */
  "",                                  /* aName */
  "kmeans",                            /* fName */
  "/usr/local/MATLAB/R2018b/toolbox/stats/eml/kmeans.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo le_emlrtBCI = { -1, /* iFirst */
  -1,                                  /* iLast */
  1344,                                /* lineNo */
  5,                                   /* colNo */
  "",                                  /* aName */
  "kmeans",                            /* fName */
  "/usr/local/MATLAB/R2018b/toolbox/stats/eml/kmeans.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo me_emlrtBCI = { -1, /* iFirst */
  -1,                                  /* iLast */
  646,                                 /* lineNo */
  32,                                  /* colNo */
  "",                                  /* aName */
  "kmeans",                            /* fName */
  "/usr/local/MATLAB/R2018b/toolbox/stats/eml/kmeans.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo ne_emlrtBCI = { -1, /* iFirst */
  -1,                                  /* iLast */
  1348,                                /* lineNo */
  8,                                   /* colNo */
  "",                                  /* aName */
  "kmeans",                            /* fName */
  "/usr/local/MATLAB/R2018b/toolbox/stats/eml/kmeans.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo oe_emlrtBCI = { -1, /* iFirst */
  -1,                                  /* iLast */
  652,                                 /* lineNo */
  32,                                  /* colNo */
  "",                                  /* aName */
  "kmeans",                            /* fName */
  "/usr/local/MATLAB/R2018b/toolbox/stats/eml/kmeans.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo pe_emlrtBCI = { -1, /* iFirst */
  -1,                                  /* iLast */
  1350,                                /* lineNo */
  9,                                   /* colNo */
  "",                                  /* aName */
  "kmeans",                            /* fName */
  "/usr/local/MATLAB/R2018b/toolbox/stats/eml/kmeans.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo qe_emlrtBCI = { -1, /* iFirst */
  -1,                                  /* iLast */
  674,                                 /* lineNo */
  40,                                  /* colNo */
  "",                                  /* aName */
  "kmeans",                            /* fName */
  "/usr/local/MATLAB/R2018b/toolbox/stats/eml/kmeans.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo re_emlrtBCI = { -1, /* iFirst */
  -1,                                  /* iLast */
  676,                                 /* lineNo */
  43,                                  /* colNo */
  "",                                  /* aName */
  "kmeans",                            /* fName */
  "/usr/local/MATLAB/R2018b/toolbox/stats/eml/kmeans.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo se_emlrtBCI = { -1, /* iFirst */
  -1,                                  /* iLast */
  680,                                 /* lineNo */
  33,                                  /* colNo */
  "",                                  /* aName */
  "kmeans",                            /* fName */
  "/usr/local/MATLAB/R2018b/toolbox/stats/eml/kmeans.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo te_emlrtBCI = { -1, /* iFirst */
  -1,                                  /* iLast */
  678,                                 /* lineNo */
  55,                                  /* colNo */
  "",                                  /* aName */
  "kmeans",                            /* fName */
  "/usr/local/MATLAB/R2018b/toolbox/stats/eml/kmeans.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo ue_emlrtBCI = { -1, /* iFirst */
  -1,                                  /* iLast */
  678,                                 /* lineNo */
  37,                                  /* colNo */
  "",                                  /* aName */
  "kmeans",                            /* fName */
  "/usr/local/MATLAB/R2018b/toolbox/stats/eml/kmeans.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo ve_emlrtBCI = { -1, /* iFirst */
  -1,                                  /* iLast */
  1266,                                /* lineNo */
  5,                                   /* colNo */
  "",                                  /* aName */
  "kmeans",                            /* fName */
  "/usr/local/MATLAB/R2018b/toolbox/stats/eml/kmeans.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo we_emlrtBCI = { -1, /* iFirst */
  -1,                                  /* iLast */
  1268,                                /* lineNo */
  9,                                   /* colNo */
  "",                                  /* aName */
  "kmeans",                            /* fName */
  "/usr/local/MATLAB/R2018b/toolbox/stats/eml/kmeans.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo xe_emlrtBCI = { -1, /* iFirst */
  -1,                                  /* iLast */
  1277,                                /* lineNo */
  17,                                  /* colNo */
  "",                                  /* aName */
  "kmeans",                            /* fName */
  "/usr/local/MATLAB/R2018b/toolbox/stats/eml/kmeans.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo ye_emlrtBCI = { -1, /* iFirst */
  -1,                                  /* iLast */
  1287,                                /* lineNo */
  13,                                  /* colNo */
  "",                                  /* aName */
  "kmeans",                            /* fName */
  "/usr/local/MATLAB/R2018b/toolbox/stats/eml/kmeans.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo af_emlrtBCI = { -1, /* iFirst */
  -1,                                  /* iLast */
  1280,                                /* lineNo */
  20,                                  /* colNo */
  "",                                  /* aName */
  "kmeans",                            /* fName */
  "/usr/local/MATLAB/R2018b/toolbox/stats/eml/kmeans.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo bf_emlrtBCI = { -1, /* iFirst */
  -1,                                  /* iLast */
  1290,                                /* lineNo */
  17,                                  /* colNo */
  "",                                  /* aName */
  "kmeans",                            /* fName */
  "/usr/local/MATLAB/R2018b/toolbox/stats/eml/kmeans.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo cf_emlrtBCI = { -1, /* iFirst */
  -1,                                  /* iLast */
  666,                                 /* lineNo */
  21,                                  /* colNo */
  "",                                  /* aName */
  "kmeans",                            /* fName */
  "/usr/local/MATLAB/R2018b/toolbox/stats/eml/kmeans.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo df_emlrtBCI = { -1, /* iFirst */
  -1,                                  /* iLast */
  1283,                                /* lineNo */
  25,                                  /* colNo */
  "",                                  /* aName */
  "kmeans",                            /* fName */
  "/usr/local/MATLAB/R2018b/toolbox/stats/eml/kmeans.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo ef_emlrtBCI = { -1, /* iFirst */
  -1,                                  /* iLast */
  1274,                                /* lineNo */
  20,                                  /* colNo */
  "",                                  /* aName */
  "kmeans",                            /* fName */
  "/usr/local/MATLAB/R2018b/toolbox/stats/eml/kmeans.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo ff_emlrtBCI = { -1, /* iFirst */
  -1,                                  /* iLast */
  1290,                                /* lineNo */
  31,                                  /* colNo */
  "",                                  /* aName */
  "kmeans",                            /* fName */
  "/usr/local/MATLAB/R2018b/toolbox/stats/eml/kmeans.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo gf_emlrtBCI = { -1, /* iFirst */
  -1,                                  /* iLast */
  1283,                                /* lineNo */
  39,                                  /* colNo */
  "",                                  /* aName */
  "kmeans",                            /* fName */
  "/usr/local/MATLAB/R2018b/toolbox/stats/eml/kmeans.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo hf_emlrtBCI = { -1, /* iFirst */
  -1,                                  /* iLast */
  1283,                                /* lineNo */
  51,                                  /* colNo */
  "",                                  /* aName */
  "kmeans",                            /* fName */
  "/usr/local/MATLAB/R2018b/toolbox/stats/eml/kmeans.m",/* pName */
  0                                    /* checkKind */
};

static emlrtRSInfo vf_emlrtRSI = { 46, /* lineNo */
  "repmat",                            /* fcnName */
  "/usr/local/MATLAB/R2018b/toolbox/eml/lib/matlab/elmat/repmat.m"/* pathName */
};

/* Function Declarations */
static void b_distfun(const emlrtStack *sp, emxArray_real_T *D, const
                      emxArray_real_T *X, const emxArray_real_T *C, const
                      emxArray_int32_T *crows, int32_T ncrows);
static void batchUpdate(const emlrtStack *sp, const emxArray_real_T *X, int32_T
  k, emxArray_int32_T *idx, emxArray_real_T *C, emxArray_real_T *D,
  emxArray_int32_T *counts, boolean_T *converged, int32_T *iter);
static void distfun(const emlrtStack *sp, emxArray_real_T *D, const
                    emxArray_real_T *X, const emxArray_real_T *C, int32_T crows);
static void e_error(const emlrtStack *sp, const mxArray *b, emlrtMCInfo
                    *location);
static void gcentroids(const emlrtStack *sp, emxArray_real_T *C,
  emxArray_int32_T *counts, const emxArray_real_T *X, const emxArray_int32_T
  *idx, const emxArray_int32_T *clusters, int32_T nclusters);
static void local_kmeans(const emlrtStack *sp, const emxArray_real_T *X, int32_T
  k, emxArray_int32_T *idxbest, emxArray_real_T *Cbest);
static void mindim2(const emlrtStack *sp, const emxArray_real_T *D,
                    emxArray_real_T *d, emxArray_int32_T *idx);

/* Function Definitions */
static void b_distfun(const emlrtStack *sp, emxArray_real_T *D, const
                      emxArray_real_T *X, const emxArray_real_T *C, const
                      emxArray_int32_T *crows, int32_T ncrows)
{
  int32_T n;
  int32_T i;
  int32_T i19;
  int32_T i20;
  int32_T cr;
  int32_T r;
  real_T a;
  emlrtStack st;
  emlrtStack b_st;
  st.prev = sp;
  st.tls = sp->tls;
  b_st.prev = &st;
  b_st.tls = st.tls;
  n = X->size[0];
  st.site = &xd_emlrtRSI;
  if ((1 <= ncrows) && (ncrows > 2147483646)) {
    b_st.site = &fb_emlrtRSI;
    check_forloop_overflow_error(&b_st);
  }

  for (i = 0; i < ncrows; i++) {
    i19 = crows->size[0];
    i20 = 1 + i;
    if ((i20 < 1) || (i20 > i19)) {
      emlrtDynamicBoundsCheckR2012b(i20, 1, i19, &gd_emlrtBCI, sp);
    }

    cr = crows->data[i20 - 1];
    i19 = C->size[0];
    i20 = crows->data[i];
    if ((i20 < 1) || (i20 > i19)) {
      emlrtDynamicBoundsCheckR2012b(i20, 1, i19, &dd_emlrtBCI, sp);
    }

    st.site = &yd_emlrtRSI;
    if ((1 <= n) && (n > 2147483646)) {
      b_st.site = &fb_emlrtRSI;
      check_forloop_overflow_error(&b_st);
    }

    for (r = 0; r < n; r++) {
      st.site = &ae_emlrtRSI;
      i19 = X->size[0];
      i20 = 1 + r;
      if ((i20 < 1) || (i20 > i19)) {
        emlrtDynamicBoundsCheckR2012b(i20, 1, i19, &ed_emlrtBCI, &st);
      }

      a = X->data[i20 - 1] - C->data[cr - 1];
      b_st.site = &oc_emlrtRSI;
      i19 = D->size[0];
      i20 = 1 + r;
      if ((i20 < 1) || (i20 > i19)) {
        emlrtDynamicBoundsCheckR2012b(i20, 1, i19, &fd_emlrtBCI, &b_st);
      }

      i19 = D->size[1];
      if ((cr < 1) || (cr > i19)) {
        emlrtDynamicBoundsCheckR2012b(cr, 1, i19, &fd_emlrtBCI, &b_st);
      }

      D->data[(i20 + D->size[0] * (cr - 1)) - 1] = a * a;
    }
  }
}

static void batchUpdate(const emlrtStack *sp, const emxArray_real_T *X, int32_T
  k, emxArray_int32_T *idx, emxArray_real_T *C, emxArray_real_T *D,
  emxArray_int32_T *counts, boolean_T *converged, int32_T *iter)
{
  emxArray_int32_T *empties;
  int32_T n;
  int32_T i21;
  emxArray_int32_T *previdx;
  int32_T lonely;
  emxArray_int32_T *moved;
  emxArray_int32_T *changed;
  int32_T j;
  int32_T nchanged;
  real_T prevtotsumD;
  emxArray_real_T *d;
  emxArray_int32_T *nidx;
  emxArray_boolean_T *b;
  int32_T exitg1;
  int32_T nempty;
  int32_T i22;
  real_T maxd;
  int32_T i;
  int32_T b_i;
  int32_T from;
  int32_T cc;
  uint32_T unnamed_idx_0;
  boolean_T overflow;
  boolean_T exitg2;
  emlrtStack st;
  emlrtStack b_st;
  emlrtStack c_st;
  st.prev = sp;
  st.tls = sp->tls;
  b_st.prev = &st;
  b_st.tls = st.tls;
  c_st.prev = &b_st;
  c_st.tls = b_st.tls;
  emlrtHeapReferenceStackEnterFcnR2012b(sp);
  emxInit_int32_T(sp, &empties, 1, &jd_emlrtRTEI, true);
  n = X->size[0];
  i21 = empties->size[0];
  empties->size[0] = k;
  emxEnsureCapacity_int32_T(sp, empties, i21, &jd_emlrtRTEI);
  for (i21 = 0; i21 < k; i21++) {
    empties->data[i21] = 0;
  }

  emxInit_int32_T(sp, &previdx, 1, &kd_emlrtRTEI, true);
  i21 = previdx->size[0];
  previdx->size[0] = X->size[0];
  emxEnsureCapacity_int32_T(sp, previdx, i21, &kd_emlrtRTEI);
  lonely = X->size[0];
  for (i21 = 0; i21 < lonely; i21++) {
    previdx->data[i21] = 0;
  }

  emxInit_int32_T(sp, &moved, 1, &ld_emlrtRTEI, true);
  i21 = moved->size[0];
  moved->size[0] = X->size[0];
  emxEnsureCapacity_int32_T(sp, moved, i21, &ld_emlrtRTEI);
  lonely = X->size[0];
  for (i21 = 0; i21 < lonely; i21++) {
    moved->data[i21] = 0;
  }

  st.site = &he_emlrtRSI;
  if ((1 <= k) && (k > 2147483646)) {
    b_st.site = &fb_emlrtRSI;
    check_forloop_overflow_error(&b_st);
  }

  emxInit_int32_T(&st, &changed, 1, &qd_emlrtRTEI, true);
  i21 = changed->size[0];
  changed->size[0] = k;
  emxEnsureCapacity_int32_T(sp, changed, i21, &md_emlrtRTEI);
  for (j = 0; j < k; j++) {
    lonely = 1 + j;
    i21 = changed->size[0];
    if ((lonely < 1) || (lonely > i21)) {
      emlrtDynamicBoundsCheckR2012b(lonely, 1, i21, &md_emlrtBCI, sp);
    }

    changed->data[lonely - 1] = lonely;
  }

  nchanged = k;
  prevtotsumD = rtInf;
  *iter = 0;
  *converged = false;
  emxInit_real_T(sp, &d, 1, &rd_emlrtRTEI, true);
  emxInit_int32_T(sp, &nidx, 1, &xb_emlrtRTEI, true);
  emxInit_boolean_T(sp, &b, 1, &pd_emlrtRTEI, true);
  do {
    exitg1 = 0;
    (*iter)++;
    st.site = &ie_emlrtRSI;
    gcentroids(&st, C, counts, X, idx, changed, nchanged);
    st.site = &je_emlrtRSI;
    b_distfun(&st, D, X, C, changed, nchanged);
    st.site = &ke_emlrtRSI;
    nempty = 0;
    b_st.site = &cf_emlrtRSI;
    if ((1 <= nchanged) && (nchanged > 2147483646)) {
      c_st.site = &fb_emlrtRSI;
      check_forloop_overflow_error(&c_st);
    }

    for (j = 0; j < nchanged; j++) {
      lonely = 1 + j;
      i21 = counts->size[0];
      i22 = changed->size[0];
      if ((lonely < 1) || (lonely > i22)) {
        emlrtDynamicBoundsCheckR2012b(lonely, 1, i22, &nd_emlrtBCI, &st);
      }

      i22 = changed->data[lonely - 1];
      if ((i22 < 1) || (i22 > i21)) {
        emlrtDynamicBoundsCheckR2012b(i22, 1, i21, &nd_emlrtBCI, &st);
      }

      if (counts->data[i22 - 1] == 0) {
        nempty++;
        i21 = changed->size[0];
        if (lonely > i21) {
          emlrtDynamicBoundsCheckR2012b(lonely, 1, i21, &od_emlrtBCI, &st);
        }

        i21 = empties->size[0];
        if ((nempty < 1) || (nempty > i21)) {
          emlrtDynamicBoundsCheckR2012b(nempty, 1, i21, &pd_emlrtBCI, &st);
        }

        empties->data[nempty - 1] = changed->data[lonely - 1];
      }
    }

    if (nempty > 0) {
      st.site = &le_emlrtRSI;
      if (nempty > 2147483646) {
        b_st.site = &fb_emlrtRSI;
        check_forloop_overflow_error(&b_st);
      }

      for (i = 0; i < nempty; i++) {
        i21 = d->size[0];
        d->size[0] = n;
        emxEnsureCapacity_real_T(sp, d, i21, &xb_emlrtRTEI);
        i21 = d->size[0];
        if (1 > i21) {
          emlrtDynamicBoundsCheckR2012b(1, 1, i21, &jd_emlrtBCI, sp);
        }

        i21 = D->size[0];
        if (1 > i21) {
          emlrtDynamicBoundsCheckR2012b(1, 1, i21, &ld_emlrtBCI, sp);
        }

        i21 = idx->size[0];
        if (1 > i21) {
          emlrtDynamicBoundsCheckR2012b(1, 1, i21, &kd_emlrtBCI, sp);
        }

        i21 = D->size[1];
        i22 = idx->data[0];
        if ((i22 < 1) || (i22 > i21)) {
          emlrtDynamicBoundsCheckR2012b(i22, 1, i21, &rd_emlrtBCI, sp);
        }

        d->data[0] = D->data[D->size[0] * (i22 - 1)];
        i21 = d->size[0];
        if (1 > i21) {
          emlrtDynamicBoundsCheckR2012b(1, 1, i21, &id_emlrtBCI, sp);
        }

        maxd = d->data[0];
        lonely = 1;
        st.site = &me_emlrtRSI;
        if ((1 <= n) && (n > 2147483646)) {
          b_st.site = &fb_emlrtRSI;
          check_forloop_overflow_error(&b_st);
        }

        for (j = 0; j < n; j++) {
          i21 = D->size[0];
          i22 = 1 + j;
          if ((i22 < 1) || (i22 > i21)) {
            emlrtDynamicBoundsCheckR2012b(i22, 1, i21, &wd_emlrtBCI, sp);
          }

          i21 = D->size[1];
          b_i = idx->size[0];
          from = 1 + j;
          if ((from < 1) || (from > b_i)) {
            emlrtDynamicBoundsCheckR2012b(from, 1, b_i, &wd_emlrtBCI, sp);
          }

          b_i = idx->data[from - 1];
          if ((b_i < 1) || (b_i > i21)) {
            emlrtDynamicBoundsCheckR2012b(b_i, 1, i21, &wd_emlrtBCI, sp);
          }

          i21 = d->size[0];
          from = 1 + j;
          if ((from < 1) || (from > i21)) {
            emlrtDynamicBoundsCheckR2012b(from, 1, i21, &xd_emlrtBCI, sp);
          }

          d->data[from - 1] = D->data[(i22 + D->size[0] * (b_i - 1)) - 1];
          i21 = d->size[0];
          i22 = 1 + j;
          if ((i22 < 1) || (i22 > i21)) {
            emlrtDynamicBoundsCheckR2012b(i22, 1, i21, &be_emlrtBCI, sp);
          }

          if (d->data[i22 - 1] > maxd) {
            i21 = d->size[0];
            i22 = 1 + j;
            if ((i22 < 1) || (i22 > i21)) {
              emlrtDynamicBoundsCheckR2012b(i22, 1, i21, &ce_emlrtBCI, sp);
            }

            maxd = d->data[i22 - 1];
            lonely = 1 + j;
          }
        }

        i21 = idx->size[0];
        if ((lonely < 1) || (lonely > i21)) {
          emlrtDynamicBoundsCheckR2012b(lonely, 1, i21, &sd_emlrtBCI, sp);
        }

        from = idx->data[lonely - 1];
        i21 = counts->size[0];
        i22 = idx->data[lonely - 1];
        if ((i22 < 1) || (i22 > i21)) {
          emlrtDynamicBoundsCheckR2012b(i22, 1, i21, &vd_emlrtBCI, sp);
        }

        if (counts->data[i22 - 1] < 2) {
          st.site = &ne_emlrtRSI;
          j = 0;
          exitg2 = false;
          while ((!exitg2) && (j <= n - 1)) {
            i21 = counts->size[0];
            i22 = j + 1;
            if ((i22 < 1) || (i22 > i21)) {
              emlrtDynamicBoundsCheckR2012b(i22, 1, i21, &me_emlrtBCI, sp);
            }

            if (counts->data[i22 - 1] > 1) {
              from = j + 1;
              exitg2 = true;
            } else {
              j++;
            }
          }

          st.site = &oe_emlrtRSI;
          j = 0;
          exitg2 = false;
          while ((!exitg2) && (j <= n - 1)) {
            i21 = idx->size[0];
            i22 = j + 1;
            if ((i22 < 1) || (i22 > i21)) {
              emlrtDynamicBoundsCheckR2012b(i22, 1, i21, &oe_emlrtBCI, sp);
            }

            if (idx->data[i22 - 1] == from) {
              lonely = j + 1;
              exitg2 = true;
            } else {
              j++;
            }
          }
        }

        i21 = empties->size[0];
        i22 = 1 + i;
        if (i22 > i21) {
          emlrtDynamicBoundsCheckR2012b(i22, 1, i21, &hd_emlrtBCI, sp);
        }

        i21 = X->size[0];
        if ((lonely < 1) || (lonely > i21)) {
          emlrtDynamicBoundsCheckR2012b(lonely, 1, i21, &ge_emlrtBCI, sp);
        }

        i21 = C->size[0];
        i22 = empties->data[i];
        if ((i22 < 1) || (i22 > i21)) {
          emlrtDynamicBoundsCheckR2012b(i22, 1, i21, &he_emlrtBCI, sp);
        }

        C->data[i22 - 1] = X->data[lonely - 1];
        i21 = counts->size[0];
        i22 = empties->data[i];
        if ((i22 < 1) || (i22 > i21)) {
          emlrtDynamicBoundsCheckR2012b(i22, 1, i21, &ie_emlrtBCI, sp);
        }

        counts->data[i22 - 1] = 1;
        i21 = idx->size[0];
        if (lonely > i21) {
          emlrtDynamicBoundsCheckR2012b(lonely, 1, i21, &je_emlrtBCI, sp);
        }

        idx->data[lonely - 1] = empties->data[i];
        st.site = &pe_emlrtRSI;
        distfun(&st, D, X, C, empties->data[i]);
        st.site = &qe_emlrtRSI;
        lonely = X->size[0];
        b_st.site = &ye_emlrtRSI;
        i21 = counts->size[0];
        if ((from < 1) || (from > i21)) {
          emlrtDynamicBoundsCheckR2012b(from, 1, i21, &ve_emlrtBCI, &st);
        }

        counts->data[from - 1] = 0;
        i21 = C->size[0];
        if (from > i21) {
          emlrtDynamicBoundsCheckR2012b(from, 1, i21, &we_emlrtBCI, &st);
        }

        C->data[from - 1] = rtNaN;
        b_st.site = &af_emlrtRSI;
        cc = 0;
        i21 = C->size[0];
        if (from > i21) {
          emlrtDynamicBoundsCheckR2012b(from, 1, i21, &xe_emlrtBCI, &st);
        }

        C->data[from - 1] = 0.0;
        b_st.site = &bf_emlrtRSI;
        if ((1 <= lonely) && (lonely > 2147483646)) {
          c_st.site = &fb_emlrtRSI;
          check_forloop_overflow_error(&c_st);
        }

        for (b_i = 0; b_i < lonely; b_i++) {
          i21 = idx->size[0];
          i22 = 1 + b_i;
          if ((i22 < 1) || (i22 > i21)) {
            emlrtDynamicBoundsCheckR2012b(i22, 1, i21, &af_emlrtBCI, &st);
          }

          if (idx->data[i22 - 1] == from) {
            cc++;
            i21 = C->size[0];
            if (from > i21) {
              emlrtDynamicBoundsCheckR2012b(from, 1, i21, &df_emlrtBCI, &st);
            }

            i21 = C->size[0];
            if (from > i21) {
              emlrtDynamicBoundsCheckR2012b(from, 1, i21, &cf_emlrtBCI, &st);
            }

            i21 = X->size[0];
            i22 = 1 + b_i;
            if ((i22 < 1) || (i22 > i21)) {
              emlrtDynamicBoundsCheckR2012b(i22, 1, i21, &cf_emlrtBCI, &st);
            }

            C->data[from - 1] += X->data[i22 - 1];
          }
        }

        i21 = counts->size[0];
        if (from > i21) {
          emlrtDynamicBoundsCheckR2012b(from, 1, i21, &ye_emlrtBCI, &st);
        }

        counts->data[from - 1] = cc;
        i21 = C->size[0];
        if (from > i21) {
          emlrtDynamicBoundsCheckR2012b(from, 1, i21, &bf_emlrtBCI, &st);
        }

        i21 = C->size[0];
        if (from > i21) {
          emlrtDynamicBoundsCheckR2012b(from, 1, i21, &cf_emlrtBCI, &st);
        }

        C->data[from - 1] /= (real_T)cc;
        st.site = &re_emlrtRSI;
        distfun(&st, D, X, C, from);
        if (nchanged < k) {
          st.site = &se_emlrtRSI;
          j = 0;
          exitg2 = false;
          while ((!exitg2) && (j <= nchanged - 1)) {
            lonely = j + 1;
            i21 = changed->size[0];
            i22 = j + 1;
            if ((i22 < 1) || (i22 > i21)) {
              emlrtDynamicBoundsCheckR2012b(i22, 1, i21, &qe_emlrtBCI, sp);
            }

            if (from == changed->data[i22 - 1]) {
              exitg2 = true;
            } else {
              i21 = changed->size[0];
              i22 = j + 1;
              if ((i22 < 1) || (i22 > i21)) {
                emlrtDynamicBoundsCheckR2012b(i22, 1, i21, &re_emlrtBCI, sp);
              }

              if (from > changed->data[i22 - 1]) {
                for (cc = nchanged; cc >= lonely; cc--) {
                  i21 = changed->size[0];
                  if ((cc < 1) || (cc > i21)) {
                    emlrtDynamicBoundsCheckR2012b(cc, 1, i21, &te_emlrtBCI, sp);
                  }

                  i21 = changed->size[0];
                  i22 = cc + 1;
                  if (i22 > i21) {
                    emlrtDynamicBoundsCheckR2012b(i22, 1, i21, &ue_emlrtBCI, sp);
                  }

                  changed->data[i22 - 1] = changed->data[cc - 1];
                }

                i21 = changed->size[0];
                i22 = j + 1;
                if ((i22 < 1) || (i22 > i21)) {
                  emlrtDynamicBoundsCheckR2012b(i22, 1, i21, &se_emlrtBCI, sp);
                }

                changed->data[i22 - 1] = from;
                nchanged++;
                exitg2 = true;
              } else {
                j++;
              }
            }
          }
        }
      }
    }

    maxd = 0.0;
    st.site = &te_emlrtRSI;
    if ((1 <= n) && (n > 2147483646)) {
      b_st.site = &fb_emlrtRSI;
      check_forloop_overflow_error(&b_st);
    }

    for (i = 0; i < n; i++) {
      i21 = D->size[0];
      i22 = 1 + i;
      if ((i22 < 1) || (i22 > i21)) {
        emlrtDynamicBoundsCheckR2012b(i22, 1, i21, &qd_emlrtBCI, sp);
      }

      i21 = D->size[1];
      b_i = idx->size[0];
      from = 1 + i;
      if ((from < 1) || (from > b_i)) {
        emlrtDynamicBoundsCheckR2012b(from, 1, b_i, &qd_emlrtBCI, sp);
      }

      b_i = idx->data[from - 1];
      if ((b_i < 1) || (b_i > i21)) {
        emlrtDynamicBoundsCheckR2012b(b_i, 1, i21, &qd_emlrtBCI, sp);
      }

      maxd += D->data[(i22 + D->size[0] * (b_i - 1)) - 1];
    }

    if (prevtotsumD <= maxd) {
      i21 = idx->size[0];
      idx->size[0] = previdx->size[0];
      emxEnsureCapacity_int32_T(sp, idx, i21, &nd_emlrtRTEI);
      lonely = previdx->size[0];
      for (i21 = 0; i21 < lonely; i21++) {
        idx->data[i21] = previdx->data[i21];
      }

      st.site = &ue_emlrtRSI;
      gcentroids(&st, C, counts, X, previdx, changed, nchanged);
      (*iter)--;
      exitg1 = 1;
    } else if (*iter >= 100) {
      exitg1 = 1;
    } else {
      i21 = previdx->size[0];
      previdx->size[0] = idx->size[0];
      emxEnsureCapacity_int32_T(sp, previdx, i21, &od_emlrtRTEI);
      lonely = idx->size[0];
      for (i21 = 0; i21 < lonely; i21++) {
        previdx->data[i21] = idx->data[i21];
      }

      prevtotsumD = maxd;
      st.site = &ve_emlrtRSI;
      mindim2(&st, D, d, nidx);
      cc = 0;
      st.site = &we_emlrtRSI;
      for (i = 0; i < n; i++) {
        i21 = nidx->size[0];
        i22 = 1 + i;
        if ((i22 < 1) || (i22 > i21)) {
          emlrtDynamicBoundsCheckR2012b(i22, 1, i21, &td_emlrtBCI, sp);
        }

        i21 = previdx->size[0];
        b_i = 1 + i;
        if ((b_i < 1) || (b_i > i21)) {
          emlrtDynamicBoundsCheckR2012b(b_i, 1, i21, &ud_emlrtBCI, sp);
        }

        if (nidx->data[i22 - 1] != previdx->data[b_i - 1]) {
          i21 = D->size[0];
          i22 = 1 + i;
          if ((i22 < 1) || (i22 > i21)) {
            emlrtDynamicBoundsCheckR2012b(i22, 1, i21, &yd_emlrtBCI, sp);
          }

          i21 = D->size[1];
          b_i = previdx->size[0];
          from = 1 + i;
          if ((from < 1) || (from > b_i)) {
            emlrtDynamicBoundsCheckR2012b(from, 1, b_i, &yd_emlrtBCI, sp);
          }

          b_i = previdx->data[from - 1];
          if ((b_i < 1) || (b_i > i21)) {
            emlrtDynamicBoundsCheckR2012b(b_i, 1, i21, &yd_emlrtBCI, sp);
          }

          i21 = d->size[0];
          from = 1 + i;
          if ((from < 1) || (from > i21)) {
            emlrtDynamicBoundsCheckR2012b(from, 1, i21, &ae_emlrtBCI, sp);
          }

          if (D->data[(i22 + D->size[0] * (b_i - 1)) - 1] > d->data[from - 1]) {
            cc++;
            i21 = moved->size[0];
            if ((cc < 1) || (cc > i21)) {
              emlrtDynamicBoundsCheckR2012b(cc, 1, i21, &de_emlrtBCI, sp);
            }

            moved->data[cc - 1] = 1 + i;
            i21 = nidx->size[0];
            i22 = 1 + i;
            if ((i22 < 1) || (i22 > i21)) {
              emlrtDynamicBoundsCheckR2012b(i22, 1, i21, &ee_emlrtBCI, sp);
            }

            i21 = idx->size[0];
            b_i = 1 + i;
            if ((b_i < 1) || (b_i > i21)) {
              emlrtDynamicBoundsCheckR2012b(b_i, 1, i21, &fe_emlrtBCI, sp);
            }

            idx->data[b_i - 1] = nidx->data[i22 - 1];
          }
        }
      }

      if (cc == 0) {
        *converged = true;
        exitg1 = 1;
      } else {
        st.site = &xe_emlrtRSI;
        unnamed_idx_0 = (uint32_T)moved->size[0];
        i21 = b->size[0];
        b->size[0] = (int32_T)unnamed_idx_0;
        emxEnsureCapacity_boolean_T(&st, b, i21, &pd_emlrtRTEI);
        lonely = (int32_T)unnamed_idx_0;
        for (i21 = 0; i21 < lonely; i21++) {
          b->data[i21] = false;
        }

        b_st.site = &df_emlrtRSI;
        if (cc > 2147483646) {
          c_st.site = &fb_emlrtRSI;
          check_forloop_overflow_error(&c_st);
        }

        for (j = 0; j < cc; j++) {
          i21 = b->size[0];
          i22 = idx->size[0];
          b_i = moved->size[0];
          from = 1 + j;
          if (from > b_i) {
            emlrtDynamicBoundsCheckR2012b(from, 1, b_i, &ke_emlrtBCI, &st);
          }

          b_i = moved->data[from - 1];
          if ((b_i < 1) || (b_i > i22)) {
            emlrtDynamicBoundsCheckR2012b(b_i, 1, i22, &ke_emlrtBCI, &st);
          }

          i22 = idx->data[b_i - 1];
          if ((i22 < 1) || (i22 > i21)) {
            emlrtDynamicBoundsCheckR2012b(i22, 1, i21, &ke_emlrtBCI, &st);
          }

          b->data[i22 - 1] = true;
          i21 = b->size[0];
          i22 = previdx->size[0];
          b_i = moved->size[0];
          from = 1 + j;
          if (from > b_i) {
            emlrtDynamicBoundsCheckR2012b(from, 1, b_i, &le_emlrtBCI, &st);
          }

          b_i = moved->data[from - 1];
          if ((b_i < 1) || (b_i > i22)) {
            emlrtDynamicBoundsCheckR2012b(b_i, 1, i22, &le_emlrtBCI, &st);
          }

          i22 = previdx->data[b_i - 1];
          if ((i22 < 1) || (i22 > i21)) {
            emlrtDynamicBoundsCheckR2012b(i22, 1, i21, &le_emlrtBCI, &st);
          }

          b->data[i22 - 1] = true;
        }

        nchanged = 0;
        lonely = b->size[0];
        b_st.site = &ef_emlrtRSI;
        overflow = ((1 <= b->size[0]) && (b->size[0] > 2147483646));
        if (overflow) {
          c_st.site = &fb_emlrtRSI;
          check_forloop_overflow_error(&c_st);
        }

        for (j = 0; j < lonely; j++) {
          i21 = b->size[0];
          i22 = 1 + j;
          if ((i22 < 1) || (i22 > i21)) {
            emlrtDynamicBoundsCheckR2012b(i22, 1, i21, &ne_emlrtBCI, &st);
          }

          if (b->data[i22 - 1]) {
            nchanged++;
            i21 = changed->size[0];
            if ((nchanged < 1) || (nchanged > i21)) {
              emlrtDynamicBoundsCheckR2012b(nchanged, 1, i21, &pe_emlrtBCI, &st);
            }

            changed->data[nchanged - 1] = 1 + j;
          }
        }
      }
    }
  } while (exitg1 == 0);

  emxFree_boolean_T(&b);
  emxFree_int32_T(&nidx);
  emxFree_real_T(&d);
  emxFree_int32_T(&changed);
  emxFree_int32_T(&moved);
  emxFree_int32_T(&previdx);
  emxFree_int32_T(&empties);
  emlrtHeapReferenceStackLeaveFcnR2012b(sp);
}

static void distfun(const emlrtStack *sp, emxArray_real_T *D, const
                    emxArray_real_T *X, const emxArray_real_T *C, int32_T crows)
{
  int32_T n;
  int32_T i17;
  int32_T r;
  int32_T i18;
  real_T a;
  emlrtStack st;
  emlrtStack b_st;
  st.prev = sp;
  st.tls = sp->tls;
  b_st.prev = &st;
  b_st.tls = st.tls;
  n = X->size[0];
  st.site = &xd_emlrtRSI;
  i17 = C->size[0];
  if ((crows < 1) || (crows > i17)) {
    emlrtDynamicBoundsCheckR2012b(crows, 1, i17, &dd_emlrtBCI, sp);
  }

  st.site = &yd_emlrtRSI;
  if ((1 <= n) && (n > 2147483646)) {
    b_st.site = &fb_emlrtRSI;
    check_forloop_overflow_error(&b_st);
  }

  for (r = 0; r < n; r++) {
    st.site = &ae_emlrtRSI;
    i17 = X->size[0];
    i18 = 1 + r;
    if ((i18 < 1) || (i18 > i17)) {
      emlrtDynamicBoundsCheckR2012b(i18, 1, i17, &ed_emlrtBCI, &st);
    }

    a = X->data[i18 - 1] - C->data[crows - 1];
    b_st.site = &oc_emlrtRSI;
    i17 = D->size[0];
    i18 = 1 + r;
    if ((i18 < 1) || (i18 > i17)) {
      emlrtDynamicBoundsCheckR2012b(i18, 1, i17, &fd_emlrtBCI, &b_st);
    }

    i17 = D->size[1];
    if (crows > i17) {
      emlrtDynamicBoundsCheckR2012b(crows, 1, i17, &fd_emlrtBCI, &b_st);
    }

    D->data[(i18 + D->size[0] * (crows - 1)) - 1] = a * a;
  }
}

static void e_error(const emlrtStack *sp, const mxArray *b, emlrtMCInfo
                    *location)
{
  const mxArray *pArray;
  pArray = b;
  emlrtCallMATLABR2012b(sp, 0, NULL, 1, &pArray, "error", true, location);
}

static void gcentroids(const emlrtStack *sp, emxArray_real_T *C,
  emxArray_int32_T *counts, const emxArray_real_T *X, const emxArray_int32_T
  *idx, const emxArray_int32_T *clusters, int32_T nclusters)
{
  int32_T n;
  int32_T ic;
  int32_T clic;
  int32_T i23;
  int32_T i24;
  int32_T cc;
  int32_T i;
  emlrtStack st;
  emlrtStack b_st;
  st.prev = sp;
  st.tls = sp->tls;
  b_st.prev = &st;
  b_st.tls = st.tls;
  n = X->size[0];
  st.site = &ye_emlrtRSI;
  if ((1 <= nclusters) && (nclusters > 2147483646)) {
    b_st.site = &fb_emlrtRSI;
    check_forloop_overflow_error(&b_st);
  }

  for (ic = 0; ic < nclusters; ic++) {
    clic = 1 + ic;
    i23 = counts->size[0];
    i24 = clusters->size[0];
    if ((clic < 1) || (clic > i24)) {
      emlrtDynamicBoundsCheckR2012b(clic, 1, i24, &ve_emlrtBCI, sp);
    }

    i24 = clusters->data[clic - 1];
    if ((i24 < 1) || (i24 > i23)) {
      emlrtDynamicBoundsCheckR2012b(i24, 1, i23, &ve_emlrtBCI, sp);
    }

    counts->data[i24 - 1] = 0;
    i23 = C->size[0];
    i24 = clusters->size[0];
    if (clic > i24) {
      emlrtDynamicBoundsCheckR2012b(clic, 1, i24, &we_emlrtBCI, sp);
    }

    i24 = clusters->data[clic - 1];
    if ((i24 < 1) || (i24 > i23)) {
      emlrtDynamicBoundsCheckR2012b(i24, 1, i23, &we_emlrtBCI, sp);
    }

    C->data[i24 - 1] = rtNaN;
  }

  st.site = &af_emlrtRSI;
  for (ic = 0; ic < nclusters; ic++) {
    i23 = clusters->size[0];
    i24 = 1 + ic;
    if ((i24 < 1) || (i24 > i23)) {
      emlrtDynamicBoundsCheckR2012b(i24, 1, i23, &ef_emlrtBCI, sp);
    }

    clic = clusters->data[i24 - 1];
    cc = 0;
    i23 = C->size[0];
    i24 = clusters->data[ic];
    if ((i24 < 1) || (i24 > i23)) {
      emlrtDynamicBoundsCheckR2012b(i24, 1, i23, &xe_emlrtBCI, sp);
    }

    C->data[i24 - 1] = 0.0;
    st.site = &bf_emlrtRSI;
    if ((1 <= n) && (n > 2147483646)) {
      b_st.site = &fb_emlrtRSI;
      check_forloop_overflow_error(&b_st);
    }

    for (i = 0; i < n; i++) {
      i23 = idx->size[0];
      i24 = 1 + i;
      if ((i24 < 1) || (i24 > i23)) {
        emlrtDynamicBoundsCheckR2012b(i24, 1, i23, &af_emlrtBCI, sp);
      }

      if (idx->data[i24 - 1] == clic) {
        cc++;
        i23 = C->size[0];
        if ((clic < 1) || (clic > i23)) {
          emlrtDynamicBoundsCheckR2012b(clic, 1, i23, &gf_emlrtBCI, sp);
        }

        i23 = X->size[0];
        i24 = 1 + i;
        if ((i24 < 1) || (i24 > i23)) {
          emlrtDynamicBoundsCheckR2012b(i24, 1, i23, &hf_emlrtBCI, sp);
        }

        i23 = C->size[0];
        if (clic > i23) {
          emlrtDynamicBoundsCheckR2012b(clic, 1, i23, &df_emlrtBCI, sp);
        }

        C->data[clic - 1] += X->data[i24 - 1];
      }
    }

    i23 = counts->size[0];
    i24 = clusters->data[ic];
    if ((i24 < 1) || (i24 > i23)) {
      emlrtDynamicBoundsCheckR2012b(i24, 1, i23, &ye_emlrtBCI, sp);
    }

    counts->data[i24 - 1] = cc;
    i23 = C->size[0];
    i24 = clusters->data[ic];
    if ((i24 < 1) || (i24 > i23)) {
      emlrtDynamicBoundsCheckR2012b(i24, 1, i23, &ff_emlrtBCI, sp);
    }

    i23 = C->size[0];
    clic = clusters->data[ic];
    if ((clic < 1) || (clic > i23)) {
      emlrtDynamicBoundsCheckR2012b(clic, 1, i23, &bf_emlrtBCI, sp);
    }

    C->data[clic - 1] = C->data[i24 - 1] / (real_T)cc;
  }
}

static void local_kmeans(const emlrtStack *sp, const emxArray_real_T *X, int32_T
  k, emxArray_int32_T *idxbest, emxArray_real_T *Cbest)
{
  int32_T n;
  real_T b_index;
  int32_T i5;
  emxArray_real_T *D;
  int32_T i6;
  int32_T high_i;
  emxArray_real_T *d;
  emxArray_real_T *sampleDist;
  boolean_T DNeedsComputing;
  int32_T c;
  boolean_T exitg1;
  emxArray_int32_T *crows;
  int32_T mid_i;
  int32_T low_ip1;
  int32_T i7;
  emxArray_int32_T *nonEmpties;
  int32_T low_i;
  real_T pt;
  real_T u;
  boolean_T exitg2;
  boolean_T exitg3;
  emlrtStack st;
  emlrtStack b_st;
  emlrtStack c_st;
  st.prev = sp;
  st.tls = sp->tls;
  b_st.prev = &st;
  b_st.tls = st.tls;
  c_st.prev = &b_st;
  c_st.tls = b_st.tls;
  emlrtHeapReferenceStackEnterFcnR2012b(sp);
  st.site = &bd_emlrtRSI;
  n = X->size[0];
  if (k < 0) {
    emlrtNonNegativeCheckR2012b(k, &emlrtDCI, &st);
  }

  b_st.site = &cd_emlrtRSI;
  b_index = b_rand();
  i5 = Cbest->size[0];
  Cbest->size[0] = k;
  emxEnsureCapacity_real_T(&st, Cbest, i5, &hb_emlrtRTEI);
  for (i5 = 0; i5 < k; i5++) {
    Cbest->data[i5] = 0.0;
  }

  emxInit_real_T(&st, &D, 2, &ub_emlrtRTEI, true);
  if (1 > k) {
    emlrtDynamicBoundsCheckR2012b(1, 1, k, &n_emlrtBCI, &st);
  }

  i5 = X->size[0];
  b_index = 1.0 + muDoubleScalarFloor(b_index * (real_T)X->size[0]);
  if (b_index != (int32_T)b_index) {
    emlrtIntegerCheckR2012b(b_index, &b_emlrtDCI, &st);
  }

  i6 = (int32_T)b_index;
  if ((i6 < 1) || (i6 > i5)) {
    emlrtDynamicBoundsCheckR2012b(i6, 1, i5, &q_emlrtBCI, &st);
  }

  Cbest->data[0] = X->data[i6 - 1];
  i5 = D->size[0] * D->size[1];
  D->size[0] = X->size[0];
  D->size[1] = k;
  emxEnsureCapacity_real_T(&st, D, i5, &ib_emlrtRTEI);
  high_i = X->size[0] * k;
  for (i5 = 0; i5 < high_i; i5++) {
    D->data[i5] = 0.0;
  }

  emxInit_real_T(&st, &d, 1, &sb_emlrtRTEI, true);
  b_st.site = &dd_emlrtRSI;
  distfun(&b_st, D, X, Cbest, 1);
  i5 = D->size[1];
  if (1 > i5) {
    emlrtDynamicBoundsCheckR2012b(1, 1, i5, &o_emlrtBCI, &st);
  }

  high_i = D->size[0];
  i5 = d->size[0];
  d->size[0] = high_i;
  emxEnsureCapacity_real_T(&st, d, i5, &jb_emlrtRTEI);
  for (i5 = 0; i5 < high_i; i5++) {
    d->data[i5] = D->data[i5];
  }

  i5 = idxbest->size[0];
  idxbest->size[0] = X->size[0];
  emxEnsureCapacity_int32_T(&st, idxbest, i5, &kb_emlrtRTEI);
  high_i = X->size[0];
  for (i5 = 0; i5 < high_i; i5++) {
    idxbest->data[i5] = 1;
  }

  emxInit_real_T(&st, &sampleDist, 1, &lb_emlrtRTEI, true);
  i5 = sampleDist->size[0];
  sampleDist->size[0] = X->size[0] + 1;
  emxEnsureCapacity_real_T(&st, sampleDist, i5, &lb_emlrtRTEI);
  high_i = X->size[0];
  for (i5 = 0; i5 <= high_i; i5++) {
    sampleDist->data[i5] = 0.0;
  }

  DNeedsComputing = false;
  b_st.site = &ed_emlrtRSI;
  if ((2 <= k) && (k > 2147483646)) {
    c_st.site = &fb_emlrtRSI;
    check_forloop_overflow_error(&c_st);
  }

  c = 2;
  exitg1 = false;
  while ((!exitg1) && (c <= k)) {
    b_index = 0.0;
    sampleDist->data[0] = 0.0;
    b_st.site = &fd_emlrtRSI;
    if ((1 <= n) && (n > 2147483646)) {
      c_st.site = &fb_emlrtRSI;
      check_forloop_overflow_error(&c_st);
    }

    for (mid_i = 0; mid_i < n; mid_i++) {
      i5 = sampleDist->size[0];
      i6 = 1 + mid_i;
      if ((i6 < 1) || (i6 > i5)) {
        emlrtDynamicBoundsCheckR2012b(i6, 1, i5, &r_emlrtBCI, &st);
      }

      i5 = d->size[0];
      i7 = 1 + mid_i;
      if ((i7 < 1) || (i7 > i5)) {
        emlrtDynamicBoundsCheckR2012b(i7, 1, i5, &s_emlrtBCI, &st);
      }

      i5 = sampleDist->size[0];
      low_i = mid_i + 2;
      if ((low_i < 1) || (low_i > i5)) {
        emlrtDynamicBoundsCheckR2012b(low_i, 1, i5, &t_emlrtBCI, &st);
      }

      sampleDist->data[low_i - 1] = sampleDist->data[i6 - 1] + d->data[i7 - 1];
      i5 = d->size[0];
      i6 = 1 + mid_i;
      if ((i6 < 1) || (i6 > i5)) {
        emlrtDynamicBoundsCheckR2012b(i6, 1, i5, &u_emlrtBCI, &st);
      }

      b_index += d->data[i6 - 1];
    }

    if ((b_index == 0.0) || (muDoubleScalarIsInf(b_index) || muDoubleScalarIsNaN
         (b_index))) {
      b_st.site = &gd_emlrtRSI;
      low_ip1 = k - c;
      mid_i = 0;
      i5 = idxbest->size[0];
      idxbest->size[0] = n;
      emxEnsureCapacity_int32_T(&b_st, idxbest, i5, &qb_emlrtRTEI);
      for (i5 = 0; i5 < n; i5++) {
        idxbest->data[i5] = 0;
      }

      for (low_i = 0; low_i <= low_ip1; low_i++) {
        high_i = (low_ip1 - low_i) + 1;
        b_index = n - mid_i;
        pt = (real_T)high_i / b_index;
        u = b_rand();
        while (u > pt) {
          mid_i++;
          b_index--;
          pt += (1.0 - pt) * ((real_T)high_i / b_index);
        }

        mid_i++;
        b_index = b_rand() * ((real_T)low_i + 1.0);
        b_index = muDoubleScalarFloor(b_index);
        i5 = idxbest->size[0];
        i6 = (int32_T)b_index + 1;
        if ((i6 < 1) || (i6 > i5)) {
          emlrtDynamicBoundsCheckR2012b(i6, 1, i5, &eb_emlrtBCI, &b_st);
        }

        i5 = idxbest->size[0];
        i7 = low_i + 1;
        if (i7 > i5) {
          emlrtDynamicBoundsCheckR2012b(i7, 1, i5, &fb_emlrtBCI, &b_st);
        }

        idxbest->data[i7 - 1] = idxbest->data[i6 - 1];
        i5 = idxbest->size[0];
        i6 = (int32_T)b_index + 1;
        if ((i6 < 1) || (i6 > i5)) {
          emlrtDynamicBoundsCheckR2012b(i6, 1, i5, &hb_emlrtBCI, &b_st);
        }

        idxbest->data[i6 - 1] = mid_i;
      }

      b_st.site = &hd_emlrtRSI;
      for (mid_i = c; mid_i <= k; mid_i++) {
        i5 = X->size[0];
        i6 = idxbest->size[0];
        i7 = (mid_i - c) + 1;
        if ((i7 < 1) || (i7 > i6)) {
          emlrtDynamicBoundsCheckR2012b(i7, 1, i6, &q_emlrtBCI, &st);
        }

        i6 = idxbest->data[i7 - 1];
        if ((i6 < 1) || (i6 > i5)) {
          emlrtDynamicBoundsCheckR2012b(i6, 1, i5, &q_emlrtBCI, &st);
        }

        i5 = Cbest->size[0];
        if (mid_i > i5) {
          emlrtDynamicBoundsCheckR2012b(mid_i, 1, i5, &ib_emlrtBCI, &st);
        }

        Cbest->data[mid_i - 1] = X->data[i6 - 1];
      }

      DNeedsComputing = true;
      exitg1 = true;
    } else {
      i5 = sampleDist->size[0];
      emxEnsureCapacity_real_T(&st, sampleDist, i5, &ob_emlrtRTEI);
      high_i = sampleDist->size[0];
      for (i5 = 0; i5 < high_i; i5++) {
        sampleDist->data[i5] /= b_index;
      }

      b_st.site = &id_emlrtRSI;
      b_index = b_rand();
      high_i = sampleDist->size[0];
      low_i = 1;
      low_ip1 = 2;
      while (high_i > low_ip1) {
        mid_i = (low_i >> 1) + (high_i >> 1);
        if (((low_i & 1) == 1) && ((high_i & 1) == 1)) {
          mid_i++;
        }

        if (b_index >= sampleDist->data[mid_i - 1]) {
          low_i = mid_i;
          low_ip1 = mid_i + 1;
        } else {
          high_i = mid_i;
        }
      }

      i5 = sampleDist->size[0];
      if ((low_i < 1) || (low_i > i5)) {
        emlrtDynamicBoundsCheckR2012b(low_i, 1, i5, &y_emlrtBCI, &st);
      }

      b_index = sampleDist->data[low_i - 1];
      if (sampleDist->data[low_i - 1] < 1.0) {
        exitg3 = false;
        while ((!exitg3) && (low_i <= n)) {
          i5 = sampleDist->size[0];
          i6 = low_i + 1;
          if ((i6 < 1) || (i6 > i5)) {
            emlrtDynamicBoundsCheckR2012b(i6, 1, i5, &bb_emlrtBCI, &st);
          }

          if (sampleDist->data[i6 - 1] <= b_index) {
            low_i++;
          } else {
            exitg3 = true;
          }
        }
      } else {
        exitg2 = false;
        while ((!exitg2) && (low_i >= 2)) {
          i5 = sampleDist->size[0];
          i6 = low_i - 1;
          if (i6 > i5) {
            emlrtDynamicBoundsCheckR2012b(i6, 1, i5, &ab_emlrtBCI, &st);
          }

          if (sampleDist->data[i6 - 1] >= b_index) {
            low_i--;
          } else {
            exitg2 = true;
          }
        }
      }

      i5 = X->size[0];
      if ((low_i < 1) || (low_i > i5)) {
        emlrtDynamicBoundsCheckR2012b(low_i, 1, i5, &q_emlrtBCI, &st);
      }

      i5 = Cbest->size[0];
      if (c > i5) {
        emlrtDynamicBoundsCheckR2012b(c, 1, i5, &db_emlrtBCI, &st);
      }

      Cbest->data[c - 1] = X->data[low_i - 1];
      b_st.site = &jd_emlrtRSI;
      distfun(&b_st, D, X, Cbest, c);
      b_st.site = &kd_emlrtRSI;
      for (mid_i = 0; mid_i < n; mid_i++) {
        i5 = D->size[0];
        i6 = 1 + mid_i;
        if ((i6 < 1) || (i6 > i5)) {
          emlrtDynamicBoundsCheckR2012b(i6, 1, i5, &lb_emlrtBCI, &st);
        }

        i5 = D->size[1];
        if (c > i5) {
          emlrtDynamicBoundsCheckR2012b(c, 1, i5, &lb_emlrtBCI, &st);
        }

        i5 = d->size[0];
        i7 = 1 + mid_i;
        if ((i7 < 1) || (i7 > i5)) {
          emlrtDynamicBoundsCheckR2012b(i7, 1, i5, &mb_emlrtBCI, &st);
        }

        if (D->data[(i6 + D->size[0] * (c - 1)) - 1] < d->data[i7 - 1]) {
          i5 = D->size[0];
          i6 = 1 + mid_i;
          if ((i6 < 1) || (i6 > i5)) {
            emlrtDynamicBoundsCheckR2012b(i6, 1, i5, &nb_emlrtBCI, &st);
          }

          i5 = D->size[1];
          if (c > i5) {
            emlrtDynamicBoundsCheckR2012b(c, 1, i5, &nb_emlrtBCI, &st);
          }

          i5 = d->size[0];
          i7 = 1 + mid_i;
          if ((i7 < 1) || (i7 > i5)) {
            emlrtDynamicBoundsCheckR2012b(i7, 1, i5, &ob_emlrtBCI, &st);
          }

          d->data[i7 - 1] = D->data[(i6 + D->size[0] * (c - 1)) - 1];
          i5 = idxbest->size[0];
          i6 = 1 + mid_i;
          if ((i6 < 1) || (i6 > i5)) {
            emlrtDynamicBoundsCheckR2012b(i6, 1, i5, &pb_emlrtBCI, &st);
          }

          idxbest->data[i6 - 1] = c;
        }
      }

      c++;
    }
  }

  emxInit_int32_T(&st, &crows, 1, &tb_emlrtRTEI, true);
  if (DNeedsComputing) {
    b_st.site = &ld_emlrtRSI;
    i5 = crows->size[0];
    crows->size[0] = k;
    emxEnsureCapacity_int32_T(&st, crows, i5, &nb_emlrtRTEI);
    for (c = 0; c < k; c++) {
      i5 = crows->size[0];
      i6 = 1 + c;
      if (i6 > i5) {
        emlrtDynamicBoundsCheckR2012b(i6, 1, i5, &x_emlrtBCI, &st);
      }

      crows->data[i6 - 1] = 1 + c;
    }

    b_st.site = &md_emlrtRSI;
    b_distfun(&b_st, D, X, Cbest, crows, k);
    b_st.site = &nd_emlrtRSI;
    mindim2(&b_st, D, d, idxbest);
  }

  i5 = crows->size[0];
  crows->size[0] = k;
  emxEnsureCapacity_int32_T(&st, crows, i5, &mb_emlrtRTEI);
  for (i5 = 0; i5 < k; i5++) {
    crows->data[i5] = 0;
  }

  b_st.site = &od_emlrtRSI;
  DNeedsComputing = ((1 <= X->size[0]) && (X->size[0] > 2147483646));
  if (DNeedsComputing) {
    c_st.site = &fb_emlrtRSI;
    check_forloop_overflow_error(&c_st);
  }

  for (mid_i = 0; mid_i < n; mid_i++) {
    i5 = crows->size[0];
    i6 = idxbest->size[0];
    i7 = 1 + mid_i;
    if ((i7 < 1) || (i7 > i6)) {
      emlrtDynamicBoundsCheckR2012b(i7, 1, i6, &v_emlrtBCI, &st);
    }

    i6 = idxbest->data[i7 - 1];
    if ((i6 < 1) || (i6 > i5)) {
      emlrtDynamicBoundsCheckR2012b(i6, 1, i5, &v_emlrtBCI, &st);
    }

    i5 = crows->size[0];
    i7 = idxbest->size[0];
    low_i = 1 + mid_i;
    if ((low_i < 1) || (low_i > i7)) {
      emlrtDynamicBoundsCheckR2012b(low_i, 1, i7, &w_emlrtBCI, &st);
    }

    i7 = idxbest->data[low_i - 1];
    if ((i7 < 1) || (i7 > i5)) {
      emlrtDynamicBoundsCheckR2012b(i7, 1, i5, &w_emlrtBCI, &st);
    }

    crows->data[i7 - 1] = crows->data[i6 - 1] + 1;
  }

  emxInit_int32_T(&st, &nonEmpties, 1, &pb_emlrtRTEI, true);
  i5 = nonEmpties->size[0];
  nonEmpties->size[0] = k;
  emxEnsureCapacity_int32_T(&st, nonEmpties, i5, &pb_emlrtRTEI);
  for (i5 = 0; i5 < k; i5++) {
    nonEmpties->data[i5] = 0;
  }

  b_st.site = &pd_emlrtRSI;
  batchUpdate(&b_st, X, k, idxbest, Cbest, D, crows, &DNeedsComputing, &high_i);
  if (!DNeedsComputing) {
    b_st.site = &qd_emlrtRSI;
    d_warning(&b_st);
  }

  high_i = 0;
  b_st.site = &rd_emlrtRSI;
  for (mid_i = 0; mid_i < k; mid_i++) {
    i5 = crows->size[0];
    i6 = 1 + mid_i;
    if (i6 > i5) {
      emlrtDynamicBoundsCheckR2012b(i6, 1, i5, &cb_emlrtBCI, &st);
    }

    if (crows->data[i6 - 1] > 0) {
      high_i++;
      i5 = nonEmpties->size[0];
      if ((high_i < 1) || (high_i > i5)) {
        emlrtDynamicBoundsCheckR2012b(high_i, 1, i5, &gb_emlrtBCI, &st);
      }

      nonEmpties->data[high_i - 1] = 1 + mid_i;
    }
  }

  emxFree_int32_T(&crows);
  b_st.site = &sd_emlrtRSI;
  b_distfun(&b_st, D, X, Cbest, nonEmpties, high_i);
  b_st.site = &td_emlrtRSI;
  DNeedsComputing = ((1 <= X->size[0]) && (X->size[0] > 2147483646));
  if (DNeedsComputing) {
    c_st.site = &fb_emlrtRSI;
    check_forloop_overflow_error(&c_st);
  }

  for (mid_i = 0; mid_i < n; mid_i++) {
    i5 = D->size[0];
    i6 = 1 + mid_i;
    if ((i6 < 1) || (i6 > i5)) {
      emlrtDynamicBoundsCheckR2012b(i6, 1, i5, &jb_emlrtBCI, &st);
    }

    i5 = D->size[1];
    i7 = idxbest->size[0];
    low_i = 1 + mid_i;
    if ((low_i < 1) || (low_i > i7)) {
      emlrtDynamicBoundsCheckR2012b(low_i, 1, i7, &jb_emlrtBCI, &st);
    }

    i7 = idxbest->data[low_i - 1];
    if ((i7 < 1) || (i7 > i5)) {
      emlrtDynamicBoundsCheckR2012b(i7, 1, i5, &jb_emlrtBCI, &st);
    }

    i5 = d->size[0];
    low_i = 1 + mid_i;
    if ((low_i < 1) || (low_i > i5)) {
      emlrtDynamicBoundsCheckR2012b(low_i, 1, i5, &kb_emlrtBCI, &st);
    }

    d->data[low_i - 1] = D->data[(i6 + D->size[0] * (i7 - 1)) - 1];
  }

  emxFree_real_T(&D);
  i5 = sampleDist->size[0];
  sampleDist->size[0] = k;
  emxEnsureCapacity_real_T(&st, sampleDist, i5, &rb_emlrtRTEI);
  for (i5 = 0; i5 < k; i5++) {
    sampleDist->data[i5] = 0.0;
  }

  b_st.site = &ud_emlrtRSI;
  DNeedsComputing = ((1 <= X->size[0]) && (X->size[0] > 2147483646));
  if (DNeedsComputing) {
    c_st.site = &fb_emlrtRSI;
    check_forloop_overflow_error(&c_st);
  }

  for (mid_i = 0; mid_i < n; mid_i++) {
    i5 = sampleDist->size[0];
    i6 = idxbest->size[0];
    i7 = 1 + mid_i;
    if ((i7 < 1) || (i7 > i6)) {
      emlrtDynamicBoundsCheckR2012b(i7, 1, i6, &qb_emlrtBCI, &st);
    }

    i6 = idxbest->data[i7 - 1];
    if ((i6 < 1) || (i6 > i5)) {
      emlrtDynamicBoundsCheckR2012b(i6, 1, i5, &qb_emlrtBCI, &st);
    }

    i5 = d->size[0];
    i7 = 1 + mid_i;
    if ((i7 < 1) || (i7 > i5)) {
      emlrtDynamicBoundsCheckR2012b(i7, 1, i5, &rb_emlrtBCI, &st);
    }

    i5 = sampleDist->size[0];
    low_i = idxbest->size[0];
    low_ip1 = 1 + mid_i;
    if ((low_ip1 < 1) || (low_ip1 > low_i)) {
      emlrtDynamicBoundsCheckR2012b(low_ip1, 1, low_i, &sb_emlrtBCI, &st);
    }

    low_i = idxbest->data[low_ip1 - 1];
    if ((low_i < 1) || (low_i > i5)) {
      emlrtDynamicBoundsCheckR2012b(low_i, 1, i5, &sb_emlrtBCI, &st);
    }

    sampleDist->data[low_i - 1] = sampleDist->data[i6 - 1] + d->data[i7 - 1];
  }

  emxFree_real_T(&d);
  b_st.site = &vd_emlrtRSI;
  if ((1 <= high_i) && (high_i > 2147483646)) {
    c_st.site = &fb_emlrtRSI;
    check_forloop_overflow_error(&c_st);
  }

  for (mid_i = 0; mid_i < high_i; mid_i++) {
    i5 = sampleDist->size[0];
    i6 = nonEmpties->size[0];
    i7 = 1 + mid_i;
    if (i7 > i6) {
      emlrtDynamicBoundsCheckR2012b(i7, 1, i6, &p_emlrtBCI, &st);
    }

    i6 = nonEmpties->data[i7 - 1];
    if ((i6 < 1) || (i6 > i5)) {
      emlrtDynamicBoundsCheckR2012b(i6, 1, i5, &p_emlrtBCI, &st);
    }
  }

  emxFree_int32_T(&nonEmpties);
  emxFree_real_T(&sampleDist);
  emlrtHeapReferenceStackLeaveFcnR2012b(sp);
}

static void mindim2(const emlrtStack *sp, const emxArray_real_T *D,
                    emxArray_real_T *d, emxArray_int32_T *idx)
{
  int32_T n;
  int32_T k;
  int32_T outsize_idx_0;
  int32_T i8;
  const mxArray *y;
  const mxArray *m28;
  static const int32_T iv20[2] = { 1, 15 };

  static const char_T u[15] = { 'M', 'A', 'T', 'L', 'A', 'B', ':', 'p', 'm', 'a',
    'x', 's', 'i', 'z', 'e' };

  boolean_T overflow;
  int32_T i;
  int32_T i9;
  int32_T i10;
  int32_T i11;
  emlrtStack st;
  emlrtStack b_st;
  st.prev = sp;
  st.tls = sp->tls;
  b_st.prev = &st;
  b_st.tls = st.tls;
  n = D->size[0];
  k = D->size[1];
  st.site = &de_emlrtRSI;
  b_st.site = &ge_emlrtRSI;
  outsize_idx_0 = D->size[0];
  if (outsize_idx_0 != D->size[0]) {
    y = NULL;
    m28 = emlrtCreateCharArray(2, iv20);
    emlrtInitCharArrayR2013a(&st, 15, m28, &u[0]);
    emlrtAssign(&y, m28);
    b_st.site = &vf_emlrtRSI;
    e_error(&b_st, y, &e_emlrtMCI);
  }

  i8 = d->size[0];
  d->size[0] = outsize_idx_0;
  emxEnsureCapacity_real_T(&st, d, i8, &vb_emlrtRTEI);
  for (i8 = 0; i8 < outsize_idx_0; i8++) {
    d->data[i8] = rtInf;
  }

  i8 = idx->size[0];
  idx->size[0] = D->size[0];
  emxEnsureCapacity_int32_T(sp, idx, i8, &wb_emlrtRTEI);
  outsize_idx_0 = D->size[0];
  for (i8 = 0; i8 < outsize_idx_0; i8++) {
    idx->data[i8] = 1;
  }

  st.site = &ee_emlrtRSI;
  overflow = ((1 <= D->size[1]) && (D->size[1] > 2147483646));
  if (overflow) {
    b_st.site = &fb_emlrtRSI;
    check_forloop_overflow_error(&b_st);
  }

  for (outsize_idx_0 = 0; outsize_idx_0 < k; outsize_idx_0++) {
    st.site = &fe_emlrtRSI;
    if ((1 <= n) && (n > 2147483646)) {
      b_st.site = &fb_emlrtRSI;
      check_forloop_overflow_error(&b_st);
    }

    for (i = 0; i < n; i++) {
      i8 = D->size[0];
      i9 = 1 + i;
      if ((i9 < 1) || (i9 > i8)) {
        emlrtDynamicBoundsCheckR2012b(i9, 1, i8, &tb_emlrtBCI, sp);
      }

      i8 = D->size[1];
      i10 = 1 + outsize_idx_0;
      if ((i10 < 1) || (i10 > i8)) {
        emlrtDynamicBoundsCheckR2012b(i10, 1, i8, &tb_emlrtBCI, sp);
      }

      i8 = d->size[0];
      i11 = 1 + i;
      if ((i11 < 1) || (i11 > i8)) {
        emlrtDynamicBoundsCheckR2012b(i11, 1, i8, &ub_emlrtBCI, sp);
      }

      if (D->data[(i9 + D->size[0] * (i10 - 1)) - 1] < d->data[i11 - 1]) {
        i8 = idx->size[0];
        i9 = 1 + i;
        if ((i9 < 1) || (i9 > i8)) {
          emlrtDynamicBoundsCheckR2012b(i9, 1, i8, &vb_emlrtBCI, sp);
        }

        idx->data[i9 - 1] = 1 + outsize_idx_0;
        i8 = D->size[0];
        i9 = 1 + i;
        if ((i9 < 1) || (i9 > i8)) {
          emlrtDynamicBoundsCheckR2012b(i9, 1, i8, &wb_emlrtBCI, sp);
        }

        i8 = D->size[1];
        i10 = 1 + outsize_idx_0;
        if ((i10 < 1) || (i10 > i8)) {
          emlrtDynamicBoundsCheckR2012b(i10, 1, i8, &wb_emlrtBCI, sp);
        }

        i8 = d->size[0];
        i11 = 1 + i;
        if ((i11 < 1) || (i11 > i8)) {
          emlrtDynamicBoundsCheckR2012b(i11, 1, i8, &xb_emlrtBCI, sp);
        }

        d->data[i11 - 1] = D->data[(i9 + D->size[0] * (i10 - 1)) - 1];
      }
    }
  }
}

void kmeans(const emlrtStack *sp, emxArray_real_T *X, real_T kin,
            emxArray_real_T *idxbest, emxArray_real_T *Cbest)
{
  int32_T n;
  int32_T i3;
  emxArray_boolean_T *wasnan;
  int32_T j;
  boolean_T hadnans;
  boolean_T overflow;
  int32_T i;
  emxArray_int32_T *idx;
  int32_T i4;
  int32_T end;
  emxArray_real_T *b_X;
  emlrtStack st;
  emlrtStack b_st;
  st.prev = sp;
  st.tls = sp->tls;
  b_st.prev = &st;
  b_st.tls = st.tls;
  emlrtHeapReferenceStackEnterFcnR2012b(sp);
  n = X->size[0];
  if (!(kin <= X->size[0])) {
    emlrtErrorWithMessageIdR2018a(sp, &xd_emlrtRTEI,
      "stats:kmeans:TooManyClusters", "stats:kmeans:TooManyClusters", 0);
  }

  i3 = (int32_T)kin;
  if ((i3 > 0) && (i3 == kin)) {
  } else {
    emlrtErrorWithMessageIdR2018a(sp, &yd_emlrtRTEI, "stats:kmeans:InvalidK",
      "stats:kmeans:InvalidK", 0);
  }

  if (i3 > X->size[0]) {
    emlrtErrorWithMessageIdR2018a(sp, &ae_emlrtRTEI,
      "Coder:builtins:AssertionFailed", "Coder:builtins:AssertionFailed", 0);
  }

  emxInit_boolean_T(sp, &wasnan, 1, &cb_emlrtRTEI, true);
  i3 = wasnan->size[0];
  wasnan->size[0] = X->size[0];
  emxEnsureCapacity_boolean_T(sp, wasnan, i3, &cb_emlrtRTEI);
  j = X->size[0];
  for (i3 = 0; i3 < j; i3++) {
    wasnan->data[i3] = false;
  }

  hadnans = false;
  st.site = &wc_emlrtRSI;
  overflow = ((1 <= X->size[0]) && (X->size[0] > 2147483646));
  if (overflow) {
    b_st.site = &fb_emlrtRSI;
    check_forloop_overflow_error(&b_st);
  }

  for (i = 0; i < n; i++) {
    i3 = X->size[0];
    i4 = i + 1;
    if ((i4 < 1) || (i4 > i3)) {
      emlrtDynamicBoundsCheckR2012b(i4, 1, i3, &g_emlrtBCI, sp);
    }

    if (muDoubleScalarIsNaN(X->data[i])) {
      hadnans = true;
      i3 = wasnan->size[0];
      i4 = i + 1;
      if ((i4 < 1) || (i4 > i3)) {
        emlrtDynamicBoundsCheckR2012b(i4, 1, i3, &h_emlrtBCI, sp);
      }

      wasnan->data[i4 - 1] = true;
    }
  }

  emxInit_int32_T(sp, &idx, 1, &eb_emlrtRTEI, true);
  if (hadnans) {
    st.site = &xc_emlrtRSI;
    c_warning(&st);
    end = wasnan->size[0] - 1;
    j = 0;
    for (i = 0; i <= end; i++) {
      if (!wasnan->data[i]) {
        j++;
      }
    }

    i3 = idx->size[0];
    idx->size[0] = j;
    emxEnsureCapacity_int32_T(sp, idx, i3, &eb_emlrtRTEI);
    j = 0;
    for (i = 0; i <= end; i++) {
      if (!wasnan->data[i]) {
        idx->data[j] = i + 1;
        j++;
      }
    }

    emxInit_real_T(sp, &b_X, 1, &eb_emlrtRTEI, true);
    i3 = X->size[0];
    i4 = b_X->size[0];
    b_X->size[0] = idx->size[0];
    emxEnsureCapacity_real_T(sp, b_X, i4, &eb_emlrtRTEI);
    j = idx->size[0];
    for (i4 = 0; i4 < j; i4++) {
      end = idx->data[i4];
      if ((end < 1) || (end > i3)) {
        emlrtDynamicBoundsCheckR2012b(end, 1, i3, &i_emlrtBCI, sp);
      }

      b_X->data[i4] = X->data[end - 1];
    }

    i3 = X->size[0];
    X->size[0] = b_X->size[0];
    emxEnsureCapacity_real_T(sp, X, i3, &gb_emlrtRTEI);
    j = b_X->size[0];
    for (i3 = 0; i3 < j; i3++) {
      X->data[i3] = b_X->data[i3];
    }

    emxFree_real_T(&b_X);
  }

  st.site = &yc_emlrtRSI;
  local_kmeans(&st, X, (int32_T)kin, idx, Cbest);
  if (hadnans) {
    j = 0;
    st.site = &ad_emlrtRSI;
    if ((1 <= n) && (n > 2147483646)) {
      b_st.site = &fb_emlrtRSI;
      check_forloop_overflow_error(&b_st);
    }

    i3 = idxbest->size[0];
    idxbest->size[0] = n;
    emxEnsureCapacity_real_T(sp, idxbest, i3, &fb_emlrtRTEI);
    for (i = 0; i < n; i++) {
      i3 = wasnan->size[0];
      i4 = 1 + i;
      if ((i4 < 1) || (i4 > i3)) {
        emlrtDynamicBoundsCheckR2012b(i4, 1, i3, &j_emlrtBCI, sp);
      }

      if (wasnan->data[i4 - 1]) {
        i3 = idxbest->size[0];
        i4 = 1 + i;
        if ((i4 < 1) || (i4 > i3)) {
          emlrtDynamicBoundsCheckR2012b(i4, 1, i3, &k_emlrtBCI, sp);
        }

        idxbest->data[i4 - 1] = rtNaN;
      } else {
        j++;
        i3 = idx->size[0];
        if ((j < 1) || (j > i3)) {
          emlrtDynamicBoundsCheckR2012b(j, 1, i3, &l_emlrtBCI, sp);
        }

        i3 = idxbest->size[0];
        i4 = 1 + i;
        if ((i4 < 1) || (i4 > i3)) {
          emlrtDynamicBoundsCheckR2012b(i4, 1, i3, &m_emlrtBCI, sp);
        }

        idxbest->data[i4 - 1] = idx->data[j - 1];
      }
    }
  } else {
    i3 = idxbest->size[0];
    idxbest->size[0] = idx->size[0];
    emxEnsureCapacity_real_T(sp, idxbest, i3, &db_emlrtRTEI);
    j = idx->size[0];
    for (i3 = 0; i3 < j; i3++) {
      idxbest->data[i3] = idx->data[i3];
    }
  }

  emxFree_int32_T(&idx);
  emxFree_boolean_T(&wasnan);
  emlrtHeapReferenceStackLeaveFcnR2012b(sp);
}

/* End of code generation (kmeans.c) */
