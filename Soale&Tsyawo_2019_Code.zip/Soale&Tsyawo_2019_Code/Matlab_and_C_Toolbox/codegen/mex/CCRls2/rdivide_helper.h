/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * rdivide_helper.h
 *
 * Code generation for function 'rdivide_helper'
 *
 */

#ifndef RDIVIDE_HELPER_H
#define RDIVIDE_HELPER_H

/* Include files */
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "tmwtypes.h"
#include "mex.h"
#include "emlrt.h"
#include "rtwtypes.h"
#include "CCRls2_types.h"

/* Function Declarations */
extern void rdivide_helper(const emxArray_uint32_T *x, uint32_T y,
  emxArray_uint32_T *z);

#endif

/* End of code generation (rdivide_helper.h) */
