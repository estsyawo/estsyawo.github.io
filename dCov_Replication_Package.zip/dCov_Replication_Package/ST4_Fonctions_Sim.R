cor.UV<- -0.2
Sig.X<- matrix(cor.UV,2,2); Sig.X[1,1]=Sig.X[2,2]=1
#==============================================================================>
# 
gdat.0a<- function(n,R,theta.0){

  datl=list()
  for (l in 1:R){
    set.seed(l) #set seed
    X=mvrnorm(n=n,mu=rep(0,2),Sigma = Sig.X)
    Y = X%*%theta.0 + rnorm(n)
    datl[[l]]<- list(Y=Y,X=X,Z=X)
  }
  datl
}
#==============================================================================>
gdat.0b<- function(n,R,theta.0){
  datl=list(); eps=0.3
  for (l in 1:R) {
    set.seed(l) #set seed
    X=mvrnorm(n=n,mu=rep(0,2),Sigma = Sig.X)
    Y = theta.0[1]*X[,1] + theta.0[2]*X[,2] + rcauchy(n,scale = 0.1+abs(X[,1]))
    datl[[l]]<- list(Y=Y,X=X,Z=X)
  }
  datl
}
#==============================================================================>
# 
gdat.1a<- function(n,R,theta.0){
  datl=list()
  for (l in 1:R){
    set.seed(l) #set seed
    U=(rchisq(n,df=1)-1)/sqrt(2)
    V=cor.UV*U + sqrt(1-cor.UV^2)*runif(n,-sqrt(3),sqrt(3))
    X=mvrnorm(n=n,mu=rep(0,2),Sigma = Sig.X)
    D = X[,1] + V
    Y = theta.0[1]*D + theta.0[2]*X[,2] + U
    datl[[l]]<- list(Y=Y,X=cbind(D,X[,2]),Z=cbind(1*(abs(X[,1])< -qnorm(1/4)),X[,2]))
  }
  datl
}
#==============================================================================>
# 
gdat.1b<- function(n,R,theta.0){
  datl=list()
  for (l in 1:R){
    set.seed(l) #set seed
    U=(rchisq(n,df=1)-1)/sqrt(2)
    V=cor.UV*U + sqrt(1-cor.UV^2)*runif(n,-sqrt(3),sqrt(3))
    X=mvrnorm(n=n,mu=rep(0,2),Sigma = Sig.X)
    D = 1*(V < -abs(X[,1]) -qnorm(1/4))
    Y = theta.0[1]*D + theta.0[2]*X[,2] + U
    datl[[l]]<- list(Y=Y,X=cbind(D,X[,2]),Z=X)
  }
  datl
}
#==============================================================================>
# 
gdat.1c<- function(n,R,theta.0){
  datl=list()
  for (l in 1:R){
    set.seed(l) #set seed
    U=rnorm(n)
    V=cor.UV*U + sqrt(1-cor.UV^2)*runif(n,-sqrt(3),sqrt(3))
    X=mvrnorm(n=n,mu=rep(0,2),Sigma = Sig.X)
    D = X[,1] + V
    Y = theta.0[1]*D + theta.0[2]*X[,2] + U/(0.1+abs(X[,1]))
    datl[[l]]<- list(Y=Y,X=cbind(D,X[,2]),Z=X)
  }
  datl
}
#==============================================================================>
# 
gdat.2a<- function(n,R,theta.0){
  datl=list()
  for (l in 1:R){
    set.seed(l) #set seed
    U=(rchisq(n,df=1)-1)/sqrt(2)
    V=cor.UV*U + sqrt(1-cor.UV^2)*runif(n,-sqrt(3),sqrt(3))
    Dstar=rnorm(n=n); D = Dstar + V
    Z = 0.2*Dstar + Dstar^2
    Y = theta.0[1]*D + theta.0[2]*Z + U
    datl[[l]]<- list(Y=Y,X=cbind(D,Z),Z=Z)
  }
  datl
}
#==============================================================================>
# 
gdat.2b<- function(n,R,theta.0){
  datl=list()
  for (l in 1:R){
    set.seed(l) #set seed
    U=(rchisq(n,df=1)-1)/sqrt(2)
    X=mvrnorm(n=n,mu=rep(0,2),Sigma = diag(1,2))
    X = X/sqrt(X[,1]^2 + X[,2]^2) #implicitly expressing X2(X1)
    D = X[,1] + 0.2*U
    Y = theta.0[1]*D + theta.0[2]*X[,2] + U
    datl[[l]]<- list(Y=Y,X=cbind(D,X[,2]),Z=X[,2])
  }
  datl
}
#==============================================================================>
# 
gdat.3<- function(n,R,theta.0){
  datl=list()
  for (l in 1:R){
    set.seed(l) #set seed
    U=(rchisq(n,df=1)-1)/sqrt(2)
    Z=rnorm(n=n)
    D = 0.2*U + runif(n,-sqrt(3),sqrt(3))*Z^2
    Y = theta.0[1]*D + theta.0[2]*Z + U
    datl[[l]]<- list(Y=Y,X=cbind(D,Z),Z=Z)
  }
  datl
}
#==============================================================================>
gdat.nl_1a<- function(n,R,theta.0){
  
  datl=list()
  for (l in 1:R){
    set.seed(l) #set seed
    X=rnorm(n=n)
    Y = X*(theta.0[1]^2) + (X^2)*theta.0[1] + rnorm(n)
    datl[[l]]<- list(Y=Y,X=X,Z=X)
  }
  datl
}

#==============================================================================>

gdat.nl_1b<- function(n,R,theta.0){
  
  datl=list()
  for (l in 1:R){
    set.seed(l) #set seed
    X=rnorm(n=n,mean = 1)
    Y = X*(theta.0[1]^2) + (X^2)*theta.0[1] + rnorm(n)
    datl[[l]]<- list(Y=Y,X=X,Z=X)
  }
  datl
}

#==============================================================================>

gdat.nl_1c<- function(n,R,theta.0){
  
  datl=list()
  for (l in 1:R){
    set.seed(l) #set seed
    X=rnorm(n=n,mean = 1)
    Y = X*(theta.0[1]^2) + (X^2)*theta.0[1] + rpareto(n,1,1)/pi
    datl[[l]]<- list(Y=Y,X=X,Z=X)
  }
  datl
}
#==============================================================================>


#==============================================================================>
# 
gdat.nl_2a<- function(n,R,theta.0){
  
  datl=list()
  for (l in 1:R){
    set.seed(l) #set seed
    X=rnorm(n=n)
    U= rchisq(n,1)/sqrt(2)
    Y = exp(cbind(X,1)%*%theta.0)  + U
    datl[[l]]<- list(Y=Y,X=X,Z=X)
  }
  datl
}

#==============================================================================>

gdat.nl_2b<- function(n,R,theta.0){
  
  datl=list()
  for (l in 1:R){
    set.seed(l) #set seed
    X=rnorm(n=n)
    Y = exp(cbind(X,1)%*%theta.0) + rpareto(n,1,1)/pi
    datl[[l]]<- list(Y=Y,X=X,Z=X)
  }
  datl
}
#==============================================================================>


#==============================================================================>
MCfun.0<- function(j=NULL,datl,b,se="ker",Rmat=NULL,cZmat=F,strtpar=NULL){
  dat<- datl[[j]]
  
    tryCatch(
      expr = {
        if(cZmat){Zmat=energy::U_center(as.matrix(dat$Z))}else{Zmat=NULL}
        obj.MDep<- mdepreg.fit(Y=dat$Y,X=as.matrix(dat$X),Z=as.matrix(dat$Z),
                               se=se,Rmat=Rmat,Zmat=Zmat,strtpar=strtpar)
        bias.MDep<- obj.MDep$coefficients[1] - b
        tstat.MDep<- bias.MDep/obj.MDep$std.error[1]
        size.MDep<- 1*(abs(tstat.MDep)>qnorm(0.975))
        res.MDep<- c(bias.MDep,tstat.MDep,size.MDep)
        names(res.MDep)<- c("bias.MDep","tstat.MDep","size.MDep")
        
        obj.MMD<- imlmreg2.fit(Y=dat$Y,X=as.matrix(dat$X),Z=as.matrix(dat$Z))
        bias.MMD<- obj.MMD$coefficients[2] - b
        tstat.MMD<- bias.MMD/obj.MMD$HC_Std.Err[2]
        size.MMD<- 1*(abs(tstat.MMD)>qnorm(0.975))
        res.MMD<- c(bias.MMD,tstat.MMD,size.MMD)
        names(res.MMD)<- c("bias.MMD","tstat.MMD","size.MMD")
        
        obj.ESC6<- imlmreg2.fit(Y=dat$Y,X=as.matrix(dat$X),Z=as.matrix(dat$Z),
                                Kern = "Esc6")
        bias.ESC6<- obj.ESC6$coefficients[2] - b
        tstat.ESC6<- bias.ESC6/obj.ESC6$HC_Std.Err[2]
        size.ESC6<- 1*(abs(tstat.ESC6)>qnorm(0.975))
        res.ESC6<- c(bias.ESC6,tstat.ESC6,size.ESC6)
        names(res.ESC6)<- c("bias.ESC6","tstat.ESC6","size.ESC6")
        
        obj.TSLS<- ivreg(dat$Y~as.matrix(dat$X)|as.matrix(dat$Z))
        bias.TSLS<- obj.TSLS$coefficients[2] - b
        obj.TSLS$std.error<- sqrt(diag(vcovHC(obj.TSLS)))
        tstat.TSLS<- bias.TSLS/obj.TSLS$std.error[2]
        size.TSLS<- 1*(abs(tstat.TSLS)>qnorm(0.975))
        res.TSLS<- c(bias.TSLS,tstat.TSLS,size.TSLS)
        names(res.TSLS)<- c("bias.TSLS","tstat.TSLS","size.TSLS")
      
        return(c(res.MDep,res.MMD,res.ESC6,res.TSLS))
      },
      error = function(e){return(rep(NA,12))},
      warning = function(w){return(rep(NA,12))},
      finally = { }
    )#end tryCatch
}
#-------------------------------------------------------------------------------
MCfun.1<- function(j=NULL,datl,b,se="ker",Rmat=NULL,cZmat=F,strtpar=NULL){
  dat<- datl[[j]]
  tryCatch(
    expr = {
      if(cZmat){Zmat=energy::U_center(as.matrix(dist(dat$Z)))}else{Zmat=NULL}
      obj.MDep<- mdepreg.fit(Y=dat$Y,X=as.matrix(dat$X),Z=as.matrix(dat$Z),
                             se=se,Rmat=Rmat,Zmat=Zmat,strtpar=strtpar)
      bias.MDep<- obj.MDep$coefficients[1] - b
      tstat.MDep<- bias.MDep/obj.MDep$std.error[1]
      size.MDep<- 1*(abs(tstat.MDep)>qnorm(0.975))
      res.MDep<- c(bias.MDep,tstat.MDep,size.MDep)
      names(res.MDep)<- c("bias.MDep","tstat.MDep","size.MDep")
      
      obj.MMD<- imlmreg2.fit(Y=dat$Y,X=as.matrix(dat$X),Z=as.matrix(dat$Z))
      bias.MMD<- obj.MMD$coefficients[2] - b
      tstat.MMD<- bias.MMD/obj.MMD$HC_Std.Err[2]
      size.MMD<- 1*(abs(tstat.MMD)>qnorm(0.975))
      res.MMD<- c(bias.MMD,tstat.MMD,size.MMD)
      names(res.MMD)<- c("bias.MMD","tstat.MMD","size.MMD")
      
      obj.ESC6<- imlmreg2.fit(Y=dat$Y,X=as.matrix(dat$X),Z=as.matrix(dat$Z),
                              Kern = "Esc6")
      bias.ESC6<- obj.ESC6$coefficients[2] - b
      tstat.ESC6<- bias.ESC6/obj.ESC6$HC_Std.Err[2]
      size.ESC6<- 1*(abs(tstat.ESC6)>qnorm(0.975))
      res.ESC6<- c(bias.ESC6,tstat.ESC6,size.ESC6)
      names(res.ESC6)<- c("bias.ESC6","tstat.ESC6","size.ESC6")
      
      return(c(res.MDep,res.MMD,res.ESC6))
    },
    error = function(e){return(rep(NA,9))},
    warning = function(w){return(rep(NA,9))},
    finally = { }
  )#end tryCatch
  
}
#==============================================================================>


#==============================================================================>
MCfun.2<- function(j=NULL,datl,b,Intercept=F,strtpar=NULL,u.fun,Xg.fun,Rmat=NULL,
                   se="ker",B=999){
  dat<- datl[[j]]
  tryCatch(
    expr = {
      obj.MDep<- mdepreg.fit2(u.fun=u.fun,Xg.fun=Xg.fun,Y=dat$Y,X=as.matrix(dat$X)
                              ,Z=as.matrix(dat$Z),Intercept=Intercept,strtpar=strtpar,
                              Rmat=Rmat,se=se,B=B)
      bias.MDep<- obj.MDep$coefficients[1] - b
      tstat.MDep<- bias.MDep/obj.MDep$std.error[1]
      size.MDep<- 1*(abs(tstat.MDep)>qnorm(0.975))
      res.MDep<- c(bias.MDep,tstat.MDep,size.MDep)
      names(res.MDep)<- c("bias.MDep","tstat.MDep","size.MDep")
      
      if(length(strtpar)==1){strtpar.ICM=as.list(strtpar+c(-1.5,1.5))
      }else{strtpar.ICM=strtpar}
      
      obj.SJK<- imnlmreg.fit(strtpar=strtpar.ICM,u.fun=u.fun,Xg.fun=Xg.fun,Y=dat$Y,
                            X=as.matrix(dat$X),Z=as.matrix(dat$Z),Intercept=Intercept,
                            Kern="Euclid")
      bias.SJK<- obj.SJK$coefficients[1] - b
      tstat.SJK<- bias.SJK/obj.SJK$HC_Std.Err[1]
      size.SJK<- 1*(abs(tstat.SJK)>qnorm(0.975))
      res.SJK<- c(bias.SJK,tstat.SJK,size.SJK)
      names(res.SJK)<- c("bias.SJK","tstat.SJK","size.SJK")
      
      obj.DL<- imnlmreg.fit(strtpar=strtpar.ICM,u.fun=u.fun,Xg.fun=Xg.fun,Y=dat$Y,
                            X=as.matrix(dat$X),Z=as.matrix(dat$Z),Intercept=Intercept,
                            Kern="DL")
      bias.DL<- obj.DL$coefficients[1] - b
      tstat.DL<- bias.DL/obj.DL$HC_Std.Err[1]
      size.DL<- 1*(abs(tstat.DL)>qnorm(0.975))
      res.DL<- c(bias.DL,tstat.DL,size.DL)
      names(res.DL)<- c("bias.DL","tstat.DL","size.DL")
      # 
      obj.ESC6<- imnlmreg.fit(strtpar=strtpar.ICM,u.fun=u.fun,Xg.fun=Xg.fun,Y=dat$Y,
                            X=as.matrix(dat$X),Z=as.matrix(dat$Z),Intercept=Intercept,
                            Kern="Esc6")
      bias.ESC6<- obj.ESC6$coefficients[1] - b
      tstat.ESC6<- bias.ESC6/obj.ESC6$HC_Std.Err[1]
      size.ESC6<- 1*(abs(tstat.ESC6)>qnorm(0.975))
      res.ESC6<- c(bias.ESC6,tstat.ESC6,size.ESC6)
      names(res.ESC6)<- c("bias.ESC6","tstat.ESC6","size.ESC6")
      
      return(c(res.MDep,res.SJK,res.DL,res.ESC6
      ))
    },
    error = function(e){return(rep(NA,12))},
    warning = function(w){return(rep(NA,12))},
    finally = { }
  )#end tryCatch
  
}
#==============================================================================>


#=====================================================================================>
#the following function ensures printing to exactly nsmall decimal places
print.fn<-function(x,nsmall=3) cat(paste(format(x,nsmall=nsmall),collapse=" &"),
                                   paste("\\","\\",sep=""),"\n")
#=====================================================================================>
RMSE<- function(x) sqrt(mean(x^2,na.rm=T))
#=====================================================================================>
res.fun<- function(res.mat,est.names=NULL,LaTeX=F){
  n.est<- nrow(res.mat)/3
  id.est<- 1 + (0:(n.est-1))*3
  
  Med.t<- apply(res.mat[id.est+1,],1,median,na.rm=T)
  MAD.B<- apply(abs(res.mat[id.est,]),1,median,na.rm=T)
  RMSE.B<- apply(res.mat[id.est,],1,RMSE)
  Rej.<- apply(res.mat[id.est+2,],1,mean,na.rm=T)
  res<- round(cbind(Med.t,MAD.B,RMSE.B,Rej.),3)
  
  if(is.null(est.names)){
    rownames(res)<- c("MDep","MMD","ESC6","TSLS")[1:n.est]
  }else{
    rownames(res)<- est.names[1:n.est]
  }
  colnames(res)<- c("Med.t","MAD","RMSE","Rej.")
  
  if(!LaTeX){
    cat("\n");print(res);cat("\n")
  }else{
    cat("\n");apply(cbind(rownames(res),res),1,print.fn,nsmall=3);cat("\n")
  }
  res
}
#----------------------
res.fun2<- function(res.mat.list,est.names=NULL,LaTeX=F,outfile="outfile.txt"){
  L = length(res.mat.list)
  res = res.fun(res.mat=res.mat.list[[1]],est.names=est.names,LaTeX=F)
  if(L>1){
    for (l in 2:L){
      res<- cbind(res,res.fun(res.mat=res.mat.list[[l]],est.names=est.names,LaTeX=F))
      }
  }
  
  sink(outfile)
  cat("\n");apply(cbind(rownames(res),res),1,print.fn,nsmall=3);cat("\n")
  sink()
}
#==============================================================================>
gSim = function(n.vec,gdat,MCfun,est.names=NULL,se="ker",B=999,cZmat=F,
                strtpar=NULL,outfile="outfile.txt",cl,R,theta.0){
  res.mat.list = list()
  for (l in 1:length(n.vec)) {
    datl<- gdat(n=n.vec[l],R=R,theta.0 = theta.0); b = theta.0[1]
    if(se=="boot"){set.seed(0); n=n.vec[l]
      Rmat = matrix(sample(1:n,n*B,replace = TRUE),n,B) #matrix to store randomly drawn matrices
    }else{Rmat=NULL}
    res.mat.list[[l]]<- pbsapply(1:R, FUN=MCfun,cl=cl,datl=datl,b=b,se=se,
                                 Rmat=Rmat,cZmat=cZmat,strtpar=strtpar)
    print(apply(res.mat.list[[l]],1,mean,na.rm=T))
  }
  res.fun2(res.mat.list,est.names=est.names,LaTeX=F,outfile=outfile)
}

#==============================================================================>
gSim2 = function(n.vec,gdat,se="ker",u.fun,Xg.fun,MCfun,Intercept=F,strtpar=NULL,
                 outfile="outfile.txt",cl,R,theta.0,B=999,est.names=NULL){
  res.mat.list = list()
  for (l in 1:length(n.vec)) {
    datl<- gdat(n=n.vec[l],R=R,theta.0 = theta.0); b = theta.0[1]
    if(se=="boot"){set.seed(0); n=n.vec[l]
    Rmat = matrix(sample(1:n,n*B,replace = TRUE),n,B) #matrix to store randomly drawn matrices
    }else{Rmat=NULL}
    
    res.mat.list[[l]]<- pbsapply(1:R, FUN=MCfun,u.fun=u.fun,Xg.fun=Xg.fun,
                                 Intercept=Intercept,cl=cl,
                                 datl=datl,b=b,strtpar=strtpar,Rmat=Rmat,se=se,B=B)
    print(apply(res.mat.list[[l]],1,mean,na.rm=T))
  }
  res.fun2(res.mat.list,est.names=est.names,LaTeX=F,outfile=outfile)
}
#=====================================================================================>
print.res.file<- function(res.mat,outfile="outfile.txt"){

  sink(outfile)
  res.fun(res.mat,LaTeX = T)
  sink()
  
}
#=====================================================================================>

