function [bets,klus, RSS0]=cordlinopt_clus2(Y,X,k,nC,bets,Xdot,clus)
%% use coordinate descent to estimate linear regression
% and incorporate covariate clustering into k clusters.

%% inputs:
% Y - vector of outcome variable
% X - matrix of p covariates, including 1's for intercept
% k - number of clusters
% nC - the first nC covariates in X are not to be clustered. nC=1 if only
% intercept is excluded from clustering.
% bets - vector of p betas
% Xdot - sum of squares of each column of X
% clus - clustering of X into k clusters


%%
[~,p] = size(X); az = 1e-20; tol = 1e-010;
cnt = 0; %counter

RSS0 = sum((Y-X*bets(1,:)').^2); % initial RSS0
%% Initial clustering
rng(1); % For reproducibility
[klus,clmns] = kmeans(bets(1,((nC+1):p))',k); % bets of length p
[lk,~] = size(klus);
clus(1,((nC+1):p)) = klus(1:lk,1);
%% to run in a while loop
while 1
    cnt = cnt+1;
for j = 1:p
    id = (1:p)~=j;
    err = Y-X(:,id)*bets(1,id)';
    
    if(j>nC)
    bj = dot(err,X(:,j))/Xdot(1,j);
    idj = clus(j); %identify current cluster assignment
    [~,idmn]=min(abs(clmns-bj)); % identify nearest cluster centre
        if(idmn~=idj)
        id = clus==idmn;
        bets(1,j) = mean([bj bets(1,id)]); %update clustered j
        clus(j) = idmn; %update j's cluster
        end 
    else
        bets(1,j) = dot(err,X(:,j))/Xdot(1,j);%update directly for non-clustered
    end %end if(j>nC)
end

%% Compute RSS & check convergence
RSS1 = sum((Y-X*bets(1,:)').^2); dev = (RSS0 - RSS1)/(az + abs(RSS0));
fprintf('\n Inner iter = %u RSS = %0.5f and dev = %0.5f \n',uint64(cnt),double(RSS1),double(dev))
if(dev<=tol)
    break;
end
RSS0=RSS1; %update RSS
klus(1:lk,1) = clus(1,((nC+1):p)); % update clusters
end % end while loop


