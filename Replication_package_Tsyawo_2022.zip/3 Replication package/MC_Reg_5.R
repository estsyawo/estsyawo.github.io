#=========================================================================================>
# Author: Emmanuel Selorm Tsyawo
# Project: Feasible IV Regression without Excluded Instruments
# Date began:   Sept 6, 2021
# Last Update:  Oct. 4, 2022
# Place:        Rabat
#=========================================================================================>
# Load packages, clear memory,
#rm(list=ls())
library(estrpac) #install from binary file estrpac_0.1.0.tgz or
# use devtools::install_github("estsyawo/estrpac")
library(AER)
library(sandwich)
library(pbapply)
setwd(dirname(rstudioapi::getActiveDocumentContext()$path)) #set working directory path to source file
list.files()
#=========================================================================================>
# Comments: Monte Carlo Simulations using the DGP involving outliers generated from the 
# Cauchy distribution
# n = 250 and n = 500
#=========================================================================================>
# Set Parameters
R = 1000 # set number of simulations
b=1#parameter of interest

RMSE = function(x) sqrt(mean(x^2))
MAD = function(x) median(abs(x))

#-------------------------------------------------------

gdat1<- function(n,gam){
  datl=list()
  for (l in 1:R) {
    set.seed(l) #generate seed
    Z=rnorm(n)
    Sig = diag(2); Sig[1,2]=Sig[2,1]=0.5
    set.seed(l+10)
    EU=MASS::mvrnorm(n=n,mu=c(0,0),Sigma = Sig)
    UC = rcauchy(n); Up=sample(x=c(0,1),size=n,replace=T,c(1-gam,gam))
    #generate endogenous covariate
    D = Z+EU[,2]
    #generate outcome
    Y = 1 + b*D + (1-Up)*c(EU[,1]) + Up*UC
    datl[[l]]<- data.frame(Y,D,Z)
  }
  datl
}

# size a, n = 250
# gamma=0.1
datl1a=gdat1(n=250,gam = 0.1) #linear homoskedastic model

summary(imlmreg2.fit(Y=datl1a[[1]]$Y,X=datl1a[[1]]$D,Z=datl1a[[1]][,-c(1,2)]))#MMD is the default
summary(imlmreg2.fit(Y=datl1a[[1]]$Y,X=datl1a[[1]]$D,Z=datl1a[[1]][,-c(1,2)],Kern = "Gauss.W"))
summary(imlmreg2.fit(Y=datl1a[[1]]$Y,X=datl1a[[1]]$D,Z=datl1a[[1]][,-c(1,2)],Kern = "Gauss"))
summary(imlmreg2.fit(Y=datl1a[[1]]$Y,X=datl1a[[1]]$D,Z=datl1a[[1]][,-c(1,2)],Kern = "DL"))
summary(imlmreg2.fit(Y=datl1a[[1]]$Y,X=datl1a[[1]]$D,Z=datl1a[[1]][,-c(1,2)],Kern = "WMD"))

MCfun1<- function(j=NULL,datl,b){
  dat = datl[[j]] #null operation for looping
  Y = dat[,1]; X = as.matrix(dat[,2])
  Z1 = as.matrix(dat[,3]); Z2 = as.matrix(dat[,-c(1,2)])
  
  #run Integrated Moment regressions
  MMDobj=imlmreg2.fit(Y,X,Z1,Kern = "Euclid")
  WMDobj=imlmreg2.fit(Y,X,Z1,Kern = "WMD")
  WMDFobj=imlmreg2.fit(Y,X,Z1,Kern = "WMDF")
  DLobj=imlmreg2.fit(Y,X,Z1,Kern = "DL")
  Esc6obj=imlmreg2.fit(Y,X,Z1,Kern = "Esc6")
  IIVobj=imlmreg2.fit(Y,X,Z1,Kern = "Gauss.W")
  #run K-Class regressions
  TSLSobj=ivreg(Y~X|Z2); TSLSobj$HC_Std.Err=sqrt(diag(vcovHC(TSLSobj)))
  JIVEobj=kClassIVreg.fit(Y,X,Z2,method = "JIVE")
  LIMLobj=kClassIVreg.fit(Y,X,Z2,method = "LIML")
  HLIMobj=kClassIVreg.fit(Y,X,Z2,method = "HLIM")
  HFULobj=kClassIVreg.fit(Y,X,Z2,method = "HFUL")
  
  #compute bias
  bias.MMD = MMDobj$coefficients[2]-b 
  bias.WMD = WMDobj$coefficients[2]-b
  bias.WMDF = WMDFobj$coefficients[2]-b
  bias.DL = DLobj$coefficients[2]-b
  bias.Esc6 = Esc6obj$coefficients[2]-b
  bias.IIV = IIVobj$coefficients[2]-b
  
  bias.TSLS = TSLSobj$coefficients[2]-b
  bias.JIVE = JIVEobj$coefficients[2]-b
  bias.LIML = LIMLobj$coefficients[2]-b
  bias.HLIM = HLIMobj$coefficients[2]-b
  bias.HFUL = HFULobj$coefficients[2]-b
  
  #compute size (for rejection probabilities)
  size.MMD = 1*(abs(bias.MMD/MMDobj$HC_Std.Err[2])>qnorm(0.975))
  size.WMD = 1*(abs(bias.WMD/WMDobj$HC_Std.Err[2])>qnorm(0.975))
  size.WMDF = 1*(abs(bias.WMDF/WMDFobj$HC_Std.Err[2])>qnorm(0.975))
  size.DL = 1*(abs(bias.DL/DLobj$HC_Std.Err[2])>qnorm(0.975))
  size.Esc6 = 1*(abs(bias.Esc6/Esc6obj$HC_Std.Err[2])>qnorm(0.975))
  size.IIV = 1*(abs(bias.IIV/IIVobj$HC_Std.Err[2])>qnorm(0.975))
  
  size.TSLS = 1*(abs(bias.TSLS/TSLSobj$HC_Std.Err[2])>qnorm(0.975))
  size.JIVE = 1*(abs(bias.JIVE/JIVEobj$HC_Std.Err[2])>qnorm(0.975))
  size.LIML = 1*(abs(bias.LIML/LIMLobj$HC_Std.Err[2])>qnorm(0.975))
  size.HLIM = 1*(abs(bias.HLIM/HLIMobj$HC_Std.Err[2])>qnorm(0.975))
  size.HFUL = 1*(abs(bias.HFUL/HFULobj$HC_Std.Err[2])>qnorm(0.975))
  
  res=c(bias.MMD,bias.WMD,bias.WMDF,bias.DL,bias.Esc6,bias.IIV,bias.TSLS,bias.JIVE,bias.LIML,bias.HLIM,
        bias.HFUL,size.MMD,
        size.WMD,size.WMDF,size.DL,size.Esc6,size.IIV,size.TSLS,size.JIVE,size.LIML,
        size.HLIM,size.HFUL)
  names(res)=c("BiasMMD","BiasWMD","BiasWMDF","BiasDL","BiasEsc6","BiasIIV","Bias.TSLS",
               "Bias.JIVE","Bias.LIML","Bias.HLIM","Bias.HFUL",
               "SizeMMD","SizeWMD","SizeWMDF","SizeDL","SizeEsc6","SizeIIV","Size.TSLS",
               "Size.JIVE","Size.LIML","Size.HLIM","Size.HFUL")
  res
}

# 
#-------------------------------------------------------

# illustration
MCfun1(j=2,datl=datl1a,b=b)

#n = 250
# gamma = 0.1
Bias1a = pbsapply(1:R, FUN=MCfun1,cl=5,datl=datl1a,b=b)
summary(t(Bias1a))

# gamma = 0.25
datl1aM=gdat1(n=250,gam = 0.25)
Bias1a.M = pbsapply(1:R, FUN=MCfun1,cl=5,datl=datl1aM,b=b)
summary(t(Bias1a.M))

# gamma = 0.5
datl1aMM=gdat1(n=250,gam = 0.5) #linear heteroskedastic model
Bias1a.MM = pbsapply(1:R, FUN=MCfun1,cl=5,datl=datl1aMM,b=b)
summary(t(Bias1a.MM))
#-------------------------------------------------------
# n = 500

# gamma = 0.1
datl1b=gdat1(n=500,gam = 0.1)
Bias1b = pbsapply(1:R, FUN=MCfun1,cl=5,datl=datl1b,b=b)
summary(t(Bias1b))

# gamma = 0.25
datl1bM=gdat1(n=500,gam = 0.25)
Bias1b.M = pbsapply(1:R, FUN=MCfun1,cl=5,datl=datl1bM,b=b)
summary(t(Bias1b.M))

# gamma = 0.5
datl1bMM=gdat1(n=500,gam = 0.5)
Bias1b.MM = pbsapply(1:R, FUN=MCfun1,cl=5,datl=datl1bMM,b=b)
summary(t(Bias1b.MM))
#=========================================================================================>

#=========================================================================================>

# Results:

Res.A1=round(cbind(apply(Bias1a[1:11,],1,mean),apply(Bias1a[1:11,],1,MAD),apply(Bias1a[1:11,],1,RMSE),
                   apply(Bias1a[12:22,],1,mean)),3)
colnames(Res.A1)=c("MB","MAD","RMSE","Rej")
rownames(Res.A1)=c("MMD","WMD","WMDF","DL","ESC6","IIV","TSLS","JIVE","LIML","HLIM","HFUL")
Res.A1

Res.A2=round(cbind(apply(Bias1a.M[1:11,],1,mean),apply(Bias1a.M[1:11,],1,MAD),apply(Bias1a.M[1:11,],1,RMSE),
                   apply(Bias1a.M[12:22,],1,mean,na.rm=TRUE)),3)
colnames(Res.A2)=c("MB","MAD","RMSE","Rej")
rownames(Res.A2)=c("MMD","WMD","WMDF","DL","ESC6","IIV","TSLS","JIVE","LIML","HLIM","HFUL")
Res.A2

Res.A3=round(cbind(apply(Bias1a.MM[1:11,],1,mean),apply(Bias1a.MM[1:11,],1,MAD),apply(Bias1a.MM[1:11,],1,RMSE),
                   apply(Bias1a.MM[12:22,],1,mean)),3)
colnames(Res.A3)=c("MB","MAD","RMSE","Rej")
rownames(Res.A3)=c("MMD","WMD","WMDF","DL","ESC6","IIV","TSLS","JIVE","LIML","HLIM","HFUL")
Res.A3

cbind(Res.A1,Res.A2,Res.A3)

#       MB   MAD  RMSE   Rej     MB   MAD   RMSE   Rej     MB   MAD   RMSE   Rej
# MMD  0.079 0.111 2.606 0.028 -0.296 0.228 14.907 0.021 -0.712 0.469 12.967 0.014
# WMD  0.073 0.121 2.818 0.030 -0.246 0.255 17.178 0.017 -0.817 0.516 15.890 0.012
# WMDF 0.073 0.120 2.816 0.031 -0.246 0.255 17.166 0.017 -0.817 0.515 15.884 0.012
# DL   0.082 0.115 2.556 0.032 -0.239 0.238 15.711 0.021 -0.736 0.501 13.738 0.012
# ESC6 0.082 0.115 2.555 0.032 -0.230 0.236 15.940 0.021 -0.738 0.504 13.831 0.012
# IIV  0.074 0.118 2.801 0.032 -0.244 0.253 17.106 0.017 -0.814 0.513 15.848 0.012
# TSLS 0.078 0.106 2.422 0.030 -0.335 0.208 12.851 0.016 -0.629 0.437 10.706 0.016
# JIVE 0.077 0.104 2.448 0.029 -0.339 0.207 13.001 0.017 -0.637 0.443 10.859 0.016
# LIML 0.078 0.106 2.422 0.030 -0.335 0.208 12.851 0.016 -0.629 0.437 10.706 0.016
# HLIM 0.077 0.104 2.448 0.029 -0.339 0.207 13.001 0.017 -0.637 0.443 10.859 0.016
# HFUL 0.078 0.105 2.436 0.030 -0.335 0.207 12.924 0.017 -0.635 0.441 10.839 0.016

#for pasting into TeX
apply(cbind(Res.A1,Res.A2,Res.A3),1,paste,collapse=" & ")

# MMD & 0.079 & 0.111 & 2.606 & 0.028 & -0.296 & 0.228 & 14.907 & 0.021 & -0.712 & 0.469 & 12.967 & 0.014\\
# WMD & 0.073 & 0.121 & 2.818 & 0.03 & -0.246 & 0.255 & 17.178 & 0.017 & -0.817 & 0.516 & 15.89 & 0.012\\
# WMDF & 0.073 & 0.12 & 2.816 & 0.031 & -0.246 & 0.255 & 17.166 & 0.017 & -0.817 & 0.515 & 15.884 & 0.012\\
# DL & 0.082 & 0.115 & 2.556 & 0.032 & -0.239 & 0.238 & 15.711 & 0.021 & -0.736 & 0.501 & 13.738 & 0.012\\
# ESC6 & 0.082 & 0.115 & 2.555 & 0.032 & -0.23 & 0.236 & 15.94 & 0.021 & -0.738 & 0.504 & 13.831 & 0.012\\
# IIV & 0.074 & 0.118 & 2.801 & 0.032 & -0.244 & 0.253 & 17.106 & 0.017 & -0.814 & 0.513 & 15.848 & 0.012\\
# TSLS & 0.078 & 0.106 & 2.422 & 0.03 & -0.335 & 0.208 & 12.851 & 0.016 & -0.629 & 0.437 & 10.706 & 0.016\\
# JIVE & 0.077 & 0.104 & 2.448 & 0.029 & -0.339 & 0.207 & 13.001 & 0.017 & -0.637 & 0.443 & 10.859 & 0.016\\
# LIML & 0.078 & 0.106 & 2.422 & 0.03 & -0.335 & 0.208 & 12.851 & 0.016 & -0.629 & 0.437 & 10.706 & 0.016\\
# HLIM & 0.077 & 0.104 & 2.448 & 0.029 & -0.339 & 0.207 & 13.001 & 0.017 & -0.637 & 0.443 & 10.859 & 0.016\\
# HFUL & 0.078 & 0.105 & 2.436 & 0.03 & -0.335 & 0.207 & 12.924 & 0.017 & -0.635 & 0.441 & 10.839 & 0.016\\

#----------------------------------------------------------------------------------------->

Res.B1=round(cbind(apply(Bias1b[1:11,],1,mean),apply(Bias1b[1:11,],1,MAD),apply(Bias1b[1:11,],1,RMSE),
                   apply(Bias1b[12:22,],1,mean)),3)
colnames(Res.B1)=c("MB","MAD","RMSE","Rej")
rownames(Res.B1)=c("MMD","WMD","WMDF","DL","ESC6","IIV","TSLS","JIVE","LIML","HLIM","HFUL")
Res.B1

Res.B2=round(cbind(apply(Bias1b.M[1:11,],1,mean),apply(Bias1b.M[1:11,],1,MAD),apply(Bias1b.M[1:11,],1,RMSE),
                   apply(Bias1b.M[12:22,],1,mean)),3)
colnames(Res.B2)=c("MB","MAD","RMSE","Rej")
rownames(Res.B2)=c("MMD","WMD","WMDF","DL","ESC6","IIV","TSLS","JIVE","LIML","HLIM","HFUL")
Res.B2

Res.B3=round(cbind(apply(Bias1b.MM[1:11,],1,mean),apply(Bias1b.MM[1:11,],1,MAD),apply(Bias1b.MM[1:11,],1,RMSE),
                   apply(Bias1b.MM[12:22,],1,mean)),3)
colnames(Res.B3)=c("MB","MAD","RMSE","Rej")
rownames(Res.B3)=c("MMD","WMD","WMDF","DL","ESC6","IIV","TSLS","JIVE","LIML","HLIM","HFUL")
Res.B3

cbind(Res.B1,Res.B2,Res.B3)

#        MB   MAD  RMSE   Rej     MB   MAD   RMSE   Rej      MB   MAD    RMSE   Rej
# MMD  0.118 0.088 4.482 0.022 -0.559 0.202 24.128 0.022  -9.909 0.450 275.636 0.027
# WMD  0.113 0.102 4.975 0.024 -0.716 0.220 30.342 0.022  -9.475 0.495 244.043 0.027
# WMDF 0.113 0.102 4.975 0.024 -0.716 0.220 30.340 0.022  -9.474 0.495 244.010 0.027
# DL   0.103 0.096 4.687 0.024 -0.710 0.212 28.508 0.024  -9.368 0.460 256.001 0.027
# ESC6 0.103 0.097 4.690 0.023 -0.710 0.212 28.328 0.023  -9.287 0.462 253.658 0.027
# IIV  0.114 0.102 4.966 0.025 -0.716 0.219 30.317 0.021  -9.398 0.494 242.378 0.026
# TSLS 0.113 0.083 4.030 0.020 -0.426 0.183 18.452 0.021 -10.738 0.426 322.376 0.021
# JIVE 0.113 0.083 4.048 0.019 -0.429 0.184 18.559 0.021 -10.831 0.428 324.110 0.021
# LIML 0.113 0.083 4.030 0.020 -0.426 0.183 18.452 0.021 -10.738 0.426 322.376 0.021
# HLIM 0.113 0.083 4.048 0.019 -0.429 0.184 18.559 0.021 -10.831 0.428 324.110 0.021
# HFUL 0.114 0.083 4.044 0.020 -0.429 0.183 18.545 0.021 -10.792 0.427 323.039 0.021

#for pasting into TeX
apply(cbind(Res.B1,Res.B2,Res.B3),1,paste,collapse=" & ")

# MMD & 0.118 & 0.088 & 4.482 & 0.022 & -0.559 & 0.202 & 24.128 & 0.022 & -9.909 & 0.45 & 275.636 & 0.027\\
# WMD & 0.113 & 0.102 & 4.975 & 0.024 & -0.716 & 0.22 & 30.342 & 0.022 & -9.475 & 0.495 & 244.043 & 0.027\\
# WMDF & 0.113 & 0.102 & 4.975 & 0.024 & -0.716 & 0.22 & 30.34 & 0.022 & -9.474 & 0.495 & 244.01 & 0.027\\
# DL & 0.103 & 0.096 & 4.687 & 0.024 & -0.71 & 0.212 & 28.508 & 0.024 & -9.368 & 0.46 & 256.001 & 0.027\\
# ESC6 & 0.103 & 0.097 & 4.69 & 0.023 & -0.71 & 0.212 & 28.328 & 0.023 & -9.287 & 0.462 & 253.658 & 0.027\\
# IIV & 0.114 & 0.102 & 4.966 & 0.025 & -0.716 & 0.219 & 30.317 & 0.021 & -9.398 & 0.494 & 242.378 & 0.026\\
# TSLS & 0.113 & 0.083 & 4.03 & 0.02 & -0.426 & 0.183 & 18.452 & 0.021 & -10.738 & 0.426 & 322.376 & 0.021\\
# JIVE & 0.113 & 0.083 & 4.048 & 0.019 & -0.429 & 0.184 & 18.559 & 0.021 & -10.831 & 0.428 & 324.11 & 0.021\\
# LIML & 0.113 & 0.083 & 4.03 & 0.02 & -0.426 & 0.183 & 18.452 & 0.021 & -10.738 & 0.426 & 322.376 & 0.021\\
# HLIM & 0.113 & 0.083 & 4.048 & 0.019 & -0.429 & 0.184 & 18.559 & 0.021 & -10.831 & 0.428 & 324.11 & 0.021\\
# HFUL & 0.114 & 0.083 & 4.044 & 0.02 & -0.429 & 0.183 & 18.545 & 0.021 & -10.792 & 0.427 & 323.039 & 0.021\\

#=========================================================================================>