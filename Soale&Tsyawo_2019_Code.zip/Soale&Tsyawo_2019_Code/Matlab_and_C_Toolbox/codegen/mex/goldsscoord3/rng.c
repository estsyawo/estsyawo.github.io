/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * rng.c
 *
 * Code generation for function 'rng'
 *
 */

/* Include files */
#include "rt_nonfinite.h"
#include "goldsscoord3.h"
#include "rng.h"
#include "goldsscoord3_mexutil.h"

/* Variable Definitions */
static emlrtMCInfo d_emlrtMCI = { 34,  /* lineNo */
  9,                                   /* colNo */
  "rng",                               /* fName */
  "/usr/local/MATLAB/R2018b/toolbox/eml/lib/matlab/randfun/rng.m"/* pName */
};

static emlrtRSInfo uf_emlrtRSI = { 34, /* lineNo */
  "rng",                               /* fcnName */
  "/usr/local/MATLAB/R2018b/toolbox/eml/lib/matlab/randfun/rng.m"/* pathName */
};

/* Function Declarations */
static void b_rng(const emlrtStack *sp, const mxArray *b, emlrtMCInfo *location);

/* Function Definitions */
static void b_rng(const emlrtStack *sp, const mxArray *b, emlrtMCInfo *location)
{
  const mxArray *pArray;
  pArray = b;
  emlrtCallMATLABR2012b(sp, 0, NULL, 1, &pArray, "rng", true, location);
}

void rng(const emlrtStack *sp)
{
  emlrtStack st;
  st.prev = sp;
  st.tls = sp->tls;
  st.site = &uf_emlrtRSI;
  b_rng(&st, emlrt_marshallOut(1.0), &d_emlrtMCI);
}

void rng_init(void)
{
}

/* End of code generation (rng.c) */
