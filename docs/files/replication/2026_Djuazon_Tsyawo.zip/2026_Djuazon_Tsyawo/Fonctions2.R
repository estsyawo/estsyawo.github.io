#Function File
#=============================================================================>
# Purpose: Computes the observed treated DF and untreated counterfactual DF
#          for the treated at a single outcome threshold.
# Input: Outcome vector Y, threshold y, treatment indicator D, time indicator t,
#        and link-function choice G.
# Output: Two-column matrix with F11_1 and F01_1 evaluated at y.
DFs.y<- function(Y,y,D,t,G){
  cell_mean <- function(x){
    if (length(x) == 0) return(NA_real_)
    mean(x)
  }
  F00 = cell_mean((1*(Y<=y))[D==0&t==0]); F01 = cell_mean((1*(Y<=y))[D==0&t==1])
  F10 = cell_mean((1*(Y<=y))[D==1&t==0]); F11 = cell_mean((1*(Y<=y))[D==1&t==1])
  
  #compute parameters of the counterfactual distribution F_{01|D=1}(y)
  if(G=="logis"){
    G=plogis; Ginv=qlogis
  }else if(G=="normal"){
    G=pnorm; Ginv=qnorm
  }else if(G=="uniform"){
    G=function(x) punif(x, min=0, max=1)
    Ginv=function(tau) qunif(tau, min=0, max=1)
  }else if(G=="identity"){
    G=function(x) x
    Ginv=function(tau) tau
  }else if(G=="Cauchy"){
    G=pcauchy; Ginv=qcauchy
  }else{
    stop("CDF not available; should be logis, normal, uniform, Cauchy or chi2")
  }
  if (any(is.na(c(F00, F01, F10, F11)))) {
    return(cbind(F11_1=NA_real_, F01_1=NA_real_))
  }
  
  #compute alpha_y
  if(Ginv(F00)==Inf){
    alpha_y = Ginv(F00-.Machine$double.eps)
  }else if(Ginv(F00)==-Inf){
    alpha_y = Ginv(F00+.Machine$double.eps)
  }else{
    alpha_y = Ginv(F00)
  }
  #compute beta_y
  if(Ginv(F10)==Inf){
    beta_y = Ginv(F10-.Machine$double.eps) - alpha_y
  }else if(Ginv(F10)==-Inf){
    beta_y = Ginv(F10+.Machine$double.eps) - alpha_y
  }else{
    beta_y = Ginv(F10) - alpha_y
  }
  #compute gamma_y
  if(Ginv(F01)==Inf){
    gamma_y = Ginv(F01-.Machine$double.eps) - alpha_y
  }else if(Ginv(F01)==-Inf){
    gamma_y = Ginv(F01+.Machine$double.eps) - alpha_y
  }else{
    gamma_y = Ginv(F01) - alpha_y
  }
  #compute counterfactual
  F01_1 = G(alpha_y + beta_y + gamma_y)
  #compute treated potential outcome for the treated
  F11_1 = F11
  
  return(cbind(F11_1,F01_1))
}
#=============================================================================>

#=============================================================================>
# Purpose: Computes the observed treated DF and a covariate-adjusted untreated
#          counterfactual DF for the treated at a single outcome threshold.
# Input: Outcome vector Y, threshold y, treatment indicator D, time indicator t,
#        link-function choice G, and covariates X.
# Output: Two-column matrix with empirical F11_1 and covariate-adjusted F01_1.
DFsX.y<- function(Y,y,D,t,G,X){
  cell_mean <- function(x){
    if (length(x) == 0) return(NA_real_)
    mean(x)
  }
  X_df <- if (is.data.frame(X)) X else as.data.frame(X)
  X_mat <- model.matrix(~ ., data = X_df)
  K <- ncol(X_mat)

  id.00<- which(D==0&t==0); id.01<- which(D==0&t==1)
  id.10<- which(D==1&t==0); id.11<- which(D==1&t==1)
  id.r<- c(id.00,id.01,id.10)

  if (length(id.r) == 0 || length(id.11) == 0) {
    return(cbind(F11_1 = NA_real_, F01_1 = NA_real_))
  }

  y_bin <- as.numeric(Y <= y)
  X_fit <- cbind(
    X_mat,
    D * X_mat,
    t * X_mat
  )

  if(G=="logis"){
    G = plogis
    fam <- stats::binomial(link = "logit")
  }else if(G=="normal"){
    G = pnorm
    fam <- stats::binomial(link = "probit")
  }else{
    stop("Covariate-adjusted DFsX.y currently supports only logis and normal links.")
  }

  robj <- stats::glm.fit(
    x = X_fit[id.r, , drop = FALSE],
    y = y_bin[id.r],
    family = fam
  )
  coef_hat <- stats::coef(robj)
  coef_hat[is.na(coef_hat)] <- 0

  alpha_y <- coef_hat[1:K]
  beta_y <- coef_hat[(K + 1):(2 * K)]
  gamma_y <- coef_hat[(2 * K + 1):(3 * K)]

  eta_cf <- as.vector(X_mat[id.11, , drop = FALSE] %*% (alpha_y + beta_y + gamma_y))
  F01_1 = mean(G(eta_cf))
  F11_1 = cell_mean(y_bin[id.11])
  
  return(cbind(F11_1,F01_1))
}
#=============================================================================>


#=============================================================================>
# Purpose: Applies DFs.y over a grid of outcome values.
# Input: Outcome vector Y, evaluation grid ygrid, treatment indicator D,
#        time indicator t, and link-function choice G.
# Output: Data frame with F11_1 and F01_1 over the full y-grid.
DFs<- function(Y,ygrid,D,t,G="normal"){
  fn=function(l) DFs.y(Y=Y,ygrid[l],D=D,t=t,G=G)
  res=t(sapply(1:length(ygrid),fn))
  res=as.data.frame(res); names(res)=c("F11_1","F01_1")
  res
}
#=============================================================================>


#=============================================================================>
# Purpose: Builds the left-inverse map of a step CDF or empirical distribution.
# Input: Support values ys and corresponding cumulative probabilities Fs.
# Output: Step function that maps probabilities to quantile values.
left.inv <- function(ys, Fs){
  ys <- sort(ys)
  Fs <- sort(Fs)
  iF <- stepfun(Fs, c(ys, max(ys)), right = TRUE)
  return(iF)
}
#=============================================================================>


#=============================================================================>
# Purpose: Computes QTT and DTT objects from a two-period/two-group sample.
# Input: Outcome vector Y, treatment indicator D, time indicator t,
#        link choice G, and optional ygrid and taus.
# Output: Matrix containing quantile functions, QTT, distribution functions,
#         and DTT over the evaluation grid.
QTT_DTT2<- function(Y,D,t,G="normal",ygrid=NULL,taus=NULL){
  nu.Y=length(unique(Y))
  if(is.null(taus)){taus=seq(0.05,0.95,length.out=min(c(101,max(2, nu.Y-1))))}
  if(is.null(ygrid)){ygrid=quantile(c(Y),probs = taus,na.rm=TRUE)}
  if (any(taus < 0 | taus > 1)) {
    stop("taus must be in [0, 1].")
  }
  DFobj=DFs(Y=Y,ygrid=ygrid,D=D,t=t,G=G)
  Q11_1.fun = left.inv(ys=ygrid,Fs=DFobj$F11_1); Q11_1=Q11_1.fun(taus)
  Q01_1.fun = left.inv(ys=ygrid,Fs=DFobj$F01_1); Q01_1=Q01_1.fun(taus)
  DTT=DFobj$F11_1-DFobj$F01_1; QTT=Q11_1-Q01_1
  return(cbind(Q11_1,Q01_1,QTT,ygrid,DFobj,DTT))
}
#=============================================================================>

#=============================================================================>
# Purpose: Pre-computes scale and supremum objects used in uniform bands.
# Input: Point estimate Fn, bootstrap matrix Boot.Fn, and sample size n.
# Output: List with scale vector Sigv and bootstrap max-statistic vector tbv.
Band.Fn.Objs<- function(Fn,Boot.Fn,n){
  Zbstar = Boot.Fn
  for (j in 1:ncol(Boot.Fn)){Zbstar[,j] = Zbstar[,j] - Fn}
  Zbstar = sqrt(n)*Zbstar
  Sigv = apply(Zbstar,1,IQR)/(qnorm(0.75)-qnorm(0.25))
  
  tbmat = abs(Zbstar)
  for (j in 1:ncol(tbmat)) {tbmat[,j]=tbmat[,j]/Sigv}
  
  tbv = apply(tbmat,2,max)
  list(Sigv=Sigv,tbv=tbv)
}
#=============================================================================>


#=============================================================================>
# Purpose: Builds uniform confidence bands from bootstrap band objects.
# Input: Point estimate Fn, Band.Fn.Objs output BFObjs, confidence level alpha,
#        sample size n, and a flag controlling whether order is preserved.
# Output: Matrix with lower and upper uniform confidence bands.
UBand.Fn=function(Fn,BFObjs,alpha=0.05,n,DQTT.fun=F){
  LB.Fn = Fn - quantile(c(BFObjs$tbv),1-alpha,na.rm=T)*BFObjs$Sigv/sqrt(n) 
  UB.Fn = Fn + quantile(c(BFObjs$tbv),1-alpha,na.rm=T)*BFObjs$Sigv/sqrt(n)
  if(DQTT.fun){
    return(cbind(LB.Fn=LB.Fn, UB.Fn=UB.Fn))
  }else{
    return(cbind(LB.Fn=sort(LB.Fn), UB.Fn=sort(UB.Fn)))
  }
}
#=============================================================================>

#=============================================================================>
# Purpose: Builds pointwise confidence intervals from robust bootstrap scale estimates.
# Input: Point estimate Fn, Band.Fn.Objs output BFObjs, confidence level alpha, sample size n.
# Output: Matrix with lower and upper pointwise confidence intervals and robust standard errors.
PBand.Fn=function(Fn,BFObjs,alpha=0.05,n){
  cv = qnorm(1-alpha/2)
  SE.Fn = BFObjs$Sigv/sqrt(n)
  PW.LB.Fn = Fn - cv*SE.Fn
  PW.UB.Fn = Fn + cv*SE.Fn
  cbind(PW.LB.Fn=PW.LB.Fn, PW.UB.Fn=PW.UB.Fn, SE.Fn=SE.Fn)
}
#=============================================================================>

#=============================================================================>
# Purpose: Computes CvM and KS statistics for equality of multiple F01_1 curves.
# Input: Matrix Fmat of curve values, optional integration weights,
#        and sample size n.
# Output: List with CvM and KS test statistics.
functional_overid_tests <- function(Fmat, weights=NULL, n=NULL){
  if (is.null(dim(Fmat)) || ncol(Fmat) < 2) {
    stop("Fmat must be a matrix with at least two columns (pre periods).")
  }
  if (is.null(n)) stop("n must be provided.")
  k <- ncol(Fmat)
  if (is.null(weights)) {
    weights <- rep(1 / nrow(Fmat), nrow(Fmat))
  }
  if (length(weights) != nrow(Fmat)) {
    stop("weights must have length equal to nrow(Fmat).")
  }
  weights <- as.numeric(weights)
  weights <- weights / sum(weights)
  
  cvm <- 0
  ks <- 0
  for (l in 1:(k-1)) {
    for (lp in (l+1):k) {
      diff <- Fmat[, l] - Fmat[, lp]
      cvm <- cvm + sum((diff^2) * weights)
      ks <- max(ks, max(abs(diff), na.rm = TRUE))
    }
  }
  list(CvM = n * cvm, KS = sqrt(n) * ks)
}
#=============================================================================>

#=============================================================================>
# Purpose: Bootstrap-calibrates the functional overidentification test.
# Input: Empirical data set, pre and post periods, link choice G,
#        common grids, bootstrap indices, sample size, and weights.
# Output: List with bootstrap CvM and KS statistics.
functional_overid_boot <- function(daten, pre_treat_mes, post_treat_mes,
                                   G="normal", ygrid=NULL, taus=NULL,
                                   B=999, id.b=NULL, n=NULL, weights=NULL){
  if (is.null(ygrid) || is.null(taus)) {
    ygrid <- sort(unique(daten$totrob))
    taus <- round(ecdf(daten$totrob)(ygrid), 6)
  }
  if (is.null(n)) n <- length(unique(daten$observ))
  if (is.null(weights)) {
    weights <- c(taus[1], diff(taus))
  }
  
  # point estimates F01_1 for each pre-treatment month
  Fhat <- sapply(pre_treat_mes, function(m) {
    w.DTT.QTT(daten=daten, pre_treat_mes=m, post_treat_mes=post_treat_mes,
              G=G, ygrid=ygrid, taus=taus)$F01_1
  })
  
  if (is.null(id.b)) stop("id.b must be provided for bootstrap.")
  B_eff <- ncol(id.b)
  boot_CvM <- numeric(B_eff)
  boot_KS <- numeric(B_eff)
  
  for (b in 1:B_eff) {
    dat_b <- daten[id.b[, b], , drop=FALSE]
    Fstar <- sapply(pre_treat_mes, function(m) {
      w.DTT.QTT(daten=dat_b, pre_treat_mes=m, post_treat_mes=post_treat_mes,
                G=G, ygrid=ygrid, taus=taus)$F01_1
    })
    # center bootstrap curves
    Fcent <- Fstar - Fhat
    stats_b <- functional_overid_tests(Fmat=Fcent, weights=weights, n=n)
    boot_CvM[b] <- stats_b$CvM
    boot_KS[b] <- stats_b$KS
  }
  
  list(boot_CvM=boot_CvM, boot_KS=boot_KS)
}
#=============================================================================>

#=============================================================================>
# Purpose: Runs pre-period, cross-control, or joint overidentification tests
#          when treatment status is encoded by a multi-valued group variable.
# Input: Data set, group definitions, time settings, common grids,
#        bootstrap settings, and comparison mode.
# Output: Nested list of test statistics, bootstrap draws, and p-values.
functional_overid_tests_generic <- function(daten, group_var, treated_value,
                                            control_values, post_treat_mes,
                                            pre_treat_mes, outcome_var="totrob",
                                            time_var="mes", unit_var="observ",
                                            G="normal", ygrid=NULL, taus=NULL,
                                            B=999, id.b=NULL, alpha=0.10,
                                            compare=c("pre","controls","both")){
  compare <- match.arg(compare)
  if (compare %in% c("pre","both") && length(pre_treat_mes) < 2) {
    stop("pre_treat_mes must contain at least two periods for pre-period tests.")
  }
  if (compare %in% c("controls","both") && length(control_values) < 2) {
    stop("control_values must contain at least two groups for control-group tests.")
  }
  if (compare %in% c("controls","both") && (is.null(ygrid) || is.null(taus))) {
    stop("For control-group tests, provide common ygrid and taus to align curves across groups.")
  }
  results <- list()
  
  build_id_b <- function(df, B){
    u <- unique(df[[unit_var]])
    N <- length(u)
    boot.unique <- matrix(sample.int(N, N * B, replace = TRUE), N, B)
    idx_by_unit <- split(seq_len(nrow(df)), df[[unit_var]])
    id.b <- matrix(NA_integer_, nrow(df), B)
    for (j in 1:B) {
      sampled_units <- u[boot.unique[, j]]
      id.b[, j] <- unlist(idx_by_unit[as.character(sampled_units)], use.names = FALSE)
    }
    id.b
  }
  
  # Precompute F01_1 for each (control, pre) pair
  F01_list <- list()
  for (g in control_values) {
    sub <- daten[daten[[group_var]] %in% c(treated_value, g), , drop=FALSE]
    sub$treat <- as.integer(sub[[group_var]] == treated_value)
    if (is.null(ygrid) || is.null(taus)) {
      ygrid_g <- sort(unique(sub[[outcome_var]]))
      taus_g <- round(ecdf(sub[[outcome_var]])(ygrid_g), 6)
    } else {
      ygrid_g <- ygrid
      taus_g <- taus
    }
    F01_list[[as.character(g)]] <- list(
      ygrid=ygrid_g,
      taus=taus_g,
      F01_mat = sapply(pre_treat_mes, function(m) {
        w.DTT.QTT(daten=sub, pre_treat_mes=m, post_treat_mes=post_treat_mes,
                  G=G, ygrid=ygrid_g, taus=taus_g)$F01_1
      })
    )
    colnames(F01_list[[as.character(g)]]$F01_mat) <- paste0("pre_", pre_treat_mes)
  }
  
  # Pre-period tests within each control group
  if (compare == "pre") {
    for (g in control_values) {
      sub <- daten[daten[[group_var]] %in% c(treated_value, g), , drop=FALSE]
      N_g <- length(unique(sub[[unit_var]]))
      ygrid_g <- F01_list[[as.character(g)]]$ygrid
      taus_g <- F01_list[[as.character(g)]]$taus
      wts <- c(taus_g[1], diff(taus_g))
      F01_1_mat <- F01_list[[as.character(g)]]$F01_mat
      if (length(wts) != nrow(F01_1_mat)) {
        wts <- rep(1 / nrow(F01_1_mat), nrow(F01_1_mat))
      }
      tests <- functional_overid_tests(Fmat=F01_1_mat, weights=wts, n=N_g)
      
      if (!is.null(id.b)) {
        if (nrow(id.b) != nrow(sub)) {
          stop("id.b provided but does not match subset row count for control group ", g)
        }
        id_b_use <- id.b
      } else {
        id_b_use <- build_id_b(sub, B)
      }
      
      boot_tests <- functional_overid_boot(
        daten=sub, pre_treat_mes=pre_treat_mes, post_treat_mes=post_treat_mes,
        G=G, ygrid=ygrid_g, taus=taus_g, B=ncol(id_b_use), id.b=id_b_use,
        n=N_g, weights=wts
      )
      pval_CvM <- mean(boot_tests$boot_CvM >= tests$CvM)
      pval_KS <- mean(boot_tests$boot_KS >= tests$KS)
      
      results$pre_tests[[as.character(g)]] <- list(
        control_group=g,
        ygrid=ygrid_g,
        taus=taus_g,
        tests=tests,
        boot=boot_tests,
        pvals=list(CvM=pval_CvM, KS=pval_KS)
      )
    }
  }
  
  # Control-group tests within each pre period
  if (compare == "controls") {
    for (m in pre_treat_mes) {
      mats <- lapply(control_values, function(g) {
        F01_list[[as.character(g)]]$F01_mat[, paste0("pre_", m)]
      })
      F01_1_mat <- do.call(cbind, mats)
      colnames(F01_1_mat) <- paste0("ctrl_", control_values)
      
      wts <- c(taus[1], diff(taus))
      if (length(wts) != nrow(F01_1_mat)) {
        wts <- rep(1 / nrow(F01_1_mat), nrow(F01_1_mat))
      }
      N_g <- length(unique(daten[daten[[group_var]] %in% c(treated_value, control_values[1]), , drop=FALSE][[unit_var]]))
      
      tests <- functional_overid_tests(Fmat=F01_1_mat, weights=wts, n=N_g)
      
      boot_CvM <- numeric(B)
      boot_KS <- numeric(B)
      for (b in 1:B) {
        Fcent_cols <- list()
        for (g in control_values) {
          sub <- daten[daten[[group_var]] %in% c(treated_value, g), , drop=FALSE]
          id_b_g <- build_id_b(sub, 1)
          sub_b <- sub[id_b_g[, 1], , drop=FALSE]
          Fstar <- w.DTT.QTT(daten=sub_b, pre_treat_mes=m, post_treat_mes=post_treat_mes,
                             G=G, ygrid=ygrid, taus=taus)$F01_1
          Fhat <- F01_list[[as.character(g)]]$F01_mat[, paste0("pre_", m)]
          Fcent_cols[[length(Fcent_cols) + 1]] <- Fstar - Fhat
        }
        Fcent_all <- do.call(cbind, Fcent_cols)
        stats_b <- functional_overid_tests(Fmat=Fcent_all, weights=wts, n=N_g)
        boot_CvM[b] <- stats_b$CvM
        boot_KS[b] <- stats_b$KS
      }
      pval_CvM <- mean(boot_CvM >= tests$CvM)
      pval_KS <- mean(boot_KS >= tests$KS)
      
      results$control_tests[[as.character(m)]] <- list(
        pre_period=m,
        tests=tests,
        boot=list(boot_CvM=boot_CvM, boot_KS=boot_KS),
        pvals=list(CvM=pval_CvM, KS=pval_KS)
      )
    }
  }
  
  # Combined test across all (control, pre) curves
  if (compare == "both") {
    if (is.null(ygrid) || is.null(taus)) {
      stop("For compare='both', provide common ygrid and taus to align curves across groups.")
    }
    wts <- c(taus[1], diff(taus))
    n_all <- length(unique(daten[daten[[group_var]] %in% c(treated_value, control_values), , drop=FALSE][[unit_var]]))
    
    # Build Fhat matrix with columns for each (g,m)
    cols <- list()
    col_names <- c()
    for (g in control_values) {
      for (m in pre_treat_mes) {
        cols[[length(cols) + 1]] <- F01_list[[as.character(g)]]$F01_mat[, paste0("pre_", m)]
        col_names <- c(col_names, paste0("g", g, "_pre", m))
      }
    }
    Fhat_all <- do.call(cbind, cols)
    colnames(Fhat_all) <- col_names
    
    tests <- functional_overid_tests(Fmat=Fhat_all, weights=wts, n=n_all)
    
    if (is.null(id.b)) {
      id.b <- build_id_b(daten[daten[[group_var]] %in% c(treated_value, control_values), , drop=FALSE], B)
    }
    B_eff <- ncol(id.b)
    boot_CvM <- numeric(B_eff)
    boot_KS <- numeric(B_eff)
    
    for (b in 1:B_eff) {
      Fcent_cols <- list()
      for (g in control_values) {
        sub <- daten[daten[[group_var]] %in% c(treated_value, g), , drop=FALSE]
        sub_b <- sub[id.b[, b], , drop=FALSE]
        for (m in pre_treat_mes) {
          Fstar <- w.DTT.QTT(daten=sub_b, pre_treat_mes=m, post_treat_mes=post_treat_mes,
                             G=G, ygrid=ygrid, taus=taus)$F01_1
          Fhat <- F01_list[[as.character(g)]]$F01_mat[, paste0("pre_", m)]
          Fcent_cols[[length(Fcent_cols) + 1]] <- Fstar - Fhat
        }
      }
      Fcent_all <- do.call(cbind, Fcent_cols)
      stats_b <- functional_overid_tests(Fmat=Fcent_all, weights=wts, n=n_all)
      boot_CvM[b] <- stats_b$CvM
      boot_KS[b] <- stats_b$KS
    }
    
    pval_CvM <- mean(boot_CvM >= tests$CvM)
    pval_KS <- mean(boot_KS >= tests$KS)
    
    results$both <- list(
      tests=tests,
      boot=list(boot_CvM=boot_CvM, boot_KS=boot_KS),
      pvals=list(CvM=pval_CvM, KS=pval_KS)
    )
  }
  
  results
}
#=============================================================================>

#=============================================================================>
# Purpose: Averages DTT-related objects across all selected pre/post month pairs.
# Input: Empirical panel data, pre and post month sets, link choice G,
#        optional common ygrid and taus, and optional pair weights.
# Output: Data frame with weighted F11_1, F01_1, and DTT values.
w.DTT.QTT <- function(daten, pre_treat_mes, post_treat_mes, G="normal",
                      ygrid=NULL, taus=NULL, pair_weights=NULL){
  req_cols <- c("mes", "totrob", "treat")
  missing_cols <- setdiff(req_cols, names(daten))
  if (length(missing_cols) > 0) {
    stop(paste0("daten is missing required columns: ",
                paste(missing_cols, collapse=", ")))
  }
  if (length(pre_treat_mes) == 0 || length(post_treat_mes) == 0) {
    stop("pre_treat_mes and post_treat_mes must be non-empty.")
  }
  if (is.null(taus)) {
    ecdfY <- ecdf(daten$totrob)
    if (is.null(ygrid)) {
      ygrid <- sort(unique(daten$totrob))
    }
    taus <- round(ecdfY(ygrid), 6)
  }
  if (is.null(ygrid)) {
    ygrid <- quantile(daten$totrob, probs=taus, na.rm=TRUE)
  }
  pair_grid <- expand.grid(pre=pre_treat_mes, post=post_treat_mes,
                           KEEP.OUT.ATTRS = FALSE)
  npairs <- nrow(pair_grid)
  use_uniform_pair_weights <- is.character(pair_weights) &&
    length(pair_weights) == 1 &&
    identical(pair_weights, "uniform")
  if (!is.null(pair_weights) && !use_uniform_pair_weights &&
      length(pair_weights) != npairs) {
    stop("pair_weights must have one entry per pre/post pair.")
  }
  
  res_list <- vector("list", npairs)
  wt <- rep(NA_real_, npairs)
  
  for (k in seq_len(npairs)) {
    pre_m <- pair_grid$pre[k]
    post_m <- pair_grid$post[k]
    dat_k <- daten[daten$mes %in% c(pre_m, post_m), , drop=FALSE]
    if (nrow(dat_k) == 0) next
    t_k <- as.integer(dat_k$mes == post_m)
    res_k <- QTT_DTT2(Y=dat_k$totrob, D=dat_k$treat, t=t_k,
                      G=G, ygrid=ygrid, taus=taus)
    res_list[[k]] <- res_k
    if (!is.null(pair_weights)) {
      if (use_uniform_pair_weights) {
        wt[k] <- 1
      } else {
        wt[k] <- pair_weights[k]
      }
    } else {
      wt[k] <- nrow(dat_k)
    }
  }
  
  ok <- !vapply(res_list, is.null, logical(1)) & is.finite(wt) & wt > 0
  if (!any(ok)) {
    stop("No valid pre/post pairs were found for weighted aggregation.")
  }
  res_list <- res_list[ok]
  wt <- wt[ok]
  wt <- wt / sum(wt)
  
  f11 <- Reduce(`+`, Map(function(x, w) x$F11_1 * w, res_list, wt))
  f01 <- Reduce(`+`, Map(function(x, w) x$F01_1 * w, res_list, wt))
  dtt <- Reduce(`+`, Map(function(x, w) x$DTT * w, res_list, wt))
  
  out <- data.frame(F11_1=f11, F01_1=f01, DTT=dtt)
  attr(out, "pair_grid_used") <- pair_grid[ok, , drop=FALSE]
  attr(out, "pair_weights_used") <- wt
  out
}
#=============================================================================>

#=============================================================================>
# Purpose: Bootstraps the weighted pre/post-pair estimator w.DTT.QTT.
# Input: Empirical data, link choice G, month sets, common grids,
#        bootstrap count B, optional bootstrap indices, and pair weights.
# Output: List of bootstrap w.DTT.QTT outputs.
w.QTT_DTT.boot <- function(daten, G="normal", pre_treat_mes, post_treat_mes,
                           ygrid=NULL, taus=NULL, B=999, id.b=NULL,
                           pair_weights=NULL){
  if (B < 1) stop("B must be at least 1.")
  nrow_data <- nrow(daten)
  if (nrow_data == 0) stop("daten must have at least one row.")
  
  if (is.null(id.b)) {
    id.b <- matrix(sample.int(nrow_data, nrow_data * B, replace=TRUE),
                   nrow_data, B)
  }
  if (!all(dim(id.b) == c(nrow_data, B))) {
    stop("id.b must be an nrow(daten) x B matrix of row indices.")
  }
  boot_fn <- function(b){
    dat_b <- daten[id.b[, b], , drop=FALSE]
    w.DTT.QTT(daten=dat_b, pre_treat_mes=pre_treat_mes,
              post_treat_mes=post_treat_mes, G=G, ygrid=ygrid, taus=taus,
              pair_weights=pair_weights)
  }
  lapply(seq_len(B), boot_fn)
}
#=============================================================================>

#=============================================================================>
# Purpose: Plots the estimated DTT curve together with uniform and optional pointwise bands.
# Input: Result data frame with ygrid, DTT, LB.Fn, UB.Fn, and optional PW.LB.Fn/PW.UB.Fn.
# Output: PDF plot saved to fig.name and invisibly returns the input result object.
plot.DTT <- function(res, fig.name="DTT.pdf"){
  needed <- c("ygrid", "DTT", "LB.Fn", "UB.Fn")
  if (!all(needed %in% names(res))) {
    stop("res must contain columns: ygrid, DTT, LB.Fn, UB.Fn")
  }
  res <- res[order(res$ygrid), , drop=FALSE]
  draw_step_band <- function(x, lower, upper, fill_col){
    if (length(x) < 2) return()
    for (i in 1:(length(x)-1)) {
      if (!all(is.finite(c(x[i], x[i+1], lower[i], upper[i])))) next
      polygon(
        x = c(x[i], x[i+1], x[i+1], x[i]),
        y = c(lower[i], lower[i], upper[i], upper[i]),
        col = fill_col,
        border = NA
      )
    }
  }
  has_pointwise <- all(c("PW.LB.Fn", "PW.UB.Fn") %in% names(res))
  ylim_vals <- c(res$DTT, res$LB.Fn, res$UB.Fn)
  if (has_pointwise) ylim_vals <- c(ylim_vals, res$PW.LB.Fn, res$PW.UB.Fn)
  ylim_dtt <- range(ylim_vals, na.rm=TRUE)
  pad_dtt <- max(0.01, 0.05 * diff(ylim_dtt))
  if (!is.finite(pad_dtt)) pad_dtt <- 0.05
  band_fill <- grDevices::adjustcolor("lightblue", alpha.f = 0.45)
  draw_h <- function(x, y, col, lty, lwd){
    if (length(x) < 2) return()
    for (i in 1:(length(x)-1)) {
      segments(x[i], y[i], x[i+1], y[i], col=col, lty=lty, lwd=lwd)
    }
  }
  pdf(fig.name, width=8, height=5)
  on.exit(dev.off(), add=TRUE)
  plot(res$ygrid, res$DTT, type="n",
       xlab="y", ylab="DTT(y)", main=" ",
       ylim=c(ylim_dtt[1] - pad_dtt, ylim_dtt[2] + pad_dtt))
  draw_step_band(res$ygrid, res$LB.Fn, res$UB.Fn, band_fill)
  draw_h(res$ygrid, res$DTT, col="steelblue4", lty=1, lwd=2)
  draw_h(res$ygrid, res$LB.Fn, col="gray35", lty=2, lwd=1.5)
  draw_h(res$ygrid, res$UB.Fn, col="gray35", lty=2, lwd=1.5)
  if (has_pointwise) {
    draw_h(res$ygrid, res$PW.LB.Fn, col="firebrick3", lty=4, lwd=1.25)
    draw_h(res$ygrid, res$PW.UB.Fn, col="firebrick3", lty=4, lwd=1.25)
  }
  abline(h=0, lty=3, col="gray55")
  if (has_pointwise) {
    legend("topright", bty="n",
           legend=c("DTT", "Uniform band", "Pointwise CI"),
           lty=c(1,0,4), lwd=c(2,0,1.25), col=c("steelblue4", NA, "firebrick3"),
           fill=c(NA, band_fill, NA), border=NA)
  } else {
    legend("topright", bty="n",
           legend=c("DTT", "Uniform band"),
           lty=c(1,0), lwd=c(2,0), col=c("steelblue4", NA),
           fill=c(NA, band_fill), border=NA)
  }
  invisible(res)
}
#=============================================================================>

#=============================================================================>
# Purpose: Plots the implied QTT curve and its uniform confidence band.
# Input: Result data frame with DF estimates and bands, optional tau grid,
#        and output filename.
# Output: PDF plot saved to fig.name and invisibly returns the QTT objects used to plot.
plot2.QTT <- function(res2, fig.name="QTT.pdf", tau.grid=NULL){
  needed <- c("ygrid","F11_1","F11_1.LB","F11_1.UB","F01_1","F01_1.LB","F01_1.UB")
  if (!all(needed %in% names(res2))) {
    stop("res2 must contain ygrid, F11_1, F11_1.LB, F11_1.UB, F01_1, F01_1.LB, F01_1.UB")
  }
  res2 <- res2[order(res2$ygrid), , drop=FALSE]
  ygrid <- res2$ygrid
  
  sanitize_df <- function(F){
    pmin(1, pmax(0, cummax(as.numeric(F))))
  }
  q_from_df <- function(tau, y, F){
    F <- sanitize_df(F)
    sapply(tau, function(tt){
      idx <- which(F >= tt)[1]
      if (is.na(idx)) max(y) else y[idx]
    })
  }
  
  F11 <- sanitize_df(res2$F11_1)
  F11LB <- sanitize_df(res2$F11_1.LB)
  F11UB <- sanitize_df(res2$F11_1.UB)
  F01 <- sanitize_df(res2$F01_1)
  F01LB <- sanitize_df(res2$F01_1.LB)
  F01UB <- sanitize_df(res2$F01_1.UB)
  
  if (is.null(tau.grid)) {
    tau.grid <- sort(unique(c(0, 1, F11, F11LB, F11UB, F01, F01LB, F01UB)))
    tau.grid <- tau.grid[tau.grid >= 0 & tau.grid <= 1]
  }
  if (length(tau.grid) < 2) {
    tau.grid <- seq(0.01, 0.99, length.out = 200)
  }
  
  Q11 <- q_from_df(tau.grid, ygrid, F11)
  Q01 <- q_from_df(tau.grid, ygrid, F01)
  # QF bands: I_j^{-1}(\tau) = [U_j^{-1}(\tau), L_j^{-1}(\tau)]
  Q11_LB <- q_from_df(tau.grid, ygrid, F11UB) # U1^{-1}
  Q11_UB <- q_from_df(tau.grid, ygrid, F11LB) # L1^{-1}
  Q01_LB <- q_from_df(tau.grid, ygrid, F01UB) # U0^{-1}
  Q01_UB <- q_from_df(tau.grid, ygrid, F01LB) # L0^{-1}
  # QTT band via Minkowski difference:
  # I_QTT^{-1} = I_1^{-1} \ominus I_0^{-1} = [U1^{-1}-L0^{-1}, L1^{-1}-U0^{-1}]
  QTT <- Q11 - Q01
  QTT_LB <- Q11_LB - Q01_UB
  QTT_UB <- Q11_UB - Q01_LB
  
  draw_step_band <- function(x, lower, upper, fill_col){
    if (length(x) < 2) return()
    for (i in 1:(length(x)-1)) {
      if (!all(is.finite(c(x[i], x[i+1], lower[i], upper[i])))) next
      polygon(
        x = c(x[i], x[i+1], x[i+1], x[i]),
        y = c(lower[i], lower[i], upper[i], upper[i]),
        col = fill_col,
        border = NA
      )
    }
  }
  draw_h <- function(x, y, col, lty, lwd){
    if (length(x) < 2) return()
    for (i in 1:(length(x)-1)) {
      segments(x[i], y[i], x[i+1], y[i], col=col, lty=lty, lwd=lwd)
    }
  }
  band_fill <- grDevices::adjustcolor("lightblue", alpha.f = 0.45)
  
  pdf(fig.name, , width=8, height=5)
  on.exit(dev.off(), add=TRUE)
  
  ylim_qtt <- range(c(QTT, QTT_LB, QTT_UB), na.rm=TRUE)
  pad_qtt <- max(0.01, 0.05 * diff(ylim_qtt))
  if (!is.finite(pad_qtt)) pad_qtt <- 0.05
  plot(tau.grid, QTT, type="n",
       #xlab=expression(tau), ylab="QTT(tau)",  TeX()
       xlab=expression(tau), ylab=TeX("QTT(\\tau)"),
       main=" ",
       ylim=c(ylim_qtt[1] - pad_qtt, ylim_qtt[2] + pad_qtt))
  draw_step_band(tau.grid, QTT_LB, QTT_UB, band_fill)
  draw_h(tau.grid, QTT, col="steelblue4", lty=1, lwd=2)
  draw_h(tau.grid, QTT_LB, col="gray35", lty=2, lwd=1.5)
  draw_h(tau.grid, QTT_UB, col="gray35", lty=2, lwd=1.5)
  abline(h=0, lty=3, col="gray55")
  legend("topright", bty="n",
         legend=c("QTT", "Uniform band"),
         lty=c(1,0), lwd=c(2,0), col=c("steelblue4", NA),
         fill=c(NA, band_fill), border=NA)
  
  invisible(list(tau=tau.grid, QTT=QTT, QTT_LB=QTT_LB, QTT_UB=QTT_UB))
}
#=============================================================================>


#===============================================================================
# Purpose: Reads rejection-rate output and produces CvM and KS power-curve plots.
# Input: Text file with rejection rates by eta and an optional output PDF stem.
# Output: Saved PDF plots when filename is provided, otherwise printed ggplot objects.
plot.pow<- function(txt_file, filename=NULL){
  df <- tryCatch(
    read.table(txt_file, header = TRUE, stringsAsFactors = FALSE),
    error = function(e) NULL
  )
  if (is.null(df) || nrow(df) == 0) stop("Failed to read txt_file.")
  
  make_plot <- function(cols, title_label) {
    long <- data.frame(
      eta = rep(df$eta, 3),
      Alpha = rep(c("0.01","0.05","0.10"), each = nrow(df)),
      Power = c(df[[cols[1]]], df[[cols[2]]], df[[cols[3]]])
    )
    ggplot(long, aes(x=eta, y=Power, color=Alpha, linetype=Alpha)) +
      geom_line(linewidth=1) +
      theme_gray() +
      xlab("eta") +
      ylab("Rejection rate") +
      ggtitle(title_label) +
      ylim(0, 1) +
      theme(legend.title=element_blank())
  }
  
  p_cvm <- make_plot(c("CvM_01","CvM_05","CvM_10"), "CvM test")
  p_ks  <- make_plot(c("KS_01","KS_05","KS_10"), "KS test")
  
  if (!is.null(filename)) {
    base <- sub("\\.[Pp][Dd][Ff]$", "", filename)
    ggsave(filename = paste0(base, "_CvM.pdf"), plot = p_cvm, width = 8, height = 6)
    ggsave(filename = paste0(base, "_KS.pdf"), plot = p_ks, width = 8, height = 6)
  } else {
    print(p_cvm)
    print(p_ks)
  }
}
#===============================================================================
