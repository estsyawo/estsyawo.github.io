Discarded C code

//double  pY[(int)n];
    //double  pXv[(int)(n*p)];
    //double  pbetas[(int)(p+1)];
    


for (int i=0; i<n; i++)
    {
        pY[i] = Y[i];
    }
    for (int j=0; j<=p; j++) {
        pbetas[j]=betas[j];
    }
    for (int i=0; i<n; i++) {
        for (int j=0; j<p; j++) {
            pXv[(int)j*n + i];
        }
    }