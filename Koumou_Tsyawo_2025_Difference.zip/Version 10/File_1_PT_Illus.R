#=========================================================================================>
# Authors: Gilles Koumou & Emmanuel Selorm Tsyawo
# Project: Difference-in-differences with as few as two cross-sectional units\\ 
#-- A new perspective to the democracy-growth debate
# Date begun: Sept. 13, 2022
# Date last updated:   Oct. 2, 2025
# Place:        Tuscaloosa
# Purpose: Graphical Illustrations of the Parallel Trends Condition
#=========================================================================================>
rm(list=ls()) # clear entire memory
library(dplyr)
library(ggplot2)
library(latex2exp)
#setwd(dirname(rstudioapi::getActiveDocumentContext()$path)) #set working directory path to source file
#=========================================================================================>


#=========================================================================================>
# Functions of untreated potential outcomes
a.fun = function(t) cos(t)

Y0D.fun = function(t,d=1,eta=0.6){
  
  if(d==0) {res = a.fun(t)
  }else{
    if(t>= 1){
      res = 0.5 + a.fun(t) + 0.25*abs(1+0.5*sin(t))*t^(-eta)
    }else{
      res = 0.5 + a.fun(t) - 0.25*abs(1+0.5*sin(t))*(-t)^(-eta)
    }  
    } #end if(d==0)
  res
}

Y0D.fun = Vectorize(Y0D.fun)

pt.vio<- function(df.obj){
  a= (df.obj$value[df.obj$period=="Post" & df.obj$group=="D=1" ]
  - df.obj$value[df.obj$period=="Pre" & df.obj$group=="D=1" ])
  
  b = (df.obj$value[df.obj$period=="Post" & df.obj$group=="D=0" ]
       - df.obj$value[df.obj$period=="Pre" & df.obj$group=="D=0" ])
  return(a-b)
}

#=========================================================================================>
n.T = 5
t.vec.5 = c(-(n.T:1),1:n.T)

# Build a tidy data.frame with both series
df.5 <- data.frame(
  t = rep(t.vec.5, 2),
  value = c(Y0D.fun(t.vec.5, d = 1, eta = 0.6),
            Y0D.fun(t.vec.5, d = 0, eta = 0.6)),
  group = factor(rep(c("D=1","D=0"), each = length(t.vec.5)))
)

ggplot(df.5, aes(x = t, y = value, linetype = group)) +
  geom_line(linewidth = 1) +
  geom_vline(xintercept = 0, linetype = 3) +
  scale_linetype_manual(
    values = c("D=1" = 1, "D=0" = 2),
    labels = c("D=1" = TeX("$E[Y_{t}(0)|D=1]$"),
               "D=0" = TeX("$E[Y_{t}(0)|D=0]$"))
  ) +
  scale_x_continuous(
    breaks = c(t.vec.5, 0),    # add 0 even if not in data
    labels = c(t.vec.5, 0)     # what to display at those ticks
  ) +
  labs(x = "Period", y = "", linetype = "") +
  theme_gray(base_size = 13) +
  theme(
    legend.position = c(0.8, 0.8),
    legend.background = element_rect(fill = "white", color = "black"),
    legend.text = element_text(size = 10)
  )

ggsave("out_PT_Illus_5.png")
#-------------------------------------------------------------------------------
# ---- Collapse to four points: pre (t<=-1) and post (t>=1) averages, per group ----
df.4 <- df.5 %>%
  mutate(period = ifelse(t <= -1, "Pre", "Post")) %>%
  group_by(group, period) %>%
  summarise(value = mean(value), .groups = "drop") %>%
  mutate(x = ifelse(period == "Pre", -1, 1)) %>%
  arrange(group, x)

# ---- Plot (four-point line plot) ----
ggplot(df.4, aes(x = x, y = value, linetype = group)) +
  geom_line(linewidth = 1) +
  geom_point(size = 2) +
  geom_vline(xintercept = 0, linetype = 3) +
  scale_linetype_manual(
    values = c("D=1" = 1, "D=0" = 2),
    labels = c("D=1" = TeX("$ E[\\bar{Y}(0) | D=1] $"),
               "D=0" = TeX("$ E[\\bar{Y}(0) | D=0] $"))
  ) +
  scale_x_continuous(
    breaks = c(-1, 0, 1),                 # only show the three key ticks
    labels = c("Pre", "0", "Post")        # replace -1 and 1 with text
  ) +
  ylim(-0.3, 0.8) +                      # set y-axis limits
  labs(x = "Period", y = "", linetype = "") +
  theme_gray(base_size = 13) +
  theme(
    legend.position = c(0.8, 0.7),
    legend.background = element_rect(fill = "white", color = "black"),
    legend.text = element_text(size = 10)
  )

ggsave("out_PT_Illus_5_b.png")

pt.vio(df.4) # 0.2993042
#=========================================================================================>


#=========================================================================================>
n.T = 25
t.vec.25 = c(-(n.T:1),1:n.T)

# Build a tidy data.frame with both series
df.25 <- data.frame(
  t = rep(t.vec.25, 2),
  value = c(Y0D.fun(t.vec.25, d = 1, eta = 0.6),
            Y0D.fun(t.vec.25, d = 0, eta = 0.6)),
  group = factor(rep(c("D=1","D=0"), each = length(t.vec.25)))
)

ggplot(df.25, aes(x = t, y = value, linetype = group)) +
  geom_line(linewidth = 1) +
  geom_vline(xintercept = 0, linetype = 3) +
  scale_linetype_manual(
    values = c("D=1" = 1, "D=0" = 2),
    labels = c("D=1" = TeX("$E[Y_{t}(0)|D=1]$"),
               "D=0" = TeX("$E[Y_{t}(0)|D=0]$"))
  ) +
  scale_x_continuous(
    breaks = c(5*t.vec.5, 0),    # add 0 even if not in data
    labels = c(5*t.vec.5, 0)     # what to display at those ticks
  ) +
  labs(x = "Period", y = "", linetype = "") +
  theme_gray(base_size = 13) +
  theme(
    legend.position = c(0.8, 0.85),
    legend.background = element_rect(fill = "white", color = "black"),
    legend.text = element_text(size = 10)
  )

ggsave("out_PT_Illus_25.png")
#-------------------------------------------------------------------------------
# ---- Collapse to four points: pre (t<=-1) and post (t>=1) averages, per group ----
df.24 <- df.25 %>%
  mutate(period = ifelse(t <= -1, "Pre", "Post")) %>%
  group_by(group, period) %>%
  summarise(value = mean(value), .groups = "drop") %>%
  mutate(x = ifelse(period == "Pre", -1, 1)) %>%
  arrange(group, x)

# ---- Plot (four-point line plot) ----
ggplot(df.24, aes(x = x, y = value, linetype = group)) +
  geom_line(linewidth = 1) +
  geom_point(size = 2) +
  geom_vline(xintercept = 0, linetype = 3) +
  scale_linetype_manual(
    values = c("D=1" = 1, "D=0" = 2),
    labels = c("D=1" = TeX("$E[\\bar{Y}(0) | D=1]$"),
               "D=0" = TeX("$E[\\bar{Y}(0) | D=0]$"))
  ) +
  # keep your tick setup; only -1 and 1 have data, 0 is the vertical line
  scale_x_continuous(
    breaks = c(-1, 0, 1),
    labels = c("Pre", 0, "Post")
  ) +
  ylim(-0.3,0.80) +
  labs(x = "Period", y = "", linetype = "") +
  theme_gray(base_size = 13) +
  theme(
    legend.position = c(0.8, 0.85),
    legend.background = element_rect(fill = "white", color = "black"),
    legend.text = element_text(size = 10)
  )

ggsave("out_PT_Illus_25_b.png")


pt.vio(df.obj = df.24) #0.1435854
#===============================================================================>


#===============================================================================>
#Graph the magnitude of the parallel trends deviation as a function of T 
pt.vio.func<- function(n.T){
  t.vec = c(-(n.T:1),1:n.T)
  
  # Build a tidy data.frame with both series
  df <- data.frame(
    t = rep(t.vec, 2),
    value = c(Y0D.fun(t.vec, d = 1, eta = 0.6),
              Y0D.fun(t.vec, d = 0, eta = 0.6)),
    group = factor(rep(c("D=1","D=0"), each = length(t.vec)))
  ) #end data.frame
  
  # ---- Collapse to four points: pre (t<=-1) and post (t>=1) averages, per group ----
  df.coll <- df %>%
    mutate(period = ifelse(t <= -1, "Pre", "Post")) %>%
    group_by(group, period) %>%
    summarise(value = mean(value), .groups = "drop") %>%
    mutate(x = ifelse(period == "Pre", -1, 1)) %>%
    arrange(group, x)
  
  return(pt.vio(df.obj = df.coll))
}; pt.vio.func=Vectorize(pt.vio.func)

#test
pt.vio.func(n.T=15)




# Discrete integer grid
df <- data.frame(
  x = 5:50
)

# Evaluate your function at integers
df$y <- pt.vio.func(df$x)

# Plot with TeX xlabel
ggplot(df, aes(x = x, y = y)) +
  geom_line(linewidth = 1, colour = "steelblue") +
  geom_point(size = 2, colour = "steelblue") +
  labs(
    x = TeX("$ T $"),
    y = " ",
    title = " "
  ) +
  theme_minimal(base_size = 14) +
  theme(
    plot.title = element_text(hjust = 0.5)
  )

ggsave("out_PT_Illus_n_5_50.png")
#===============================================================================>