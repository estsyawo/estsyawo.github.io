/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * warning.c
 *
 * Code generation for function 'warning'
 *
 */

/* Include files */
#include "rt_nonfinite.h"
#include "goldsscoord3.h"
#include "warning.h"

/* Variable Definitions */
static emlrtMCInfo emlrtMCI = { 14,    /* lineNo */
  25,                                  /* colNo */
  "warning",                           /* fName */
  "/usr/local/MATLAB/R2018b/toolbox/shared/coder/coder/+coder/+internal/warning.m"/* pName */
};

static emlrtMCInfo b_emlrtMCI = { 14,  /* lineNo */
  9,                                   /* colNo */
  "warning",                           /* fName */
  "/usr/local/MATLAB/R2018b/toolbox/shared/coder/coder/+coder/+internal/warning.m"/* pName */
};

static emlrtRSInfo sf_emlrtRSI = { 14, /* lineNo */
  "warning",                           /* fcnName */
  "/usr/local/MATLAB/R2018b/toolbox/shared/coder/coder/+coder/+internal/warning.m"/* pathName */
};

/* Function Declarations */
static void b_feval(const emlrtStack *sp, const mxArray *b, const mxArray *c,
                    emlrtMCInfo *location);
static const mxArray *c_feval(const emlrtStack *sp, const mxArray *b, const
  mxArray *c, const mxArray *d, const mxArray *e, emlrtMCInfo *location);
static const mxArray *d_feval(const emlrtStack *sp, const mxArray *b, const
  mxArray *c, const mxArray *d, emlrtMCInfo *location);
static const mxArray *feval(const emlrtStack *sp, const mxArray *b, const
  mxArray *c, emlrtMCInfo *location);

/* Function Definitions */
static void b_feval(const emlrtStack *sp, const mxArray *b, const mxArray *c,
                    emlrtMCInfo *location)
{
  const mxArray *pArrays[2];
  pArrays[0] = b;
  pArrays[1] = c;
  emlrtCallMATLABR2012b(sp, 0, NULL, 2, pArrays, "feval", true, location);
}

static const mxArray *c_feval(const emlrtStack *sp, const mxArray *b, const
  mxArray *c, const mxArray *d, const mxArray *e, emlrtMCInfo *location)
{
  const mxArray *pArrays[4];
  const mxArray *m38;
  pArrays[0] = b;
  pArrays[1] = c;
  pArrays[2] = d;
  pArrays[3] = e;
  return emlrtCallMATLABR2012b(sp, 1, &m38, 4, pArrays, "feval", true, location);
}

static const mxArray *d_feval(const emlrtStack *sp, const mxArray *b, const
  mxArray *c, const mxArray *d, emlrtMCInfo *location)
{
  const mxArray *pArrays[3];
  const mxArray *m39;
  pArrays[0] = b;
  pArrays[1] = c;
  pArrays[2] = d;
  return emlrtCallMATLABR2012b(sp, 1, &m39, 3, pArrays, "feval", true, location);
}

static const mxArray *feval(const emlrtStack *sp, const mxArray *b, const
  mxArray *c, emlrtMCInfo *location)
{
  const mxArray *pArrays[2];
  const mxArray *m36;
  pArrays[0] = b;
  pArrays[1] = c;
  return emlrtCallMATLABR2012b(sp, 1, &m36, 2, pArrays, "feval", true, location);
}

void b_warning(const emlrtStack *sp, int32_T varargin_1, const char_T
               varargin_2[14])
{
  const mxArray *y;
  const mxArray *m20;
  static const int32_T iv13[2] = { 1, 7 };

  static const char_T u[7] = { 'w', 'a', 'r', 'n', 'i', 'n', 'g' };

  const mxArray *b_y;
  const mxArray *m21;
  static const int32_T iv14[2] = { 1, 7 };

  static const char_T b_u[7] = { 'm', 'e', 's', 's', 'a', 'g', 'e' };

  const mxArray *c_y;
  const mxArray *m22;
  static const int32_T iv15[2] = { 1, 32 };

  static const char_T msgID[32] = { 'C', 'o', 'd', 'e', 'r', ':', 'M', 'A', 'T',
    'L', 'A', 'B', ':', 'r', 'a', 'n', 'k', 'D', 'e', 'f', 'i', 'c', 'i', 'e',
    'n', 't', 'M', 'a', 't', 'r', 'i', 'x' };

  const mxArray *d_y;
  const mxArray *m23;
  const mxArray *e_y;
  const mxArray *m24;
  static const int32_T iv16[2] = { 1, 14 };

  emlrtStack st;
  st.prev = sp;
  st.tls = sp->tls;
  y = NULL;
  m20 = emlrtCreateCharArray(2, iv13);
  emlrtInitCharArrayR2013a(sp, 7, m20, &u[0]);
  emlrtAssign(&y, m20);
  b_y = NULL;
  m21 = emlrtCreateCharArray(2, iv14);
  emlrtInitCharArrayR2013a(sp, 7, m21, &b_u[0]);
  emlrtAssign(&b_y, m21);
  c_y = NULL;
  m22 = emlrtCreateCharArray(2, iv15);
  emlrtInitCharArrayR2013a(sp, 32, m22, &msgID[0]);
  emlrtAssign(&c_y, m22);
  d_y = NULL;
  m23 = emlrtCreateNumericMatrix(1, 1, mxINT32_CLASS, mxREAL);
  *(int32_T *)emlrtMxGetData(m23) = varargin_1;
  emlrtAssign(&d_y, m23);
  e_y = NULL;
  m24 = emlrtCreateCharArray(2, iv16);
  emlrtInitCharArrayR2013a(sp, 14, m24, &varargin_2[0]);
  emlrtAssign(&e_y, m24);
  st.site = &sf_emlrtRSI;
  b_feval(&st, y, c_feval(&st, b_y, c_y, d_y, e_y, &emlrtMCI), &b_emlrtMCI);
}

void c_warning(const emlrtStack *sp)
{
  const mxArray *y;
  const mxArray *m25;
  static const int32_T iv17[2] = { 1, 7 };

  static const char_T u[7] = { 'w', 'a', 'r', 'n', 'i', 'n', 'g' };

  const mxArray *b_y;
  const mxArray *m26;
  static const int32_T iv18[2] = { 1, 7 };

  static const char_T b_u[7] = { 'm', 'e', 's', 's', 'a', 'g', 'e' };

  const mxArray *c_y;
  const mxArray *m27;
  static const int32_T iv19[2] = { 1, 31 };

  static const char_T msgID[31] = { 's', 't', 'a', 't', 's', ':', 'k', 'm', 'e',
    'a', 'n', 's', ':', 'M', 'i', 's', 's', 'i', 'n', 'g', 'D', 'a', 't', 'a',
    'R', 'e', 'm', 'o', 'v', 'e', 'd' };

  emlrtStack st;
  st.prev = sp;
  st.tls = sp->tls;
  y = NULL;
  m25 = emlrtCreateCharArray(2, iv17);
  emlrtInitCharArrayR2013a(sp, 7, m25, &u[0]);
  emlrtAssign(&y, m25);
  b_y = NULL;
  m26 = emlrtCreateCharArray(2, iv18);
  emlrtInitCharArrayR2013a(sp, 7, m26, &b_u[0]);
  emlrtAssign(&b_y, m26);
  c_y = NULL;
  m27 = emlrtCreateCharArray(2, iv19);
  emlrtInitCharArrayR2013a(sp, 31, m27, &msgID[0]);
  emlrtAssign(&c_y, m27);
  st.site = &sf_emlrtRSI;
  b_feval(&st, y, feval(&st, b_y, c_y, &emlrtMCI), &b_emlrtMCI);
}

void d_warning(const emlrtStack *sp)
{
  const mxArray *y;
  const mxArray *m29;
  static const int32_T iv21[2] = { 1, 7 };

  static const char_T u[7] = { 'w', 'a', 'r', 'n', 'i', 'n', 'g' };

  const mxArray *b_y;
  const mxArray *m30;
  static const int32_T iv22[2] = { 1, 7 };

  static const char_T b_u[7] = { 'm', 'e', 's', 's', 'a', 'g', 'e' };

  const mxArray *c_y;
  const mxArray *m31;
  static const int32_T iv23[2] = { 1, 29 };

  static const char_T msgID[29] = { 's', 't', 'a', 't', 's', ':', 'k', 'm', 'e',
    'a', 'n', 's', ':', 'F', 'a', 'i', 'l', 'e', 'd', 'T', 'o', 'C', 'o', 'n',
    'v', 'e', 'r', 'g', 'e' };

  const mxArray *d_y;
  const mxArray *m32;
  emlrtStack st;
  st.prev = sp;
  st.tls = sp->tls;
  y = NULL;
  m29 = emlrtCreateCharArray(2, iv21);
  emlrtInitCharArrayR2013a(sp, 7, m29, &u[0]);
  emlrtAssign(&y, m29);
  b_y = NULL;
  m30 = emlrtCreateCharArray(2, iv22);
  emlrtInitCharArrayR2013a(sp, 7, m30, &b_u[0]);
  emlrtAssign(&b_y, m30);
  c_y = NULL;
  m31 = emlrtCreateCharArray(2, iv23);
  emlrtInitCharArrayR2013a(sp, 29, m31, &msgID[0]);
  emlrtAssign(&c_y, m31);
  d_y = NULL;
  m32 = emlrtCreateNumericMatrix(1, 1, mxINT32_CLASS, mxREAL);
  *(int32_T *)emlrtMxGetData(m32) = 100;
  emlrtAssign(&d_y, m32);
  st.site = &sf_emlrtRSI;
  b_feval(&st, y, d_feval(&st, b_y, c_y, d_y, &emlrtMCI), &b_emlrtMCI);
}

void warning(const emlrtStack *sp)
{
  const mxArray *y;
  const mxArray *m16;
  static const int32_T iv9[2] = { 1, 7 };

  static const char_T u[7] = { 'w', 'a', 'r', 'n', 'i', 'n', 'g' };

  const mxArray *b_y;
  const mxArray *m17;
  static const int32_T iv10[2] = { 1, 7 };

  static const char_T b_u[7] = { 'm', 'e', 's', 's', 'a', 'g', 'e' };

  const mxArray *c_y;
  const mxArray *m18;
  static const int32_T iv11[2] = { 1, 27 };

  static const char_T msgID[27] = { 'C', 'o', 'd', 'e', 'r', ':', 'M', 'A', 'T',
    'L', 'A', 'B', ':', 's', 'i', 'n', 'g', 'u', 'l', 'a', 'r', 'M', 'a', 't',
    'r', 'i', 'x' };

  emlrtStack st;
  st.prev = sp;
  st.tls = sp->tls;
  y = NULL;
  m16 = emlrtCreateCharArray(2, iv9);
  emlrtInitCharArrayR2013a(sp, 7, m16, &u[0]);
  emlrtAssign(&y, m16);
  b_y = NULL;
  m17 = emlrtCreateCharArray(2, iv10);
  emlrtInitCharArrayR2013a(sp, 7, m17, &b_u[0]);
  emlrtAssign(&b_y, m17);
  c_y = NULL;
  m18 = emlrtCreateCharArray(2, iv11);
  emlrtInitCharArrayR2013a(sp, 27, m18, &msgID[0]);
  emlrtAssign(&c_y, m18);
  st.site = &sf_emlrtRSI;
  b_feval(&st, y, feval(&st, b_y, c_y, &emlrtMCI), &b_emlrtMCI);
}

/* End of code generation (warning.c) */
