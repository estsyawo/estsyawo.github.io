/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * CCRls2.c
 *
 * Code generation for function 'CCRls2'
 *
 */

/* Include files */
#include <string.h>
#include "mwmathutil.h"
#include "rt_nonfinite.h"
#include "CCRls2.h"
#include "CCRls2_emxutil.h"
#include "mldivide.h"
#include "rdivide_helper.h"
#include "CCRls2_data.h"
#include "blas.h"

/* Function Definitions */
void CCRls2(const real_T Y[1000], const real_T Xv[20000000], uint32_T n,
            uint32_T p, emxArray_real_T *betas)
{
  int32_T loop_ub;
  int32_T Y_size[1];
  real_T Y_data[1000];
  emxArray_real_T *X;
  int32_T i0;
  int32_T i1;
  int32_T slc;
  int32_T b_n;
  int32_T b_loop_ub;
  emxArray_uint32_T *y;
  int32_T k;
  emxArray_uint32_T *lcls;
  uint32_T nlcls;
  emxArray_real_T *X0;
  emxArray_real_T *bet_vec;
  emxArray_real_T *coefs;
  real_T val0;
  real_T val1;
  real_T l;
  real_T coef0[2];
  real_T dev;
  emxArray_boolean_T *ngIDLS;
  emxArray_boolean_T *IDls;
  emxArray_real_T *XB;
  emxArray_real_T *XX;
  emxArray_real_T *r0;
  emxArray_int32_T *r1;
  emxArray_int32_T *r2;
  emxArray_int32_T *r3;
  cell_wrap_0 reshapes[3];
  emxArray_char_T *charStr;
  emxArray_int32_T *a_tmp;
  emxArray_real_T *b_X;
  uint32_T IND;
  ptrdiff_t m_t;
  ptrdiff_t n_t;
  ptrdiff_t k_t;
  ptrdiff_t lda_t;
  ptrdiff_t ldb_t;
  ptrdiff_t ldc_t;
  char_T TRANSA;
  char_T TRANSB;
  boolean_T empty_non_axis_sizes;
  int8_T input_sizes_idx_1;
  int32_T i2;
  boolean_T guard1 = false;
  real_T a_data[1000];
  real_T y_data[1000];
  real_T d0;
  emlrtHeapReferenceStackEnterFcnR2012b(emlrtRootTLSGlobal);
  emlrtMEXProfilingFunctionEntry(CCRls2_complete_name, isMexOutdated);

  /*  Note: this function takes vectorised inputs.  */
  /*  Vectorisation is column major. */
  emlrtMEXProfilingStatement(2, isMexOutdated);
  if (1U > n) {
    loop_ub = 0;
  } else {
    loop_ub = (int32_T)n;
  }

  Y_size[0] = loop_ub;
  if (0 <= loop_ub - 1) {
    memcpy(&Y_data[0], &Y[0], (uint32_T)(loop_ub * (int32_T)sizeof(real_T)));
  }

  emxInit_real_T(&X, 2, true);

  /* extract actual data */
  emlrtMEXProfilingStatement(3, isMexOutdated);

  /*  total number of elements in Xv and covariates */
  emlrtMEXProfilingStatement(4, isMexOutdated);

  /* extract total number of elements in covariates */
  emlrtMEXProfilingStatement(5, isMexOutdated);

  /* convert design vector into design matrix */
  emlrtMEXProfilingStatement(6, isMexOutdated);
  i0 = (int32_T)n;
  i1 = X->size[0] * X->size[1];
  X->size[0] = (int32_T)n;
  X->size[1] = (int32_T)p;
  emxEnsureCapacity_real_T(X, i1);
  for (slc = 0; slc < i0; slc++) {
    emlrtMEXProfilingStatement(7, isMexOutdated);
    i1 = (int32_T)p;
    for (b_n = 0; b_n < i1; b_n++) {
      emlrtMEXProfilingStatement(8, isMexOutdated);
      X->data[slc + X->size[0] * b_n] = Xv[(int32_T)(b_n * n + slc)];
      emlrtMEXProfilingStatement(9, isMexOutdated);
      if (*emlrtBreakCheckR2012bFlagVar != 0) {
        emlrtBreakCheckR2012b(emlrtRootTLSGlobal);
      }
    }

    emlrtMEXProfilingStatement(10, isMexOutdated);
    if (*emlrtBreakCheckR2012bFlagVar != 0) {
      emlrtBreakCheckR2012b(emlrtRootTLSGlobal);
    }
  }

  emlrtMEXProfilingStatement(11, isMexOutdated);

  /*  vector to store parameters, excludes intercept */
  emlrtMEXProfilingStatement(12, isMexOutdated);
  i0 = betas->size[0] * betas->size[1];
  betas->size[0] = 1;
  betas->size[1] = (int32_T)(p + 1U);
  emxEnsureCapacity_real_T(betas, i0);
  b_loop_ub = (int32_T)(p + 1U);
  for (i0 = 0; i0 < b_loop_ub; i0++) {
    betas->data[i0] = 0.0;
  }

  /*  fraction of total number of observations as partition size */
  emlrtMEXProfilingStatement(14, isMexOutdated);
  slc = (int32_T)muDoubleScalarRound(0.1 * (real_T)n);

  /* maximum size of a local covariate cluster. */
  emlrtMEXProfilingStatement(15, isMexOutdated);
  if ((uint32_T)slc > p) {
    emlrtMEXProfilingStatement(16, isMexOutdated);
  }

  emxInit_uint32_T(&y, 2, true);
  emlrtMEXProfilingStatement(18, isMexOutdated);
  if (p < 1U) {
    b_n = 0;
  } else {
    b_n = (int32_T)p;
  }

  i0 = y->size[0] * y->size[1];
  y->size[0] = 1;
  y->size[1] = b_n;
  emxEnsureCapacity_uint32_T(y, i0);
  for (k = 0; k < b_n; k++) {
    y->data[k] = (uint32_T)(k + 1);
  }

  emxInit_uint32_T(&lcls, 2, true);
  rdivide_helper(y, (uint32_T)slc, lcls);

  /* partition covarites into clusters */
  emlrtMEXProfilingStatement(19, isMexOutdated);
  b_n = lcls->size[1];
  nlcls = lcls->data[0];
  emxFree_uint32_T(&y);
  for (k = 2; k <= b_n; k++) {
    if (nlcls < lcls->data[k - 1]) {
      nlcls = lcls->data[k - 1];
    }
  }

  emxInit_real_T(&X0, 2, true);

  /*  number of partitions */
  /*  Initialise parameters */
  emlrtMEXProfilingStatement(20, isMexOutdated);
  betas->data[0] = 0.0;

  /* initialise intercept */
  emlrtMEXProfilingStatement(21, isMexOutdated);
  i0 = X0->size[0] * X0->size[1];
  X0->size[0] = (int32_T)n;
  X0->size[1] = 2;
  emxEnsureCapacity_real_T(X0, i0);
  b_loop_ub = (int32_T)n << 1;
  for (i0 = 0; i0 < b_loop_ub; i0++) {
    X0->data[i0] = 1.0;
  }

  emxInit_real_T(&bet_vec, 2, true);

  /*  coef0 = zeros(1,2)'; */
  emlrtMEXProfilingStatement(22, isMexOutdated);
  i0 = (int32_T)p;
  i1 = bet_vec->size[0] * bet_vec->size[1];
  bet_vec->size[0] = 1;
  bet_vec->size[1] = (int32_T)p;
  emxEnsureCapacity_real_T(bet_vec, i1);
  for (b_n = 0; b_n < i0; b_n++) {
    emlrtMEXProfilingStatement(23, isMexOutdated);
    b_loop_ub = X->size[0] - 1;
    for (i1 = 0; i1 <= b_loop_ub; i1++) {
      X0->data[i1 + X0->size[0]] = X->data[i1 + X->size[0] * b_n];
    }

    emlrtMEXProfilingStatement(24, isMexOutdated);
    mldivide(X0, Y_data, Y_size, coef0);
    emlrtMEXProfilingStatement(25, isMexOutdated);
    bet_vec->data[b_n] = coef0[1];
    emlrtMEXProfilingStatement(26, isMexOutdated);
    if (*emlrtBreakCheckR2012bFlagVar != 0) {
      emlrtBreakCheckR2012b(emlrtRootTLSGlobal);
    }
  }

  emxFree_real_T(&X0);
  emxInit_real_T(&coefs, 1, true);
  emlrtMEXProfilingStatement(27, isMexOutdated);
  val0 = 1.00000000001E+10;
  val1 = 0.0;
  l = 0.0;
  dev = 1.00000000001E+10;
  emlrtMEXProfilingStatement(28, isMexOutdated);
  i0 = coefs->size[0];
  coefs->size[0] = slc;
  emxEnsureCapacity_real_T(coefs, i0);
  for (i0 = 0; i0 < slc; i0++) {
    coefs->data[i0] = 0.0;
  }

  emxInit_boolean_T(&ngIDLS, 2, true);
  emlrtMEXProfilingStatement(29, isMexOutdated);
  i0 = ngIDLS->size[0] * ngIDLS->size[1];
  ngIDLS->size[0] = 1;
  b_loop_ub = (int32_T)(p - slc);
  ngIDLS->size[1] = b_loop_ub;
  emxEnsureCapacity_boolean_T(ngIDLS, i0);
  for (i0 = 0; i0 < b_loop_ub; i0++) {
    ngIDLS->data[i0] = false;
  }

  emxInit_boolean_T(&IDls, 2, true);
  emlrtMEXProfilingStatement(30, isMexOutdated);
  i0 = IDls->size[0] * IDls->size[1];
  IDls->size[0] = 1;
  IDls->size[1] = slc;
  emxEnsureCapacity_boolean_T(IDls, i0);
  for (i0 = 0; i0 < slc; i0++) {
    IDls->data[i0] = false;
  }

  emlrtMEXProfilingStatement(31, isMexOutdated);
  emxInit_real_T(&XB, 1, true);
  emxInit_real_T(&XX, 2, true);
  emxInit_real_T(&r0, 2, true);
  emxInit_int32_T(&r1, 2, true);
  emxInit_int32_T(&r2, 2, true);
  emxInit_int32_T(&r3, 2, true);
  emxInitMatrix_cell_wrap_0(reshapes, true);
  emxInit_char_T(&charStr, 2, true);
  emxInit_int32_T(&a_tmp, 1, true);
  emxInit_real_T(&b_X, 2, true);
  while (dev > 1.0E-6) {
    emlrtMEXProfilingStatement(32, isMexOutdated);
    if (l > 0.0) {
      emlrtMEXProfilingStatement(33, isMexOutdated);
      val0 = val1;
      emlrtMEXProfilingStatement(34, isMexOutdated);
      if (2 > coefs->size[0] - 1) {
        i0 = 1;
      } else {
        i0 = 2;
      }

      k = IDls->size[1];
      b_n = -1;
      for (slc = 0; slc < k; slc++) {
        if (IDls->data[slc]) {
          bet_vec->data[slc] = coefs->data[i0 + b_n];
          b_n++;
        }
      }

      emlrtMEXProfilingStatement(35, isMexOutdated);
      betas->data[0] = coefs->data[0];
      emlrtMEXProfilingStatement(36, isMexOutdated);
      k = ngIDLS->size[1] - 1;
      b_n = 0;
      for (slc = 0; slc <= k; slc++) {
        if (ngIDLS->data[slc]) {
          b_n++;
        }
      }

      i0 = r3->size[0] * r3->size[1];
      r3->size[0] = 1;
      r3->size[1] = b_n;
      emxEnsureCapacity_int32_T(r3, i0);
      b_n = 0;
      for (slc = 0; slc <= k; slc++) {
        if (ngIDLS->data[slc]) {
          r3->data[b_n] = slc + 1;
          b_n++;
        }
      }

      i0 = r0->size[0] * r0->size[1];
      r0->size[0] = 1;
      r0->size[1] = r3->size[1];
      emxEnsureCapacity_real_T(r0, i0);
      val1 = coefs->data[coefs->size[0] - 1];
      b_loop_ub = r3->size[0] * r3->size[1];
      for (i0 = 0; i0 < b_loop_ub; i0++) {
        r0->data[i0] = bet_vec->data[r3->data[i0] - 1] * val1;
      }

      k = ngIDLS->size[1];
      b_n = 0;
      for (slc = 0; slc < k; slc++) {
        if (ngIDLS->data[slc]) {
          bet_vec->data[slc] = r0->data[b_n];
          b_n++;
        }
      }

      emlrtMEXProfilingStatement(37, isMexOutdated);
    }

    emlrtMEXProfilingStatement(38, isMexOutdated);
    l++;
    IND = (uint32_T)(l - (real_T)(((uint32_T)muDoubleScalarRound(l / (real_T)
      nlcls) - 1U) * nlcls));
    emlrtMEXProfilingStatement(39, isMexOutdated);
    i0 = IDls->size[0] * IDls->size[1];
    IDls->size[0] = 1;
    IDls->size[1] = lcls->size[1];
    emxEnsureCapacity_boolean_T(IDls, i0);
    b_loop_ub = lcls->size[0] * lcls->size[1];
    for (i0 = 0; i0 < b_loop_ub; i0++) {
      IDls->data[i0] = (lcls->data[i0] == IND);
    }

    /*  nIDls = length(IDls); */
    emlrtMEXProfilingStatement(40, isMexOutdated);
    i0 = ngIDLS->size[0] * ngIDLS->size[1];
    ngIDLS->size[0] = 1;
    ngIDLS->size[1] = lcls->size[1];
    emxEnsureCapacity_boolean_T(ngIDLS, i0);
    b_loop_ub = lcls->size[0] * lcls->size[1];
    for (i0 = 0; i0 < b_loop_ub; i0++) {
      ngIDLS->data[i0] = (lcls->data[i0] != IND);
    }

    emlrtMEXProfilingStatement(41, isMexOutdated);
    k = ngIDLS->size[1] - 1;
    b_n = 0;
    for (slc = 0; slc <= k; slc++) {
      if (ngIDLS->data[slc]) {
        b_n++;
      }
    }

    i0 = r1->size[0] * r1->size[1];
    r1->size[0] = 1;
    r1->size[1] = b_n;
    emxEnsureCapacity_int32_T(r1, i0);
    b_n = 0;
    for (slc = 0; slc <= k; slc++) {
      if (ngIDLS->data[slc]) {
        r1->data[b_n] = slc + 1;
        b_n++;
      }
    }

    i0 = a_tmp->size[0];
    a_tmp->size[0] = r1->size[1];
    emxEnsureCapacity_int32_T(a_tmp, i0);
    b_loop_ub = r1->size[1];
    for (i0 = 0; i0 < b_loop_ub; i0++) {
      a_tmp->data[i0] = r1->data[i0];
    }

    b_loop_ub = X->size[0];
    i0 = XX->size[0] * XX->size[1];
    XX->size[0] = b_loop_ub;
    XX->size[1] = a_tmp->size[0];
    emxEnsureCapacity_real_T(XX, i0);
    b_n = a_tmp->size[0];
    for (i0 = 0; i0 < b_n; i0++) {
      for (i1 = 0; i1 < b_loop_ub; i1++) {
        XX->data[i1 + XX->size[0] * i0] = X->data[i1 + X->size[0] * (a_tmp->
          data[i0] - 1)];
      }
    }

    i0 = coefs->size[0];
    coefs->size[0] = a_tmp->size[0];
    emxEnsureCapacity_real_T(coefs, i0);
    b_loop_ub = a_tmp->size[0];
    for (i0 = 0; i0 < b_loop_ub; i0++) {
      coefs->data[i0] = bet_vec->data[a_tmp->data[i0] - 1];
    }

    if (a_tmp->size[0] == 1) {
      i0 = XB->size[0];
      XB->size[0] = XX->size[0];
      emxEnsureCapacity_real_T(XB, i0);
      b_loop_ub = XX->size[0];
      for (i0 = 0; i0 < b_loop_ub; i0++) {
        XB->data[i0] = 0.0;
        b_n = XX->size[1];
        for (i1 = 0; i1 < b_n; i1++) {
          XB->data[i0] += XX->data[i0 + XX->size[0] * i1] * coefs->data[i1];
        }
      }
    } else {
      i0 = X->size[0];
      if ((i0 == 0) || (a_tmp->size[0] == 0) || (a_tmp->size[0] == 0)) {
        b_loop_ub = X->size[0];
        i0 = XB->size[0];
        XB->size[0] = b_loop_ub;
        emxEnsureCapacity_real_T(XB, i0);
        for (i0 = 0; i0 < b_loop_ub; i0++) {
          XB->data[i0] = 0.0;
        }
      } else {
        val1 = 1.0;
        dev = 0.0;
        i0 = X->size[0];
        m_t = (ptrdiff_t)i0;
        n_t = (ptrdiff_t)1;
        k_t = (ptrdiff_t)a_tmp->size[0];
        i0 = X->size[0];
        lda_t = (ptrdiff_t)i0;
        ldb_t = (ptrdiff_t)a_tmp->size[0];
        i0 = X->size[0];
        ldc_t = (ptrdiff_t)i0;
        i0 = X->size[0];
        i1 = XB->size[0];
        XB->size[0] = i0;
        emxEnsureCapacity_real_T(XB, i1);
        TRANSA = 'N';
        TRANSB = 'N';
        dgemm(&TRANSA, &TRANSB, &m_t, &n_t, &k_t, &val1, &XX->data[0], &lda_t,
              &coefs->data[0], &ldb_t, &dev, &XB->data[0], &ldc_t);
      }
    }

    emlrtMEXProfilingStatement(42, isMexOutdated);
    emlrtMEXProfilingStatement(43, isMexOutdated);
    k = IDls->size[1] - 1;
    b_n = 0;
    for (slc = 0; slc <= k; slc++) {
      if (IDls->data[slc]) {
        b_n++;
      }
    }

    i0 = r2->size[0] * r2->size[1];
    r2->size[0] = 1;
    r2->size[1] = b_n;
    emxEnsureCapacity_int32_T(r2, i0);
    b_n = 0;
    for (slc = 0; slc <= k; slc++) {
      if (IDls->data[slc]) {
        r2->data[b_n] = slc + 1;
        b_n++;
      }
    }

    if ((int32_T)n != 0) {
      k = (int32_T)n;
    } else {
      i0 = X->size[0];
      i1 = a_tmp->size[0];
      a_tmp->size[0] = r2->size[1];
      emxEnsureCapacity_int32_T(a_tmp, i1);
      b_loop_ub = r2->size[1];
      for (i1 = 0; i1 < b_loop_ub; i1++) {
        a_tmp->data[i1] = r2->data[i1];
      }

      if ((i0 != 0) && (a_tmp->size[0] != 0)) {
        k = X->size[0];
      } else if (XB->size[0] != 0) {
        k = XB->size[0];
      } else {
        i2 = (int32_T)n;
        k = muIntScalarMax_sint32(i2, 0);
        i0 = X->size[0];
        if (i0 > k) {
          k = X->size[0];
        }
      }
    }

    empty_non_axis_sizes = (k == 0);
    if (empty_non_axis_sizes || ((int32_T)n != 0)) {
      input_sizes_idx_1 = 1;
    } else {
      input_sizes_idx_1 = 0;
    }

    i0 = reshapes[0].f1->size[0] * reshapes[0].f1->size[1];
    reshapes[0].f1->size[0] = k;
    reshapes[0].f1->size[1] = input_sizes_idx_1;
    emxEnsureCapacity_real_T(reshapes[0].f1, i0);
    b_loop_ub = k * input_sizes_idx_1;
    for (i0 = 0; i0 < b_loop_ub; i0++) {
      reshapes[0].f1->data[i0] = 1.0;
    }

    guard1 = false;
    if (empty_non_axis_sizes) {
      guard1 = true;
    } else {
      i0 = X->size[0];
      i1 = a_tmp->size[0];
      a_tmp->size[0] = r2->size[1];
      emxEnsureCapacity_int32_T(a_tmp, i1);
      b_loop_ub = r2->size[1];
      for (i1 = 0; i1 < b_loop_ub; i1++) {
        a_tmp->data[i1] = r2->data[i1];
      }

      if ((i0 != 0) && (a_tmp->size[0] != 0)) {
        guard1 = true;
      } else {
        slc = 0;
      }
    }

    if (guard1) {
      i0 = a_tmp->size[0];
      a_tmp->size[0] = r2->size[1];
      emxEnsureCapacity_int32_T(a_tmp, i0);
      b_loop_ub = r2->size[1];
      for (i0 = 0; i0 < b_loop_ub; i0++) {
        a_tmp->data[i0] = r2->data[i0];
      }

      slc = a_tmp->size[0];
    }

    if (empty_non_axis_sizes || (XB->size[0] != 0)) {
      input_sizes_idx_1 = 1;
    } else {
      input_sizes_idx_1 = 0;
    }

    b_loop_ub = X->size[0];
    i0 = b_X->size[0] * b_X->size[1];
    b_X->size[0] = b_loop_ub;
    b_X->size[1] = r2->size[1];
    emxEnsureCapacity_real_T(b_X, i0);
    b_n = r2->size[1];
    for (i0 = 0; i0 < b_n; i0++) {
      for (i1 = 0; i1 < b_loop_ub; i1++) {
        b_X->data[i1 + b_X->size[0] * i0] = X->data[i1 + X->size[0] * (r2->
          data[i0] - 1)];
      }
    }

    i0 = XX->size[0] * XX->size[1];
    XX->size[0] = reshapes[0].f1->size[0];
    XX->size[1] = (reshapes[0].f1->size[1] + slc) + input_sizes_idx_1;
    emxEnsureCapacity_real_T(XX, i0);
    b_loop_ub = reshapes[0].f1->size[1];
    for (i0 = 0; i0 < b_loop_ub; i0++) {
      b_n = reshapes[0].f1->size[0];
      for (i1 = 0; i1 < b_n; i1++) {
        XX->data[i1 + XX->size[0] * i0] = reshapes[0].f1->data[i1 + reshapes[0].
          f1->size[0] * i0];
      }
    }

    for (i0 = 0; i0 < slc; i0++) {
      for (i1 = 0; i1 < k; i1++) {
        XX->data[i1 + XX->size[0] * (i0 + reshapes[0].f1->size[1])] = b_X->
          data[i1 + k * i0];
      }
    }

    b_loop_ub = input_sizes_idx_1;
    for (i0 = 0; i0 < b_loop_ub; i0++) {
      for (i1 = 0; i1 < k; i1++) {
        XX->data[i1 + XX->size[0] * (reshapes[0].f1->size[1] + slc)] = XB->
          data[i1];
      }
    }

    /* make room for intercept term */
    emlrtMEXProfilingStatement(44, isMexOutdated);
    b_mldivide(XX, Y_data, Y_size, coefs);
    emlrtMEXProfilingStatement(45, isMexOutdated);
    if ((XX->size[1] == 1) || (coefs->size[0] == 1)) {
      i0 = XB->size[0];
      XB->size[0] = XX->size[0];
      emxEnsureCapacity_real_T(XB, i0);
      b_loop_ub = XX->size[0];
      for (i0 = 0; i0 < b_loop_ub; i0++) {
        XB->data[i0] = 0.0;
        b_n = XX->size[1];
        for (i1 = 0; i1 < b_n; i1++) {
          XB->data[i0] += XX->data[i0 + XX->size[0] * i1] * coefs->data[i1];
        }
      }
    } else if ((XX->size[0] == 0) || (XX->size[1] == 0) || (coefs->size[0] == 0))
    {
      i0 = XB->size[0];
      XB->size[0] = XX->size[0];
      emxEnsureCapacity_real_T(XB, i0);
      b_loop_ub = XX->size[0];
      for (i0 = 0; i0 < b_loop_ub; i0++) {
        XB->data[i0] = 0.0;
      }
    } else {
      val1 = 1.0;
      dev = 0.0;
      m_t = (ptrdiff_t)XX->size[0];
      n_t = (ptrdiff_t)1;
      k_t = (ptrdiff_t)XX->size[1];
      lda_t = (ptrdiff_t)XX->size[0];
      ldb_t = (ptrdiff_t)XX->size[1];
      ldc_t = (ptrdiff_t)XX->size[0];
      i0 = XB->size[0];
      XB->size[0] = XX->size[0];
      emxEnsureCapacity_real_T(XB, i0);
      TRANSA = 'N';
      TRANSB = 'N';
      dgemm(&TRANSA, &TRANSB, &m_t, &n_t, &k_t, &val1, &XX->data[0], &lda_t,
            &coefs->data[0], &ldb_t, &dev, &XB->data[0], &ldc_t);
    }

    for (i0 = 0; i0 < loop_ub; i0++) {
      a_data[i0] = Y_data[i0] - XB->data[i0];
    }

    b_n = (int16_T)loop_ub;
    for (k = 0; k < b_n; k++) {
      y_data[k] = a_data[k] * a_data[k];
    }

    b_n = (int16_T)loop_ub;
    if ((int16_T)loop_ub == 0) {
      val1 = 0.0;
    } else {
      val1 = y_data[0];
      for (k = 2; k <= b_n; k++) {
        val1 += y_data[k - 1];
      }
    }

    emlrtMEXProfilingStatement(46, isMexOutdated);
    if (l > 1.0) {
      emlrtMEXProfilingStatement(47, isMexOutdated);
      dev = (val0 - val1) / (1.0 + muDoubleScalarAbs(val0));
      emlrtMEXProfilingStatement(50, isMexOutdated);
    } else {
      emlrtMEXProfilingStatement(48, isMexOutdated);
      emlrtMEXProfilingStatement(49, isMexOutdated);
      dev = 1.0;
      emlrtMEXProfilingStatement(50, isMexOutdated);
    }

    /*  print progress */
    emlrtMEXProfilingStatement(51, isMexOutdated);
    if (!muDoubleScalarIsInf(l)) {
      d0 = muDoubleScalarRem(l, 100.0);
    } else {
      d0 = rtNaN;
    }

    if (d0 == 0.0) {
      emlrtMEXProfilingStatement(52, isMexOutdated);
      b_n = (int32_T)emlrtMexSnprintf(NULL, 0,
        "iter = %.0f fval = %f and dev = %f", l, val1, dev) + 1;
      i0 = charStr->size[0] * charStr->size[1];
      charStr->size[0] = 1;
      charStr->size[1] = b_n;
      emxEnsureCapacity_char_T(charStr, i0);
      emlrtMexSnprintf(&charStr->data[0], (size_t)b_n,
                       "iter = %.0f fval = %f and dev = %f", l, val1, dev);
      emlrtMEXProfilingStatement(53, isMexOutdated);
    }

    emlrtMEXProfilingStatement(54, isMexOutdated);
    if (*emlrtBreakCheckR2012bFlagVar != 0) {
      emlrtBreakCheckR2012b(emlrtRootTLSGlobal);
    }
  }

  emxFree_real_T(&b_X);
  emxFree_int32_T(&a_tmp);
  emxFree_char_T(&charStr);
  emxFreeMatrix_cell_wrap_0(reshapes);
  emxFree_int32_T(&r3);
  emxFree_int32_T(&r2);
  emxFree_int32_T(&r1);
  emxFree_real_T(&r0);
  emxFree_real_T(&XX);
  emxFree_real_T(&XB);
  emxFree_boolean_T(&IDls);
  emxFree_boolean_T(&ngIDLS);
  emxFree_real_T(&coefs);
  emxFree_uint32_T(&lcls);
  emxFree_real_T(&X);
  emlrtMEXProfilingStatement(55, isMexOutdated);
  emlrtMEXProfilingStatement(56, isMexOutdated);
  i0 = (int32_T)p;
  for (b_n = 0; b_n < i0; b_n++) {
    emlrtMEXProfilingStatement(57, isMexOutdated);
    betas->data[b_n + 1] = bet_vec->data[b_n];
    emlrtMEXProfilingStatement(58, isMexOutdated);
    if (*emlrtBreakCheckR2012bFlagVar != 0) {
      emlrtBreakCheckR2012b(emlrtRootTLSGlobal);
    }
  }

  emxFree_real_T(&bet_vec);
  emlrtMEXProfilingFunctionExit(isMexOutdated);
  emlrtHeapReferenceStackLeaveFcnR2012b(emlrtRootTLSGlobal);
}

/* End of code generation (CCRls2.c) */
