#=========================================================================================>
# Authors: Gilles Koumou & Emmanuel Selorm Tsyawo
# Project: Difference-in-differences with as few as two cross-sectional units\\ 
#-- A new perspective to the democracy-growth debate
# Date begun: Sept. 13, 2022
# Date last updated:   Oct. 2, 2026
# Place:        Tuscaloosa
# Purpose: Simulations
#=========================================================================================>
rm(list=ls()) # clear entire memory
library(tseries)
library(lmtest)
library(sandwich)
library(parallel)
library(pbapply)
library(ggplot2)
#setwd(dirname(rstudioapi::getActiveDocumentContext()$path)) #set working directory path to source file
#=========================================================================================>
source("File_0_Fonctions.R")
#=========================================================================================>
#Comments:
# Compare the power curves of t-tests at the 10%, 5%, 1% levels using competing estimators: 
# DiD, SC, and BA with homogeneous treatment effects.
#=========================================================================================>
# Set parameters
R=10000 #number of Monte Carlo Samples
a=0.5 #difference in counterfactual group mean outcomes
n.vec=c(25,50,100,200,400) #vector samples sizes nT,nTau
g.vec=seq(0,1,length.out=11)
cl=floor(detectCores()/2) #number of cores for parallel computation
#=========================================================================================>


#===============================================================================
#start.time<- Sys.time()
#===============================================================================


#=========================================================================================>
# DGP_1: MDS; alf0=alf1; phi(t) = 0; nu_t = 0
MC_Res_DGP_1 = MC_DGP.pow(out.file="pow_DGP_1",n=n.vec[1],g.vec=g.vec,R=R,ATT=0.0,error.type="MDS",
                      alph=c(a,a),phi=NULL,eta=NULL,
                      t.X="Level",se.type="NW",cl=cl)
#=========================================================================================>


#=========================================================================================>
# DGP_2: MDS; alf0=-alf1; phi(t) = 0; nu_t = 0
MC_Res_DGP_2 = MC_DGP.pow(out.file="pow_DGP_2",n=n.vec[1],g.vec=g.vec,R=R,ATT=0.0,error.type="MDS",
                      alph=c(a,-a),phi=NULL,eta=NULL,
                      t.X="Level",se.type="NW",cl=cl)
#=========================================================================================>


#=========================================================================================>
# DGP_3: MDS; alf0=alf1; phi(t) = 1{t>=4}*sqrt{2}; nu_t = 0
phi_3<- function(var.time){(var.time>=4)*sqrt(2)}; phi_3=Vectorize(phi_3)
MC_Res_DGP_3 = MC_DGP.pow(out.file="pow_DGP_3",n=n.vec[1],g.vec=g.vec,R=R,ATT=0.0,error.type="MDS",
                      alph=c(a,a),phi=phi_3,eta=NULL,
                      t.X="Level",se.type="NW",cl=cl)
#=========================================================================================>


#=========================================================================================>
# DGP_4A: MDS; alf0=alf1; phi(t) = 0; eta = 0.9
MC_Res_DGPb_4A = MC_DGP.pow(out.file="pow_DGP_4A",n=n.vec[1],g.vec=g.vec,R=R,ATT=0.0,error.type="MDS",
                         alph=c(a,a),phi=NULL,eta=0.9,
                         t.X="Level",se.type="NW",cl=cl)
#=========================================================================================>


#=========================================================================================>
# DGP_4B: MDS; alf0=alf1; phi(t) = 0; eta = 0.25; necessary & sufficient identification condition
MC_Res_DGPb_4B = MC_DGP.pow(out.file="pow_DGP_4B",n=n.vec[1],g.vec=g.vec,R=R,ATT=0.0,error.type="MDS",
                         alph=c(a,a),phi=NULL,eta=0.25,
                         t.X="Level",se.type="NW",nu.suff=TRUE,cl=cl)
#=========================================================================================>


#=========================================================================================>
# DGP_5: GARCH(1,1) errors
MC_Res_DGP_5 = MC_DGP.pow(out.file="pow_DGP_5",n=n.vec[1],g.vec=g.vec,R=R,ATT=0.0,error.type="GARCH",
                      alph=c(a,a),phi=NULL,eta=NULL,
                      t.X="Level",se.type="NW",cl=cl)
#=========================================================================================>


#=========================================================================================>
# DGP_6: MA(1) errors
MC_Res_DGP_6 = MC_DGP.pow(out.file="pow_DGP_6",n=n.vec[1],g.vec=g.vec,R=R,ATT=0.0,error.type="MA",
                      alph=c(a,a),phi=NULL,eta=NULL,
                      t.X="Level",se.type="NW",cl=cl)
#=========================================================================================>


#=========================================================================================>
# DGP_7: AR(1) untreated potential outcomes
MC_Res_DGP_7 = MC_DGP.pow(out.file="pow_DGP_7",n=n.vec[1],g.vec=g.vec,R=R,ATT=0.0,error.type="AR",
                      alph=c(a,a),phi=cos,eta=NULL,
                      t.X="Lag",se.type="NW",cl=cl)
#=========================================================================================>


#=========================================================================================>
# DGP_8: Unit root untreated potential outcomes
MC_Res_DGP_8 = MC_DGP.pow(out.file="pow_DGP_8",n=n.vec[1],g.vec=g.vec,R=R,ATT=0.0,error.type="Unit.Root",
                      alph=c(a,a),phi=NULL,eta=NULL,
                      t.X="Diff",se.type="NW",cl=cl)
#=========================================================================================>


#=========================================================================================>
# DGP_9: Common quadratic trend
phi.9<- function(var.time){var.time+var.time^2/500}; phi.9=Vectorize(phi.9)
MC_Res_DGP_9 = MC_DGP.pow(out.file="pow_DGP_9",n=n.vec[1],g.vec=g.vec,R=R,ATT=0.0,error.type="White.Noise",
                      alph=c(a,a),phi=phi.9,eta=NULL,
                      t.X="Level",se.type="NW",cl=cl)
#=========================================================================================>


#=========================================================================================>
# DGP_10: Deterministic time trend in the untreated potential outcome of the treated group
MC_Res_DGPb_10 = MC_DGP.pow(out.file="pow_DGP_10",n=n.vec[1],g.vec=g.vec,R=R,ATT=0.0,error.type="Trend",
                         alph=c(a,a),phi=NULL,eta=NULL,
                         t.X="Trend",se.type="NW",cl=cl)
#=========================================================================================>


#===============================================================================

cat("See output/ for generated tables and plots \n ")

#===============================================================================
# end.time<- Sys.time()
# print(end.time-start.time)
#===============================================================================






















