/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * goldssopt.c
 *
 * Code generation for function 'goldssopt'
 *
 */

/* Include files */
#include <math.h>
#include "mwmathutil.h"
#include "rt_nonfinite.h"
#include "CCRl_clus.h"
#include "goldssopt.h"
#include "Xkrun.h"
#include "rdivide_helper.h"
#include "CCRl_clus_emxutil.h"
#include "log.h"
#include "CCRl_clus_data.h"

/* Function Definitions */
void goldssopt(const emxArray_real_T *coefs, const emxArray_real_T *Y, const
               emxArray_real_T *X, const emxArray_real_T *Xc, uint64_T a,
               uint64_T b, uint64_T *optk, emxArray_real_T *clus,
               emxArray_real_T *deltas, real_T *BIC)
{
  emxArray_real_T *clus_c;
  emxArray_real_T *del_c;
  int32_T n;
  uint64_T c;
  uint64_T d;
  real_T fd;
  real_T y;
  real_T yd;
  int32_T ex_t;
  uint64_T yint;
  uint64_T b_y1;
  uint64_T b_y0;
  real_T fc;
  uint64_T n1;
  int32_T b_ex_t;
  uint64_T ldword;
  uint64_T temp0;
  int32_T c_ex_t;
  int32_T d_ex_t;
  emlrtHeapReferenceStackEnterFcnR2012b(emlrtRootTLSGlobal);
  emxInit_real_T(&clus_c, 1, true);
  emxInit_real_T(&del_c, 1, true);
  n = X->size[0];

  /*  function [clus,deltas,RSS] = Xkrun(coefs,Y,X,k) */
  /* define function in k */
  c = b - rdivide_helper(b - a);
  d = a + rdivide_helper(b - a);
  Xkrun(coefs, Y, X, Xc, c, clus_c, del_c, &fd);
  y = X->size[0];
  b_log(&y);
  if (muDoubleScalarIsNaN(y) || (y <= 0.0)) {
    yint = 0UL;
  } else {
    yd = frexp(y, &ex_t);
    if ((int16_T)ex_t <= -64) {
      yint = 0UL;
    } else {
      yint = (uint64_T)muDoubleScalarRound(yd * 9.007199254740992E+15);
      b_y1 = yint >> 32;
      b_y0 = yint & 4294967295UL;
      if (c == 0UL) {
        yint = 0UL;
      } else if (muDoubleScalarIsInf(y)) {
        yint = MAX_uint64_T;
      } else if ((int16_T)((int16_T)ex_t - 53) > 64) {
        yint = MAX_uint64_T;
      } else {
        n1 = c >> 32;
        yint = c & 4294967295UL;
        ldword = yint * b_y0;
        temp0 = yint * b_y1;
        yint = n1 * b_y0;
        b_y0 = ((temp0 & 4294967295UL) + (ldword >> 32)) + (yint & 4294967295UL);
        ldword = (ldword & 4294967295UL) + (b_y0 << 32);
        yint = ((n1 * b_y1 + (temp0 >> 32)) + (yint >> 32)) + (b_y0 >> 32);
        if ((int16_T)((int16_T)ex_t - 53) >= 0) {
          if (yint > 0UL) {
            yint = MAX_uint64_T;
          } else if ((ldword >> (uint8_T)((int16_T)ex_t - 117)) > 0UL) {
            yint = MAX_uint64_T;
          } else {
            yint = ldword << (uint8_T)((int16_T)ex_t - 53);
          }
        } else if ((int16_T)((int16_T)ex_t - 53) >= -64) {
          if ((yint >> (uint8_T)(53 - (int16_T)ex_t)) > 0UL) {
            yint = MAX_uint64_T;
          } else {
            yint = ((ldword >> (uint8_T)(53 - (int16_T)ex_t)) + (yint <<
                     (uint8_T)((int16_T)ex_t + 11))) + (ldword >> (uint8_T)(52 -
              (int16_T)ex_t) & 1UL);
          }
        } else {
          yint = (yint >> (uint8_T)-(int16_T)((int16_T)ex_t + 11)) + (yint >>
            (uint8_T)-(int16_T)((int16_T)ex_t + 12) & 1UL);
        }
      }
    }
  }

  fd /= (real_T)X->size[0];
  b_log(&fd);
  fc = (real_T)eml_i64dplus(yint, (real_T)X->size[0] * fd);
  Xkrun(coefs, Y, X, Xc, d, clus, deltas, &fd);
  y = muDoubleScalarLog(X->size[0]);
  if (y <= 0.0) {
    yint = 0UL;
  } else {
    yd = frexp(y, &b_ex_t);
    if (b_ex_t <= -64) {
      yint = 0UL;
    } else {
      yint = (uint64_T)muDoubleScalarRound(yd * 9.007199254740992E+15);
      b_y1 = yint >> 32;
      b_y0 = yint & 4294967295UL;
      if (d == 0UL) {
        yint = 0UL;
      } else {
        n1 = d >> 32;
        yint = d & 4294967295UL;
        ldword = yint * b_y0;
        temp0 = yint * b_y1;
        yint = n1 * b_y0;
        b_y0 = ((temp0 & 4294967295UL) + (ldword >> 32)) + (yint & 4294967295UL);
        ldword = (ldword & 4294967295UL) + (b_y0 << 32);
        yint = ((n1 * b_y1 + (temp0 >> 32)) + (yint >> 32)) + (b_y0 >> 32);
        if (b_ex_t - 53 >= -64) {
          if ((yint >> (uint8_T)(53 - b_ex_t)) > 0UL) {
            yint = MAX_uint64_T;
          } else {
            yint = ((ldword >> (uint8_T)(53 - b_ex_t)) + (yint << (uint8_T)
                     (b_ex_t + 11))) + (ldword >> (uint8_T)(52 - b_ex_t) & 1UL);
          }
        } else {
          yint = (yint >> (uint8_T)-(b_ex_t + 11)) + (yint >> (uint8_T)-(b_ex_t
            + 12) & 1UL);
        }
      }
    }
  }

  fd /= (real_T)X->size[0];
  b_log(&fd);
  fd = (real_T)eml_i64dplus(yint, (real_T)X->size[0] * fd);

  /*     %% begin while loop */
  while (c - d > 1UL) {
    if (fc < fd) {
      b = d;
    } else {
      a = c;
    }

    /*  end if */
    c = b - rdivide_helper(b - a);
    d = a + rdivide_helper(b - a);
    Xkrun(coefs, Y, X, Xc, c, clus_c, del_c, &fd);
    y = muDoubleScalarLog(n);
    if (y <= 0.0) {
      yint = 0UL;
    } else {
      yd = frexp(y, &c_ex_t);
      if (c_ex_t <= -64) {
        yint = 0UL;
      } else {
        yint = (uint64_T)muDoubleScalarRound(yd * 9.007199254740992E+15);
        b_y1 = yint >> 32;
        b_y0 = yint & 4294967295UL;
        if (c == 0UL) {
          yint = 0UL;
        } else {
          n1 = c >> 32;
          yint = c & 4294967295UL;
          ldword = yint * b_y0;
          temp0 = yint * b_y1;
          yint = n1 * b_y0;
          b_y0 = ((temp0 & 4294967295UL) + (ldword >> 32)) + (yint
            & 4294967295UL);
          ldword = (ldword & 4294967295UL) + (b_y0 << 32);
          yint = ((n1 * b_y1 + (temp0 >> 32)) + (yint >> 32)) + (b_y0 >> 32);
          if (c_ex_t - 53 >= -64) {
            if ((yint >> (uint8_T)(53 - c_ex_t)) > 0UL) {
              yint = MAX_uint64_T;
            } else {
              yint = ((ldword >> (uint8_T)(53 - c_ex_t)) + (yint << (uint8_T)
                       (c_ex_t + 11))) + (ldword >> (uint8_T)(52 - c_ex_t) & 1UL);
            }
          } else {
            yint = (yint >> (uint8_T)-(c_ex_t + 11)) + (yint >> (uint8_T)
              -(c_ex_t + 12) & 1UL);
          }
        }
      }
    }

    fc = (real_T)eml_i64dplus(yint, (real_T)n * muDoubleScalarLog(fd / (real_T)n));
    Xkrun(coefs, Y, X, Xc, d, clus, deltas, &fd);
    y = muDoubleScalarLog(n);
    if (y <= 0.0) {
      yint = 0UL;
    } else {
      yd = frexp(y, &d_ex_t);
      if (d_ex_t <= -64) {
        yint = 0UL;
      } else {
        yint = (uint64_T)muDoubleScalarRound(yd * 9.007199254740992E+15);
        b_y1 = yint >> 32;
        b_y0 = yint & 4294967295UL;
        if (d == 0UL) {
          yint = 0UL;
        } else {
          n1 = d >> 32;
          yint = d & 4294967295UL;
          ldword = yint * b_y0;
          temp0 = yint * b_y1;
          yint = n1 * b_y0;
          b_y0 = ((temp0 & 4294967295UL) + (ldword >> 32)) + (yint
            & 4294967295UL);
          ldword = (ldword & 4294967295UL) + (b_y0 << 32);
          yint = ((n1 * b_y1 + (temp0 >> 32)) + (yint >> 32)) + (b_y0 >> 32);
          if (d_ex_t - 53 >= -64) {
            if ((yint >> (uint8_T)(53 - d_ex_t)) > 0UL) {
              yint = MAX_uint64_T;
            } else {
              yint = ((ldword >> (uint8_T)(53 - d_ex_t)) + (yint << (uint8_T)
                       (d_ex_t + 11))) + (ldword >> (uint8_T)(52 - d_ex_t) & 1UL);
            }
          } else {
            yint = (yint >> (uint8_T)-(d_ex_t + 11)) + (yint >> (uint8_T)
              -(d_ex_t + 12) & 1UL);
          }
        }
      }
    }

    fd = (real_T)eml_i64dplus(yint, (real_T)n * muDoubleScalarLog(fd / (real_T)n));
  }

  /* end while loop */
  if (fc <= fd) {
    d = c;
    fd = fc;
    n = clus->size[0];
    clus->size[0] = clus_c->size[0];
    emxEnsureCapacity_real_T(clus, n);
    ex_t = clus_c->size[0];
    for (n = 0; n < ex_t; n++) {
      clus->data[n] = clus_c->data[n];
    }

    n = deltas->size[0];
    deltas->size[0] = del_c->size[0];
    emxEnsureCapacity_real_T(deltas, n);
    ex_t = del_c->size[0];
    for (n = 0; n < ex_t; n++) {
      deltas->data[n] = del_c->data[n];
    }
  }

  emxFree_real_T(&del_c);
  emxFree_real_T(&clus_c);

  /*  end if */
  *optk = d;
  *BIC = fd;
  emlrtHeapReferenceStackLeaveFcnR2012b(emlrtRootTLSGlobal);
}

/* End of code generation (goldssopt.c) */
