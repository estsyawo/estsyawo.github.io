/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * _coder_CCRl_clus_mex.c
 *
 * Code generation for function '_coder_CCRl_clus_mex'
 *
 */

/* Include files */
#include "CCRl_clus.h"
#include "_coder_CCRl_clus_mex.h"
#include "CCRl_clus_terminate.h"
#include "_coder_CCRl_clus_api.h"
#include "CCRl_clus_initialize.h"
#include "CCRl_clus_data.h"

/* Function Declarations */
static void CCRl_clus_mexFunction(int32_T nlhs, mxArray *plhs[3], int32_T nrhs,
  const mxArray *prhs[8]);

/* Function Definitions */
static void CCRl_clus_mexFunction(int32_T nlhs, mxArray *plhs[3], int32_T nrhs,
  const mxArray *prhs[8])
{
  const mxArray *outputs[3];
  int32_T b_nlhs;

  /* Check for proper number of arguments. */
  if (nrhs != 8) {
    emlrtErrMsgIdAndTxt(emlrtRootTLSGlobal, "EMLRT:runTime:WrongNumberOfInputs",
                        5, 12, 8, 4, 9, "CCRl_clus");
  }

  if (nlhs > 3) {
    emlrtErrMsgIdAndTxt(emlrtRootTLSGlobal,
                        "EMLRT:runTime:TooManyOutputArguments", 3, 4, 9,
                        "CCRl_clus");
  }

  /* Call the function. */
  CCRl_clus_api(prhs, nlhs, outputs);

  /* Copy over outputs to the caller. */
  if (nlhs < 1) {
    b_nlhs = 1;
  } else {
    b_nlhs = nlhs;
  }

  emlrtReturnArrays(b_nlhs, plhs, outputs);
}

void mexFunction(int32_T nlhs, mxArray *plhs[], int32_T nrhs, const mxArray
                 *prhs[])
{
  mexAtExit(CCRl_clus_atexit);

  /* Module initialization. */
  CCRl_clus_initialize();

  /* Dispatch the entry-point. */
  CCRl_clus_mexFunction(nlhs, plhs, nrhs, prhs);

  /* Module termination. */
  CCRl_clus_terminate();
}

emlrtCTX mexFunctionCreateRootTLS(void)
{
  emlrtCreateRootTLS(&emlrtRootTLSGlobal, &emlrtContextGlobal, NULL, 1);
  return emlrtRootTLSGlobal;
}

/* End of code generation (_coder_CCRl_clus_mex.c) */
