Gerstner_Tsyawo_2022_Datafile.R: this file produces the main dataset.

Gerstner_Tsyawo_2022_ConstructW.R: this file produces the spatial weight matrices.

Gerstner_Tsyawo_2022_Code.R: Main File - this file produces all of the results in the paper.

Function Files: SARARGMM.R and Spatial_functions.R

.csv Files are datafiles to construct the spatial weight matrices and main datafile