/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * qrsolve.c
 *
 * Code generation for function 'qrsolve'
 *
 */

/* Include files */
#include "mwmathutil.h"
#include <string.h>
#include "rt_nonfinite.h"
#include "CCRls2.h"
#include "qrsolve.h"
#include "xgeqp3.h"
#include "lapacke.h"

/* Function Declarations */
static int32_T rankFromQR(const real_T A_data[], const int32_T A_size[2]);

/* Function Definitions */
static int32_T rankFromQR(const real_T A_data[], const int32_T A_size[2])
{
  int32_T r;
  int32_T minmn;
  int32_T maxmn;
  real_T tol;
  r = 0;
  if (A_size[0] < 2) {
    minmn = A_size[0];
    maxmn = 2;
  } else {
    minmn = 2;
    maxmn = A_size[0];
  }

  if (minmn > 0) {
    tol = 2.2204460492503131E-15 * (real_T)maxmn * muDoubleScalarAbs(A_data[0]);
    while ((r < minmn) && (!(muDoubleScalarAbs(A_data[r + A_size[0] * r]) <= tol)))
    {
      r++;
    }
  }

  return r;
}

void qrsolve(const real_T A_data[], const int32_T A_size[2], const real_T
             B_data[], const int32_T B_size[1], real_T Y[2])
{
  int32_T b_A_size[2];
  int32_T loop_ub;
  real_T b_A_data[2000];
  real_T tau_data[2];
  int32_T tau_size[1];
  int32_T jpvt[2];
  int32_T rankA;
  real_T b_B_data[1000];
  ptrdiff_t nrc_t;
  int32_T j;
  ptrdiff_t info_t;
  int32_T Y_tmp;
  int32_T b_Y_tmp;
  b_A_size[0] = A_size[0];
  b_A_size[1] = 2;
  loop_ub = A_size[0] * A_size[1];
  if (0 <= loop_ub - 1) {
    memcpy(&b_A_data[0], &A_data[0], (uint32_T)(loop_ub * (int32_T)sizeof(real_T)));
  }

  xgeqp3(b_A_data, b_A_size, tau_data, tau_size, jpvt);
  rankA = rankFromQR(b_A_data, b_A_size);
  if (0 <= B_size[0] - 1) {
    memcpy(&b_B_data[0], &B_data[0], (uint32_T)(B_size[0] * (int32_T)sizeof
            (real_T)));
  }

  Y[0] = 0.0;
  Y[1] = 0.0;
  if (b_A_size[0] != 0) {
    nrc_t = (ptrdiff_t)B_size[0];
    info_t = LAPACKE_dormqr(102, 'L', 'T', nrc_t, (ptrdiff_t)1, (ptrdiff_t)
      muIntScalarMin_sint32(b_A_size[0], 2), &b_A_data[0], (ptrdiff_t)b_A_size[0],
      &tau_data[0], &b_B_data[0], nrc_t);
    if ((int32_T)info_t != 0) {
      loop_ub = B_size[0];
      for (j = 0; j < loop_ub; j++) {
        b_B_data[j] = rtNaN;
      }
    }
  }

  for (loop_ub = 0; loop_ub < rankA; loop_ub++) {
    Y[jpvt[loop_ub] - 1] = b_B_data[loop_ub];
  }

  for (j = rankA; j >= 1; j--) {
    Y_tmp = jpvt[j - 1] - 1;
    b_Y_tmp = b_A_size[0] * (j - 1);
    Y[Y_tmp] /= b_A_data[(j + b_Y_tmp) - 1];
    for (loop_ub = 0; loop_ub <= j - 2; loop_ub++) {
      Y[jpvt[0] - 1] -= Y[Y_tmp] * b_A_data[b_Y_tmp];
    }
  }
}

/* End of code generation (qrsolve.c) */
