% Test function in Matlab for CCRl_clus.m

%% Generate data:
n=2000; p = 20;
tbets = [-2 -1 0 1 2]./5;
B = [0.5 tbets tbets tbets tbets]';


X = ones(n,p); XX = ones(n,(p+1));
s = RandStream('mlfg6331_64'); 
X(:,(1:p)) = rand(s,n,p); XX(:,(2:(p+1))) = X;
Y = XX*B + rand(s,[n,1]);

%% Test function
kmin = 2; kmax = 12; frql = 1; kp = 0.02;

Xc = XX(:,(2:3)); X = XX(:,(4:21)); 

[k, betas,clus] = CCRl_clus(Y,X,Xc,frql,kp,kmin,kmax,0);
[km, betasm,clusm] = CCRl_clus_mex(Y,X,Xc,uint64(frql),kp,uint64(kmin),uint64(kmax),false);



%% Test cordlin() function
bets=cordlin(Y,XX); % compare to
ecoefs=XX\Y;
disp([bets' ecoefs]);

%% Test cordlin_clus() 
nC = 1;k_=5;
[bets,deltas,clus, RSS1]=cordlin_clus(Y,XX,k_,nC);

[clus'  B(2:21,1)];
disp([B(:,1) bets' ecoefs]); %compare true to estimated

%% Test goldsscoord( )

[optk,clus,bets,deltas,BIC] = goldsscoord(Y,XX,nC,kmin,kmax);
[optkm,clusm,betsm,deltasm,BICm] = goldsscoord_mex(Y,XX,nC,kmin,kmax);

% verify equality of results (matlab vs mex)
% optk==optkm; clus==clusm; bets==betsm; deltas==deltasm; BIC==BICm;
% all exactly equal!

%% Test goldsscoord2( )

[optk2,clus2,bets2,BIC2] = goldsscoord2(Y,XX,nC,kmin,kmax);
[optkm2,clusm2,betsm2,BICm2] = goldsscoord2_mex(Y,XX,nC,kmin,kmax);

% optk2==optk; clus2==clus; bets2==bets; BIC2==BIC;

% verify equality of results (matlab vs mex)
% optkm2==optkm; clusm2'==clusm; betsm2==betsm; BICm2==BICm;
% all exactly equal!

%% Test goldscoord3()

[optk3,clus3,bets3,BIC3] = goldsscoord3(Y,XX,nC,kmin,kmax);
[optkm3,clusm3,betsm3,BICm3] = goldsscoord3_mex(Y,XX,nC,kmin,kmax);

% optk3==optkm3; clus3==clusm3; bets3==betsm3; BIC3==BICm3;

disp([B(:,1) bets3' ecoefs]); %compare true to estimated
disp([B(:,1) betsm3' ecoefs]); %compare true to estimated

