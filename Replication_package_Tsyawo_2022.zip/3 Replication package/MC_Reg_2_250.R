#=========================================================================================>
# Author: Emmanuel Selorm Tsyawo
# Project: Feasible IV Regression without Excluded Instruments
# Date began:   Sept 5, 2021
# Last Update:  Sept 11, 2021
# Place:        Rabat
#=========================================================================================>
# Load packages, clear memory,
#rm(list=ls())
library(MASS)
library(estrpac)#install from binary file estrpac_0.1.0.tgz or
# use devtools::install_github("estsyawo/estrpac")
library(pbapply)
library(AER)
setwd(dirname(rstudioapi::getActiveDocumentContext()$path)) #set working directory path to source file
list.files()
#=========================================================================================>
# Comments: Monte Carlo Simulations using the DGP of Antoine & Lavergne 2014 (section 5)
# n = 250; DGP_2A & DGP_2B
#=========================================================================================>
# Set Parameters
R = 1000 # set number of simulations
a=b=0 #set parameters
#B=499 # number of non-parametric bootstrap samples

RMSE = function(x) sqrt(mean(x^2))
MAD = function(x) median(abs(x))

#-------------------------------------------------------
# ... pz must be an even number
gdat1<- function(n,f.fun,s.fun,gam,pz=12){
  datl=list(); K = pz/2; C=8
  for (l in 1:R) {
    set.seed(l) #generate seed
    X=rnorm(n)
    Sig = diag(2); Sig[1,2]=Sig[2,1]=0.8
    set.seed(l+10)
    EU=mvrnorm(n=n,mu=c(0,0),Sigma = Sig)
    #generate endogenous covariate
    D = n^(-gam)*sqrt(C)*f.fun(X) + EU[,2]
    #generate outcome
    Y = a + b*D + s.fun(X)*EU[,1]
    #generate instruments
    I = (0:K)/K #intervals
    Z = matrix(NA,n,pz-1)
    Z[,1]=X
    for (j in 2:K) {
      #cat("at j = ",j,", indices are ",c(2*(j-1),2*(j-1)+1),"\n")
      Z[,2*(j-1)]= ((qnorm(I[j-1])<=X)&(X<=qnorm(I[j])))*1
      Z[,2*(j-1)+1]=X*Z[,2*(j-1)]
    }
    datl[[l]]<- data.frame(Y,D,Z)
  }
  datl
}
#transformations of x
f.fun1=function(x){x}; f.fun2=function(x){sqrt(2*pi*sqrt(27))*x*exp(-x^2/2)}
#skedastic function of x
s.fun1=function(x){sqrt((1+x^2)/2)}; s.fun2=function(x){1}

# size a, n = 250
datl1a=gdat1(n=250,f.fun=f.fun1,s.fun=s.fun1,gam = 0.45,pz=12) #linear heteroskedastic model

summary(imlmreg2.fit(Y=datl1a[[1]]$Y,X=datl1a[[1]]$D,Z=datl1a[[1]][,-c(1,2)]))#MMD is the default
summary(imlmreg2.fit(Y=datl1a[[1]]$Y,X=datl1a[[1]]$D,Z=datl1a[[1]][,-c(1,2)],Kern = "Gauss.W"))
summary(imlmreg2.fit(Y=datl1a[[1]]$Y,X=datl1a[[1]]$D,Z=datl1a[[1]][,-c(1,2)],Kern = "Gauss"))
summary(imlmreg2.fit(Y=datl1a[[1]]$Y,X=datl1a[[1]]$D,Z=datl1a[[1]][,-c(1,2)],Kern = "DL"))
summary(imlmreg2.fit(Y=datl1a[[1]]$Y,X=datl1a[[1]]$D,Z=datl1a[[1]][,-c(1,2)],Kern = "WMD"))

MCfun1<- function(j=NULL,datl,b){
  dat = datl[[j]] #null operation for looping
  Y = dat[,1]; X = as.matrix(dat[,2])
  Z1 = as.matrix(dat[,3]); Z2 = as.matrix(dat[,-c(1,2)])
  
  #run Integrated Moment regressions
  MMDobj=imlmreg2.fit(Y,X,Z1,Kern = "Euclid")
  WMDobj=imlmreg2.fit(Y,X,Z1,Kern = "WMD")
  WMDFobj=imlmreg2.fit(Y,X,Z1,Kern = "WMDF")
  DLobj=imlmreg2.fit(Y,X,Z1,Kern = "DL")
  Esc6obj=imlmreg2.fit(Y,X,Z1,Kern = "Esc6")
  IIVobj=imlmreg2.fit(Y,X,Z1,Kern = "Gauss.W")
  #run K-Class regressions
  TSLSobj=ivreg(Y~X|Z2); TSLSobj$HC_Std.Err=sqrt(diag(vcovHC(TSLSobj)))
  JIVEobj=kClassIVreg.fit(Y,X,Z2,method = "JIVE")
  LIMLobj=kClassIVreg.fit(Y,X,Z2,method = "LIML")
  HLIMobj=kClassIVreg.fit(Y,X,Z2,method = "HLIM")
  HFULobj=kClassIVreg.fit(Y,X,Z2,method = "HFUL")
  
  #compute bias
  bias.MMD = MMDobj$coefficients[2]-b 
  bias.WMD = WMDobj$coefficients[2]-b
  bias.WMDF = WMDFobj$coefficients[2]-b
  bias.DL = DLobj$coefficients[2]-b
  bias.Esc6 = Esc6obj$coefficients[2]-b
  bias.IIV = IIVobj$coefficients[2]-b
  
  bias.TSLS = TSLSobj$coefficients[2]-b
  bias.JIVE = JIVEobj$coefficients[2]-b
  bias.LIML = LIMLobj$coefficients[2]-b
  bias.HLIM = HLIMobj$coefficients[2]-b
  bias.HFUL = HFULobj$coefficients[2]-b
  
  #compute size (for rejection probabilities)
  size.MMD = 1*(abs(bias.MMD/MMDobj$HC_Std.Err[2])>qnorm(0.975))
  size.WMD = 1*(abs(bias.WMD/WMDobj$HC_Std.Err[2])>qnorm(0.975))
  size.WMDF = 1*(abs(bias.WMDF/WMDFobj$HC_Std.Err[2])>qnorm(0.975))
  size.DL = 1*(abs(bias.DL/DLobj$HC_Std.Err[2])>qnorm(0.975))
  size.Esc6 = 1*(abs(bias.Esc6/Esc6obj$HC_Std.Err[2])>qnorm(0.975))
  size.IIV = 1*(abs(bias.IIV/IIVobj$HC_Std.Err[2])>qnorm(0.975))
  
  size.TSLS = 1*(abs(bias.TSLS/TSLSobj$HC_Std.Err[2])>qnorm(0.975))
  size.JIVE = 1*(abs(bias.JIVE/JIVEobj$HC_Std.Err[2])>qnorm(0.975))
  size.LIML = 1*(abs(bias.LIML/LIMLobj$HC_Std.Err[2])>qnorm(0.975))
  size.HLIM = 1*(abs(bias.HLIM/HLIMobj$HC_Std.Err[2])>qnorm(0.975))
  size.HFUL = 1*(abs(bias.HFUL/HFULobj$HC_Std.Err[2])>qnorm(0.975))
  
  res=c(bias.MMD,bias.WMD,bias.WMDF,bias.DL,bias.Esc6,bias.IIV,bias.TSLS,bias.JIVE,bias.LIML,bias.HLIM,
        bias.HFUL,size.MMD,
        size.WMD,size.WMDF,size.DL,size.Esc6,size.IIV,size.TSLS,size.JIVE,size.LIML,
        size.HLIM,size.HFUL)
  names(res)=c("BiasMMD","BiasWMD","BiasWMDF","BiasDL","BiasEsc6","BiasIIV","Bias.TSLS",
               "Bias.JIVE","Bias.LIML","Bias.HLIM","Bias.HFUL",
               "SizeMMD","SizeWMD","SizeWMDF","SizeDL","SizeEsc6","SizeIIV","Size.TSLS",
               "Size.JIVE","Size.LIML","Size.HLIM","Size.HFUL")
  res
}

# 
#-------------------------------------------------------

# illustration
MCfun1(j=2,datl=datl1a,b=b)

#linear heteroskedastic model, n = 250, gamma = 0.45
Bias1a = pbsapply(1:R, FUN=MCfun1,cl=5,datl=datl1a,b=b)
summary(t(Bias1a))

# gamma = 0.3
datl1aM=gdat1(n=250,f.fun=f.fun1,s.fun=s.fun1,gam = 0.30)
Bias1a.M = pbsapply(1:R, FUN=MCfun1,cl=5,datl=datl1aM,b=b)
summary(t(Bias1a.M))

# gamma = 0.15
datl1aMM=gdat1(n=250,f.fun=f.fun1,s.fun=s.fun1,gam = 0.15) #linear heteroskedastic model
Bias1a.MM = pbsapply(1:R, FUN=MCfun1,cl=5,datl=datl1aMM,b=b)
summary(t(Bias1a.MM))
#-------------------------------------------------------

#gamma = 0.45
datl1b=gdat1(n=250,f.fun=f.fun2,s.fun=s.fun1,gam = 0.45)
Bias1b = pbsapply(1:R, FUN=MCfun1,cl=5,datl=datl1b,b=b)
summary(t(Bias1b))

# gamma = 0.3
datl1bM=gdat1(n=250,f.fun=f.fun2,s.fun=s.fun1,gam = 0.30)
Bias1b.M = pbsapply(1:R, FUN=MCfun1,cl=5,datl=datl1bM,b=b)
summary(t(Bias1b.M))

# gamma = 0.15
datl1bMM=gdat1(n=250,f.fun=f.fun2,s.fun=s.fun1,gam = 0.15)
Bias1b.MM = pbsapply(1:R, FUN=MCfun1,cl=5,datl=datl1bMM,b=b)
summary(t(Bias1b.MM))
#=========================================================================================>

# Results:

Res.A1=round(cbind(apply(Bias1a[1:11,],1,mean),apply(Bias1a[1:11,],1,MAD),apply(Bias1a[1:11,],1,RMSE),
                   apply(Bias1a[12:22,],1,mean)),3)
colnames(Res.A1)=c("MB","MAD","RMSE","Rej")
rownames(Res.A1)=c("MMD","WMD","WMDF","DL","ESC6","IIV","TSLS","JIVE","LIML","HLIM","HFUL")
Res.A1

Res.A2=round(cbind(apply(Bias1a.M[1:11,],1,mean),apply(Bias1a.M[1:11,],1,MAD),apply(Bias1a.M[1:11,],1,RMSE),
                   apply(Bias1a.M[12:22,],1,mean,na.rm=TRUE)),3)
colnames(Res.A2)=c("MB","MAD","RMSE","Rej")
rownames(Res.A2)=c("MMD","WMD","WMDF","DL","ESC6","IIV","TSLS","JIVE","LIML","HLIM","HFUL")
Res.A2

Res.A3=round(cbind(apply(Bias1a.MM[1:11,],1,mean),apply(Bias1a.MM[1:11,],1,MAD),apply(Bias1a.MM[1:11,],1,RMSE),
                   apply(Bias1a.MM[12:22,],1,mean)),3)
colnames(Res.A3)=c("MB","MAD","RMSE","Rej")
rownames(Res.A3)=c("MMD","WMD","WMDF","DL","ESC6","IIV","TSLS","JIVE","LIML","HLIM","HFUL")
Res.A3

cbind(Res.A1,Res.A2,Res.A3)

#         MB   MAD    RMSE   Rej     MB   MAD  RMSE   Rej     MB   MAD  RMSE   Rej
# MMD  -0.015 0.202   0.391 0.081 -0.003 0.092 0.145 0.051 -0.001 0.042 0.062 0.045
# WMD  -0.011 0.213   2.574 0.058 -0.016 0.092 0.147 0.047 -0.003 0.041 0.061 0.043
# WMDF -0.211 0.211   3.138 0.060 -0.015 0.092 0.146 0.047 -0.002 0.041 0.061 0.043
# DL   -0.029 0.200   0.991 0.070 -0.005 0.089 0.141 0.053 -0.001 0.040 0.061 0.048
# ESC6 -0.025 0.192   0.349 0.071 -0.005 0.088 0.141 0.052 -0.001 0.039 0.061 0.048
# IIV  -0.003 0.194   0.354 0.084 -0.001 0.089 0.139 0.051  0.000 0.040 0.060 0.043
# TSLS  0.318 0.331   0.380 0.395  0.085 0.111 0.159 0.132  0.017 0.046 0.068 0.065
# JIVE -0.079 0.356   6.520 0.059 -0.046 0.115 0.186 0.045 -0.008 0.046 0.069 0.045
# LIML -0.314 0.253   6.788 0.067 -0.020 0.103 0.177 0.048 -0.003 0.045 0.070 0.047
# HLIM -0.924 1.661  18.958 0.125 -0.193 0.169 0.432 0.028 -0.029 0.051 0.079 0.046
# HFUL  6.581 1.460 291.007 0.104 -0.171 0.160 0.454 0.027 -0.027 0.049 0.078 0.046

#for pasting into TeX
apply(cbind(Res.A1,Res.A2,Res.A3),1,paste,collapse=" & ")

# MMD -0.015 & 0.202 & 0.391 & 0.081 & -0.003 & 0.092 & 0.145 & 0.051 & -0.001 & 0.042 & 0.062 & 0.045" 
# WMD -0.011 & 0.213 & 2.574 & 0.058 & -0.016 & 0.092 & 0.147 & 0.047 & -0.003 & 0.041 & 0.061 & 0.043" 
# WMDF -0.211 & 0.211 & 3.138 & 0.06 & -0.015 & 0.092 & 0.146 & 0.047 & -0.002 & 0.041 & 0.061 & 0.043" 
# DL -0.029 & 0.2 & 0.991 & 0.07 & -0.005 & 0.089 & 0.141 & 0.053 & -0.001 & 0.04 & 0.061 & 0.048" 
# ESC6 -0.025 & 0.192 & 0.349 & 0.071 & -0.005 & 0.088 & 0.141 & 0.052 & -0.001 & 0.039 & 0.061 & 0.048" 
# IIV -0.003 & 0.194 & 0.354 & 0.084 & -0.001 & 0.089 & 0.139 & 0.051 & 0 & 0.04 & 0.06 & 0.043" 
# TSLS 0.318 & 0.331 & 0.38 & 0.395 & 0.085 & 0.111 & 0.159 & 0.132 & 0.017 & 0.046 & 0.068 & 0.065" 
# JIVE -0.079 & 0.356 & 6.52 & 0.059 & -0.046 & 0.115 & 0.186 & 0.045 & -0.008 & 0.046 & 0.069 & 0.045" 
# LIML -0.314 & 0.253 & 6.788 & 0.067 & -0.02 & 0.103 & 0.177 & 0.048 & -0.003 & 0.045 & 0.07 & 0.047" 
# HLIM -0.924 & 1.661 & 18.958 & 0.125 & -0.193 & 0.169 & 0.432 & 0.028 & -0.029 & 0.051 & 0.079 & 0.046" 
# HFUL 6.581 & 1.46 & 291.007 & 0.104 & -0.171 & 0.16 & 0.454 & 0.027 & -0.027 & 0.049 & 0.078 & 0.046"

#----------------------------------------------------------------------------------------->

Res.B1=round(cbind(apply(Bias1b[1:11,],1,mean),apply(Bias1b[1:11,],1,MAD),apply(Bias1b[1:11,],1,RMSE),
                   apply(Bias1b[12:22,],1,mean)),3)
colnames(Res.B1)=c("MB","MAD","RMSE","Rej")
rownames(Res.B1)=c("MMD","WMD","WMDF","DL","ESC6","IIV","TSLS","JIVE","LIML","HLIM","HFUL")
Res.B1

Res.B2=round(cbind(apply(Bias1b.M[1:11,],1,mean),apply(Bias1b.M[1:11,],1,MAD),apply(Bias1b.M[1:11,],1,RMSE),
                   apply(Bias1b.M[12:22,],1,mean)),3)
colnames(Res.B2)=c("MB","MAD","RMSE","Rej")
rownames(Res.B2)=c("MMD","WMD","WMDF","DL","ESC6","IIV","TSLS","JIVE","LIML","HLIM","HFUL")
Res.B2

Res.B3=round(cbind(apply(Bias1b.MM[1:11,],1,mean),apply(Bias1b.MM[1:11,],1,MAD),apply(Bias1b.MM[1:11,],1,RMSE),
                   apply(Bias1b.MM[12:22,],1,mean)),3)
colnames(Res.B3)=c("MB","MAD","RMSE","Rej")
rownames(Res.B3)=c("MMD","WMD","WMDF","DL","ESC6","IIV","TSLS","JIVE","LIML","HLIM","HFUL")
Res.B3

cbind(Res.B1,Res.B2,Res.B3)
#         MB   MAD  RMSE   Rej     MB   MAD  RMSE   Rej     MB   MAD  RMSE   Rej
# MMD  -0.001 0.083 0.130 0.052  0.000 0.037 0.056 0.043  0.000 0.016 0.025 0.039
# WMD  -0.011 0.074 0.118 0.041 -0.002 0.033 0.050 0.049  0.000 0.014 0.022 0.049
# WMDF -0.010 0.073 0.117 0.041 -0.001 0.032 0.050 0.049  0.000 0.014 0.022 0.049
# DL   -0.003 0.079 0.124 0.050  0.000 0.035 0.054 0.044  0.000 0.015 0.024 0.040
# ESC6 -0.004 0.079 0.125 0.051  0.000 0.035 0.054 0.047  0.000 0.015 0.024 0.040
# IIV   0.000 0.074 0.113 0.048  0.000 0.033 0.049 0.047  0.000 0.014 0.022 0.048
# TSLS  0.078 0.093 0.122 0.167  0.016 0.032 0.048 0.071  0.003 0.013 0.020 0.054
# JIVE -0.032 0.086 0.141 0.041 -0.005 0.032 0.051 0.045 -0.001 0.014 0.022 0.049
# LIML -0.017 0.077 0.134 0.040 -0.002 0.033 0.051 0.045  0.000 0.014 0.022 0.050
# HLIM -0.180 0.147 0.331 0.041 -0.025 0.039 0.061 0.059 -0.004 0.015 0.023 0.050
# HFUL -0.163 0.137 0.303 0.039 -0.023 0.038 0.060 0.056 -0.004 0.015 0.023 0.048

#for pasting into TeX
apply(cbind(Res.B1,Res.B2,Res.B3),1,paste,collapse=" & ")

# MMD -0.001 & 0.083 & 0.13 & 0.052 & 0 & 0.037 & 0.056 & 0.043 & 0 & 0.016 & 0.025 & 0.039" 
# WMD -0.011 & 0.074 & 0.118 & 0.041 & -0.002 & 0.033 & 0.05 & 0.049 & 0 & 0.014 & 0.022 & 0.049" 
# WMDF -0.01 & 0.073 & 0.117 & 0.041 & -0.001 & 0.032 & 0.05 & 0.049 & 0 & 0.014 & 0.022 & 0.049" 
# DL -0.003 & 0.079 & 0.124 & 0.05 & 0 & 0.035 & 0.054 & 0.044 & 0 & 0.015 & 0.024 & 0.04" 
# ESC6 -0.004 & 0.079 & 0.125 & 0.051 & 0 & 0.035 & 0.054 & 0.047 & 0 & 0.015 & 0.024 & 0.04" 
# IIV 0 & 0.074 & 0.113 & 0.048 & 0 & 0.033 & 0.049 & 0.047 & 0 & 0.014 & 0.022 & 0.048" 
# TSLS 0.078 & 0.093 & 0.122 & 0.167 & 0.016 & 0.032 & 0.048 & 0.071 & 0.003 & 0.013 & 0.02 & 0.054" 
# JIVE -0.032 & 0.086 & 0.141 & 0.041 & -0.005 & 0.032 & 0.051 & 0.045 & -0.001 & 0.014 & 0.022 & 0.049" 
# LIML -0.017 & 0.077 & 0.134 & 0.04 & -0.002 & 0.033 & 0.051 & 0.045 & 0 & 0.014 & 0.022 & 0.05" 
# HLIM -0.18 & 0.147 & 0.331 & 0.041 & -0.025 & 0.039 & 0.061 & 0.059 & -0.004 & 0.015 & 0.023 & 0.05" 
# HFUL -0.163 & 0.137 & 0.303 & 0.039 & -0.023 & 0.038 & 0.06 & 0.056 & -0.004 & 0.015 & 0.023 & 0.048"

#=========================================================================================>