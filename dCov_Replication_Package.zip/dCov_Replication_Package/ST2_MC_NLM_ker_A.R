#=========================================================================================>
# Load packages, clear memory,
rm(list=ls())
library(MASS)
library(energy)
library(pbapply)
library(estrpac)
library(ivreg)
library(sandwich)
library(parallel)
library(quantreg)
library(EnvStats)
#=========================================================================================>
source("ST4_Fonctions.R")
source("ST4_Fonctions_Sim.R")
#=========================================================================================>
#set parameters
theta.0<- (5/4)*c(1,-1); b = theta.0[1]
R<- 1000
n.vec = c(50,100,200)
cl<- floor(detectCores()/2)
est.names= c("MDep","SJK","DL","ESC6")
#generate starting values: 
s.dat<- gdat.0a(n=500,R=1,theta.0=theta.0);(strtpar=coef(lm(s.dat[[1]]$Y~s.dat[[1]]$X))[-1])

#=========================================================================================>


#=========================================================================================>
# DGPs 1: 
u.fun1<- function(par0,Y,X){Y - (par0^2)*X - par0*(X^2)}
Xg.fun1<- function(par0,X){-2*par0*X - X^2}

gSim2(n.vec=n.vec,gdat=gdat.nl_1a,se="ker",u.fun=u.fun1,Xg.fun=Xg.fun1,MCfun=MCfun.2,
      Intercept=F,strtpar=strtpar[1],outfile="out_NLM_ker_1a",cl=cl,R=R,
      theta.0=theta.0,est.names=est.names)

gSim2(n.vec=n.vec,gdat=gdat.nl_1b,se="ker",u.fun=u.fun1,Xg.fun=Xg.fun1,MCfun=MCfun.2,
      Intercept=F,strtpar=strtpar[1],outfile="out_NLM_ker_1b",cl=cl,R=R,
      theta.0=theta.0,est.names=est.names)

gSim2(n.vec=n.vec,gdat=gdat.nl_1c,se="ker",u.fun=u.fun1,Xg.fun=Xg.fun1,MCfun=MCfun.2,
      Intercept=F,strtpar=strtpar[1],outfile="out_NLM_ker_1c",cl=cl,R=R,
      theta.0=theta.0,est.names=est.names)

#=========================================================================================>
# DGPs 2: 
u.fun2<- function(par0,Y,X){Y - exp(X%*%par0)}
Xg.fun2<- function(par0,X){X*c(exp(X%*%par0))}

gSim2(n.vec=n.vec,gdat=gdat.nl_2a,se="ker",u.fun=u.fun2,Xg.fun=Xg.fun2,MCfun=MCfun.2,
      Intercept=T,strtpar=strtpar,outfile="out_NLM_ker_2a",cl=cl,R=R,
      theta.0=theta.0,est.names=est.names)

gSim2(n.vec=n.vec,gdat=gdat.nl_2b,se="ker",u.fun=u.fun2,Xg.fun=Xg.fun2,MCfun=MCfun.2,
      Intercept=T,strtpar=strtpar,outfile="out_NLM_ker_2b",cl=cl,R=R,
      theta.0=theta.0,est.names=est.names)
#=========================================================================================>
