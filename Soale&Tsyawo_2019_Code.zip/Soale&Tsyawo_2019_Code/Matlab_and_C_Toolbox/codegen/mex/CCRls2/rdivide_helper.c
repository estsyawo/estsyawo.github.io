/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * rdivide_helper.c
 *
 * Code generation for function 'rdivide_helper'
 *
 */

/* Include files */
#include "rt_nonfinite.h"
#include "CCRls2.h"
#include "rdivide_helper.h"
#include "CCRls2_emxutil.h"

/* Function Definitions */
void rdivide_helper(const emxArray_uint32_T *x, uint32_T y, emxArray_uint32_T *z)
{
  int32_T nx;
  int32_T k;
  uint32_T b_z;
  uint32_T b_x;
  nx = z->size[0] * z->size[1];
  z->size[0] = 1;
  z->size[1] = x->size[1];
  emxEnsureCapacity_uint32_T(z, nx);
  nx = x->size[1];
  for (k = 0; k < nx; k++) {
    if (y == 0U) {
      if (x->data[k] == 0U) {
        b_z = 0U;
      } else {
        b_z = MAX_uint32_T;
      }
    } else {
      b_z = x->data[k] / y;
      b_x = x->data[k] - b_z * y;
      if ((b_x > 0U) && (b_x >= (y >> 1U) + (y & 1U))) {
        b_z++;
      }
    }

    z->data[k] = b_z;
  }
}

/* End of code generation (rdivide_helper.c) */
