MATLAB="/Applications/MATLAB_R2018b.app"
Arch=maci64
ENTRYPOINT=mexFunction
MAPFILE=$ENTRYPOINT'.map'
PREFDIR="/Users/Selorm/Library/Application Support/MathWorks/MATLAB/R2018b"
OPTSFILE_NAME="./setEnv.sh"
. $OPTSFILE_NAME
COMPILER=$CC
. $OPTSFILE_NAME
echo "# Make settings for CCRls2" > CCRls2_mex.mki
echo "CC=$CC" >> CCRls2_mex.mki
echo "CFLAGS=$CFLAGS" >> CCRls2_mex.mki
echo "CLIBS=$CLIBS" >> CCRls2_mex.mki
echo "COPTIMFLAGS=$COPTIMFLAGS" >> CCRls2_mex.mki
echo "CDEBUGFLAGS=$CDEBUGFLAGS" >> CCRls2_mex.mki
echo "CXX=$CXX" >> CCRls2_mex.mki
echo "CXXFLAGS=$CXXFLAGS" >> CCRls2_mex.mki
echo "CXXLIBS=$CXXLIBS" >> CCRls2_mex.mki
echo "CXXOPTIMFLAGS=$CXXOPTIMFLAGS" >> CCRls2_mex.mki
echo "CXXDEBUGFLAGS=$CXXDEBUGFLAGS" >> CCRls2_mex.mki
echo "LDFLAGS=$LDFLAGS" >> CCRls2_mex.mki
echo "LDOPTIMFLAGS=$LDOPTIMFLAGS" >> CCRls2_mex.mki
echo "LDDEBUGFLAGS=$LDDEBUGFLAGS" >> CCRls2_mex.mki
echo "Arch=$Arch" >> CCRls2_mex.mki
echo "LD=$LD" >> CCRls2_mex.mki
echo OMPFLAGS= >> CCRls2_mex.mki
echo OMPLINKFLAGS= >> CCRls2_mex.mki
echo "EMC_COMPILER=clang" >> CCRls2_mex.mki
echo "EMC_CONFIG=optim" >> CCRls2_mex.mki
"/Applications/MATLAB_R2018b.app/bin/maci64/gmake" -j 1 -B -f CCRls2_mex.mk
