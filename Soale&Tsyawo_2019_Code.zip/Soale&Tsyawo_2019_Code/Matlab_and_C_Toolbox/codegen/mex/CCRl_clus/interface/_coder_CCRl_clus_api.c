/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * _coder_CCRl_clus_api.c
 *
 * Code generation for function '_coder_CCRl_clus_api'
 *
 */

/* Include files */
#include "rt_nonfinite.h"
#include "CCRl_clus.h"
#include "_coder_CCRl_clus_api.h"
#include "CCRl_clus_emxutil.h"
#include "CCRl_clus_data.h"

/* Function Declarations */
static void b_emlrt_marshallIn(const mxArray *u, const emlrtMsgIdentifier
  *parentId, emxArray_real_T *y);
static const mxArray *b_emlrt_marshallOut(const emxArray_real_T *u);
static void c_emlrt_marshallIn(const mxArray *X, const char_T *identifier,
  emxArray_real_T *y);
static const mxArray *c_emlrt_marshallOut(const emxArray_real_T *u);
static void d_emlrt_marshallIn(const mxArray *u, const emlrtMsgIdentifier
  *parentId, emxArray_real_T *y);
static uint64_T e_emlrt_marshallIn(const mxArray *frql, const char_T *identifier);
static void emlrt_marshallIn(const mxArray *Y, const char_T *identifier,
  emxArray_real_T *y);
static const mxArray *emlrt_marshallOut(const uint64_T u);
static uint64_T f_emlrt_marshallIn(const mxArray *u, const emlrtMsgIdentifier
  *parentId);
static real_T g_emlrt_marshallIn(const mxArray *kp, const char_T *identifier);
static real_T h_emlrt_marshallIn(const mxArray *u, const emlrtMsgIdentifier
  *parentId);
static boolean_T i_emlrt_marshallIn(const mxArray *rpt, const char_T *identifier);
static boolean_T j_emlrt_marshallIn(const mxArray *u, const emlrtMsgIdentifier
  *parentId);
static void k_emlrt_marshallIn(const mxArray *src, const emlrtMsgIdentifier
  *msgId, emxArray_real_T *ret);
static void l_emlrt_marshallIn(const mxArray *src, const emlrtMsgIdentifier
  *msgId, emxArray_real_T *ret);
static uint64_T m_emlrt_marshallIn(const mxArray *src, const emlrtMsgIdentifier *
  msgId);
static real_T n_emlrt_marshallIn(const mxArray *src, const emlrtMsgIdentifier
  *msgId);
static boolean_T o_emlrt_marshallIn(const mxArray *src, const emlrtMsgIdentifier
  *msgId);

/* Function Definitions */
static void b_emlrt_marshallIn(const mxArray *u, const emlrtMsgIdentifier
  *parentId, emxArray_real_T *y)
{
  k_emlrt_marshallIn(emlrtAlias(u), parentId, y);
  emlrtDestroyArray(&u);
}

static const mxArray *b_emlrt_marshallOut(const emxArray_real_T *u)
{
  const mxArray *y;
  const mxArray *m1;
  static const int32_T iv0[2] = { 0, 0 };

  y = NULL;
  m1 = emlrtCreateNumericArray(2, iv0, mxDOUBLE_CLASS, mxREAL);
  emlrtMxSetData((mxArray *)m1, &u->data[0]);
  emlrtSetDimensions((mxArray *)m1, u->size, 2);
  emlrtAssign(&y, m1);
  return y;
}

static void c_emlrt_marshallIn(const mxArray *X, const char_T *identifier,
  emxArray_real_T *y)
{
  emlrtMsgIdentifier thisId;
  thisId.fIdentifier = (const char *)identifier;
  thisId.fParent = NULL;
  thisId.bParentIsCell = false;
  d_emlrt_marshallIn(emlrtAlias(X), &thisId, y);
  emlrtDestroyArray(&X);
}

static const mxArray *c_emlrt_marshallOut(const emxArray_real_T *u)
{
  const mxArray *y;
  const mxArray *m2;
  static const int32_T iv1[1] = { 0 };

  y = NULL;
  m2 = emlrtCreateNumericArray(1, iv1, mxDOUBLE_CLASS, mxREAL);
  emlrtMxSetData((mxArray *)m2, &u->data[0]);
  emlrtSetDimensions((mxArray *)m2, u->size, 1);
  emlrtAssign(&y, m2);
  return y;
}

static void d_emlrt_marshallIn(const mxArray *u, const emlrtMsgIdentifier
  *parentId, emxArray_real_T *y)
{
  l_emlrt_marshallIn(emlrtAlias(u), parentId, y);
  emlrtDestroyArray(&u);
}

static uint64_T e_emlrt_marshallIn(const mxArray *frql, const char_T *identifier)
{
  uint64_T y;
  emlrtMsgIdentifier thisId;
  thisId.fIdentifier = (const char *)identifier;
  thisId.fParent = NULL;
  thisId.bParentIsCell = false;
  y = f_emlrt_marshallIn(emlrtAlias(frql), &thisId);
  emlrtDestroyArray(&frql);
  return y;
}

static void emlrt_marshallIn(const mxArray *Y, const char_T *identifier,
  emxArray_real_T *y)
{
  emlrtMsgIdentifier thisId;
  thisId.fIdentifier = (const char *)identifier;
  thisId.fParent = NULL;
  thisId.bParentIsCell = false;
  b_emlrt_marshallIn(emlrtAlias(Y), &thisId, y);
  emlrtDestroyArray(&Y);
}

static const mxArray *emlrt_marshallOut(const uint64_T u)
{
  const mxArray *y;
  const mxArray *m0;
  y = NULL;
  m0 = emlrtCreateNumericMatrix(1, 1, mxUINT64_CLASS, mxREAL);
  *(uint64_T *)emlrtMxGetData(m0) = u;
  emlrtAssign(&y, m0);
  return y;
}

static uint64_T f_emlrt_marshallIn(const mxArray *u, const emlrtMsgIdentifier
  *parentId)
{
  uint64_T y;
  y = m_emlrt_marshallIn(emlrtAlias(u), parentId);
  emlrtDestroyArray(&u);
  return y;
}

static real_T g_emlrt_marshallIn(const mxArray *kp, const char_T *identifier)
{
  real_T y;
  emlrtMsgIdentifier thisId;
  thisId.fIdentifier = (const char *)identifier;
  thisId.fParent = NULL;
  thisId.bParentIsCell = false;
  y = h_emlrt_marshallIn(emlrtAlias(kp), &thisId);
  emlrtDestroyArray(&kp);
  return y;
}

static real_T h_emlrt_marshallIn(const mxArray *u, const emlrtMsgIdentifier
  *parentId)
{
  real_T y;
  y = n_emlrt_marshallIn(emlrtAlias(u), parentId);
  emlrtDestroyArray(&u);
  return y;
}

static boolean_T i_emlrt_marshallIn(const mxArray *rpt, const char_T *identifier)
{
  boolean_T y;
  emlrtMsgIdentifier thisId;
  thisId.fIdentifier = (const char *)identifier;
  thisId.fParent = NULL;
  thisId.bParentIsCell = false;
  y = j_emlrt_marshallIn(emlrtAlias(rpt), &thisId);
  emlrtDestroyArray(&rpt);
  return y;
}

static boolean_T j_emlrt_marshallIn(const mxArray *u, const emlrtMsgIdentifier
  *parentId)
{
  boolean_T y;
  y = o_emlrt_marshallIn(emlrtAlias(u), parentId);
  emlrtDestroyArray(&u);
  return y;
}

static void k_emlrt_marshallIn(const mxArray *src, const emlrtMsgIdentifier
  *msgId, emxArray_real_T *ret)
{
  static const int32_T dims[1] = { -1 };

  const boolean_T bv0[1] = { true };

  int32_T iv2[1];
  int32_T i10;
  emlrtCheckVsBuiltInR2012b(emlrtRootTLSGlobal, msgId, src, "double", false, 1U,
    dims, &bv0[0], iv2);
  ret->allocatedSize = iv2[0];
  i10 = ret->size[0];
  ret->size[0] = iv2[0];
  emxEnsureCapacity_real_T(ret, i10);
  ret->data = (real_T *)emlrtMxGetData(src);
  ret->canFreeData = false;
  ret->canFreeData = false;
  emlrtDestroyArray(&src);
}

static void l_emlrt_marshallIn(const mxArray *src, const emlrtMsgIdentifier
  *msgId, emxArray_real_T *ret)
{
  static const int32_T dims[2] = { -1, -1 };

  const boolean_T bv1[2] = { true, true };

  int32_T iv3[2];
  int32_T i11;
  emlrtCheckVsBuiltInR2012b(emlrtRootTLSGlobal, msgId, src, "double", false, 2U,
    dims, &bv1[0], iv3);
  ret->allocatedSize = iv3[0] * iv3[1];
  i11 = ret->size[0] * ret->size[1];
  ret->size[0] = iv3[0];
  ret->size[1] = iv3[1];
  emxEnsureCapacity_real_T(ret, i11);
  ret->data = (real_T *)emlrtMxGetData(src);
  ret->canFreeData = false;
  ret->canFreeData = false;
  emlrtDestroyArray(&src);
}

static uint64_T m_emlrt_marshallIn(const mxArray *src, const emlrtMsgIdentifier *
  msgId)
{
  uint64_T ret;
  static const int32_T dims = 0;
  emlrtCheckBuiltInR2012b(emlrtRootTLSGlobal, msgId, src, "uint64", false, 0U,
    &dims);
  ret = *(uint64_T *)emlrtMxGetData(src);
  emlrtDestroyArray(&src);
  return ret;
}

static real_T n_emlrt_marshallIn(const mxArray *src, const emlrtMsgIdentifier
  *msgId)
{
  real_T ret;
  static const int32_T dims = 0;
  emlrtCheckBuiltInR2012b(emlrtRootTLSGlobal, msgId, src, "double", false, 0U,
    &dims);
  ret = *(real_T *)emlrtMxGetData(src);
  emlrtDestroyArray(&src);
  return ret;
}

static boolean_T o_emlrt_marshallIn(const mxArray *src, const emlrtMsgIdentifier
  *msgId)
{
  boolean_T ret;
  static const int32_T dims = 0;
  emlrtCheckBuiltInR2012b(emlrtRootTLSGlobal, msgId, src, "logical", false, 0U,
    &dims);
  ret = *emlrtMxGetLogicals(src);
  emlrtDestroyArray(&src);
  return ret;
}

void CCRl_clus_api(const mxArray * const prhs[8], int32_T nlhs, const mxArray
                   *plhs[3])
{
  emxArray_real_T *Y;
  emxArray_real_T *X;
  emxArray_real_T *Xc;
  emxArray_real_T *betas;
  emxArray_real_T *clus;
  uint64_T frql;
  real_T kp;
  uint64_T kmin;
  uint64_T kmax;
  boolean_T rpt;
  uint64_T k;
  emlrtHeapReferenceStackEnterFcnR2012b(emlrtRootTLSGlobal);
  emxInit_real_T(&Y, 1, true);
  emxInit_real_T(&X, 2, true);
  emxInit_real_T(&Xc, 2, true);
  emxInit_real_T(&betas, 2, true);
  emxInit_real_T(&clus, 1, true);

  /* Marshall function inputs */
  Y->canFreeData = false;
  emlrt_marshallIn(emlrtAlias(prhs[0]), "Y", Y);
  X->canFreeData = false;
  c_emlrt_marshallIn(emlrtAlias(prhs[1]), "X", X);
  Xc->canFreeData = false;
  c_emlrt_marshallIn(emlrtAlias(prhs[2]), "Xc", Xc);
  frql = e_emlrt_marshallIn(emlrtAliasP(prhs[3]), "frql");
  kp = g_emlrt_marshallIn(emlrtAliasP(prhs[4]), "kp");
  kmin = e_emlrt_marshallIn(emlrtAliasP(prhs[5]), "kmin");
  kmax = e_emlrt_marshallIn(emlrtAliasP(prhs[6]), "kmax");
  rpt = i_emlrt_marshallIn(emlrtAliasP(prhs[7]), "rpt");

  /* Invoke the target function */
  CCRl_clus(Y, X, Xc, frql, kp, kmin, kmax, rpt, &k, betas, clus);

  /* Marshall function outputs */
  plhs[0] = emlrt_marshallOut(k);
  emxFree_real_T(&Xc);
  emxFree_real_T(&X);
  emxFree_real_T(&Y);
  if (nlhs > 1) {
    betas->canFreeData = false;
    plhs[1] = b_emlrt_marshallOut(betas);
  }

  emxFree_real_T(&betas);
  if (nlhs > 2) {
    clus->canFreeData = false;
    plhs[2] = c_emlrt_marshallOut(clus);
  }

  emxFree_real_T(&clus);
  emlrtHeapReferenceStackLeaveFcnR2012b(emlrtRootTLSGlobal);
}

/* End of code generation (_coder_CCRl_clus_api.c) */
