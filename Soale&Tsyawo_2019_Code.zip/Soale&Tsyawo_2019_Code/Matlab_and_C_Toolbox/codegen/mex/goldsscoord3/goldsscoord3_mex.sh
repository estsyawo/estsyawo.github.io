MATLAB="/usr/local/MATLAB/R2018b"
Arch=glnxa64
ENTRYPOINT=mexFunction
MAPFILE=$ENTRYPOINT'.map'
PREFDIR="/home/selorm/.matlab/R2018b"
OPTSFILE_NAME="./setEnv.sh"
. $OPTSFILE_NAME
COMPILER=$CC
. $OPTSFILE_NAME
echo "# Make settings for goldsscoord3" > goldsscoord3_mex.mki
echo "CC=$CC" >> goldsscoord3_mex.mki
echo "CFLAGS=$CFLAGS" >> goldsscoord3_mex.mki
echo "CLIBS=$CLIBS" >> goldsscoord3_mex.mki
echo "COPTIMFLAGS=$COPTIMFLAGS" >> goldsscoord3_mex.mki
echo "CDEBUGFLAGS=$CDEBUGFLAGS" >> goldsscoord3_mex.mki
echo "CXX=$CXX" >> goldsscoord3_mex.mki
echo "CXXFLAGS=$CXXFLAGS" >> goldsscoord3_mex.mki
echo "CXXLIBS=$CXXLIBS" >> goldsscoord3_mex.mki
echo "CXXOPTIMFLAGS=$CXXOPTIMFLAGS" >> goldsscoord3_mex.mki
echo "CXXDEBUGFLAGS=$CXXDEBUGFLAGS" >> goldsscoord3_mex.mki
echo "LDFLAGS=$LDFLAGS" >> goldsscoord3_mex.mki
echo "LDOPTIMFLAGS=$LDOPTIMFLAGS" >> goldsscoord3_mex.mki
echo "LDDEBUGFLAGS=$LDDEBUGFLAGS" >> goldsscoord3_mex.mki
echo "Arch=$Arch" >> goldsscoord3_mex.mki
echo "LD=$LD" >> goldsscoord3_mex.mki
echo OMPFLAGS= >> goldsscoord3_mex.mki
echo OMPLINKFLAGS= >> goldsscoord3_mex.mki
echo "EMC_COMPILER=gcc" >> goldsscoord3_mex.mki
echo "EMC_CONFIG=optim" >> goldsscoord3_mex.mki
"/usr/local/MATLAB/R2018b/bin/glnxa64/gmake" -j 1 -B -f goldsscoord3_mex.mk
