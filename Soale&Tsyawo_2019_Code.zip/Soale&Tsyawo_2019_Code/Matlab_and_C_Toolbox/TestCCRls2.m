%% TestCCRls
n=uint32(1000); p = uint32(20000);
CCRls2(Y,X(:),n,p); 