#=========================================================================================>
# Author: Emmanuel Selorm Tsyawo
# Project: Feasible IV Regression without Excluded Instruments
# Date began:   Sept 6, 2021
# Last Update:  March 7, 2021
# Place:        Rabat
#=========================================================================================>
# Load packages, clear memory,
#rm(list=ls())
library(estrpac)#install from binary file estrpac_0.1.0.tgz or
# use devtools::install_github("estsyawo/estrpac")
library(pbapply)
setwd(dirname(rstudioapi::getActiveDocumentContext()$path)) #set working directory path to source file
#source("Fonctions.R")
list.files()
#=========================================================================================>
# Comments: Monte Carlo Simulations using the DGP of Escanciano 2018 (Online Appendix)
# n = 500; DGP_3A and DGP_3B
#=========================================================================================>
# Set Parameters
R = 1000 # set number of simulations
b=1#parameter of interest

RMSE = function(x) sqrt(mean(x^2))
MAD = function(x) median(abs(x))

#-------------------------------------------------------

gdat1<- function(n,f.fun,gam){
  datl=list()
  for (l in 1:R) {
    set.seed(l) #generate seed
    Z=rnorm(n)
    Sig = diag(2); Sig[1,2]=Sig[2,1]=0.8
    set.seed(l+10)
    EU=MASS::mvrnorm(n=n,mu=c(0,0),Sigma = Sig)
    #generate endogenous covariate
    D = f.fun(Z,EU[,2],gam)
    #generate outcome
    Y = 1 + b*D + EU[,1]
    datl[[l]]<- data.frame(Y,D,Z)
  }
  datl
}
#transformations of Z for the endogenous variable
f.fun1=function(Z,U,gam){gam*Z+U}
f.fun2=function(Z,U,gam){1*((1+gam*Z+U)>0)}

# n = 500
# gamma=0.1
datl1a=gdat1(n=500,f.fun=f.fun1,gam = 0.1) #linear homoskedastic model

summary(imlmreg2.fit(Y=datl1a[[1]]$Y,X=datl1a[[1]]$D,Z=datl1a[[1]][,-c(1,2)]))#MMD is the default
summary(imlmreg2.fit(Y=datl1a[[1]]$Y,X=datl1a[[1]]$D,Z=datl1a[[1]][,-c(1,2)],Kern = "Gauss.W"))
summary(imlmreg2.fit(Y=datl1a[[1]]$Y,X=datl1a[[1]]$D,Z=datl1a[[1]][,-c(1,2)],Kern = "Gauss"))
summary(imlmreg2.fit(Y=datl1a[[1]]$Y,X=datl1a[[1]]$D,Z=datl1a[[1]][,-c(1,2)],Kern = "DL"))
summary(imlmreg2.fit(Y=datl1a[[1]]$Y,X=datl1a[[1]]$D,Z=datl1a[[1]][,-c(1,2)],Kern = "WMD"))

MCfun1<- function(j=NULL,datl,b){
  dat = datl[[j]] #null operation for looping
  Y = dat[,1]; X = as.matrix(dat[,2])
  Z1 = as.matrix(dat[,3]); Z2 = as.matrix(dat[,-c(1,2)])
  
  #run Integrated Moment regressions
  MMDobj=imlmreg2.fit(Y,X,Z1,Kern = "Euclid")
  WMDobj=imlmreg2.fit(Y,X,Z1,Kern = "WMD")
  WMDFobj=imlmreg2.fit(Y,X,Z1,Kern = "WMDF")
  DLobj=imlmreg2.fit(Y,X,Z1,Kern = "DL")
  Esc6obj=imlmreg2.fit(Y,X,Z1,Kern = "Esc6")
  IIVobj=imlmreg2.fit(Y,X,Z1,Kern = "Gauss.W")
  #run K-Class regressions
  TSLSobj=ivreg(Y~X|Z2); TSLSobj$HC_Std.Err=sqrt(diag(vcovHC(TSLSobj)))
  JIVEobj=kClassIVreg.fit(Y,X,Z2,method = "JIVE")
  LIMLobj=kClassIVreg.fit(Y,X,Z2,method = "LIML")
  HLIMobj=kClassIVreg.fit(Y,X,Z2,method = "HLIM")
  HFULobj=kClassIVreg.fit(Y,X,Z2,method = "HFUL")
  
  #compute bias
  bias.MMD = MMDobj$coefficients[2]-b 
  bias.WMD = WMDobj$coefficients[2]-b
  bias.WMDF = WMDFobj$coefficients[2]-b
  bias.DL = DLobj$coefficients[2]-b
  bias.Esc6 = Esc6obj$coefficients[2]-b
  bias.IIV = IIVobj$coefficients[2]-b
  
  bias.TSLS = TSLSobj$coefficients[2]-b
  bias.JIVE = JIVEobj$coefficients[2]-b
  bias.LIML = LIMLobj$coefficients[2]-b
  bias.HLIM = HLIMobj$coefficients[2]-b
  bias.HFUL = HFULobj$coefficients[2]-b
  
  #compute size (for rejection probabilities)
  size.MMD = 1*(abs(bias.MMD/MMDobj$HC_Std.Err[2])>qnorm(0.975))
  size.WMD = 1*(abs(bias.WMD/WMDobj$HC_Std.Err[2])>qnorm(0.975))
  size.WMDF = 1*(abs(bias.WMDF/WMDFobj$HC_Std.Err[2])>qnorm(0.975))
  size.DL = 1*(abs(bias.DL/DLobj$HC_Std.Err[2])>qnorm(0.975))
  size.Esc6 = 1*(abs(bias.Esc6/Esc6obj$HC_Std.Err[2])>qnorm(0.975))
  size.IIV = 1*(abs(bias.IIV/IIVobj$HC_Std.Err[2])>qnorm(0.975))
  
  size.TSLS = 1*(abs(bias.TSLS/TSLSobj$HC_Std.Err[2])>qnorm(0.975))
  size.JIVE = 1*(abs(bias.JIVE/JIVEobj$HC_Std.Err[2])>qnorm(0.975))
  size.LIML = 1*(abs(bias.LIML/LIMLobj$HC_Std.Err[2])>qnorm(0.975))
  size.HLIM = 1*(abs(bias.HLIM/HLIMobj$HC_Std.Err[2])>qnorm(0.975))
  size.HFUL = 1*(abs(bias.HFUL/HFULobj$HC_Std.Err[2])>qnorm(0.975))
  
  res=c(bias.MMD,bias.WMD,bias.WMDF,bias.DL,bias.Esc6,bias.IIV,bias.TSLS,bias.JIVE,bias.LIML,bias.HLIM,
        bias.HFUL,size.MMD,
        size.WMD,size.WMDF,size.DL,size.Esc6,size.IIV,size.TSLS,size.JIVE,size.LIML,
        size.HLIM,size.HFUL)
  names(res)=c("BiasMMD","BiasWMD","BiasWMDF","BiasDL","BiasEsc6","BiasIIV","Bias.TSLS",
               "Bias.JIVE","Bias.LIML","Bias.HLIM","Bias.HFUL",
               "SizeMMD","SizeWMD","SizeWMDF","SizeDL","SizeEsc6","SizeIIV","Size.TSLS",
               "Size.JIVE","Size.LIML","Size.HLIM","Size.HFUL")
  res
}

# 
#-------------------------------------------------------

# illustration
MCfun1(j=2,datl=datl1a,b=b)

#linear homoskedastic model, n = 250, gamma = 0.1
Bias1a = pbsapply(1:R, FUN=MCfun1,cl=5,datl=datl1a,b=b)
summary(t(Bias1a))

# gamma = 0.25
datl1aM=gdat1(n=500,f.fun=f.fun1,gam = 0.25)
Bias1a.M = pbsapply(1:R, FUN=MCfun1,cl=5,datl=datl1aM,b=b)
summary(t(Bias1a.M))

# gamma = 0.5
datl1aMM=gdat1(n=500,f.fun=f.fun1,gam = 0.5) #linear heteroskedastic model
Bias1a.MM = pbsapply(1:R, FUN=MCfun1,cl=5,datl=datl1aMM,b=b)
summary(t(Bias1a.MM))
#-------------------------------------------------------
# n = 500

#gamma = 0.1
datl1b=gdat1(n=500,f.fun=f.fun2,gam = 0.1)
Bias1b = pbsapply(1:R, FUN=MCfun1,cl=5,datl=datl1b,b=b)
summary(t(Bias1b))

# gamma = 0.5
datl1bM=gdat1(n=500,f.fun=f.fun2,gam = 0.5)
Bias1b.M = pbsapply(1:R, FUN=MCfun1,cl=5,datl=datl1bM,b=b)
summary(t(Bias1b.M))

# gamma = 1
datl1bMM=gdat1(n=500,f.fun=f.fun2,gam = 1)
Bias1b.MM = pbsapply(1:R, FUN=MCfun1,cl=5,datl=datl1bMM,b=b)
summary(t(Bias1b.MM))
#=========================================================================================>


#=========================================================================================>

# Results:

Res.A1=round(cbind(apply(Bias1a[1:11,],1,mean),apply(Bias1a[1:11,],1,MAD),apply(Bias1a[1:11,],1,RMSE),
                   apply(Bias1a[12:22,],1,mean)),3)
colnames(Res.A1)=c("MB","MAD","RMSE","Rej")
rownames(Res.A1)=c("MMD","WMD","WMDF","DL","ESC6","IIV","TSLS","JIVE","LIML","HLIM","HFUL")
Res.A1

Res.A2=round(cbind(apply(Bias1a.M[1:11,],1,mean),apply(Bias1a.M[1:11,],1,MAD),apply(Bias1a.M[1:11,],1,RMSE),
                   apply(Bias1a.M[12:22,],1,mean,na.rm=TRUE)),3)
colnames(Res.A2)=c("MB","MAD","RMSE","Rej")
rownames(Res.A2)=c("MMD","WMD","WMDF","DL","ESC6","IIV","TSLS","JIVE","LIML","HLIM","HFUL")
Res.A2

Res.A3=round(cbind(apply(Bias1a.MM[1:11,],1,mean),apply(Bias1a.MM[1:11,],1,MAD),apply(Bias1a.MM[1:11,],1,RMSE),
                   apply(Bias1a.MM[12:22,],1,mean)),3)
colnames(Res.A3)=c("MB","MAD","RMSE","Rej")
rownames(Res.A3)=c("MMD","WMD","WMDF","DL","ESC6","IIV","TSLS","JIVE","LIML","HLIM","HFUL")
Res.A3

cbind(Res.A1,Res.A2,Res.A3)

#         MB   MAD    RMSE   Rej     MB   MAD  RMSE   Rej     MB   MAD  RMSE   Rej
# MMD   0.080 0.263   1.632 0.137  0.002 0.112 0.181 0.063  0.001 0.058 0.088 0.054
# WMD   0.529 0.313  12.827 0.083 -0.022 0.123 0.212 0.055 -0.004 0.063 0.096 0.044
# WMDF -0.019 0.311   1.953 0.085 -0.021 0.122 0.211 0.055 -0.004 0.063 0.096 0.044
# DL   -3.220 0.288  98.206 0.129 -0.002 0.117 0.188 0.064  0.000 0.059 0.091 0.052
# ESC6  0.105 0.255   0.475 0.118 -0.004 0.113 0.188 0.062 -0.001 0.059 0.091 0.052
# IIV   0.173 0.290   1.670 0.137  0.002 0.121 0.195 0.066  0.001 0.063 0.095 0.048
# TSLS -0.304 0.270   3.522 0.074 -0.027 0.109 0.193 0.054 -0.006 0.055 0.087 0.041
# JIVE  6.190 0.375 144.399 0.094 -0.061 0.117 0.225 0.036 -0.013 0.056 0.090 0.037
# LIML -0.304 0.270   3.522 0.074 -0.027 0.109 0.193 0.054 -0.006 0.055 0.087 0.041
# HLIM  6.190 0.375 144.399 0.094 -0.061 0.117 0.225 0.036 -0.013 0.056 0.090 0.037
# HFUL -0.407 0.268   6.115 0.075 -0.027 0.110 0.193 0.053 -0.006 0.055 0.087 0.040

#for pasting into TeX
apply(cbind(Res.A1,Res.A2,Res.A3),1,paste,collapse=" & ")

# MMD 0.08 & 0.263 & 1.632 & 0.137 & 0.002 & 0.112 & 0.181 & 0.063 & 0.001 & 0.058 & 0.088 & 0.054" 
# WMD 0.529 & 0.313 & 12.827 & 0.083 & -0.022 & 0.123 & 0.212 & 0.055 & -0.004 & 0.063 & 0.096 & 0.044" 
# WMDF -0.019 & 0.311 & 1.953 & 0.085 & -0.021 & 0.122 & 0.211 & 0.055 & -0.004 & 0.063 & 0.096 & 0.044" 
# DL -3.22 & 0.288 & 98.206 & 0.129 & -0.002 & 0.117 & 0.188 & 0.064 & 0 & 0.059 & 0.091 & 0.052" 
# ESC6 0.105 & 0.255 & 0.475 & 0.118 & -0.004 & 0.113 & 0.188 & 0.062 & -0.001 & 0.059 & 0.091 & 0.052" 
# IIV 0.173 & 0.29 & 1.67 & 0.137 & 0.002 & 0.121 & 0.195 & 0.066 & 0.001 & 0.063 & 0.095 & 0.048" 
# TSLS -0.304 & 0.27 & 3.522 & 0.074 & -0.027 & 0.109 & 0.193 & 0.054 & -0.006 & 0.055 & 0.087 & 0.041" 
# JIVE 6.19 & 0.375 & 144.399 & 0.094 & -0.061 & 0.117 & 0.225 & 0.036 & -0.013 & 0.056 & 0.09 & 0.037" 
# LIML -0.304 & 0.27 & 3.522 & 0.074 & -0.027 & 0.109 & 0.193 & 0.054 & -0.006 & 0.055 & 0.087 & 0.041" 
# HLIM 6.19 & 0.375 & 144.399 & 0.094 & -0.061 & 0.117 & 0.225 & 0.036 & -0.013 & 0.056 & 0.09 & 0.037" 
# HFUL -0.407 & 0.268 & 6.115 & 0.075 & -0.027 & 0.11 & 0.193 & 0.053 & -0.006 & 0.055 & 0.087 & 0.04"

#----------------------------------------------------------------------------------------->

Res.B1=round(cbind(apply(Bias1b[1:11,],1,mean),apply(Bias1b[1:11,],1,MAD),apply(Bias1b[1:11,],1,RMSE),
                   apply(Bias1b[12:22,],1,mean)),3)
colnames(Res.B1)=c("MB","MAD","RMSE","Rej")
rownames(Res.B1)=c("MMD","WMD","WMDF","DL","ESC6","IIV","TSLS","JIVE","LIML","HLIM","HFUL")
Res.B1

Res.B2=round(cbind(apply(Bias1b.M[1:11,],1,mean),apply(Bias1b.M[1:11,],1,MAD),apply(Bias1b.M[1:11,],1,RMSE),
                   apply(Bias1b.M[12:22,],1,mean)),3)
colnames(Res.B2)=c("MB","MAD","RMSE","Rej")
rownames(Res.B2)=c("MMD","WMD","WMDF","DL","ESC6","IIV","TSLS","JIVE","LIML","HLIM","HFUL")
Res.B2

Res.B3=round(cbind(apply(Bias1b.MM[1:11,],1,mean),apply(Bias1b.MM[1:11,],1,MAD),apply(Bias1b.MM[1:11,],1,RMSE),
                   apply(Bias1b.MM[12:22,],1,mean)),3)
colnames(Res.B3)=c("MB","MAD","RMSE","Rej")
rownames(Res.B3)=c("MMD","WMD","WMDF","DL","ESC6","IIV","TSLS","JIVE","LIML","HLIM","HFUL")
Res.B3

cbind(Res.B1,Res.B2,Res.B3)

#         MB   MAD    RMSE   Rej     MB   MAD   RMSE   Rej     MB   MAD  RMSE   Rej
# MMD   4.790 2.569  73.194 0.016 -2.209 0.530 59.136 0.041 -0.015 0.195 0.289 0.043
# WMD   1.128 2.643  47.062 0.015 -0.325 0.552  2.530 0.037 -0.016 0.196 0.293 0.046
# WMDF  1.610 2.641  36.591 0.015 -0.322 0.552  2.507 0.037 -0.016 0.196 0.292 0.046
# DL   -0.701 1.279  22.195 0.034 -0.025 0.280  0.436 0.037 -0.005 0.161 0.239 0.041
# ESC6 10.606 2.636 218.732 0.015 -0.153 0.439  1.238 0.048 -0.007 0.158 0.231 0.048
# IIV  -0.058 2.644  29.036 0.015 -0.298 0.551  2.374 0.041 -0.013 0.195 0.291 0.046
# TSLS -1.235 1.185  31.307 0.034 -0.027 0.234  0.379 0.033 -0.006 0.125 0.195 0.043
# JIVE  0.615 1.515  18.730 0.100 -0.064 0.237  0.407 0.032 -0.012 0.126 0.196 0.044
# LIML -1.235 1.185  31.307 0.034 -0.027 0.234  0.379 0.033 -0.006 0.125 0.195 0.043
# HLIM  0.615 1.515  18.730 0.100 -0.064 0.237  0.407 0.032 -0.012 0.126 0.196 0.044
# HFUL -0.880 1.235  33.766 0.032 -0.026 0.228  0.377 0.033 -0.004 0.125 0.194 0.041

#for pasting into TeX
apply(cbind(Res.B1,Res.B2,Res.B3),1,paste,collapse=" & ")

# MMD 4.79 & 2.569 & 73.194 & 0.016 & -2.209 & 0.53 & 59.136 & 0.041 & -0.015 & 0.195 & 0.289 & 0.043" 
# WMD 1.128 & 2.643 & 47.062 & 0.015 & -0.325 & 0.552 & 2.53 & 0.037 & -0.016 & 0.196 & 0.293 & 0.046" 
# WMDF 1.61 & 2.641 & 36.591 & 0.015 & -0.322 & 0.552 & 2.507 & 0.037 & -0.016 & 0.196 & 0.292 & 0.046" 
# DL -0.701 & 1.279 & 22.195 & 0.034 & -0.025 & 0.28 & 0.436 & 0.037 & -0.005 & 0.161 & 0.239 & 0.041" 
# ESC6 10.606 & 2.636 & 218.732 & 0.015 & -0.153 & 0.439 & 1.238 & 0.048 & -0.007 & 0.158 & 0.231 & 0.048" 
# IIV -0.058 & 2.644 & 29.036 & 0.015 & -0.298 & 0.551 & 2.374 & 0.041 & -0.013 & 0.195 & 0.291 & 0.046" 
# TSLS -1.235 & 1.185 & 31.307 & 0.034 & -0.027 & 0.234 & 0.379 & 0.033 & -0.006 & 0.125 & 0.195 & 0.043" 
# JIVE 0.615 & 1.515 & 18.73 & 0.1 & -0.064 & 0.237 & 0.407 & 0.032 & -0.012 & 0.126 & 0.196 & 0.044" 
# LIML -1.235 & 1.185 & 31.307 & 0.034 & -0.027 & 0.234 & 0.379 & 0.033 & -0.006 & 0.125 & 0.195 & 0.043" 
# HLIM 0.615 & 1.515 & 18.73 & 0.1 & -0.064 & 0.237 & 0.407 & 0.032 & -0.012 & 0.126 & 0.196 & 0.044" 
# HFUL -0.88 & 1.235 & 33.766 & 0.032 & -0.026 & 0.228 & 0.377 & 0.033 & -0.004 & 0.125 & 0.194 & 0.041"

#=========================================================================================>