function bets=cordlin(Y,X)

%% use coordinate descent to estimate linear regression

[~,p] = size(X); az = 1e-20; tol = 1e-010;
bets = zeros(1,p); % initialise with zeros
Xdot = zeros(1,p); k = 0;
RSS0 = sum((Y-X*bets(1,:)').^2); % initial RSS0
for j=1:p
    Xdot(1,j) = dot(X(:,j),X(:,j));
end

% to run in a while loop
while 1
    k = k+1;
for j =1:p
    id = (1:p)~=j;
    err = Y-X(:,id)*bets(1,id)';
    bets(1,j) = dot(err,X(:,j))/Xdot(1,j);
end
RSS1 = sum((Y-X*bets(1,:)').^2); dev = (RSS0 - RSS1)/(az + abs(RSS0));
% check convergence
if(dev<=tol)
    break;
end
sprintf('iter = %u RSS = %0.5f and dev = %0.5f',uint64(k),double(RSS1),double(dev))
RSS0=RSS1;
end