//=====================================================
// Clustered Gini helper
// Purpose:
//   Provide fast C++ routines for the clustered order-2 Gini mean-difference
//   statistic and its empirical first-order projection ingredients. These
//   routines are used by the clustered simulation arm in R/.
// Inputs:
//   Passed from R via Rcpp.
// Outputs:
//   Rcpp-exported lists containing point estimates, leave-one-out averages,
//   centred projections, and feasible variance ingredients.
// Side effects:
//   None.
//=====================================================

// [[Rcpp::depends(Rcpp)]]
#include <Rcpp.h>
using namespace Rcpp;

//=====================================================
// cluster_gini_stat_cpp
// Purpose:
//   Compute the theta-centred clustered order-2 Gini U-statistic together with
//   its leave-one-out averages, centred empirical first-order projections, and
//   cluster-robust feasible variance estimate.
// Inputs:
//   W : numeric vector of scalar observations.
//   cluster_id : integer vector of 0-indexed cluster labels, same length as W.
//   theta : scalar centring constant for the kernel |w_i - w_j| - theta.
// Outputs:
//   Rcpp list with elements:
//     U_phi_n
//     hat_sigma2
//     loo_avg
//     hat_phi_n
// Side effects:
//   None.
//=====================================================
// [[Rcpp::export]]
List cluster_gini_stat_cpp(NumericVector W, IntegerVector cluster_id, double theta) {
  const int n = W.size();
  if (cluster_id.size() != n) stop("W and cluster_id must have the same length.");

  int G = 0;
  for (int i = 0; i < n; i++) {
    if (cluster_id[i] < 0) stop("cluster_id must be 0-indexed (>= 0).");
    if (cluster_id[i] + 1 > G) G = cluster_id[i] + 1;
  }

  std::vector<int> cluster_size(G, 0);
  for (int i = 0; i < n; i++) cluster_size[cluster_id[i]]++;

  double total_sum = 0.0;
  NumericVector row_sum_all(n, 0.0);

  for (int i = 0; i < n; i++) {
    double rs = 0.0;
    const double wi = W[i];
    for (int j = 0; j < n; j++) {
      if (i == j) continue;
      const double d = std::fabs(wi - W[j]);
      total_sum += d;
      rs += d;
    }
    row_sum_all[i] = rs;
  }

  const double U_phi_n = total_sum / ((double)n * (n - 1)) - theta;

  NumericVector loo_avg(n);
  NumericVector hat_phi_n(n);
  for (int i = 0; i < n; i++) {
    loo_avg[i] = row_sum_all[i] / (double)(n - 1) - theta;
    hat_phi_n[i] = loo_avg[i] - U_phi_n;
  }

  std::vector<double> cluster_sum_proj(G, 0.0);
  for (int i = 0; i < n; i++) cluster_sum_proj[cluster_id[i]] += hat_phi_n[i];

  double hat_sigma2 = 0.0;
  for (int g = 0; g < G; g++) hat_sigma2 += cluster_sum_proj[g] * cluster_sum_proj[g];
  hat_sigma2 = 4.0 / (double)n * hat_sigma2;

  return List::create(
    Named("U_phi_n") = U_phi_n,
    Named("hat_sigma2") = hat_sigma2,
    Named("loo_avg") = loo_avg,
    Named("hat_phi_n") = hat_phi_n
  );
}
