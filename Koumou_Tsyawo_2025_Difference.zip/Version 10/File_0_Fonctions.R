#=======================================================================================>
# Purpose: Compute a simple ATT from two series (a treated and an untreated one)
#           using DiD as developed in Koumou & Tsyawo 2022

#Arguments: 
#           Y1 - outcome series of the treated group
#           Y0 - outcome series of the untreated group
#           var.time - a vector of time periods
#           time.treat - time of treatment; should be an element in var.time;
#                        it can also be a vector of contiguous time periods -
#                         observations corresponding to time.treat are not used
#                         in computations
#           Diff - logical (F/T) for differencing the summands of ATT (see paper) in case
#                 it has a unit-root; defaults to F (false)
#           se.type - type of standard error; defaults to the Newey-West procedure
#           transf - a transformation (function) applied to Y1 and Y0; defaults to NULL

#Value: A list of the following
#           list(est.ATT=reg.Obj$coefficients,se.ATT=se.ATT,t.stat=est.ATT/se.ATT,
#pval.ATT=pval.ATT,ADF.test,KPSS.test,X10=X10)
#           est.ATT - estimate of ATT
#           se.ATT - standard error
#           t.stat - t-statistic
#           pval.ATT - p-value of the t-stat
#           ADF.test - ADF test object for test of independent sampling of the summands of ATT
#           KPSS.test - KPSS test object: null hypothesis is unit root of the summands of ATT
#           X10 - summands of ATT; they sum up to est.ATT
#           

ATT.fun<-function(Y1,Y0,var.time,time.treat,t.X="Level",se.type="NW"
                  ,transf=NULL,weight=NULL,q=0){
  
  if(!is.null(transf)){Y1=transf(Y1); Y0=transf(Y0)}
  
  id.post = which(var.time>max(time.treat))
  id.pre = which(var.time<min(time.treat))
  ids = c(id.post,id.pre)
  
  
  
  if(t.X=="Level"){
    X10 = Y1-Y0
    t.dum<- var.time>max(time.treat)*1
    
    if(is.null(weight)){
      reg.Obj=lm(X10[ids] ~ t.dum[ids], x=T,y=T)
    }else{
      reg.Obj=lm(I(X10[ids]*weight) ~ I(t.dum[ids]*weight), x=T,y=T)
    }
    #diagnostics:
    # Dickey-Fuller Test of non-stationarity
    ADF.test=adf.test(na.omit(X10[ids]))
    #Kwiatkowski-Phillips-Schmidt-Shin (KPSS) for level or trend stationarity
    KPSS.test=kpss.test(na.omit(X10[ids]),null="Trend")
    # Durbin-Watson test for two-sided autoccorrelation
    DW.test=dwtest(reg.Obj,alternative = "two.sided")
    
    est.ATT=reg.Obj$coefficients[2] 
    if(se.type=="NW"){
      mat.vcov = vcovHAC(reg.Obj)
      se.ATT=sqrt(c(mat.vcov[2,2]))
    }else if(se.type=="HC"){
      mat.vcov = vcovHC(reg.Obj)
      se.ATT=sqrt(c(mat.vcov[2,2]))
    }
    
  }else if(t.X=="Diff"){
    X10.post<- diff((Y1-Y0)[id.post])
    X10.pre<- diff((Y1-Y0)[id.pre])
    X10 = c(X10.post,X10.pre)
    t.dum<- rep(0,length(X10))
    t.dum[1:length(X10.post)]<- 1
    
    if(is.null(weight)){
      reg.Obj=lm(X10 ~ t.dum, x=T,y=T)
    }else{
      reg.Obj=lm(I(X10*weight) ~ I(t.dum*weight), x=T,y=T)
    }
    ids = 1:length(t.dum)
    #diagnostics:
    # Dickey-Fuller Test of non-stationarity
    ADF.test=adf.test(na.omit(X10[ids]))
    #Kwiatkowski-Phillips-Schmidt-Shin (KPSS) for level or trend stationarity
    KPSS.test=kpss.test(na.omit(X10[ids]),null="Trend")
    # Durbin-Watson test for two-sided autoccorrelation
    DW.test=dwtest(reg.Obj,alternative = "two.sided")
    
    est.ATT=reg.Obj$coefficients[2] 
    if(se.type=="NW"){
      mat.vcov = vcovHAC(reg.Obj)
      se.ATT=sqrt(c(mat.vcov[2,2]))
    }else if(se.type=="HC"){
      mat.vcov = vcovHC(reg.Obj)
      se.ATT=sqrt(c(mat.vcov[2,2]))
    }
    
  }else if(t.X=="Lag"){
    X10 = Y1-Y0
    T.post = length(id.post); T.pre = length(id.pre)
    t.dum<- var.time>max(time.treat)*1
    idz = c(id.post[-T.post],id.pre[-T.pre])
    ids = c(id.post[-1],id.pre[-1])
    
    if(is.null(weight)){
      reg.Obj=lm(X10[ids] ~ t.dum[ids] + X10[idz], x=T,y=T)
    }else{
      reg.Obj=lm(I(X10[ids]*weight) ~ I(t.dum[ids]*weight) + I(X10[idz]*weight), x=T,y=T)
    }
    
    #diagnostics:
    # Dickey-Fuller Test of non-stationarity
    ADF.test=adf.test(na.omit(reg.Obj$residuals))
    #Kwiatkowski-Phillips-Schmidt-Shin (KPSS) for level or trend stationarity
    KPSS.test=kpss.test(na.omit(reg.Obj$residuals),null="Trend")
    # Durbin-Watson test for two-sided autoccorrelation
    DW.test=dwtest(reg.Obj,alternative = "two.sided")
    
    est.ATT=reg.Obj$coefficients[2] 
    if(se.type=="NW"){
      mat.vcov = vcovHAC(reg.Obj)
      se.ATT=sqrt(c(mat.vcov[2,2]))
    }else if(se.type=="HC"){
      mat.vcov = vcovHC(reg.Obj)
      se.ATT=sqrt(c(mat.vcov[2,2]))
    }
    
  }else if(t.X=="MA"){
    
    X10 = Y1-Y0
    t.dum<- var.time>max(time.treat)*1
    
    if(is.null(weight)){
      reg.Obj=estimate_maq_robust(X10[ids], t.dum[ids], q = q, method = c("ML","REML"))
    }else{
      reg.Obj=estimate_maq_robust(I(X10[ids]*weight), I(t.dum[ids]*weight), q = q, method = c("ML","REML"))
    }
    
    
    #reg.Obj=lm(X10[ids] ~ 1, x=T,y=T)
    #diagnostics:
    # Dickey-Fuller Test of non-stationarity
    ADF.test=adf.test(na.omit(reg.Obj$fit$residuals))
    #Kwiatkowski-Phillips-Schmidt-Shin (KPSS) for level or trend stationarity
    KPSS.test=kpss.test(na.omit(reg.Obj$fit$residuals),null="Trend")
    # Ljung-Box test for two-sided autoccorrelation
    m <- min(10, floor(length(na.omit(reg.Obj$fit$residuals)) / 5))  # rule-of-thumb lag choice
    
    DW.test=list()
    DW.test[[1]]<- "The Ljung-Box applies in this case instead."
    DW.test[[2]]<- Box.test(resid(reg.Obj$fit,type="normalized"),lag=m,type = "Ljung-Box",fitdf=1)
    
    est.ATT=reg.Obj$fit$coefficients[2] 
    se.ATT=reg.Obj$se_robust[2]
    mat.vcov=reg.Obj$vcov_robust
    
  }else if(t.X=="Trend"){
    X10 = Y1-Y0
    t.dum<- var.time>max(time.treat)*1
    
    n = length(ids)
    trnd = var.time
    trnd[var.time<0] = var.time[var.time<0] + abs(min(var.time)) + 1
    trnd[var.time>0] = var.time[var.time>0] + abs(min(var.time))
    trnd = trnd/n #scaling time trend by n
    
    
    if(is.null(weight)){
      reg.Obj=lm(X10[ids] ~ t.dum[ids] + trnd[ids], x=T,y=T)
    }else{
      reg.Obj=lm(I(X10[ids]*weight) ~ I(t.dum[ids]*weight) + I(trnd[ids]*weight), x=T,y=T)
    }
    
    #diagnostics:
    # Dickey-Fuller Test of non-stationarity
    ADF.test=adf.test(na.omit(X10[ids]))
    #Kwiatkowski-Phillips-Schmidt-Shin (KPSS) for level or trend stationarity
    KPSS.test=kpss.test(na.omit(X10[ids]),null="Trend")
    # Durbin-Watson test for two-sided autoccorrelation
    DW.test=dwtest(reg.Obj,alternative = "two.sided")
    
    est.ATT=reg.Obj$coefficients[2] 
    if(se.type=="NW"){
      mat.vcov = vcovHAC(reg.Obj)
      se.ATT=sqrt(c(mat.vcov[2,2]))
    }else if(se.type=="HC"){
      mat.vcov = vcovHC(reg.Obj)
      se.ATT=sqrt(c(mat.vcov[2,2]))
    }
    
  }
  
  
  
  
  pval.ATT = 2*pnorm(-abs(est.ATT/se.ATT))
  
  list(est.ATT=est.ATT, se.ATT=se.ATT, t.stat=est.ATT/se.ATT,
       pval.ATT=pval.ATT, ADF.test=ADF.test, KPSS.test=KPSS.test,
       DW.test=DW.test,reg.Obj=reg.Obj,mat.vcov=mat.vcov)
}
#=======================================================================================>


#=======================================================================================>
# Purpose: Compute a simple ATT from two series (a treated and an untreated one)
#           using DiD as developed in Koumou & Tsyawo 2022

#Arguments: 
#           Y1 - outcome series of the treated group
#           Y0 - outcome series of the untreated group
#           var.time - a vector of time periods
#           time.treat - time of treatment; should be an element in var.time;
#                        it can also be a vector of contiguous time periods -
#                         observations corresponding to time.treat are not used
#                         in computations
#           Diff - logical (F/T) for differencing the summands of ATT (see paper) in case
#                 it has a unit-root; defaults to F (false)
#           se.type - type of standard error; defaults to the Newey-West procedure
#           transf - a transformation (function) applied to Y1 and Y0; defaults to NULL

#Value: A list of the following
#           list(est.ATT=reg.Obj$coefficients,se.ATT=se.ATT,t.stat=est.ATT/se.ATT,
#pval.ATT=pval.ATT,ADF.test,KPSS.test,X10=X10)
#           est.ATT - estimate of ATT
#           se.ATT - standard error
#           t.stat - t-statistic
#           pval.ATT - p-value of the t-stat
#           ADF.test - ADF test object for test of independent sampling of the summands of ATT
#           KPSS.test - KPSS test object: null hypothesis is unit root of the summands of ATT
#           X10 - summands of ATT; they sum up to est.ATT
#           

ATT.fun2<-function(Y1,Y0,var.time,time.treat,Diff=F,se.type="HC",transf=NULL){
  if(!is.null(transf)){Y1=transf(Y1); Y0=transf(Y0)}
  id.post = which(var.time>max(time.treat))
  id.pre = which(var.time<min(time.treat))
  
  T.post = length(id.post) #number of post-treatment periods
  T.pre = length(id.pre) #number of pre-treatment periods
  
  if(Diff){Y1=diff(Y1);Y0=diff(Y0)}
  
  est.ATT =  mean(Y1[id.post]-Y0[id.post],na.rm = T) - mean(Y1[id.pre]-Y0[id.pre],na.rm = T)
  if(se.type=="NW"){
    #...
  }else if(se.type=="HC"){
    se.ATT=sqrt(var(Y1[id.post]-Y0[id.post],na.rm = T)/T.post +
                  var(Y1[id.pre]-Y0[id.pre],na.rm = T)/T.pre)
  }else if(se.type=="boot"){
    fn.boot<- function(j){
      id.pre.boot=boot.mats[[1]][,j]; id.post.boot=boot.mats[[2]][,j]
      mean(Y1[id.post.boot]-Y0[id.post.boot]) - mean(Y1[id.pre.boot]-Y0[id.pre.boot])
    }
    se.ATT=sd(sapply(1:ncol(boot.mats[[1]]),fn.boot))
  }
  pval.ATT = 2*pnorm(-abs(est.ATT/se.ATT))
  # #diagnostics:
  # # Dickey-Fuller Test of non-stationarity
  ADF.test = adf.test(na.omit(Y1-Y0))
  # 
  DW.test=dwtest(lm(Y1-Y0 ~1, x=T,y=T))
  # #Kwiatkowski-Phillips-Schmidt-Shin (KPSS) for level or trend stationarity
  KPSS.test = kpss.test(na.omit(Y1-Y0),null="Trend")
  
  list(est.ATT=est.ATT,se.ATT=se.ATT,t.stat=est.ATT/se.ATT,
       pval.ATT=pval.ATT,ADF.test=ADF.test,DW.test=DW.test,KPSS.test=KPSS.test)
}
#=======================================================================================>


#=======================================================================================>
# Purpose: Compute a simple ATT from two series (a treated and an untreated one)
#           using Synthetic Control (SC) with convex weighting as illustrated in Koumou & Tsyawo 2022.
#           The SC simplifies in this case to taking the average of the difference between the treated 
#           and the untreated unit outcomes in the post-treatment period
#           

#Arguments: 
#           Y1 - outcome series of the treated group
#           Y0 - outcome series of the untreated group
#           var.time - a vector of time periods
#           time.treat - time of treatment; should be an element in var.time;
#                        it can also be a vector of contiguous time periods -
#                         observations corresponding to time.treat are not used
#                         in computations
#           Diff - logical (F/T) for differencing the summands of ATT (see paper) in case
#                 it has a unit-root; defaults to F (false)
#           se.type - type of standard error; defaults to the Newey-West procedure
#           transf - a transformation (function) applied to Y1 and Y0; defaults to NULL

#Value: A list of the following
#           list(est.ATT=reg.Obj$coefficients,se.ATT=se.ATT,t.stat=est.ATT/se.ATT,
#pval.ATT=pval.ATT,ADF.test,KPSS.test,X10=X10)
#           est.ATT - estimate of ATT
#           se.ATT - standard error
#           t.stat - t-statistic
#           pval.ATT - p-value of the t-stat
#           ADF.test - ADF test object for test of independent sampling of the summands of ATT
#           KPSS.test - KPSS test object: null hypothesis is unit root of the summands of ATT
#           X10 - summands of ATT; they sum up to est.ATT
#           

SC.fun<- function(Y1,Y0,var.time,time.treat,t.X="Level",se.type="NW",transf=NULL){
  
  if(!is.null(transf)){Y1=transf(Y1); Y0=transf(Y0)}
  
  ids = which(var.time>max(time.treat))
  X10 = Y1-Y0
  
  if(t.X %in% c("Level","MA")){
    reg.Obj=lm(X10[ids] ~ 1, x=T,y=T)
    #diagnostics:
    # Dickey-Fuller Test of non-stationarity
    ADF.test=adf.test(na.omit(X10[ids]))
    #Kwiatkowski-Phillips-Schmidt-Shin (KPSS) for level or trend stationarity
    KPSS.test=kpss.test(na.omit(X10[ids]),null="Trend")
    # Durbin-Watson test for two-sided autoccorrelation
    DW.test=dwtest(reg.Obj,alternative = "two.sided")
  }else if(t.X=="Diff"){
    X10 = diff(X10[ids])
    reg.Obj = lm(X10 ~ 1, x=T,y=T)
    #diagnostics:
    # Dickey-Fuller Test of non-stationarity
    ADF.test=adf.test(na.omit(X10))
    #Kwiatkowski-Phillips-Schmidt-Shin (KPSS) for level or trend stationarity
    KPSS.test=kpss.test(na.omit(X10),null="Trend")
    # Durbin-Watson test for two-sided autoccorrelation
    DW.test=dwtest(reg.Obj,alternative = "two.sided")
  }else if(t.X=="Lag"){
    T.post = length(ids)
    
    idz = c(ids[-T.post])
    ids = c(ids[-1])
    reg.Obj=lm(X10[ids] ~ X10[idz], x=T,y=T)
    #diagnostics:
    # Dickey-Fuller Test of non-stationarity
    ADF.test=adf.test(na.omit(reg.Obj$residuals))
    #Kwiatkowski-Phillips-Schmidt-Shin (KPSS) for level or trend stationarity
    KPSS.test=kpss.test(na.omit(reg.Obj$residuals),null="Trend")
    # Durbin-Watson test for two-sided autoccorrelation
    DW.test=dwtest(reg.Obj,alternative = "two.sided")
  }else if(t.X=="Trend"){
    n = length(ids)
    trnd = var.time/n #scaling time trend by n
    reg.Obj=lm(X10[ids] ~ trnd[ids], x=T,y=T)
    #diagnostics:
    # Dickey-Fuller Test of non-stationarity
    ADF.test=adf.test(na.omit(X10[ids]))
    #Kwiatkowski-Phillips-Schmidt-Shin (KPSS) for level or trend stationarity
    KPSS.test=kpss.test(na.omit(X10[ids]),null="Trend")
    # Durbin-Watson test for two-sided autoccorrelation
    DW.test=dwtest(reg.Obj,alternative = "two.sided")
  }
  
  est.ATT=reg.Obj$coefficients[1] 
  if(se.type=="NW"){
    se.ATT=sqrt(c(vcovHAC(reg.Obj)[1,1]))
  }else if(se.type=="HC"){
    se.ATT=sqrt(c(vcovHC(reg.Obj)[1,1]))
  }
  t.stat=est.ATT/se.ATT
  pval.ATT = 2*pnorm(-abs(t.stat))
  
  list(est.ATT=est.ATT, se.ATT=se.ATT, t.stat=t.stat,
       pval.ATT=pval.ATT, ADF.test=ADF.test, KPSS.test=KPSS.test,
       DW.test=DW.test,reg.Obj=reg.Obj)
  
}
#=======================================================================================>


#=======================================================================================>
# Purpose: Compute a simple ATT from two series (a treated and an untreated one)
#           using Synthetic Control (SC) with an intercept and without convex weighting 
#           as illustrated in Koumou & Tsyawo 2022.
#           The SC simplifies in this case to using the pre-treatment linear projection of
#           the treated outcome onto the untreated to impute untreated potentential outcomes
#           of the treated in the post-treatment period.
#           

#Arguments: 
#           Y1 - outcome series of the treated group
#           Y0 - outcome series of the untreated group
#           var.time - a vector of time periods
#           time.treat - time of treatment; should be an element in var.time;
#                        it can also be a vector of contiguous time periods -
#                         observations corresponding to time.treat are not used
#                         in computations
#           Diff - logical (F/T) for differencing the summands of ATT (see paper) in case
#                 it has a unit-root; defaults to F (false)
#           se.type - type of standard error; defaults to the Newey-West procedure
#           transf - a transformation (function) applied to Y1 and Y0; defaults to NULL

#Value: A list of the following
#           list(est.ATT=reg.Obj$coefficients,se.ATT=se.ATT,t.stat=est.ATT/se.ATT,
#pval.ATT=pval.ATT,ADF.test,KPSS.test,X10=X10)
#           est.ATT - estimate of ATT
#           se.ATT - standard error
#           t.stat - t-statistic
#           pval.ATT - p-value of the t-stat
#           ADF.test - ADF test object for test of independent sampling of the summands of ATT
#           KPSS.test - KPSS test object: null hypothesis is unit root of the summands of ATT
#           X10 - summands of ATT; they sum up to est.ATT
#           

SC2.fun<- function(Y1,Y0,var.time,time.treat,Diff=F,se.type="HC",transf=NULL){
  if(!is.null(transf)){Y1=transf(Y1); Y0=transf(Y0)}
  id.post = which(var.time>max(time.treat))
  id.pre = which(var.time<min(time.treat))
  
  T.post = length(id.post) #number of post-treatment periods
  T.pre = length(id.pre) #number of pre-treatment periods
  
  if(!Diff){
    Y11=Y1[id.post]; Y01=Y0[id.post]
    Y10=Y1[id.pre];  Y00=Y0[id.pre]
  }else{
    Y11=diff(Y1[id.post]); Y01=diff(Y0[id.post])
    Y10=diff(Y1[id.pre]);  Y00=diff(Y0[id.pre])
      }
  
  #obtain the SC weights (intercept  and non-convex weights)
  reg.Obj=lm(Y10~Y00, x=T,y=T)
  
  #compute ATT
  X10=Y11-cbind(1,Y01)%*%reg.Obj$coefficients
  est.ATT = c(mean(X10))
  
  #covariance matrix of the SC weights
  if(se.type=="NW"){
    VC.pre=vcovHAC(reg.Obj)
    #components from the influence functions for computing the covariance matrix
    Var.1<- var((Y11-mean(Y11)) - c(cbind(1,Y01-mean(Y01))%*%reg.Obj$coefficients))
    Var.2<- (T.post/T.pre)*t(c(1,mean(Y01)))%*%(T.pre*VC.pre)%*%c(1,mean(Y01))/T.pre
    se.ATT = c(sqrt(Var.1+Var.2))
  }else if(se.type=="HC"){
    VC.pre=vcovHC(reg.Obj)
    #components from the influence functions for computing the covariance matrix
    Var.1<- var((Y11-mean(Y11)) - c(cbind(1,Y01-mean(Y01))%*%reg.Obj$coefficients))
    Var.2<- (T.post/T.pre)*t(c(1,mean(Y01)))%*%(T.pre*VC.pre)%*%c(1,mean(Y01))/T.pre
    se.ATT = c(sqrt(Var.1+Var.2))
  }else if(se.type=="boot"){
    #implement here...
  }

  pval.ATT = 2*pnorm(-abs(est.ATT/se.ATT))
  #diagnostics:
  # Dickey-Fuller Test of non-stationarity
  ADF.test=adf.test(na.omit(X10))
  
  #Kwiatkowski-Phillips-Schmidt-Shin (KPSS) for level or trend stationarity
  KPSS.test=kpss.test(na.omit(X10),null="Trend")
  
  list(est.ATT=est.ATT,se.ATT=se.ATT,t.stat=est.ATT/se.ATT,
       pval.ATT=pval.ATT,ADF.test,KPSS.test,X10=X10/T.post,reg.Obj=reg.Obj)
}
#=======================================================================================>



#=======================================================================================>
# Purpose: Compute a simple ATT from a series (a treated) using the Before-After estimator
#             This estimator uses the pre-treatment observations of the treated unit as a
#             a control for the post-treatment period.
#           

#Arguments: 
#           Y1 - outcome series of the treated group
#           var.time - a vector of time periods
#           time.treat - time of treatment; should be an element in var.time;
#                        it can also be a vector of contiguous time periods -
#                         observations corresponding to time.treat are not used
#                         in computations
#           Diff - logical (F/T) for differencing the summands of ATT (see paper) in case
#                 it has a unit-root; defaults to F (false)
#           se.type - type of standard error; defaults to the Newey-West procedure
#           transf - a transformation (function) applied to Y1 and Y0; defaults to NULL

#Value: A list of the following
#           list(est.ATT=reg.Obj$coefficients,se.ATT=se.ATT,t.stat=est.ATT/se.ATT,
#pval.ATT=pval.ATT,ADF.test,KPSS.test,X10=X10)
#           est.ATT - estimate of ATT
#           se.ATT - standard error
#           t.stat - t-statistic
#           pval.ATT - p-value of the t-stat
#           ADF.test - ADF test object for test of independent sampling of the summands of ATT
#           KPSS.test - KPSS test object: null hypothesis is unit root of the summands of ATT
#           X10 - summands of ATT; they sum up to est.ATT
#           

BA.fun<- function(Y1,var.time,time.treat,t.X="Level",se.type="NW",transf=NULL){
  
  if(!is.null(transf)){Y1=transf(Y1)}
  
  id.post = which(var.time>max(time.treat))
  id.pre = which(var.time<min(time.treat))
  ids = c(id.post,id.pre)
  
  if(t.X %in% c("Level","MA")){
    t.dum<- var.time>max(time.treat)*1
    reg.Obj=lm(Y1[ids] ~ t.dum[ids], x=T,y=T)
    #diagnostics:
    # Dickey-Fuller Test of non-stationarity
    ADF.test=adf.test(na.omit(Y1[ids]))
    #Kwiatkowski-Phillips-Schmidt-Shin (KPSS) for level or trend stationarity
    KPSS.test=kpss.test(na.omit(Y1[ids]),null="Trend")
    # Durbin-Watson test for two-sided autoccorrelation
    DW.test=dwtest(reg.Obj,alternative = "two.sided")
  }else if(t.X=="Diff"){
    Y1.post<- diff(Y1[id.post])
    Y1.pre<- diff(Y1[id.pre])
    Y1 = c(Y1.post,Y1.pre)
    t.dum<- rep(0,length(Y1))
    t.dum[1:length(Y1.post)]<- 1
    reg.Obj=lm(Y1 ~ t.dum, x=T,y=T)
    ids = 1:length(t.dum)
    #diagnostics:
    # Dickey-Fuller Test of non-stationarity
    ADF.test=adf.test(na.omit(Y1[ids]))
    #Kwiatkowski-Phillips-Schmidt-Shin (KPSS) for level or trend stationarity
    KPSS.test=kpss.test(na.omit(Y1[ids]),null="Trend")
    # Durbin-Watson test for two-sided autoccorrelation
    DW.test=dwtest(reg.Obj,alternative = "two.sided")
  }else if(t.X=="Lag"){
    T.post = length(id.post); T.pre = length(id.pre)
    t.dum<- var.time>max(time.treat)*1
    idz = c(id.post[-T.post],id.pre[-T.pre])
    ids = c(id.post[-1],id.pre[-1])
    reg.Obj=lm(Y1[ids] ~ t.dum[ids] + Y1[idz], x=T,y=T)
    #diagnostics:
    # Dickey-Fuller Test of non-stationarity
    ADF.test=adf.test(na.omit(reg.Obj$residuals))
    #Kwiatkowski-Phillips-Schmidt-Shin (KPSS) for level or trend stationarity
    KPSS.test=kpss.test(na.omit(reg.Obj$residuals),null="Trend")
    # Durbin-Watson test for two-sided autoccorrelation
    DW.test=dwtest(reg.Obj,alternative = "two.sided")
  }else if(t.X=="Trend"){
    t.dum<- var.time>max(time.treat)*1
    
    n = length(ids)
    trnd = var.time
    trnd[var.time<0] = var.time[var.time<0] + abs(min(var.time)) + 1
    trnd[var.time>0] = var.time[var.time>0] + abs(min(var.time))
    trnd = trnd/n #scaling time trend by n
    
    reg.Obj=lm(Y1[ids] ~ t.dum[ids] + trnd[ids], x=T,y=T)
    #diagnostics:
    # Dickey-Fuller Test of non-stationarity
    ADF.test=adf.test(na.omit(Y1[ids]))
    #Kwiatkowski-Phillips-Schmidt-Shin (KPSS) for level or trend stationarity
    KPSS.test=kpss.test(na.omit(Y1[ids]),null="Trend")
    # Durbin-Watson test for two-sided autoccorrelation
    DW.test=dwtest(reg.Obj,alternative = "two.sided")
  }
  
  est.ATT=reg.Obj$coefficients[2] 
  if(se.type=="NW"){
    se.ATT=sqrt(c(vcovHAC(reg.Obj)[2,2]))
  }else if(se.type=="HC"){
    se.ATT=sqrt(c(vcovHC(reg.Obj)[2,2]))
  }
  t.stat=est.ATT/se.ATT
  pval.ATT = 2*pnorm(-abs(t.stat))
  
  list(est.ATT=est.ATT, se.ATT=se.ATT, t.stat=t.stat,
       pval.ATT=pval.ATT, ADF.test=ADF.test, KPSS.test=KPSS.test,
       DW.test=DW.test,reg.Obj=reg.Obj)
  
}
#=======================================================================================>


#===============================================================================
# Robust vcov for gls with correlation structure (HC0-style under GLS)
vcovHC_gls <- function(fit) {
  stopifnot(inherits(fit, "gls"))
  X <- model.matrix(formula(fit), data = fit$data)
  e <- resid(fit, type = "response")
  
  # Correlation matrix from nlme (single group assumed)
  R <- corMatrix(fit$modelStruct$corStruct)
  if (is.list(R)) R <- R[[1L]]
  # If you used variance weights in gls(..., weights=...), you'd need to fold them in here.
  
  sig2 <- fit$sigma^2
  V <- sig2 * R
  
  # Solve V %*% z = y without explicitly inverting
  cholV <- chol(V)
  V_inv_y <- function(y) backsolve(cholV, forwardsolve(t(cholV), y))
  
  # Bread: (X' V^{-1} X)^{-1}
  XVinv <- apply(X, 2, V_inv_y)         # columns: V^{-1} x_j
  H <- crossprod(X, XVinv)              # X' V^{-1} X
  bread <- solve(H)
  
  # Meat: sum_t (x_t x_t' * (V^{-1} e)_t^2)
  u_star <- V_inv_y(e)                  # V^{-1} e (vector length T)
  ZX <- X * as.numeric(u_star)          # rowwise multiply by u_star
  meat <- crossprod(ZX)                 # X' diag(u_star^2) X
  
  # Sandwich
  vcov_rob <- bread %*% meat %*% bread
  vcov_rob
}
#-------------------------------------------------------------------------------
# Estimation wrapper for your model X_t = beta0 + ATT * post_t + U_t, U_t ~ MA(q)
estimate_maq_robust <- function(X, post, q = 0, method = c("ML","REML")) {
  method <- match.arg(method)
  stopifnot(length(X) == length(post))
  dat <- data.frame(X = as.numeric(X), post = as.numeric(post))
  
  fit <- gls(X ~ post, data = dat, method = method,
             correlation = corARMA(p = 0, q = q), na.action = na.omit)
  
  Vrob <- vcovHC_gls(fit)
  se   <- sqrt(diag(Vrob))
  ct   <- coeftest(fit, vcov. = Vrob)   # robust tests (lmtest)
  
  list(fit = fit, coef = coef(fit), vcov_robust = Vrob, se_robust = se,
       coeftest_robust = ct)
}
#===============================================================================


#===============================================================================
MC_Sim_Fun<- function(l,datlist,ATT,t.X="Level",se.type="NW",weight=NULL,q=1){
  donnees=datlist[[l]] #extract data
  
  #Compute proposed ATT
  DiD.Obj = ATT.fun(Y1=donnees$Y1,Y0=donnees$Y0,var.time = donnees$var.time,
          time.treat=0,t.X=t.X,se.type=se.type,transf=NULL,weight=weight,q=q)
  bias.ATT = DiD.Obj$est.ATT-mean(ATT) #bias in ATT
  Rej.ATT = 1*(DiD.Obj$pval.ATT<= c(0.01,0.05,0.1)) #for size control
  res.ATT=c(bias.ATT,Rej.ATT); names(res.ATT)<- c("Bias.DiD","DiD.Rej.01","DiD.Rej.05","DiD.Rej.10")
  
  #Compute Synthetic Control convex weights without intercept
  SC.Obj = SC.fun(Y1=donnees$Y1,Y0=donnees$Y0,var.time = donnees$var.time,
          time.treat = 0, t.X=t.X,se.type=se.type,transf=NULL)
  bias.SC = SC.Obj$est.ATT-mean(ATT) #bias in ATT
  Rej.SC = 1*(SC.Obj$pval.ATT<= c(0.01,0.05,0.1)) #for size control
  res.SC=c(bias.SC,Rej.SC); names(res.SC)<- c("Bias.SC","SC.Rej.01","SC.Rej.05","SC.Rej.10")
  
  #Before-After (BA) estimator
  BA.Obj = BA.fun(Y1=donnees$Y1,var.time = donnees$var.time,
         time.treat=0,t.X=t.X,se.type=se.type,transf=NULL)
  
  bias.BA = BA.Obj$est.ATT-mean(ATT) #bias in ATT
  Rej.BA = 1*(BA.Obj$pval.ATT<= c(0.01,0.05,0.1)) #for size control
  res.BA=c(bias.BA,Rej.BA); names(res.BA)<- c("Bias.BA","BA.Rej.01","BA.Rej.05","BA.Rej.10")
  
  #Concatenate results
  res=c(res.ATT,res.SC,res.BA)
  #return results
  res
}
#===============================================================================


#===============================================================================
MC_Sim_idt<- function(l,datlist,ATT,t.X="Level",se.type="NW",q=0){
  donnees=datlist[[l]] #extract data
  
  #Compute power based on identification tests
  DiD.Obj = ATT.fun(Y1=donnees$Y1,Y0=donnees$Y0,var.time = donnees$var.time,
                    time.treat=0,t.X=t.X,se.type=se.type,transf=NULL,q=q)
  id.DiD = 1*(DiD.Obj$pval.ATT<= c(0.01,0.05,0.1)) #for size control
  
  #Compute Synthetic Control convex weights without intercept
  SC.Obj = SC.fun(Y1=donnees$Y1,Y0=donnees$Y0,var.time = donnees$var.time,
                  time.treat = 0, t.X=t.X,se.type=se.type,transf=NULL)
  id.SC = 1*(SC.Obj$pval.ATT<= c(0.01,0.05,0.1)) #for size control
  
  #Before-After (BA) estimator
  BA.Obj = BA.fun(Y1=donnees$Y1,var.time = donnees$var.time,
                  time.treat=0,t.X=t.X,se.type=se.type,transf=NULL)
  id.BA = 1*(BA.Obj$pval.ATT<= c(0.01,0.05,0.1)) #for size control
  
  #Compute power based on pre- tests
  id.pre = which(donnees$var.time<0)
  pt0<- donnees$var.time[ceiling(0.5*length(id.pre))]
  
  pt.DiD.Obj = ATT.fun(Y1=donnees$Y1[id.pre],Y0=donnees$Y0[id.pre],
                       var.time = donnees$var.time[id.pre],
                    time.treat=pt0,t.X=t.X,se.type=se.type,transf=NULL,q=q)
  pt.DiD = 1*(pt.DiD.Obj$pval.ATT<= c(0.01,0.05,0.1)) #for size control
  
  #Compute Synthetic Control convex weights without intercept
  pt.SC.Obj = SC.fun(Y1=donnees$Y1[id.pre],Y0=donnees$Y0[id.pre],
                     var.time = donnees$var.time[id.pre],
                  time.treat = pt0, t.X=t.X,se.type=se.type,transf=NULL)
  pt.SC = 1*(pt.SC.Obj$pval.ATT<= c(0.01,0.05,0.1)) #for size control
  
  #Before-After (BA) estimator
  pt.BA.Obj = BA.fun(Y1=donnees$Y1[id.pre],var.time = donnees$var.time[id.pre],
                  time.treat=pt0,t.X=t.X,se.type=se.type,transf=NULL)
  pt.BA = 1*(pt.BA.Obj$pval.ATT<= c(0.01,0.05,0.1)) #for size control
  
  #Concatenate results
  res=c(id.DiD,id.SC,id.BA,pt.DiD,pt.SC,pt.BA)
  #return results
  res
}
#===============================================================================


#===============================================================================
#function to compute Root Mean Squared Error
RMSE.f<- function(X) sqrt(mean(c(X)^2)) 
#===============================================================================


#===============================================================================
summary.ATT<- function(MC_Res){
  c1=c(1,5,9)
  MB = apply(MC_Res[c1,],1,mean); names(MB)<- c("DiD.MB","SC.MB","BA.MB")
  MAD = apply(abs(MC_Res[c1,]),1,median); names(MAD)<- c("DiD.MAD","SC.MAD","BA.MAD")
  RMSE = apply(MC_Res[c1,],1,RMSE.f); names(RMSE)<- c("DiD.RMSE","SC.RMSE","BA.RMSE")
  res=c(MB,MAD,RMSE,apply(MC_Res[-c1,],1,mean))
  #arrange results for reporting in LaTeX
  round(res,3)[c(1:9,10+(0:2)*3,11+(0:2)*3,12+(0:2)*3)]
}
#=======================================================================================>


#=======================================================================================>
extract.res<- function(MC_Res.list,out.file,n.vec){
  res.all=NULL
  for (l in 1:length(MC_Res.list)) {
    res.all = rbind(res.all,summary.ATT(MC_Res.list[[l]]))
  }
  sink(out.file)
  cat("\n")
  cat("MB, MAD, RMSE: \n")
  cat("\n")
  apply(cbind(rep(" ",length(n.vec)),n.vec,res.all[,1:9]),1,print.fn)
  cat("\n")
  cat("Rejection Rates: \n")
  cat("\n")
  apply(cbind(rep(" ",length(n.vec)),n.vec,res.all[,10:18]),1,print.fn)
  sink()
  cbind(n.vec,res.all)
}
#=======================================================================================>


#=======================================================================================>
extract.pow<- function(MC_Res.list,g.vec){
  res.all=NULL
  for (l in 1:length(MC_Res.list)) {
    res.all = rbind(res.all,summary.ATT(MC_Res.list[[l]]))
  }
  res<- data.frame(g.vec,res.all[,10:18])
  names(res)<- c("gamma","DiD_01","SC_01","BA_01","DiD_05","SC_05","BA_05",
                 "DiD_10","SC_10","BA_10")
  res
}
#=======================================================================================>


#=======================================================================================>
MC_DGP<- function(out.file,n.vec,R,ATT,error.type,alph,phi,eta,
                  t.X,se.type,nu.suff=F,lam.vec=NULL,weight=NULL,q=1,cl){
  #------------------------------>
  
  #------------------------------>
  # Simulate data and compute results
  MC_Res.list = list()
  for (l in 1:length(n.vec)) {
    #--------------->
    # generate data list
    if(is.null(lam.vec)){
      nT=nTau=n.vec[l]
    }else{
      n=2*n.vec[l]; nT = ceiling(lam.vec[l]*n); nTau = n-nT
    }
    
    donnees.liste = lapply(1:R,dat.gen,nT=nT,nTau=nTau,
                           ATT=ATT,error.type=error.type,
                         alph=alph,phi=phi,eta=eta,nu.suff=nu.suff)
    
    #test
    # MC_Sim_Fun(l=1,datlist=donnees.liste,ATT=ATT,t.X=t.X,se.type=se.type)
    # MC_Sim_Fun(l=1,datlist=donnees.liste,ATT,t.X=t.X,se.type="NW",weight=T,q=q)
    #--------------->
    
    MC_Res.list[[l]] = pbsapply(1:R, FUN=MC_Sim_Fun,cl=cl,datlist=donnees.liste,
                                ATT=ATT,t.X=t.X,se.type=se.type,weight=weight,q=q)
  }#end for (l in 1:length(n.vec))
  #------------------------------>
  
  #------------------------------>
  
  res.sim<- extract.res(MC_Res.list=MC_Res.list,out.file=out.file,n.vec=n.vec)
  res.sim
}
#=======================================================================================>


#=======================================================================================>
#heterogeneity in treatment effects
MC_DGPb<- function(out.file,n.vec,R,error.type,alph,phi,eta,
                  t.X,se.type,nu.suff=F,q=0,cl){
  #------------------------------>
  
  #------------------------------>
  # Simulate data and compute results
  MC_Res.list = list()
  for (l in 1:length(n.vec)) {
    #--------------->
    # generate data list
    ATT = sin(1:n.vec[l])/pi
    
    donnees.liste = lapply(1:R,dat.gen,nT=n.vec[l],nTau=n.vec[l],ATT=ATT,error.type=error.type,
                           alph=alph,phi=phi,eta=eta,nu.suff=nu.suff)
    
    #test
    # MC_Sim_Fun(l=1,datlist=donnees.liste,ATT=ATT,t.X=t.X,se.type=se.type)
    #--------------->
    
    MC_Res.list[[l]] = pbsapply(1:R, FUN=MC_Sim_Fun,cl=cl,datlist=donnees.liste,
                                ATT=ATT,t.X=t.X,se.type=se.type,q=q)
  }#end for (l in 1:length(n.vec))
  #------------------------------>
  
  #------------------------------>
  
  res.sim<- extract.res(MC_Res.list=MC_Res.list,out.file=out.file,n.vec=n.vec)
  res.sim
}
#=======================================================================================>


#=======================================================================================>
MC_DGP.pow<- function(out.file,n,g.vec,R,ATT,error.type,alph,phi,eta,
                  t.X,se.type,nu.suff=F,q=0,cl){
  #------------------------------>
  
  #------------------------------>
  # Simulate data and compute results
  MC_Res.list = list()
  for (l in 1:length(g.vec)) {
    #--------------->
    # generate data list
    
    donnees.liste = lapply(1:R,dat.gen,nT=n,nTau=n,ATT=(ATT+g.vec[l]),error.type=error.type,
                           alph=alph,phi=phi,eta=eta,nu.suff=nu.suff)
    
    #test
    # MC_Sim_Fun(l=1,datlist=donnees.liste,ATT=ATT,t.X=t.X,se.type=se.type)
    #--------------->
    
    MC_Res.list[[l]] = pbsapply(1:R, FUN=MC_Sim_Fun,cl=cl,datlist=donnees.liste,
                                ATT=ATT,t.X=t.X,se.type=se.type,q=q)
  }#end for (l in 1:length(g.vec))
  #------------------------------>
  
  #------------------------------>
  
  res.sim<- extract.pow(MC_Res.list=MC_Res.list,g.vec=g.vec)

  #------------------------------>
  
  #------------------------------>
  Label.tests = c("DiD_10"="DiD","SC_10"="SC","BA_10"="BA")
  x.lab = "ATT"
  y.lab = " "
  
  col.val_10 = c("DiD_10"="black","SC_10"="red","BA_10"="blue")
  line.val_10 = c("DiD_10"="solid","SC_10"=22,"BA_10"=42)
  shape.val_10 = c("DiD_10"=1,"SC_10"=2,"BA_10"=3)
  
  col.val_05 = c("DiD_05"="black","SC_05"="red","BA_05"="blue")
  line.val_05 = c("DiD_05"="solid","SC_05"=22,"BA_05"=42)
  shape.val_05 = c("DiD_05"=1,"SC_05"=2,"BA_05"=3)
  
  
  col.val_01 = c("DiD_01"="black","SC_01"="red","BA_01"="blue")
  line.val_01 = c("DiD_01"="solid","SC_01"=22,"BA_01"=42)
  shape.val_01 = c("DiD_01"=1,"SC_01"=2,"BA_01"=3)
  
  col.val=list();col.val[[1]]=col.val_10;col.val[[2]]=col.val_05;col.val[[3]]=col.val_01
  line.val=list();line.val[[1]]=line.val_10;line.val[[2]]=line.val_05;line.val[[3]]=line.val_01
  shape.val=list();shape.val[[1]]=shape.val_10;shape.val[[2]]=shape.val_05;shape.val[[3]]=shape.val_01
  
  plot.pow(filename=out.file,pow.mat=res.sim,
           Label.tests,x.lab,y.lab,col.val,line.val,shape.val)
  return(res.sim)
}
#=======================================================================================>


#=======================================================================================>
MC_idtest.pow<- function(test.DGP,out.file,n,h.vec,R,ATT=0.0,error.type,alph,phi,
                      t.X,se.type,q=0,cl){
  #------------------------------>
  
  #------------------------------>
  # Simulate data and compute results
  MC_Res.list = list()
  for (l in 1:length(h.vec)) {
    #--------------->
    # generate data list
    #dat.gen_test(seed=0,nT,nTau,ATT=0.0,error.type="MDS",alph,phi=NULL,h,test.DGP)
    donnees.liste = lapply(1:R,dat.gen_test,nT=n,nTau=n,ATT=ATT,error.type=error.type,
                           alph=alph,phi=phi,h=h.vec[l],test.DGP=test.DGP)
    
    #test
    # MC_Sim_Fun(l=1,datlist=donnees.liste,ATT=ATT,t.X=t.X,se.type=se.type)
    #--------------->
    
    MC_Res.list[[l]] = pbsapply(1:R, FUN=MC_Sim_idt,cl=cl,datlist=donnees.liste,
                                ATT=ATT,t.X=t.X,se.type=se.type,q=q)
  }#end for (l in 1:length(h.vec))
  #------------------------------>
  
  
  #------------------------------>
  
  res.all=NULL
  for (l in 1:length(MC_Res.list)) {
    res.all = rbind(res.all,apply(MC_Res.list[[l]],1,mean))
  }
  res.sim<- data.frame(h.vec,res.all)
  names(res.sim)<- c("h.vec","id.DiD_01","id.DiD_05","id.DiD_10",
                     "id.SC_01","id.SC_05","id.SC_10",
                     "id.BA_01","id.BA_05","id.BA_10",
                     "pt.DiD_01","pt.DiD_05","pt.DiD_10",
                     "pt.SC_01","pt.SC_05","pt.SC_10",
                     "pt.BA_01","pt.BA_05","pt.BA_10")
  n.test = (ncol(res.sim)-1)/3
  id.01 = (0:(n.test-1))*3 +2
  pow.mat=res.sim[,c(1,id.01,id.01+1,id.01+2)] #rearrange columns for plotting
  #------------------------------>
  #c("Chi2_05"="black","Esc6_05"="red","Gauss_05"="blue","SZ_05"="darkorchid","t_05"="goldenrod4"),
  #------------------------------>
  Label.tests = c("id.DiD_10"="id.DiD","id.SC_10"="id.SC","id.BA_10"="id.BA",
                  "pt.DiD_10"="pt.DiD","pt.SC_10"="pt.SC","pt.BA_10"="pt.BA")
  x.lab = "h"
  y.lab = " "
  
  col.val_10 = c("id.DiD_10"="black","id.SC_10"="red","id.BA_10"="blue",
                 "pt.DiD_10"="darkorchid","pt.SC_10"="goldenrod4","pt.BA_10"="darkgreen")
  line.val_10 = c("id.DiD_10"="solid","id.SC_10"=22,"id.BA_10"=42,
                  "pt.DiD_10"=11,"pt.SC_10"=15,"pt.BA_10"=19)
  shape.val_10 = c("id.DiD_10"=1,"id.SC_10"=2,"id.BA_10"=3,
                   "pt.DiD_10"=4,"pt.SC_10"=5,"pt.BA_10"=6)
  
  col.val_05 = c("id.DiD_05"="black","id.SC_05"="red","id.BA_05"="blue",
                 "pt.DiD_05"="darkorchid","pt.SC_05"="goldenrod4","pt.BA_05"="darkgreen")
  line.val_05 = c("id.DiD_05"="solid","id.SC_05"=22,"id.BA_05"=42,
                  "pt.DiD_05"=11,"pt.SC_05"=15,"pt.BA_05"=19)
  shape.val_05 = c("id.DiD_05"=1,"id.SC_05"=2,"id.BA_05"=3,
                   "pt.DiD_05"=4,"pt.SC_05"=5,"pt.BA_05"=6)
  
  
  col.val_01 = c("id.DiD_01"="black","id.SC_01"="red","id.BA_01"="blue",
                 "pt.DiD_01"="darkorchid","pt.SC_01"="goldenrod4","pt.BA_01"="darkgreen")
  line.val_01 = c("id.DiD_01"="solid","id.SC_01"=22,"id.BA_01"=42,
                  "pt.DiD_01"=11,"pt.SC_01"=15,"pt.BA_01"=19)
  shape.val_01 = c("id.DiD_01"=1,"id.SC_01"=2,"id.BA_01"=3,
                   "pt.DiD_01"=4,"pt.SC_01"=5,"pt.BA_01"=6)
  
  
  # 
  # #####################
  # 
  # col.val_05 = c("DiD_05"="black","SC_05"="red","BA_05"="blue")
  # line.val_05 = c("DiD_05"="solid","SC_05"=22,"BA_05"=42)
  # shape.val_05 = c("DiD_05"=1,"SC_05"=2,"BA_05"=3)
  # 
  # 
  # col.val_01 = c("DiD_01"="black","SC_01"="red","BA_01"="blue")
  # line.val_01 = c("DiD_01"="solid","SC_01"=22,"BA_01"=42)
  # shape.val_01 = c("DiD_01"=1,"SC_01"=2,"BA_01"=3)
  
  col.val=list();col.val[[1]]=col.val_10;col.val[[2]]=col.val_05;col.val[[3]]=col.val_01
  line.val=list();line.val[[1]]=line.val_10;line.val[[2]]=line.val_05;line.val[[3]]=line.val_01
  shape.val=list();shape.val[[1]]=shape.val_10;shape.val[[2]]=shape.val_05;shape.val[[3]]=shape.val_01
  
  plot.pow(filename=out.file,pow.mat=pow.mat,
           Label.tests,x.lab,y.lab,col.val,line.val,shape.val)
  return(pow.mat)
}
#=======================================================================================>


#===============================================================================
#Generic function for plotting power power curves
# Arguments:
# (1) pow.mat: an (n.g x 3*n.test +1) matrix, first column is gamma 

# Label.tests = c("Chi2_10"=latex2exp::TeX("$chi^2$"),"Gauss_10"="Gauss","SZ_10"="S&Z","Esc6_10"="Esc6")
# x.lab = latex2exp::TeX("$gamma$")
# y.lab = " "
# col.val = c("Chi2_10"="black","Esc6_10"="red","Gauss_10"="blue","SZ_10"="darkorchid")
# line.val = c("Chi2_10"="solid","Esc6_10"=22,"Gauss_10"=42,"SZ_10"=44)
# shape.val = c("Chi2_01"=1,"Esc6_01"=2,"Gauss_01"=3,"SZ_01"=4)

  
plot.pow<- function(filename=NULL,pow.mat,Label.tests,
                    x.lab,y.lab,col.val,line.val,shape.val){
   
  pow.mat<- as.data.frame(pow.mat)
  gamvec<- pow.mat[,1]
  
  #------------------------------------------------>
  group_10<- group_05<- group_01<- c()
  n.test = (ncol(pow.mat)-1)/3 #number of estimators/tests to compare
  n.g = nrow(pow.mat) #number of sample sizes (or gamma) considered
  id.01 = (1:n.test)+1 #recall first column of pow.mat is gamma
  id.05 = ((n.test+1):(2*n.test)) + 1
  id.10 = ((2*n.test+1):(3*n.test)) + 1
  
  for(l in 1:n.test){
    group_01<- c(group_01,rep(names(pow.mat)[-1][1:n.test][l],n.g))
    group_05<- c(group_05,rep(names(pow.mat)[-1][n.test+(1:n.test)][l],n.g))
    group_10<- c(group_10,rep(names(pow.mat)[-1][2*n.test+(1:n.test)][l],n.g))
  }
  #------------------------------------------------->
  df_10<-data.frame(gam = rep(pow.mat[,1],n.test), 
                    Pow = unlist(pow.mat[,id.10]),
                    group=group_10, group_col = group_10,group_line =group_10)
  #----------------->
  df_05<-data.frame(gam = rep(pow.mat[,1],n.test), 
                    Pow = unlist(pow.mat[,id.05]),
                    group=group_05, group_col = group_05,group_line =group_05)
  #----------------->
  df_01<-data.frame(gam = rep(pow.mat[,1],n.test), 
                    Pow = unlist(pow.mat[,id.01]),
                    group=group_01, group_col = group_01,group_line =group_01)
  #------------------------------------------------>
  ppt.Pow_10<- ggplot(data=df_10)+
    aes(x=gam,y=Pow,colour=group_10)+
    theme_gray()+
    xlab(x.lab)+
    ylab(y.lab)+
    scale_colour_manual(name="Labels", values=col.val[[1]],
                        labels=Label.tests)+
    scale_linetype_manual(name="Labels", values=line.val[[1]],
                          labels=Label.tests)+
    scale_shape_manual(name="Labels", values=shape.val[[1]],
                       labels=Label.tests)+
    theme(legend.title=element_blank())+
    theme(axis.text=element_text(size=40),axis.title=element_text(size=40,face="bold"))+
    theme(legend.text = element_text(colour="black", size=40))+
    theme(legend.position = c(0.75,0.4),legend.key.size = unit(2, 'cm'))+
    ylim(low=-0.1,high=1.1)+
    geom_line(aes(linetype = group_10),size=1.0)+
    geom_point(aes(shape=group_10),size=4)+
    geom_hline(yintercept = 0.1,colour = "brown",size=0.25)
  ppt.Pow_10
  if(!is.null(filename)){
    ggsave(paste(filename,"_10.png",sep = ""),width=30,height=30,unit="cm")  
  }
  #------------------------------------------------>
  ppt.Pow_05<- ggplot(data=df_05)+
    aes(x=gam,y=Pow,colour=group_05)+
    theme_gray()+
    xlab(x.lab)+
    ylab(y.lab)+
    scale_colour_manual(name="Labels", values=col.val[[2]],
                        labels=Label.tests)+
    scale_linetype_manual(name="Labels", values=line.val[[2]],
                          labels=Label.tests)+
    scale_shape_manual(name="Labels", values=shape.val[[2]],
                       labels=Label.tests)+
    theme(legend.title=element_blank())+
    theme(axis.text=element_text(size=40),axis.title=element_text(size=40,face="bold"))+
    theme(legend.text = element_text(colour="black", size=15))+
    theme(legend.position = "none")+
    ylim(low=-0.1,high=1.1)+
    geom_line(aes(linetype = group_05),size=1.0)+
    geom_point(aes(shape=group_05),size=4)+
    geom_hline(yintercept = 0.05,colour = "brown",size=0.25)
  ppt.Pow_05
  if(!is.null(filename)){
    ggsave(paste(filename,"_05.png",sep = ""),width=30,height=30,unit="cm")  
  }
  #------------------------------------------------>
  ppt.Pow_01<- ggplot(data=df_01)+
    aes(x=gam,y=Pow,colour=group_01)+
    theme_gray()+
    xlab(x.lab)+
    ylab(y.lab)+
    scale_colour_manual(name="Labels", values=col.val[[3]],
                        labels=Label.tests)+
    scale_linetype_manual(name="Labels", values=line.val[[3]],
                          labels=Label.tests)+
    scale_shape_manual(name="Labels", values=shape.val[[3]],
                       labels=Label.tests)+
    theme(legend.title=element_blank())+
    theme(axis.text=element_text(size=40),axis.title=element_text(size=40,face="bold"))+
    theme(legend.text = element_text(colour="black", size=15))+
    theme(legend.position = "none")+
    ylim(low=-0.1,high=1.1)+
    geom_line(aes(linetype = group_01),size=1.0)+
    geom_point(aes(shape=group_01),size=4)+
    geom_hline(yintercept = 0.01,colour = "brown",size=0.25)
  ppt.Pow_01
  if(!is.null(filename)){
    ggsave(paste(filename,"_01.png",sep = ""),width=30,height=30,unit="cm")  
  }
  #------------------------------------------------>
}
#===============================================================================



#lrs<- (lm.D9$x*lm.D9$y)%*%solve(crossprod(lm.D9$x))

#ATT.fun(Y1,Y0,var.time,time.treat,t.X="Level",se.type="NW",transf=NULL)

# identif.test<- function(Y1,Y0.a,Y0.b,var.time,time.treat,t.X="Level",
#                         se.type="NW",transf=NULL){
#   n = sum(var.time!=0)
#   #estimate ATTs and extract its summands
#   obj.a<- ATT.fun(Y1=Y1,Y0=Y0.a,var.time=var.time,time.treat=time.treat,t.X=t.X,
#                   se.type=se.type,transf=transf)
#   lrs.a<- (obj.a$reg.Obj$x*obj.a$reg.Obj$y)%*%solve(crossprod(obj.a$reg.Obj$x)/n)
#   obj.b<- ATT.fun(Y1=Y1,Y0=Y0.b,var.time=var.time,time.treat=time.treat,t.X=t.X,
#                   se.type=se.type,transf=transf)
#   lrs.b<- (obj.b$reg.Obj$x*obj.b$reg.Obj$y)%*%solve(crossprod(obj.b$reg.Obj$x)/n)
#   
#   #lrs.a_b<- lm( c(lrs.a[,2]-lrs.b[,2]) ~ 1 )
#   
#   #if(!is.null(transf)){Y1=transf(Y1); Y0=transf(Y0)}
#   
#   # id.post = which(var.time>max(time.treat))
#   # id.pre = which(var.time<min(time.treat))
#   # ids = c(id.post,id.pre)
#   
#   if(t.X=="Level"){
#     X10 = lrs.a[,2]-lrs.b[,2]
#     #t.dum<- var.time>max(time.treat)*1
#     reg.Obj=lm(X10 ~ 1)
#     #diagnostics:
#     # Dickey-Fuller Test of non-stationarity
#     ADF.test=adf.test(na.omit(X10))
#     #Kwiatkowski-Phillips-Schmidt-Shin (KPSS) for level or trend stationarity
#     KPSS.test=kpss.test(na.omit(X10),null="Trend")
#     # Durbin-Watson test for two-sided autoccorrelation
#     DW.test=dwtest(reg.Obj,alternative = "two.sided")
#   }else if(t.X=="Diff"){
#     X10<- diff(lrs.a[,2]-lrs.b[,2])
#     # t.dum<- rep(0,length(X10))
#     # t.dum[1:length(X10.post)]<- 1
#     reg.Obj=lm(X10 ~ 1)
#     #ids = 1:length(t.dum)
#     #diagnostics:
#     # Dickey-Fuller Test of non-stationarity
#     ADF.test=adf.test(na.omit(X10))
#     #Kwiatkowski-Phillips-Schmidt-Shin (KPSS) for level or trend stationarity
#     KPSS.test=kpss.test(na.omit(X10),null="Trend")
#     # Durbin-Watson test for two-sided autoccorrelation
#     DW.test=dwtest(reg.Obj,alternative = "two.sided")
#   }else if(t.X=="Lag"){
#     X10 = lrs.a[,2]-lrs.b[,2]
#     # T.post = length(id.post); T.pre = length(id.pre)
#     # t.dum<- var.time>max(time.treat)*1
#     # idz = c(id.post[-T.post],id.pre[-T.pre])
#     # ids = c(id.post[-1],id.pre[-1])
#     reg.Obj=lm(X10[-1] ~ X10[-length(X10)])
#     #diagnostics:
#     # Dickey-Fuller Test of non-stationarity
#     ADF.test=adf.test(na.omit(reg.Obj$residuals))
#     #Kwiatkowski-Phillips-Schmidt-Shin (KPSS) for level or trend stationarity
#     KPSS.test=kpss.test(na.omit(reg.Obj$residuals),null="Trend")
#     # Durbin-Watson test for two-sided autoccorrelation
#     DW.test=dwtest(reg.Obj,alternative = "two.sided")
#   }
#   
#   est.theta=reg.Obj$coefficients[1] 
#   if(se.type=="NW"){
#     mat.vcov = vcovHAC(reg.Obj)
#     se.theta=sqrt(c(mat.vcov[2,2]))
#   }else if(se.type=="HC"){
#     mat.vcov = vcovHC(reg.Obj)
#     se.theta=sqrt(c(mat.vcov[2,2]))
#   }
#   t.stat=est.theta/se.theta
#   pval.theta = 2*pnorm(-abs(t.stat))
#   
#   list(est.theta=est.theta, se.theta=se.theta, t.stat=t.stat,
#        pval.theta=pval.theta, ADF.test=ADF.test, KPSS.test=KPSS.test,
#        DW.test=DW.test,reg.Obj=reg.Obj,mat.vcov=mat.vcov)
#   
# }

#=======================================================================================>
# Empirical Application - results to return:
# MnB - mean norm bias, 
# MAD - scaled Median Absolute Regression
# RMSE - Root Mean Squared Error
# Rej. - 5% Empirical Size
# kbar - median k (number of non-zero parameters estimated)

res.fun<- function(LaTeX=FALSE,outfile="out.file.txt"){
  
  suffix.namen<- c("1990.1992","1990","1991","1992")
  res<- data.frame(matrix(" ",8,9))
  rownames(res)<- c("ATT","Ste.ATT","p-val","lag.Y","Ste.lag.Y","ADF","KPSS","DW")
  colnames(res)<- c(suffix.namen," ",suffix.namen)
  n.sn<- length(suffix.namen)
  
  for (j in 1:n.sn) {
    obj_log = get(paste("log_lag_",suffix.namen[j],sep = ""))
    obj_lev = get(paste("lag_",suffix.namen[j],sep = ""))
    
    res[1,j] = round(obj_log$est.ATT,3)
    res[1,(j+1+n.sn)] = round(obj_lev$est.ATT,3)
    
    res[2,j] = round(obj_log$se.ATT,3)
    res[2,(j+1+n.sn)] = round(obj_lev$se.ATT,3)
    
    res[3,j] = round(obj_log$pval.ATT,3)
    res[3,(j+1+n.sn)] = round(obj_lev$pval.ATT,3)
    
    res[4,j] = round(obj_log$reg.Obj$coefficients[3],3)
    res[4,(j+1+n.sn)] = round(obj_lev$reg.Obj$coefficients[3],3)
    
    res[5,j] = round(sqrt(obj_log$mat.vcov[3,3]),3)
    res[5,(j+1+n.sn)] = round(sqrt(obj_lev$mat.vcov[3,3]),3)
    
    res[6,j] = round(obj_log$ADF.test$p.value,3)
    res[6,(j+1+n.sn)] = round(obj_lev$ADF.test$p.value,3)
    
    res[7,j] = round(obj_log$KPSS.test$p.value,3)
    res[7,(j+1+n.sn)] = round(obj_lev$KPSS.test$p.value,3)
    
    res[8,j] = round(obj_log$DW.test$p.value,3)
    res[8,(j+1+n.sn)] = round(obj_lev$DW.test$p.value,3)
    
  }
  

  if(!LaTeX){
    cat("\n");print(res);cat("\n")
  }else{
    sink(outfile)
    cat("\n");apply(cbind(rownames(res),res),1,print.fn,nsmall=3);cat("\n")
    sink()
  }
  res
}
#=====================================================================================>

#=====================================================================================>
#the following function ensures printing to exactly nsmall decimal places
print.fn<-function(x,nsmall=3) cat(paste(format(x,nsmall=nsmall),collapse=" &"),paste("\\","\\",sep=""),"\n")
#=====================================================================================>


#=======================================================================================>
dat.gen<- function(seed=0,nT,nTau,ATT=0.0,error.type="MDS",alph,phi=NULL,eta=NULL,nu.suff=F){

  #------------------------------------>
  #create the time variable
  var.time = c(-(nTau:1),0,1:nT) #in ascending order from -nTau to nT
  id.post = which(var.time>0)
  n = nT+nTau+1 #a period for the period of treatment

  #------------------------------------>
  # set seed
  set.seed(seed)

  #------------------------------------>
  #compute eta.vec
  if(error.type=="MDS"){
    #generate errors of untreated potential outcome
    eps.0<- (rchisq(n=(n+1),df=1)-1)/sqrt(2)
    eps.1<- rt(n=(n+1),df=nT)/sqrt(nT/(nT-2))

    e.0<- eps.0[2:(n+1)]*eps.0[1:n] #an extra error for lagging
    e.1<- eps.1[2:(n+1)]*eps.1[1:n] #an extra error for lagging

    e.1<- (e.0 + e.1)/sqrt(2) #cross-sectional dependence
  }else if(error.type=="White.Noise"){
    eps.0<- (rchisq(n=(n+2),df=1)-1)/sqrt(2)
    eps.1<- rt(n=(n+2),df=nT)/sqrt(nT/(nT-2))

    e.0<- (eps.0[1:n] + eps.0[2:(n+1)]*eps.0[3:(n+2)])/sqrt(2) #an extra error for lagging
    e.1<- (eps.1[1:n] + eps.1[2:(n+1)]*eps.1[3:(n+2)])/sqrt(2) #an extra error for lagging

    e.1<- (e.0 + e.1)/sqrt(2) #cross-sectional dependence
  }else if(error.type=="MA"){ #with white noise

    eps.0<- (rchisq(n=(n+3),df=1)-1)/sqrt(2)
    eps.1<- rt(n=(n+3),df=nT)/sqrt(nT/(nT-2))

    eps.0<- (eps.0[1:(n+1)] + eps.0[2:(n+2)]*eps.0[3:(n+3)])/sqrt(2) #an extra error for lagging
    eps.1<- (eps.1[1:(n+1)] + eps.1[2:(n+2)]*eps.1[3:(n+3)])/sqrt(2) #an extra error for lagging


    b<- 0.25
    e.0<- eps.0[1:n] + b*eps.0[2:(n+1)]  #MA(1)
    e.1<- eps.1[1:n] + b*eps.1[2:(n+1)]  #MA(1)

    e.1<- (e.0 + e.1)/sqrt(2) #cross-sectional dependence
  }else if(error.type=="GARCH"){
    eps.0<- (rchisq(n=(n+1),df=1)-1)/sqrt(2)
    eps.1<- rt(n=(n+1),df=nT)/sqrt(nT/(nT-2))

    sig2.0=sig2.1=e.0=e.1=rep(0,(n+1))
    for (t in 2:(n+1)) {

      sig2.0[t] = 0.4 + 0.3*(e.0[t-1])^2 + 0.3*sig2.0[t-1]
      e.0[t] = sqrt(sig2.0[t])*eps.0[t]

      sig2.1[t] = 0.4 + 0.3*(e.1[t-1])^2 + 0.3*sig2.1[t-1]
      e.1[t] = sqrt(sig2.1[t])*eps.1[t]
    }#end for t
    e.1<- (e.0 + e.1)/sqrt(2) #cross-sectional dependence
    e.1=e.1[-1]; e.0=e.0[-1] #remove initial value
  }else if(error.type %in% c("AR","Unit.Root")){
    if(error.type=="AR"){b1=0.5}else if(error.type=="Unit.Root"){b1=1.0}

    eps.0<- (rchisq(n=(n+3),df=1)-1)/sqrt(2)
    eps.1<- rt(n=(n+3),df=nT)/sqrt(nT/(nT-2))

    eps.0<- (eps.0[1:(n+1)] + eps.0[2:(n+2)]*eps.0[3:(n+3)])/sqrt(2) #an extra error for lagging
    eps.1<- (eps.1[1:(n+1)] + eps.1[2:(n+2)]*eps.1[3:(n+3)])/sqrt(2) #an extra error for lagging

    Y0=Y1=y0.1=rep(0,(n+1))
    for (t in 2:(n+1)) { #t indexes zero as well so count to n+1
      Y0[t] = alph[1] + b1*Y0[t-1] + eps.0[t]
      y0.1[t] = alph[2] + b1*y0.1[t-1] + eps.0[t]/sqrt(2)
      #Y1[t] = (alph[2]-alph[1]) + ATT*(var.time[t-1]>0) + Y0[t] + b1*(Y1[t-1]-Y0[t-1]) + eps.1[t]
      #if((length(ATT)>1) & (var.time[t-1]>0)){ATTt = ATT[var.time[t-1]]}else{ATTt=ATT}
      
      if(length(ATT)>1){ #if heterogeneous treatment effects
        if(var.time[t-1]>0){
          ATTt = ATT[var.time[t-1]]*(var.time[t-1]>0) #effect post-treatment
        }else{
          ATTt = 0.0 #no effect pre-treatment
        }
      }else{
        if(var.time[t-1]>0){
          ATTt = ATT #effect post-treatment
        }else{
          ATTt = 0.0 #no effect pre-treatment
        }
      }
      
      
      Y1[t] = ATTt + y0.1[t] + b1*(Y1[t-1]-y0.1[t-1]) + eps.1[t]/sqrt(2)
    }#end for t
    Y0=Y0[-1]; Y1=Y1[-1] #remove initial value
  }
  
  # else{
  #   stop("error type not recognised. \n")
  # }

  if(!(error.type %in% c("AR","Unit.Root"))){
    #------------------------------------>
    #compute eta.vec
    if(is.null(eta)){
      nu.vec = 0.0
    }else{
      if(!nu.suff){
        nu.vec = rnorm(n=n,mean = 0.5*sign(var.time)*1/c(nTau:1,Inf,(1:nT))^eta,sd=1)
      }else{
        nu.vec = rnorm(n=n,mean = 0.5*1/c(nTau:1,Inf,(1:nT))^eta,sd=1)
      }
    }
    #------------------------------------>
    #compute phi
    if(is.null(phi)){
      vec.phi = 0.0
    }else{
      vec.phi = phi(var.time)
    }
    
    if(error.type=="Trend"){
      #generate errors MDS of untreated potential outcome
      eps.0<- (rchisq(n=(n+1),df=1)-1)/sqrt(2)
      eps.1<- rt(n=(n+1),df=nT)/sqrt(nT/(nT-2))
      
      e.0<- eps.0[2:(n+1)]*eps.0[1:n] #an extra error for lagging
      e.1<- eps.1[2:(n+1)]*eps.1[1:n] #an extra error for lagging
      
      e.1<- (e.0 + e.1)/sqrt(2) #cross-sectional dependence
      
      #generate deterministic trend
      nu.vec = var.time
      nu.vec[var.time<0] = var.time[var.time<0] + abs(min(var.time)) + 1
      nu.vec[var.time>0] = var.time[var.time>0] + abs(min(var.time))
    }

    #generate untreated potential outcomes with MDS errors
    y0.0 = alph[1] + vec.phi + e.0
    y0.1 = alph[2] + vec.phi + e.1 + nu.vec

    #Generate observed outcomes
    Y0 = y0.0 #the untreated potential outcome of the untreated group is observed
    Y1 = y0.1; Y1[id.post] = Y1[id.post] + ATT #no-anticipation assumption imposed before treatment
    }# if(!(error.type %in% c("AR","Unit.Root")))

  data.frame(Y1,Y0,var.time)
}
#=======================================================================================>


#=======================================================================================>
dat.gen_test<- function(seed=0,nT,nTau,ATT=0.0,error.type="MDS",alph,phi=NULL,h,test.DGP=1){
  
  #------------------------------------>
  #create the time variable
  var.time = c(-(nTau:1),0,1:nT) #in ascending order from -nTau to nT
  id.post = which(var.time>0)
  n = nT+nTau+1 #a period for the period of treatment
  
  #------------------------------------>
  # set seed
  set.seed(seed)
  
  #------------------------------------>
  #compute eta.vec
  if(error.type=="MDS"){
    #generate errors of untreated potential outcome
    eps.0<- (rchisq(n=(n+1),df=1)-1)/sqrt(2)
    eps.1<- rt(n=(n+1),df=nT)/sqrt(nT/(nT-2))
    
    e.0<- eps.0[2:(n+1)]*eps.0[1:n] #an extra error for lagging
    e.1<- eps.1[2:(n+1)]*eps.1[1:n] #an extra error for lagging
    
    e.1<- (e.0 + e.1)/sqrt(2) #cross-sectional dependence
  }else if(error.type=="White.Noise"){
    eps.0<- (rchisq(n=(n+2),df=1)-1)/sqrt(2)
    eps.1<- rt(n=(n+2),df=nT)/sqrt(nT/(nT-2))
    
    e.0<- (eps.0[1:n] + eps.0[2:(n+1)]*eps.0[3:(n+2)])/sqrt(2) #an extra error for lagging
    e.1<- (eps.1[1:n] + eps.1[2:(n+1)]*eps.1[3:(n+2)])/sqrt(2) #an extra error for lagging
    
    e.1<- (e.0 + e.1)/sqrt(2) #cross-sectional dependence
  }else if(error.type=="MA"){ #with white noise
    
    eps.0<- (rchisq(n=(n+3),df=1)-1)/sqrt(2)
    eps.1<- rt(n=(n+3),df=nT)/sqrt(nT/(nT-2))
    
    eps.0<- (eps.0[1:(n+1)] + eps.0[2:(n+2)]*eps.0[3:(n+3)])/sqrt(2) #an extra error for lagging
    eps.1<- (eps.1[1:(n+1)] + eps.1[2:(n+2)]*eps.1[3:(n+3)])/sqrt(2) #an extra error for lagging
    
    
    b<- 0.25
    e.0<- eps.0[1:n] + b*eps.0[2:(n+1)]  #MA(1)
    e.1<- eps.1[1:n] + b*eps.1[2:(n+1)]  #MA(1)
    
    e.1<- (e.0 + e.1)/sqrt(2) #cross-sectional dependence
  }else if(error.type=="GARCH"){
    eps.0<- (rchisq(n=(n+1),df=1)-1)/sqrt(2)
    eps.1<- rt(n=(n+1),df=nT)/sqrt(nT/(nT-2))
    
    sig2.0=sig2.1=e.0=e.1=rep(0,(n+1))
    for (t in 2:(n+1)) {
      
      sig2.0[t] = 0.4 + 0.3*(e.0[t-1])^2 + 0.3*sig2.0[t-1]
      e.0[t] = sqrt(sig2.0[t])*eps.0[t]
      
      sig2.1[t] = 0.4 + 0.3*(e.1[t-1])^2 + 0.3*sig2.1[t-1]
      e.1[t] = sqrt(sig2.1[t])*eps.1[t]
    }#end for t
    e.1<- (e.0 + e.1)/sqrt(2) #cross-sectional dependence
    e.1=e.1[-1]; e.0=e.0[-1] #remove initial value
  }else if(error.type %in% c("AR","Unit.Root")){
    if(error.type=="AR"){b1=0.5}else if(error.type=="Unit.Root"){b1=1.0}
    
    eps.0<- (rchisq(n=(n+3),df=1)-1)/sqrt(2)
    eps.1<- rt(n=(n+3),df=nT)/sqrt(nT/(nT-2))
    
    eps.0<- (eps.0[1:(n+1)] + eps.0[2:(n+2)]*eps.0[3:(n+3)])/sqrt(2) #an extra error for lagging
    eps.1<- (eps.1[1:(n+1)] + eps.1[2:(n+2)]*eps.1[3:(n+3)])/sqrt(2) #an extra error for lagging
    
    #eps.1<- (eps.0 + eps.1)/sqrt(2) #cross-sectional dependence
    
    Y0=Y1=y0.1=rep(0,(n+1))
    for (t in 2:(n+1)) {
      Y0[t] = alph[1] + b1*Y0[t-1] + eps.0[t]
      y0.1[t] = alph[2] + b1*y0.1[t-1] + eps.0[t]/sqrt(2)
      #Y1[t] = (alph[2]-alph[1]) + ATT*(var.time[t-1]>0) + Y0[t] + b1*(Y1[t-1]-Y0[t-1]) + eps.1[t]
      Y1[t] = ATT*(var.time[t-1]>0) + y0.1[t] + b1*(Y1[t-1]-y0.1[t-1]) + eps.1[t]/sqrt(2)
    }#end for t
    Y0=Y0[-1]; Y1=Y1[-1] #remove initial value
  }else{
    stop("error type not recognised. \n")
  }
  
  if(!(error.type %in% c("AR","Unit.Root"))){
    #------------------------------------>
    #compute eta.vec
      
    if(test.DGP==1){
        m.vec = 2.5*h*( abs(var.time) )^(-1/4)
        m.vec[is.na(m.vec) | is.infinite(m.vec)] = 0
        nu.vec = rnorm(n=n,mean = m.vec,sd=1)
        nu.vec[id.post]=0.0
      }else if(test.DGP==2){
        m.vec = 2.5*h*( abs(var.time) )^(-1/4)
        m.vec[is.na(m.vec) | is.infinite(m.vec)] = 0
        nu.vec = rnorm(n=n,mean = m.vec,sd=1)
        nu.vec[-id.post]=0.0
      }else if(test.DGP==3){
        #mean = 0.5*1/c(nTau:1,Inf,(1:nT))^eta
        #m.vec = 0.5*( abs( var.time-ceiling(h*nT) ) )^(-1/4)
        m.vec = 2.5*(1-h*(1-sign(var.time)))*( abs(var.time) )^(-1/4)
        m.vec[is.na(m.vec) | is.infinite(m.vec)] = 0
        nu.vec = rnorm(n=n,mean = m.vec,sd=1)
        #nu.vec[id.post]=0.0
      }
    # else if(test.DGP==4){
    #     m.vec = 0.5*sign(var.time)*abs(var.time)^(h)
    #     m.vec[is.na(m.vec) | is.infinite(m.vec)] = 0
    #     nu.vec = rnorm(n=n,mean = m.vec,sd=1)
    #   }
    #------------------------------------>
    #compute phi
    if(is.null(phi)){
      vec.phi = 0.0
    }else{
      vec.phi = phi(var.time)
    }
    
    #generate untreated potential outcomes with MDS errors
    y0.0 = alph[1] + vec.phi + e.0
    y0.1 = alph[2] + vec.phi + e.1 + nu.vec
    
    #Generate observed outcomes
    Y0 = y0.0 #the untreated potential outcome of the untreated group is observed
    Y1 = y0.1; Y1[id.post] = Y1[id.post] + ATT #no-anticipation assumption imposed before treatment
  }# if(!(error.type %in% c("AR","Unit.Root")))
  
  data.frame(Y1,Y0,var.time)
}
#=======================================================================================>
