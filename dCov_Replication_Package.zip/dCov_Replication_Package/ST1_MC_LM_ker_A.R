#=========================================================================================>
# Load packages, clear memory,
rm(list=ls())
library(MASS)
library(energy)
library(pbapply)
library(estrpac)
library(ivreg)
library(sandwich)
library(parallel)
library(quantreg)
library(latex2exp)
library(triangulr)
#=========================================================================================>
source("ST4_Fonctions.R")
source("ST4_Fonctions_Sim.R")
#=========================================================================================>
#set parameters
theta.0<- c(0.5,-0.5); b = theta.0[1]
R<- 1000
n.vec = c(50,100,200)
cl<- floor(detectCores()/2)
#generate starting values: 
s.dat<- gdat.0a(n=500,R=1,theta.0=theta.0);(strtpar=coef(lm(s.dat[[1]]$Y~s.dat[[1]]$X))[-1])
est.names.0 <- c("MDep","MMD","ESC6","OLS")
#=========================================================================================>


#=========================================================================================>
# DGPs 0: 
gSim(n.vec=n.vec,gdat=gdat.0a,MCfun=MCfun.0,est.names=est.names.0,se="ker",strtpar=strtpar,
     outfile="out_LM_ker_0a.txt",cl=cl,R=R,theta.0 = theta.0)

gSim(n.vec=n.vec,gdat=gdat.0b,MCfun=MCfun.0,est.names=est.names.0,se="ker",strtpar=strtpar,
     outfile="out_LM_ker_0b.txt",cl=cl,R=R,theta.0 = theta.0)
#=========================================================================================>
# DGPs 1: 
gSim(n.vec=n.vec,gdat=gdat.1a,MCfun=MCfun.0,se="ker",strtpar=strtpar,
     outfile="out_LM_ker_1a.txt",cl=cl,R=R,theta.0 = theta.0)

gSim(n.vec=n.vec,gdat=gdat.1b,MCfun=MCfun.0,se="ker",strtpar=strtpar,
     outfile="out_LM_ker_1b.txt",cl=cl,R=R,theta.0 = theta.0)

gSim(n.vec=n.vec,gdat=gdat.1c,MCfun=MCfun.0,se="ker",strtpar=strtpar,
     outfile="out_LM_ker_1c.txt",cl=cl,R=R,theta.0 = theta.0)
#=========================================================================================>
# DGPs 2: 
gSim(n.vec=n.vec,gdat=gdat.2a,MCfun=MCfun.1,se="ker",strtpar=strtpar,
     outfile="out_LM_ker_2a.txt",cl=cl,R=R,theta.0 = theta.0)

gSim(n.vec=n.vec,gdat=gdat.2b,MCfun=MCfun.1,se="ker",strtpar=strtpar,
     outfile="out_LM_ker_2b.txt",cl=cl,R=R,theta.0 = theta.0)
#=========================================================================================>
# DGPs 3: 
gSim(n.vec=n.vec,gdat=gdat.3,MCfun=MCfun.1,se="ker",strtpar=strtpar,
     outfile="out_LM_ker_3.txt",cl=cl,R=R,theta.0 = theta.0)
#=========================================================================================>
