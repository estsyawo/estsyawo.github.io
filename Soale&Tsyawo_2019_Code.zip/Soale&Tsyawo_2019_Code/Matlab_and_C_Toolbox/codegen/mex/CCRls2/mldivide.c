/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * mldivide.c
 *
 * Code generation for function 'mldivide'
 *
 */

/* Include files */
#include <string.h>
#include "mwmathutil.h"
#include "rt_nonfinite.h"
#include "CCRls2.h"
#include "mldivide.h"
#include "CCRls2_emxutil.h"
#include "lusolve.h"
#include "xgeqp3.h"
#include "qrsolve.h"
#include "CCRls2_data.h"
#include "lapacke.h"

/* Function Definitions */
void b_mldivide(const emxArray_real_T *A, const real_T B_data[], const int32_T
                B_size[1], emxArray_real_T *Y)
{
  emxArray_real_T *b_A;
  emxArray_int32_T *jpvt;
  uint32_T unnamed_idx_0;
  int32_T maxmn;
  real_T tau_data[1000];
  int32_T tau_size[1];
  int32_T minmn;
  int32_T rankR;
  real_T tol;
  real_T b_B_data[1000];
  ptrdiff_t nrc_t;
  ptrdiff_t info_t;
  emlrtHeapReferenceStackEnterFcnR2012b(emlrtRootTLSGlobal);
  emxInit_real_T(&b_A, 2, true);
  emxInit_int32_T(&jpvt, 2, true);
  if ((A->size[0] == 0) || (A->size[1] == 0) || (B_size[0] == 0)) {
    unnamed_idx_0 = (uint32_T)A->size[1];
    maxmn = Y->size[0];
    Y->size[0] = (int32_T)unnamed_idx_0;
    emxEnsureCapacity_real_T(Y, maxmn);
    minmn = (int32_T)unnamed_idx_0;
    for (maxmn = 0; maxmn < minmn; maxmn++) {
      Y->data[maxmn] = 0.0;
    }
  } else if (A->size[0] == A->size[1]) {
    lusolve(A, B_data, B_size, tau_data, tau_size);
    maxmn = Y->size[0];
    Y->size[0] = tau_size[0];
    emxEnsureCapacity_real_T(Y, maxmn);
    minmn = tau_size[0];
    for (maxmn = 0; maxmn < minmn; maxmn++) {
      Y->data[maxmn] = tau_data[maxmn];
    }
  } else {
    maxmn = b_A->size[0] * b_A->size[1];
    b_A->size[0] = A->size[0];
    b_A->size[1] = A->size[1];
    emxEnsureCapacity_real_T(b_A, maxmn);
    minmn = A->size[0] * A->size[1];
    for (maxmn = 0; maxmn < minmn; maxmn++) {
      b_A->data[maxmn] = A->data[maxmn];
    }

    b_xgeqp3(b_A, tau_data, tau_size, jpvt);
    rankR = 0;
    if (b_A->size[0] < b_A->size[1]) {
      minmn = b_A->size[0];
      maxmn = b_A->size[1];
    } else {
      minmn = b_A->size[1];
      maxmn = b_A->size[0];
    }

    if (minmn > 0) {
      tol = muDoubleScalarMin(1.4901161193847656E-8, 2.2204460492503131E-15 *
        (real_T)maxmn) * muDoubleScalarAbs(b_A->data[0]);
      while ((rankR < minmn) && (!(muDoubleScalarAbs(b_A->data[rankR + b_A->
                size[0] * rankR]) <= tol))) {
        rankR++;
      }
    }

    if (0 <= B_size[0] - 1) {
      memcpy(&b_B_data[0], &B_data[0], (uint32_T)(B_size[0] * (int32_T)sizeof
              (real_T)));
    }

    minmn = b_A->size[1];
    maxmn = Y->size[0];
    Y->size[0] = minmn;
    emxEnsureCapacity_real_T(Y, maxmn);
    for (maxmn = 0; maxmn < minmn; maxmn++) {
      Y->data[maxmn] = 0.0;
    }

    minmn = muIntScalarMin_sint32(b_A->size[0], b_A->size[1]);
    if ((b_A->size[0] != 0) && (b_A->size[1] != 0)) {
      nrc_t = (ptrdiff_t)B_size[0];
      info_t = LAPACKE_dormqr(102, 'L', 'T', nrc_t, (ptrdiff_t)1, (ptrdiff_t)
        minmn, &b_A->data[0], (ptrdiff_t)b_A->size[0], &tau_data[0], &b_B_data[0],
        nrc_t);
      if ((int32_T)info_t != 0) {
        minmn = B_size[0];
        for (maxmn = 0; maxmn < minmn; maxmn++) {
          b_B_data[maxmn] = rtNaN;
        }
      }
    }

    for (minmn = 0; minmn < rankR; minmn++) {
      Y->data[jpvt->data[minmn] - 1] = b_B_data[minmn];
    }

    for (maxmn = rankR; maxmn >= 1; maxmn--) {
      Y->data[jpvt->data[maxmn - 1] - 1] /= b_A->data[(maxmn + b_A->size[0] *
        (maxmn - 1)) - 1];
      for (minmn = 0; minmn <= maxmn - 2; minmn++) {
        Y->data[jpvt->data[minmn] - 1] -= Y->data[jpvt->data[maxmn - 1] - 1] *
          b_A->data[minmn + b_A->size[0] * (maxmn - 1)];
      }
    }
  }

  emxFree_int32_T(&jpvt);
  emxFree_real_T(&b_A);
  emlrtHeapReferenceStackLeaveFcnR2012b(emlrtRootTLSGlobal);
}

void mldivide(const emxArray_real_T *A, const real_T B_data[], const int32_T
              B_size[1], real_T Y[2])
{
  int32_T r1;
  int32_T r2;
  real_T a21;
  if ((A->size[0] == 0) || (B_size[0] == 0)) {
    Y[0] = 0.0;
    Y[1] = 0.0;
  } else if (A->size[0] == 2) {
    if (muDoubleScalarAbs(A->data[1]) > muDoubleScalarAbs(A->data[0])) {
      r1 = 1;
      r2 = 0;
    } else {
      r1 = 0;
      r2 = 1;
    }

    a21 = A->data[r2] / A->data[r1];
    Y[1] = (B_data[r2] - B_data[r1] * a21) / (A->data[r2 + A->size[0]] - a21 *
      A->data[r1 + A->size[0]]);
    Y[0] = (B_data[r1] - Y[1] * A->data[r1 + A->size[0]]) / A->data[r1];
  } else {
    qrsolve(A->data, A->size, B_data, B_size, Y);
  }
}

/* End of code generation (mldivide.c) */
