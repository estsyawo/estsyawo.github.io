function [optk,clus,deltas,BIC] = goldssopt(coefs,Y,X,Xc,a,b)
tol = 1;
[n,~] = size(X);
% function [clus,deltas,RSS] = Xkrun(coefs,Y,X,k)
gr = (sqrt(5) + 1) / 2;
f = @(k) Xkrun(coefs,Y,X,Xc,k); %define function in k
    
    c = ceil(b - (b - a) / gr);
    d = floor(a + (b - a) / gr);
    [clus_c,del_c,RSS_c] = f(c); fc = double(n*log(RSS_c/n) + c*log(n));
    [clus_d,del_d,RSS_d] = f(d); fd = double(n*log(RSS_d/n) + d*log(n));
    
    %% begin while loop
    while abs(c - d) > tol
        if fc < fd
            b = d;
        else
            a = c;
        end % end if
         
    c = ceil(b - (b - a) / gr);
    d = floor(a + (b - a) / gr); 
    [clus_c,del_c,RSS_c] = f(c); fc = double(n*log(RSS_c/n) + c*log(n));
    [clus_d,del_d,RSS_d] = f(d); fd = double(n*log(RSS_d/n) + d*log(n));

    end %end while loop
    if fc<=fd
      optk=c;BIC = double(fc); clus = clus_c; deltas=del_c;  
    else
       optk=d;BIC = double(fd); clus = clus_d; deltas=del_d; 
    end % end if
    
end
    
        