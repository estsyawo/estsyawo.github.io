function [k, betas,clus] = CCRl_clus(Y,X,Xc,frql,kp,kmin,kmax,rpt)

%% Info:
% Author: Emmanuel Selorm Tsyawo
% Date: Feb. 23, 2019

% Linear Clustered covariate regression with BIC criterion
% Function: CCRl_clus(Y,X,frql,kmin,kmax)
% Arguments:
%         Y - outcome variable, length n
%         X - n x p matrix of covariates to be clustered (should not include 1s for intercept)
%         Xc - matrix of lXc covariates of interest not to be clustered, eg.
%         treamtment variable(s).
%         frql - number of iterations after which to search anew for the
%         number of clusters. Recommended: a multiple of p
%         kp - the fraction in (0,1) of n that constitutes a partition
%         [kmin,kmax] - the interval over which to search for the optimal
%         number of clusters. Should be kmin >= 2 and kmax<=
%         min(floor(kp*n),p) where kp in (0,1). 
%         rpt - logical for randomising partition assignment of columns in
%         X
% Output: 
%         k - optimal number of clusters
%         betas - the parameter estimates (length p + lXc + 1). The first
%         element is the intercept term.
%         clus - cluster assignments of covariate elements


%% 1 Initialise parameters
[n,p]=size(X); tol = 1e-06; az = 1e-20;
[~,lXc] = size(Xc);
bet_vec = zeros(1,p); % vector to store parameters, excludes intercept
bet_vecv= zeros(1,p);%: vector of same length as bet_vec that keeps varied
Onez = ones(n,1); % for intercepts

slc = floor(kp*n); %maximum size of a local covariate clusters.
if (slc > p)
    error('Error: use this function for p >> kp*n'); %warning, 
end
lcls = ceil((1:p)./slc); %partition covarites into clusters
nlcls = max(lcls); % number of partitions
if(rpt)
   lcls(1:p)=lcls(randsample(p,p)); 
end

l=uint64(0); % initialise counter

% initialise parameters
betc = zeros(1,(lXc+1)); %initialise intercept and coefficients of on Xc
X0 = ones(n,2); % for the initialisation of coefficients
for j=1:p
   X0(:,2) = X(:,j); 
   coef0 = X0\Y;
   bet_vec(j) = coef0(2) ;
end

% initial search for optimal number of clusters k and clustering
bet_vecv(1:p) = bet_vec(1:p); % pass bet_vec to bet_vecv
[k,clus,deltas,BIC] = goldssopt(bet_vecv',Y,X,Xc,kmin,kmax);
betc(1:(lXc+1)) = deltas(1:(lXc+1)); % extract intercept and coefficients on Xc
del = deltas((lXc+2):end);
for j=1:p
   bet_vec(j)=del(clus(j)); %update betas with deltas
end

val0 = double(BIC); val1=val0; val1=val1 - 0.9*abs(val0); dev = double(10.0);


%% 2 Commence main iteration until convergence
while 1
    % iterate and identify partition
     l = l+1; IND = l - (ceil(l/nlcls)-1)*nlcls; %identify partition index
     IDls = lcls ==IND; % identify covariates in active partition
     ngIDLS = lcls ~=IND; % identify covariates not in active partition
     XB = X(:,ngIDLS)*bet_vec(ngIDLS)'; % linear combination of inactive partion
     Xl = X(:,IDls); % extract covariates in active partition
     XX = [Onez Xc Xl XB]; %make room for intercept term
     coefs = XX\Y; %compute coefficients
    %sprintf('iter = %.0f ',l)
     %% print progress
     if(mod(l,frql)~=0)
     bet_vec(IDls)=coefs((lXc+2):(end-1)); % update parameters
     bet_vecv(IDls) = bet_vec(IDls); %update bet_vecv
     betc(1:(lXc+1)) = coefs(1:(lXc+1)); % extract intercept and coefficients on Xc
     bet_vec(ngIDLS) =  bet_vec(ngIDLS) * coefs(end); %correction for inactive partition
     [clus,deltas,RSS] = Xkrun(bet_vec',Y,X,Xc,k);
     del = deltas((lXc+2):end);
     for j=1:p
        bet_vec(j)=del(clus(j)); %update betas with deltas
     end
      val1 = double(n*log(RSS/n) + k*log(n)); %compute BIC
          else
     %sprintf('iter = %.0f fval = %f and dev = %f',l,val1,dev)
     sprintf('iter = %u fval = %0.5f and dev = %0.5f',uint64(l),double(val1),double(dev));
     %sprintf('fval = %f and dev = %f',val1,dev)
     [k,clus,deltas,BIC] = goldssopt(bet_vecv',Y,X,Xc,kmin,kmax);
     betc(1:(lXc+1)) = deltas(1:(lXc+1)); % extract intercept and coefficients on Xc
     del = deltas((lXc+2):end);
     for j=1:p
        bet_vec(j)=del(clus(j)); %update betas with deltas
     end
       val1 = double(BIC);
     end %end if
     
     dev = (val0-val1)/(az+abs(val0)); 
     
     %% 3 check for convergence
     if(dev<=tol)
         break;
     end
  
     %% 4 update value
     val0 = val1;
end % end while
betas = [betc bet_vec]; %concatenate final parameter estimates
end % end function
