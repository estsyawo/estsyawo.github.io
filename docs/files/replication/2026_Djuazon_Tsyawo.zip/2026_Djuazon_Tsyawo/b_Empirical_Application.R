#=========================================================================================>
# Authors: Nelly Charlotte Djuazon & Emmanuel Selorm Tsyawo
# Project: Quantile and Distribution Treatment Effects on the Treated with Possibly 
#          Non-Continuous Outcomes
# Date began:   Apr. 13, 2023
# Last Update:  March 28, 2026
# Place:        Tuscaloosa, AL
#=========================================================================================>
# Comment: Estimates the empirical DTT and QTT results under the uniform specification and 
#          saves the corresponding figures and tables.
#=========================================================================================>
# Load packages, clear memonry,

rm(list=ls()) #clear memory

#set working directory
get_script_dir <- function() {
  cmd_args <- commandArgs(trailingOnly = FALSE)
  file_arg <- grep("^--file=", cmd_args, value = TRUE)
  if (length(file_arg) > 0) {
    p <- sub("^--file=", "", file_arg[1])
    p <- gsub("~\\+~", " ", p)
    return(dirname(normalizePath(p, winslash = "/", mustWork = FALSE)))
  }
  if (requireNamespace("rstudioapi", quietly = TRUE)) {
    p <- tryCatch(rstudioapi::getActiveDocumentContext()$path, error = function(e) "")
    if (nzchar(p)) return(dirname(p))
  }
  getwd()
}

setwd(get_script_dir()) # set working directory path to source file when available
#=========================================================================================>
# Load packages and source functions
output_dir <- "output"
if (!dir.exists(output_dir)) dir.create(output_dir, recursive = TRUE)

library(haven)
library(plm)
library(sandwich)
source("Fonctions2.R") #source functions for use in main text
library(pbapply)
library(dplyr)
library(ggplot2)
library(purrr)
library(latex2exp)

#=========================================================================================>
# Load data and define tuning parameters
list.files()

donnees = read_dta("MonthlyPanel_tab3ABC.dta")
B=999 #number of bootstrap samples
Alpha = .10 #10% confidence bands
#=========================================================================================>
# Data exploration
#=========================================================================================>
table(donnees$observ) #balanced panel
names(donnees)
length(unique(donnees$mes)) # 9 months observed
unique(donnees$mes) #mes is Month in Spanish
u.obs<- unique(donnees$observ) #unique observations
(N=length(u.obs)) # 876 neighbourhoods (unique cross-sectional units)
#treatment occurs in July, month 7
#=========================================================================================>
# Defining treatment
#=========================================================================================>
# Defining treatment variables (D)
#institu1 : dummy within the same block;
#institu3 : one block away
#cuad2 : two blocks away
donnees$treat = donnees$institu1
table(donnees$treat)/9
# 0   1 
# 839  37

#=========================================================================================>
# Computing DTT and QTT objects
#=========================================================================================>

table(donnees$totrob) #upper bound grid at 1.0 (0.1% of obs)
#generate grid points on the support of the outcome
ygrid = unique(donnees$totrob)
(ygrid = sort(ygrid[ygrid <=1.0]))# truncate of the support at 1.0
ecdfY=ecdf(donnees$totrob) # getting an empirical CDF for the entire data set
if (interactive()) {
  plot(ecdfY, verticals = FALSE, do.points = FALSE) #plotting the ecdf
}

# ECDF at ygrid; use to generate taus
(taus = round(ecdfY(ygrid),3))
# [1] 0.799 0.930 0.956 0.959 0.990 0.997 0.999


#April through December; treatment occurs in July, month 7
pre_treat_mes<- 4:6; nTcal = length(pre_treat_mes)
post_treat_mes<- 8:12; nT = length(post_treat_mes)

#this function computes DFs, DTTs for all pre-post pairs and averages over them
# returns the weighted DF, weighted counterfactual DF, and weighted DTT
output_suffix <- "_unif"

# compute DFs and DTT on the full sample
w_DF_DTT<- w.DTT.QTT(daten=donnees,pre_treat_mes=pre_treat_mes,post_treat_mes=post_treat_mes,
          G="uniform",ygrid=ygrid,taus=taus)
cbind(ygrid,w_DF_DTT)

# ygrid     F11_1     F01_1        DTT
# 1  0.00 0.8972973 0.7874497 0.10984763
# 2  0.25 0.9891892 0.8959851 0.09320405
# 3  0.50 0.9891892 0.9206062 0.06858304
# 4  0.75 0.9891892 0.9233378 0.06585142
# 5  1.00 0.9945946 0.9865161 0.00807850
#=========================================================================================>
# Empirical bootstrap of QTT and DTT
#=========================================================================================>

#bootstrap over unique observations: u.obs

set.seed(0)
boot.unique<- matrix(sample.int(N, N * B, replace=TRUE), N, B)
idx_by_unit <- split(seq_len(nrow(donnees)), donnees$observ)
id.b<- matrix(NA_integer_, nrow(donnees), B)
for(j in 1:ncol(id.b)){
  sampled_units <- u.obs[boot.unique[,j]]
  id.b[,j] <- unlist(idx_by_unit[as.character(sampled_units)], use.names = FALSE)
}
#####################################################

list.w_DF_DTT<- w.QTT_DTT.boot(daten=donnees,G="uniform",pre_treat_mes=pre_treat_mes,
                                          post_treat_mes=post_treat_mes,ygrid=ygrid,taus=taus,B=B,
                               id.b=id.b)
#=========================================================================================>
# Construct Boot Matrix for DFs and DTT
b.F11_1.mat<- b.F01_1.mat<- b.DTT.mat<- matrix(NA,length(taus),B)
for (l in 1:B) {
  b.F11_1.mat[,l]<- list.w_DF_DTT[[l]][,1]
  b.F01_1.mat[,l]<- list.w_DF_DTT[[l]][,2]
  b.DTT.mat[,l]<- list.w_DF_DTT[[l]][,3]
}
# compute Band.Fn.Objs
BFObjs.DTT = Band.Fn.Objs(Fn=w_DF_DTT$DTT,Boot.Fn = b.DTT.mat,n=N)
# Compute Uniform Confidence Bands
UBand.DTT<- UBand.Fn(Fn=c(w_DF_DTT$DTT),BFObjs=BFObjs.DTT,
                     alpha=Alpha,n=N,DQTT.fun=T)
# DTT with uniform confidence bands and robust pointwise confidence intervals
PBand.DTT<- PBand.Fn(Fn=c(w_DF_DTT$DTT),BFObjs=BFObjs.DTT,
                     alpha=Alpha,n=N)
(res = cbind(ygrid=ygrid,DTT=w_DF_DTT[,3],UBand.DTT,PBand.DTT)) 
(res=as.data.frame(res))
all(res$DTT<= res$UB.Fn) & all(res$DTT>= res$LB.Fn)
#plot DTT
plot.DTT(res,fig.name=file.path(output_dir, paste0("DTT", output_suffix, ".pdf")))
#=========================================================================================>

#The DF bands needed for Uniform Bands on QTT need to have joint coverage
# compute Band.Fn.Objs

apply(rbind(b.F11_1.mat,b.F01_1.mat), 1, IQR)

BFObjs.DFs = Band.Fn.Objs(Fn=c(w_DF_DTT$F11_1,w_DF_DTT$F01_1),
                          Boot.Fn = rbind(b.F11_1.mat,b.F01_1.mat),n=N)
# Compute Uniform Confidence Bands
UBand.DFs<- UBand.Fn(Fn=c(w_DF_DTT$F11_1,w_DF_DTT$F01_1),BFObjs=BFObjs.DFs,
                     alpha=Alpha,n=N,DQTT.fun=T)

id.1<- 1:length(ygrid)

res2<- data.frame(ygrid,w_DF_DTT$F11_1,UBand.DFs[id.1,],w_DF_DTT$F01_1,UBand.DFs[-id.1,])
names(res2)<- c("ygrid","F11_1","F11_1.LB","F11_1.UB","F01_1","F01_1.LB","F01_1.UB")
#impose support restrictions on DF bands >=0 and <= 1
res2$F11_1.LB[res2$F11_1.LB<0]=0
res2$F11_1.UB[res2$F11_1.UB>1]=1.0
res2$F01_1.LB[res2$F01_1.LB<0]=0
res2$F01_1.UB[res2$F01_1.UB>1]=1.0

plot2.QTT(res2,fig.name=file.path(output_dir, paste0("QTT", output_suffix, ".pdf")))
#=========================================================================================>
# Tables for DTT and QTT (uniform bands) for LaTeX paste
#=========================================================================================>

# DTT table
DTT_table <- data.frame(
  ygrid = ygrid,
  DTT = w_DF_DTT$DTT,
  DTT_LB = UBand.DTT[, 1],
  DTT_UB = UBand.DTT[, 2],
  DTT_PW_LB = PBand.DTT[, 1],
  DTT_PW_UB = PBand.DTT[, 2],
  DTT_SE = PBand.DTT[, 3]
)

# QTT table (Minkowski difference bands)
sanitize_df <- function(F){
  pmin(1, pmax(0, cummax(as.numeric(F))))
}
q_from_df <- function(tau, y, F){
  F <- sanitize_df(F)
  sapply(tau, function(tt){
    idx <- which(F >= tt)[1]
    if (is.na(idx)) max(y) else y[idx]
  })
}

F11 <- sanitize_df(res2$F11_1)
F11LB <- sanitize_df(res2$F11_1.LB)
F11UB <- sanitize_df(res2$F11_1.UB)
F01 <- sanitize_df(res2$F01_1)
F01LB <- sanitize_df(res2$F01_1.LB)
F01UB <- sanitize_df(res2$F01_1.UB)

tau.grid <- sort(unique(c(0, 1, F11, F11LB, F11UB, F01, F01LB, F01UB)))
tau.grid <- tau.grid[tau.grid >= 0 & tau.grid <= 1]
if (length(tau.grid) < 2) {
  tau.grid <- seq(0.01, 0.99, length.out = 200)
}

Q11 <- q_from_df(tau.grid, ygrid, F11)
Q01 <- q_from_df(tau.grid, ygrid, F01)
Q11_LB <- q_from_df(tau.grid, ygrid, F11UB) # U1^{-1}
Q11_UB <- q_from_df(tau.grid, ygrid, F11LB) # L1^{-1}
Q01_LB <- q_from_df(tau.grid, ygrid, F01UB) # U0^{-1}
Q01_UB <- q_from_df(tau.grid, ygrid, F01LB) # L0^{-1}

QTT <- Q11 - Q01
QTT_LB <- Q11_LB - Q01_UB
QTT_UB <- Q11_UB - Q01_LB

QTT_table <- data.frame(
  tau = tau.grid,
  QTT = QTT,
  QTT_LB = QTT_LB,
  QTT_UB = QTT_UB
)

out_file <- file.path(output_dir, paste0("DTT_QTT_tables", output_suffix, ".txt"))
if (file.exists(out_file)) file.remove(out_file)
writeLines(c(
  "DTT table (uniform bands):",
  "columns: ygrid, DTT, DTT_LB, DTT_UB, DTT_PW_LB, DTT_PW_UB, DTT_SE"
), out_file)
write.table(DTT_table, file = out_file, append = TRUE, row.names = FALSE, col.names = FALSE)

cat("\nQTT table (Minkowski bands):\n", file = out_file, append = TRUE)
cat("columns: tau, QTT, QTT_LB, QTT_UB\n", file = out_file, append = TRUE)
write.table(QTT_table, file = out_file, append = TRUE, row.names = FALSE, col.names = FALSE)
#=========================================================================================>

# #=============================================================================>
# Specification/identification tests for equality of pre-treatment F01_1 curves
# Build matrix of F01_1 across each pre-treatment month
F01_1_mat <- sapply(pre_treat_mes, function(m) {
  w.DTT.QTT(daten = donnees, pre_treat_mes = m, post_treat_mes = post_treat_mes,
            G = "uniform", ygrid = ygrid, taus = taus)$F01_1
})
colnames(F01_1_mat) <- paste0("pre_", pre_treat_mes)

# Use empirical weights dHhat from taus
wts <- c(taus[1], diff(taus))
tests <- functional_overid_tests(Fmat = F01_1_mat, weights = wts, n = N)

cat("\nPre-treatment equality tests (F01_1 curves):\n")
cat("CvM_n =", tests$CvM, "\n") # CvM_n = 14.25028
cat("KS_n  =", tests$KS, "\n") # KS_n  = 3.246426 

boot_tests <- functional_overid_boot(
  daten = donnees,
  pre_treat_mes = pre_treat_mes,
  post_treat_mes = post_treat_mes,
  G = "uniform",
  ygrid = ygrid,
  taus = taus,
  B = B,
  id.b = id.b,
  n = N,
  weights = wts
)

pval_CvM <- (1+sum(boot_tests$boot_CvM >= tests$CvM))/(B+1)
pval_KS <- (1+sum(boot_tests$boot_KS >= tests$KS))/(B+1)

cat("CvM bootstrap p-value =", pval_CvM, "\n") # CvM bootstrap p-value = 0.489
cat("KS bootstrap p-value  =", pval_KS, "\n") # KS bootstrap p-value  = 0.527

# #=============================================================================>
