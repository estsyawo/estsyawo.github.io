# Output Map

This project writes generated tables, logs, and figures to the `output/` sub-folder.

## R Files And Their Outputs

| R file | Output written to `output/` |
| --- | --- |
| `File_0_Main.R` | End-to-end runner. Writes `out_2a_Empirical.txt` and `out_2b_Empirical_More.txt` by sinking the console output of the two empirical scripts. Also triggers all outputs produced by the sourced scripts below. |
| `File_0_Fonctions.R` | Helper file. No standalone output when sourced by itself, but it provides the writers used by other scripts: simulation summary `.txt` files, power-curve `.png` files, and LaTeX-style table `.txt` files. |
| `File_1_PT_Illus.R` | `out_PT_Illus_5.png`, `out_PT_Illus_5_b.png`, `out_PT_Illus_25.png`, `out_PT_Illus_25_b.png`, `out_PT_Illus_n_5_50.png` |
| `File_2a_Empirical.R` | `out_GDP_per_Capita.png`, `out_logGDP_per_Capita.png`, `tab.empirical.txt` |
| `File_2b_Empirical_More.R` | `tab.empirical2.txt` |
| `File_3a_Sim.R` | `out_DGP_1.txt`, `out_DGP_2.txt`, `out_DGP_3.txt`, `out_DGP_4A.txt`, `out_DGP_4B.txt`, `out_DGP_5.txt`, `out_DGP_6.txt`, `out_DGP_7.txt`, `out_DGP_8.txt`, `out_DGP_9.txt`, `out_DGP_10.txt` |
| `File_3b_Sim.R` | `out_DGPb_1.txt`, `out_DGPb_2.txt`, `out_DGPb_3.txt`, `out_DGPb_4A.txt`, `out_DGPb_4B.txt`, `out_DGPb_5.txt`, `out_DGPb_6.txt`, `out_DGPb_7.txt`, `out_DGPb_8.txt`, `out_DGPb_9.txt`, `out_DGPb_10.txt` |
| `File_3c_Sim.R` | Power-curve figures: `pow_DGP_1_10.png`, `pow_DGP_1_05.png`, `pow_DGP_1_01.png`, ..., `pow_DGP_10_10.png`, `pow_DGP_10_05.png`, `pow_DGP_10_01.png` including `pow_DGP_4A_*` and `pow_DGP_4B_*` |
| `File_3d_Sim.R` | Identification-test power figures: `test_DGP_1_10.png`, `test_DGP_1_05.png`, `test_DGP_1_01.png`, `test_DGP_2_10.png`, `test_DGP_2_05.png`, `test_DGP_2_01.png`, `test_DGP_3_10.png`, `test_DGP_3_05.png`, `test_DGP_3_01.png` |
| `File_3e_Sim.R` | `out_DGPe_1.txt`, `out_DGPe_2.txt`, `out_DGPe_3.txt`, `out_DGPe_4A.txt`, `out_DGPe_4B.txt`, `out_DGPe_5.txt`, `out_DGPe_6.txt`, `out_DGPe_7.txt`, `out_DGPe_8.txt`, `out_DGPe_9.txt`, `out_DGPe_10.txt` |

## Notes

- Scripts that use `output_path(...)` automatically write into `output/`.
- `File_2a_Empirical.R` and `File_2b_Empirical_More.R` also print to the console; when run through `File_0_Main.R`, that console output is captured in `out_2a_Empirical.txt` and `out_2b_Empirical_More.txt`.
- `File_0_Fonctions.R` is the shared infrastructure file; it does not need to be run directly to produce outputs.
