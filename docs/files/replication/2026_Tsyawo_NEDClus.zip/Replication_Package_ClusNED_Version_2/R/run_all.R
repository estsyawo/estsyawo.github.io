#=====================================================
# Main simulation runner
# Purpose:
#   Run the manuscript-facing Monte Carlo designs for both simulation arms reported
#   in CLT_U_Stats.tex, Section Sect:Simulations, and write the current summary
#   grids and manuscript table text files.
# Inputs:
#   None when executed as a script; design values are set below.
# Outputs:
#   Timestamped CSV and .txt files in output/.
# Side effects:
#   Clears the workspace, sources setup and simulation libraries, may launch a
#   PSOCK cluster, prints progress, and writes output files.
#=====================================================

# Manuscript-facing note:
#   This is the main simulation entry point. It refreshes the clustered and
#   weak-dependence Monte Carlo outputs discussed in `Sect:Simulations`.

rm(list = ls())
start.time <- Sys.time()

#=====================================================
# Local path helper
#=====================================================

# Purpose:
#   Recover the directory containing this script across command-line and IDE use.
# Inputs:
#   None.
# Outputs:
#   Character scalar path.
# Side effects:
#   None.
script_dir <- function() {
  args <- commandArgs(trailingOnly = FALSE)
  file_arg <- "--file="
  path <- sub(file_arg, "", args[startsWith(args, file_arg)][1])
  if (!is.na(path) && file.exists(path)) return(dirname(normalizePath(path)))
  if (requireNamespace("rstudioapi", quietly = TRUE) && rstudioapi::isAvailable()) {
    active_path <- rstudioapi::getActiveDocumentContext()$path
    if (!is.null(active_path) && nzchar(active_path)) return(dirname(normalizePath(active_path)))
  }
  getwd()
}

setwd(script_dir())

source("00_setup.R")
source("clustered_gini_sim.R")
source("ned_rank_correlation_sim.R")

run_label <- format(Sys.time(), "%Y%m%d_%H%M%S")
cl <- make_default_sim_cluster()
if (inherits(cl, "cluster")) {
  on.exit(parallel::stopCluster(cl), add = TRUE)
}

#=====================================================
# Clustered-arm design
#=====================================================

cluster_G_grid <- c(200, 400, 600)
cluster_reps <- 2000
cluster_rho_grid <- c(0.00, 0.25, 0.50)
cluster_beta <- 0.15
cluster_cap_multiplier <- 4
run_cluster_arm <- TRUE

#=====================================================
# Weak-dependence-arm design
#=====================================================

ned_n_grid <- c(400, 800, 1200)
ned_reps <- cluster_reps
ned_alpha_grid <- cluster_rho_grid
ned_bandwidth <- NULL

#=====================================================
# Execute clustered arm
#=====================================================

if (run_cluster_arm) {
  cat("\n\n==================== Clustered Gini / third L-moment arm ====================\n\n")
  cluster_prefix <- sprintf("clustered_gini_l3_reps%s_%s", cluster_reps, run_label)
  cluster_summary_grid <- run_clustered_gini_l3_grid(
    Gs = cluster_G_grid,
    rhos = cluster_rho_grid,
    n_reps = cluster_reps,
    seed = 20260803L,
    cl = cl,
    output_prefix = cluster_prefix,
    beta = cluster_beta,
    cap_multiplier = cluster_cap_multiplier
  )
  cluster_table_file <- file.path(sim_output_dir(), paste0(cluster_prefix, "_table.txt"))
  write_clustered_gini_l3_latex_table(
    cluster_summary_grid,
    cluster_table_file
  )
  cat(sprintf("Wrote clustered table text: %s\n", cluster_table_file))
}

#=====================================================
# Execute weak-dependence arm
#=====================================================

cat("\n\n==================== NED / Kendall-Spearman rank arm ====================\n\n")
ned_rows <- list()
ned_idx <- 1L
for (n_target in ned_n_grid) {
  ned_rows[[ned_idx]] <- run_ned_rank_calibrated_grid(
    n = n_target,
    rhos = ned_alpha_grid,
    n_reps = ned_reps,
    seed = 20260728L + n_target,
    bandwidth = ned_bandwidth,
    cl = cl,
    output_prefix = NULL
  )
  ned_idx <- ned_idx + 1L
}
ned_summary_grid <- do.call(rbind, ned_rows)
row.names(ned_summary_grid) <- NULL
ned_prefix <- sprintf("ned_rank_reps%s_%s", ned_reps, run_label)
write_sim_table(paste0(ned_prefix, "_summary_grid"), ned_summary_grid)
ned_table_file <- file.path(sim_output_dir(), paste0(ned_prefix, "_table.txt"))
write_ned_rank_latex_table(ned_summary_grid, ned_table_file)
cat(sprintf("Wrote NED table text: %s\n", ned_table_file))

#=====================================================
# Elapsed time
#=====================================================

end.time <- Sys.time()
cat("\nElapsed time:\n")
print(end.time - start.time)
